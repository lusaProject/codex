package main

import (
	"flag"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	gateway "rtsp-webcodecs-gateway/rtsp-gateway"
)

const defaultStreamURL = "rtsp://172.20.173.132/live/test"
const defaultCameraPublishURL = "rtsp://172.20.173.132:554/live/camera1"

func main() {
	addr := flag.String("addr", ":18080", "HTTP/WebSocket listen address")
	webDir := flag.String("web-dir", "web-player", "directory that contains the H5 player")
	defaultRTSPURL := flag.String("rtsp-url", defaultRTSPURL(), "default RTSP URL when the websocket url parameter is omitted")
	defaultPublishURL := flag.String("publish-url", defaultPublishURL(), "default RTSP URL used by the browser camera publisher")
	defaultPublishVideoCodec := flag.String("publish-video-codec", defaultPublishVideoCodec(), "default browser publisher video codec: h264 or h265")
	defaultPublishAudioCodec := flag.String("publish-audio-codec", defaultPublishAudioCodec(), "default browser publisher audio codec: aac, pcma/g711a, pcmu/g711u, or none")
	flag.Parse()

	publishVideoCodec, err := gateway.NormalizePublishVideoCodec(*defaultPublishVideoCodec)
	if err != nil {
		log.Fatalf("invalid -publish-video-codec: %v", err)
	}
	publishAudioCodec, err := gateway.NormalizePublishAudioCodec(*defaultPublishAudioCodec)
	if err != nil {
		log.Fatalf("invalid -publish-audio-codec: %v", err)
	}

	logger := log.New(os.Stdout, "[rtsp-gateway] ", log.LstdFlags)
	server := &gateway.Server{
		Logger:                   logger,
		DefaultRTSPURL:           *defaultRTSPURL,
		DefaultPublishURL:        *defaultPublishURL,
		DefaultPublishVideoCodec: publishVideoCodec,
		DefaultPublishAudioCodec: publishAudioCodec,
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/rtsp", server.HandleRTSPWebSocket)
	mux.HandleFunc("/publish", server.HandlePublishWebSocket)
	mux.HandleFunc("/config", server.HandleConfig)
	mux.Handle("/", noCache(http.FileServer(http.Dir(filepath.Clean(*webDir)))))

	httpServer := &http.Server{
		Addr:              *addr,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	logger.Printf("listening on http://%s", printableAddr(*addr))
	logger.Printf("serving player from %s", filepath.Clean(*webDir))
	logger.Printf("default publisher codecs: video=%s audio=%s", publishVideoCodec, publishAudioCodec)

	if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		logger.Fatalf("server failed: %v", err)
	}
}

func printableAddr(addr string) string {
	if addr == "" {
		return "127.0.0.1:80"
	}
	if strings.HasPrefix(addr, ":") {
		return "127.0.0.1" + addr
	}
	return addr
}

func defaultRTSPURL() string {
	if value := strings.TrimSpace(os.Getenv("RTSP_URL")); value != "" {
		return value
	}
	return defaultStreamURL
}

func defaultPublishURL() string {
	if value := strings.TrimSpace(os.Getenv("RTSP_PUBLISH_URL")); value != "" {
		return value
	}
	return defaultCameraPublishURL
}

func defaultPublishVideoCodec() string {
	if value := strings.TrimSpace(os.Getenv("RTSP_PUBLISH_VIDEO_CODEC")); value != "" {
		return value
	}
	return "h264"
}

func defaultPublishAudioCodec() string {
	if value := strings.TrimSpace(os.Getenv("RTSP_PUBLISH_AUDIO_CODEC")); value != "" {
		return value
	}
	return "aac"
}

func noCache(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		next.ServeHTTP(w, r)
	})
}
