import {
  CODEC_AAC,
  CODEC_PCMA,
  CODEC_PCMU,
  FRAME_TYPE_AUDIO,
  copyArrayBuffer,
  hex,
  parseG711AudioPayload,
  parseMPEG4AudioPayload,
  parsePacket
} from "./media-packet.js";

let audioDecoder;
let audioConfigured = false;
let audioConfigKey = "";
let audioFrames = 0;
let audioUnsupportedNotified = false;
let audioBatch;
let audioFlushTimer;

const MAX_AUDIO_DECODE_QUEUE = 32;
const AUDIO_BATCH_FRAMES = 2048;
const AUDIO_BATCH_TIMEOUT_MS = 20;

self.onmessage = async event => {
  const msg = event.data;

  switch (msg.type) {
    case "packet":
      try {
        await handleAudioPacket(parsePacket(msg.buffer));
      } catch (err) {
        self.postMessage({ type: "audio-status", text: err.message });
      }
      break;
    case "reset":
      resetAudioState();
      break;
    default:
      break;
  }
};

async function handleAudioPacket(packet) {
  if (packet.frameType !== FRAME_TYPE_AUDIO) {
    return;
  }

  if (packet.codec === CODEC_PCMU || packet.codec === CODEC_PCMA) {
    handleG711Packet(packet);
    return;
  }

  if (packet.codec !== CODEC_AAC) {
    return;
  }

  if (!("AudioDecoder" in self)) {
    if (!audioUnsupportedNotified) {
      audioUnsupportedNotified = true;
      self.postMessage({ type: "audio-status", text: "AudioDecoder unavailable" });
    }
    return;
  }

  const audio = parseMPEG4AudioPayload(packet.payload);
  const configKey = makeAudioConfigKey(audio);
  if (!audioConfigured || audioConfigKey !== configKey) {
    await configureAudioDecoder(audio, configKey);
  }

  if (!audioDecoder || audioDecoder.decodeQueueSize >= MAX_AUDIO_DECODE_QUEUE) {
    return;
  }

  audioDecoder.decode(new EncodedAudioChunk({
    type: "key",
    timestamp: packet.timestampUs,
    duration: Math.round(1024 * 1_000_000 / audio.sampleRate),
    data: audio.data
  }));
}

function handleG711Packet(packet) {
  const audio = parseG711AudioPayload(packet.payload);
  const codec = packet.codec === CODEC_PCMU ? "PCMU" : "PCMA";
  const configKey = `${codec}/${audio.sampleRate}/${audio.channels}`;

  if (!audioConfigured || audioConfigKey !== configKey || audioDecoder) {
    resetAudioDecoder();
    audioConfigured = true;
    audioConfigKey = configKey;
    self.postMessage({
      type: "audio-configured",
      codec,
      sampleRate: audio.sampleRate,
      channels: audio.channels
    });
  }

  const frames = Math.floor(audio.data.byteLength / audio.channels);
  if (frames <= 0) {
    return;
  }

  const channelSamples = Array.from({ length: audio.channels }, () => new Float32Array(frames));
  for (let frame = 0; frame < frames; frame += 1) {
    for (let channel = 0; channel < audio.channels; channel += 1) {
      const sample = audio.data[(frame * audio.channels) + channel];
      channelSamples[channel][frame] = packet.codec === CODEC_PCMU
        ? decodeMuLaw(sample)
        : decodeALaw(sample);
    }
  }

  audioFrames += frames;

  const channelData = channelSamples.map(samples => samples.buffer);
  self.postMessage({
    type: "audio",
    sampleRate: audio.sampleRate,
    channels: audio.channels,
    frames,
    totalFrames: audioFrames,
    channelData
  }, channelData);
}

function decodeMuLaw(sample) {
  const value = (~sample) & 0xff;
  const magnitude = ((((value & 0x0f) << 3) + 0x84) << ((value & 0x70) >> 4)) - 0x84;
  return clampSample((value & 0x80) ? -magnitude : magnitude);
}

function decodeALaw(sample) {
  const value = sample ^ 0x55;
  let magnitude = value & 0x0f;
  const exponent = (value & 0x70) >> 4;

  if (exponent !== 0) {
    magnitude = ((magnitude * 2) + 1 + 32) << (exponent + 2);
  } else {
    magnitude = ((magnitude * 2) + 1) << 3;
  }

  return clampSample((value & 0x80) ? magnitude : -magnitude);
}

function clampSample(sample) {
  if (!Number.isFinite(sample)) {
    return 0;
  }
  return Math.max(-1, Math.min(1, sample / 32768));
}

function makeAudioConfigKey(audio) {
  return [
    audio.objectType,
    audio.sampleRate,
    audio.channels,
    Array.from(audio.description, hex).join("")
  ].join("/");
}

async function configureAudioDecoder(audio, configKey) {
  resetAudioDecoder();

  const codec = `mp4a.40.${audio.objectType}`;
  const config = {
    codec,
    sampleRate: audio.sampleRate,
    numberOfChannels: audio.channels,
    description: copyArrayBuffer(audio.description)
  };

  const support = await AudioDecoder.isConfigSupported(config);
  if (!support.supported) {
    self.postMessage({ type: "audio-status", text: `${codec} unsupported` });
    return;
  }

  audioDecoder = new AudioDecoder({
    output: audioData => {
      try {
        appendAudioData(audioData);
      } catch (err) {
        self.postMessage({ type: "audio-status", text: err.message });
      } finally {
        audioData.close();
      }
    },
    error: err => {
      self.postMessage({ type: "audio-status", text: err.message });
      resetAudioDecoder();
    }
  });

  audioDecoder.configure(config);
  audioConfigured = true;
  audioConfigKey = configKey;
  self.postMessage({
    type: "audio-configured",
    codec,
    sampleRate: audio.sampleRate,
    channels: audio.channels
  });
}

function resetAudioState() {
  audioFrames = 0;
  audioUnsupportedNotified = false;
  resetAudioDecoder();
}

function resetAudioDecoder() {
  audioConfigured = false;
  audioConfigKey = "";
  clearAudioBatch();
  if (audioDecoder) {
    try {
      audioDecoder.close();
    } catch {
      // AudioDecoder can already be closed after a decode error.
    }
    audioDecoder = undefined;
  }
}

function appendAudioData(audioData) {
  const frames = audioData.numberOfFrames;
  const channels = audioData.numberOfChannels;
  const sampleRate = audioData.sampleRate;

  if (
    audioBatch &&
    (audioBatch.sampleRate !== sampleRate || audioBatch.channels !== channels)
  ) {
    flushAudioBatch();
  }

  if (!audioBatch) {
    audioBatch = {
      sampleRate,
      channels,
      frames: 0,
      planes: Array.from({ length: channels }, () => [])
    };
  }

  for (let channel = 0; channel < channels; channel += 1) {
    const samples = new Float32Array(frames);
    audioData.copyTo(samples, {
      format: "f32-planar",
      planeIndex: channel,
      frameCount: frames
    });
    audioBatch.planes[channel].push(samples);
  }

  audioBatch.frames += frames;
  audioFrames += frames;

  if (audioBatch.frames >= AUDIO_BATCH_FRAMES) {
    flushAudioBatch();
  } else {
    scheduleAudioFlush();
  }
}

function scheduleAudioFlush() {
  if (audioFlushTimer) {
    return;
  }

  audioFlushTimer = setTimeout(() => {
    audioFlushTimer = undefined;
    flushAudioBatch();
  }, AUDIO_BATCH_TIMEOUT_MS);
}

function flushAudioBatch() {
  if (!audioBatch || audioBatch.frames === 0) {
    return;
  }

  if (audioFlushTimer) {
    clearTimeout(audioFlushTimer);
    audioFlushTimer = undefined;
  }

  const channelData = [];
  const transfers = [];
  for (let channel = 0; channel < audioBatch.channels; channel += 1) {
    const merged = new Float32Array(audioBatch.frames);
    let offset = 0;
    for (const chunk of audioBatch.planes[channel]) {
      merged.set(chunk, offset);
      offset += chunk.length;
    }
    channelData.push(merged.buffer);
    transfers.push(merged.buffer);
  }

  self.postMessage({
    type: "audio",
    sampleRate: audioBatch.sampleRate,
    channels: audioBatch.channels,
    frames: audioBatch.frames,
    totalFrames: audioFrames,
    channelData
  }, transfers);

  audioBatch = undefined;
}

function clearAudioBatch() {
  if (audioFlushTimer) {
    clearTimeout(audioFlushTimer);
    audioFlushTimer = undefined;
  }
  audioBatch = undefined;
}
