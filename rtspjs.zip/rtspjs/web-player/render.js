import { CameraPublisher } from "./publisher.js";

const canvas = document.getElementById("screen");
const localPreview = document.getElementById("localPreview");
const empty = document.getElementById("empty");
const emptyDetail = document.getElementById("emptyDetail");
const form = document.getElementById("controlForm");
const input = document.getElementById("streamInput");
const connectBtn = document.getElementById("connectBtn");
const disconnectBtn = document.getElementById("disconnectBtn");
const publishForm = document.getElementById("publishForm");
const publishInput = document.getElementById("publishInput");
const publishBtn = document.getElementById("publishBtn");
const stopPublishBtn = document.getElementById("stopPublishBtn");
const stateDot = document.getElementById("stateDot");
const statusText = document.getElementById("statusText");
const renderText = document.getElementById("renderText");
const codecText = document.getElementById("codecText");
const audioText = document.getElementById("audioText");
const audioBufferText = document.getElementById("audioBufferText");
const audioUnderrunText = document.getElementById("audioUnderrunText");
const sizeText = document.getElementById("sizeText");
const frameText = document.getElementById("frameText");
const dropText = document.getElementById("dropText");
const renderFpsText = document.getElementById("renderFpsText");
const decodeFpsText = document.getElementById("decodeFpsText");
const videoQueueText = document.getElementById("videoQueueText");
const videoDelayText = document.getElementById("videoDelayText");
const publishStatusText = document.getElementById("publishStatusText");
const publishVideoText = document.getElementById("publishVideoText");
const publishAudioText = document.getElementById("publishAudioText");
const publishFrameText = document.getElementById("publishFrameText");
const publishDropText = document.getElementById("publishDropText");
const publishBufferText = document.getElementById("publishBufferText");

const WORKER_VERSION = "20260518-h265-g711";
const AUDIO_PENDING_LIMIT = 16;

const params = new URLSearchParams(location.search);
const appConfig = await loadAppConfig();
input.value = params.get("url") || params.get("rtsp") || appConfig.defaultRTSPURL || input.value;
publishInput.value = params.get("publish") || appConfig.defaultPublishURL || publishInput.value;
emptyDetail.textContent = input.value;
const publishVideoCodec = params.get("publishVideoCodec") ||
  params.get("videoCodec") ||
  appConfig.publishVideoCodec ||
  "h264";
const publishAudioCodec = params.get("publishAudioCodec") ||
  params.get("audioCodec") ||
  appConfig.publishAudioCodec ||
  "aac";

let worker;
let connected = false;
let audioContext;
let audioNode;
let audioReadyPromise;
let pendingAudioMessages = [];
const publisher = new CameraPublisher({
  preview: localPreview,
  makeWebSocketURL: makePublishWebSocketURL,
  onStatus: updatePublishStatus,
  onStats: updatePublishStats,
  videoCodec: publishVideoCodec,
  audioCodec: publishAudioCodec
});

function setState(state, text) {
  stateDot.className = `dot ${state}`;
  statusText.textContent = text;
}

function setConnected(value) {
  connected = value;
  connectBtn.disabled = value;
  disconnectBtn.disabled = !value;
}

function setPublishConnected(value) {
  publishBtn.disabled = value;
  stopPublishBtn.disabled = !value;
}

function makeWebSocketURL(stream) {
  const scheme = location.protocol === "https:" ? "wss:" : "ws:";
  const url = new URL(`${scheme}//${location.host}/rtsp`);
  url.searchParams.set("url", stream);
  return url.toString();
}

function makePublishWebSocketURL(stream) {
  const scheme = location.protocol === "https:" ? "wss:" : "ws:";
  const url = new URL(`${scheme}//${location.host}/publish`);
  url.searchParams.set("url", stream);
  return url.toString();
}

function initWorker() {
  if (!window.isSecureContext) {
    setState("error", "需要安全上下文");
    return false;
  }

  if (!("VideoDecoder" in window)) {
    setState("error", "WebCodecs 不可用");
    return false;
  }

  if (!canvas.transferControlToOffscreen) {
    setState("error", "OffscreenCanvas 不可用");
    return false;
  }

  const offscreen = canvas.transferControlToOffscreen();
  worker = new Worker(`./decoder-worker.js?v=${WORKER_VERSION}`, { type: "module" });
  worker.onmessage = event => {
    const msg = event.data;

    switch (msg.type) {
      case "status":
        setState(msg.state, msg.text);
        break;
      case "configured":
        codecText.textContent = msg.codec;
        break;
      case "renderer":
        renderText.textContent = msg.renderer;
        break;
      case "audio-configured":
        audioText.textContent = `${msg.codec} ${msg.sampleRate}Hz ${msg.channels}ch`;
        break;
      case "audio-status":
        audioText.textContent = msg.text;
        break;
      case "audio":
        queueAudio(msg);
        break;
      case "frame":
        empty.classList.add("hidden");
        sizeText.textContent = `${msg.width} x ${msg.height}`;
        frameText.textContent = msg.frames.toString();
        break;
      case "drops":
        dropText.textContent = msg.dropped.toString();
        break;
      case "video-stats":
        updateVideoStats(msg);
        break;
      case "closed":
        setConnected(false);
        resetAudioSchedule();
        if (msg.clean) {
          setState("idle", "已断开");
        } else {
          setState("error", msg.reason || "连接已关闭");
        }
        break;
      case "error":
        setConnected(false);
        resetAudioSchedule();
        setState("error", msg.message);
        break;
      default:
        break;
    }
  };
  worker.postMessage({ type: "init", canvas: offscreen }, [offscreen]);
  return true;
}

function connect() {
  if (!worker && !initWorker()) {
    return;
  }

  const stream = input.value.trim();
  if (!stream) {
    setState("error", "缺少流地址");
    return;
  }

  empty.classList.remove("hidden");
  emptyDetail.textContent = stream;
  renderText.textContent = "-";
  codecText.textContent = "-";
  audioText.textContent = "-";
  resetAudioStats();
  sizeText.textContent = "-";
  frameText.textContent = "0";
  dropText.textContent = "0";
  resetVideoStats();
  startAudio();
  setConnected(true);
  setState("connecting", "连接中");
  worker.postMessage({
    type: "connect",
    wsUrl: makeWebSocketURL(stream)
  });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  connect();
});

disconnectBtn.addEventListener("click", () => {
  if (worker && connected) {
    worker.postMessage({ type: "disconnect" });
  }
  resetAudioSchedule();
});

publishForm.addEventListener("submit", async event => {
  event.preventDefault();

  const stream = publishInput.value.trim();
  if (!stream) {
    updatePublishStatus({ state: "error", text: "缺少推流地址" });
    return;
  }

  setPublishConnected(true);
  resetPublishStats();
  try {
    await publisher.start(stream);
  } catch {
    setPublishConnected(false);
  }
});

stopPublishBtn.addEventListener("click", () => {
  publisher.stop();
  setPublishConnected(false);
});

updatePublishStatus({ state: "idle", text: "空闲" });

setState("idle", "空闲");

async function loadAppConfig() {
  try {
    const response = await fetch("./config", { cache: "no-store" });
    if (!response.ok) {
      return {};
    }
    return await response.json();
  } catch {
    return {};
  }
}

function startAudio() {
  resetAudioSchedule();

  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) {
    audioText.textContent = "AudioContext 不可用";
    return;
  }

  if (!audioContext || audioContext.state === "closed") {
    audioContext = new AudioContextClass();
    audioNode = undefined;
    audioReadyPromise = undefined;
  }

  audioContext.resume().catch(err => {
    audioText.textContent = err.message;
  });

  ensureAudioOutput().catch(err => {
    audioText.textContent = err.message;
  });
}

async function ensureAudioOutput() {
  if (!audioContext || audioContext.state === "closed") {
    throw new Error("AudioContext 不可用");
  }

  if (!audioContext.audioWorklet) {
    throw new Error("AudioWorklet 不可用");
  }

  if (audioNode) {
    return audioNode;
  }

  if (!audioReadyPromise) {
    audioReadyPromise = setupAudioOutput().catch(err => {
      audioReadyPromise = undefined;
      throw err;
    });
  }

  return audioReadyPromise;
}

async function setupAudioOutput() {
  await audioContext.audioWorklet.addModule(`./audio-output-worklet.js?v=${WORKER_VERSION}`);

  audioNode = new AudioWorkletNode(audioContext, "pcm-player", {
    numberOfInputs: 0,
    numberOfOutputs: 1,
    outputChannelCount: [2]
  });
  audioNode.port.onmessage = event => {
    const msg = event.data;
    if (msg && msg.type === "audio-stats") {
      updateAudioStats(msg);
    }
  };
  audioNode.port.onmessageerror = () => {
    audioText.textContent = "音频播放线程通信失败";
  };
  audioNode.connect(audioContext.destination);
  flushPendingAudio();
  return audioNode;
}

function queueAudio(msg) {
  if (!audioContext || audioContext.state === "closed") {
    return;
  }

  if (!audioNode) {
    pendingAudioMessages.push(msg);
    while (pendingAudioMessages.length > AUDIO_PENDING_LIMIT) {
      pendingAudioMessages.shift();
    }
    ensureAudioOutput().catch(err => {
      audioText.textContent = err.message;
    });
    return;
  }

  postAudioToNode(msg);
}

function flushPendingAudio() {
  if (!audioNode) {
    return;
  }

  for (const msg of pendingAudioMessages) {
    postAudioToNode(msg);
  }
  pendingAudioMessages = [];
}

function postAudioToNode(msg) {
  const transfers = msg.channelData.filter(buffer => buffer instanceof ArrayBuffer);
  audioNode.port.postMessage({
    type: "audio",
    sampleRate: msg.sampleRate,
    channels: msg.channels,
    frames: msg.frames,
    channelData: msg.channelData
  }, transfers);
}

function resetAudioSchedule() {
  pendingAudioMessages = [];
  resetAudioStats();
  if (audioNode) {
    audioNode.port.postMessage({ type: "reset" });
  }
}

function resetAudioStats() {
  audioBufferText.textContent = "0ms";
  audioUnderrunText.textContent = "0";
}

function updateAudioStats(stats) {
  audioBufferText.textContent = `${Math.max(0, stats.bufferMs || 0)}ms`;
  audioUnderrunText.textContent = `${Math.max(0, stats.underruns || 0)}`;
}

function resetVideoStats() {
  renderFpsText.textContent = "-";
  decodeFpsText.textContent = "-";
  videoQueueText.textContent = "0";
  videoDelayText.textContent = "0ms";
}

function updateVideoStats(stats) {
  renderFpsText.textContent = formatFps(stats.renderFps);
  decodeFpsText.textContent = formatFps(stats.decodeFps);
  videoQueueText.textContent = `${Math.max(0, stats.videoQueue || 0)}`;
  videoDelayText.textContent = `${Math.trunc(stats.videoDelayMs || 0)}ms`;
}

function updatePublishStatus(status) {
  publishStatusText.textContent = status.text || "-";
  if (status.state === "error" || status.state === "idle") {
    setPublishConnected(false);
  }
}

function resetPublishStats() {
  publishVideoText.textContent = "-";
  publishAudioText.textContent = "-";
  publishFrameText.textContent = "0 / 0";
  publishDropText.textContent = "0";
  publishBufferText.textContent = "0KB";
}

function updatePublishStats(stats) {
  publishVideoText.textContent = stats.videoCodec || "-";
  publishAudioText.textContent = `${stats.audioCodec || "-"} ${stats.audioSampleRate || 0}Hz ${stats.audioChannels || 0}ch`;
  publishFrameText.textContent = `${Math.max(0, stats.videoFrames || 0)} / ${Math.max(0, stats.audioFrames || 0)}`;
  publishDropText.textContent = `${Math.max(0, stats.dropped || 0)}`;
  publishBufferText.textContent = `${Math.round((stats.bufferedBytes || 0) / 1024)}KB`;
}

function formatFps(value) {
  if (!Number.isFinite(value)) {
    return "-";
  }
  return value.toFixed(1);
}
