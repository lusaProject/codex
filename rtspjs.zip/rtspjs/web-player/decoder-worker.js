import {
  FRAME_TYPE_AUDIO,
  FRAME_TYPE_VIDEO,
  peekFrameType
} from "./media-packet.js";

const CHILD_WORKER_VERSION = "20260518-h265-g711";

let videoWorker;
let audioWorker;
let ws;

self.onmessage = event => {
  const msg = event.data;

  switch (msg.type) {
    case "init":
      initWorkers(msg.canvas);
      break;
    case "connect":
      connect(msg.wsUrl);
      break;
    case "disconnect":
      closeStream(true);
      break;
    default:
      break;
  }
};

function initWorkers(canvas) {
  closeChildWorkers();

  videoWorker = new Worker(`./video-worker.js?v=${CHILD_WORKER_VERSION}`, { type: "module" });
  audioWorker = new Worker(`./audio-worker.js?v=${CHILD_WORKER_VERSION}`, { type: "module" });

  videoWorker.onmessage = forwardWorkerMessage;
  audioWorker.onmessage = forwardWorkerMessage;

  videoWorker.postMessage({ type: "init", canvas }, [canvas]);
}

function forwardWorkerMessage(event) {
  const msg = event.data;
  if (msg && msg.type === "audio" && Array.isArray(msg.channelData)) {
    self.postMessage(msg, msg.channelData);
    return;
  }

  self.postMessage(msg);
}

function postStatus(state, text) {
  self.postMessage({ type: "status", state, text });
}

function connect(wsUrl) {
  if (!videoWorker || !audioWorker) {
    self.postMessage({ type: "error", message: "Worker 未初始化" });
    return;
  }

  closeStream(false);
  resetChildWorkers();

  ws = new WebSocket(wsUrl);
  ws.binaryType = "arraybuffer";

  ws.onopen = () => postStatus("connecting", "等待关键帧");
  ws.onmessage = event => {
    try {
      forwardPacket(event.data);
    } catch (err) {
      self.postMessage({ type: "error", message: err.message });
      closeStream(false);
    }
  };
  ws.onerror = () => {
    self.postMessage({ type: "error", message: "WebSocket 错误" });
  };
  ws.onclose = event => {
    ws = undefined;
    resetChildWorkers();
    self.postMessage({
      type: "closed",
      clean: event.wasClean,
      reason: event.reason || "连接已关闭"
    });
  };
}

function forwardPacket(buffer) {
  const frameType = peekFrameType(buffer);
  if (frameType === FRAME_TYPE_VIDEO) {
    videoWorker.postMessage({ type: "packet", buffer }, [buffer]);
    return;
  }

  if (frameType === FRAME_TYPE_AUDIO) {
    audioWorker.postMessage({ type: "packet", buffer }, [buffer]);
  }
}

function resetChildWorkers() {
  if (videoWorker) {
    videoWorker.postMessage({ type: "reset" });
  }
  if (audioWorker) {
    audioWorker.postMessage({ type: "reset" });
  }
}

function closeStream(clean) {
  if (ws) {
    const old = ws;
    ws = undefined;
    old.onopen = null;
    old.onmessage = null;
    old.onerror = null;
    old.onclose = null;
    if (old.readyState === WebSocket.OPEN || old.readyState === WebSocket.CONNECTING) {
      old.close();
    }
  }

  resetChildWorkers();
  if (clean) {
    self.postMessage({ type: "closed", clean: true });
  }
}

function closeChildWorkers() {
  closeStream(false);

  if (videoWorker) {
    videoWorker.terminate();
    videoWorker = undefined;
  }
  if (audioWorker) {
    audioWorker.terminate();
    audioWorker = undefined;
  }
}
