const INITIAL_PREBUFFER_SECONDS = 0.6;
const RESUME_PREBUFFER_SECONDS = 0.05;
const MAX_BUFFER_SECONDS = 1.2;
const STATS_INTERVAL_SECONDS = 0.25;

class PCMPlayerProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.queue = [];
    this.bufferedFrames = 0;
    this.started = false;
    this.hasPlayed = false;
    this.underruns = 0;
    this.droppedChunks = 0;
    this.initialPrebufferFrames = Math.floor(sampleRate * INITIAL_PREBUFFER_SECONDS);
    this.resumePrebufferFrames = Math.floor(sampleRate * RESUME_PREBUFFER_SECONDS);
    this.maxBufferedFrames = Math.floor(sampleRate * MAX_BUFFER_SECONDS);
    this.statsIntervalFrames = Math.floor(sampleRate * STATS_INTERVAL_SECONDS);
    this.framesSinceStats = 0;

    this.port.onmessage = event => {
      const msg = event.data;
      if (msg.type === "reset") {
        this.reset();
        return;
      }

      if (msg.type === "audio") {
        this.pushAudio(msg);
      }
    };
  }

  pushAudio(msg) {
    if (!msg.frames || !msg.sampleRate || !Array.isArray(msg.channelData)) {
      return;
    }

    const chunk = {
      sampleRate: msg.sampleRate,
      channels: msg.channels,
      frames: msg.frames,
      position: 0,
      data: msg.channelData.map(buffer => new Float32Array(buffer))
    };

    const outputFrames = this.outputFramesFor(chunk);
    if (this.queue.length > 0 && this.bufferedFrames + outputFrames > this.maxBufferedFrames) {
      this.droppedChunks += 1;
      this.postStats();
      return;
    }

    this.queue.push(chunk);
    this.bufferedFrames += outputFrames;
    this.postStats();
  }

  process(_inputs, outputs) {
    const output = outputs[0];
    if (!output || output.length === 0) {
      return true;
    }

    const frameCount = output[0].length;
    for (const channel of output) {
      channel.fill(0);
    }

    if (!this.started) {
      const prebufferFrames = this.hasPlayed
        ? this.resumePrebufferFrames
        : this.initialPrebufferFrames;
      if (this.bufferedFrames < prebufferFrames) {
        this.maybePostStats(frameCount);
        return true;
      }
      this.started = true;
      this.hasPlayed = true;
    }

    let frame = 0;
    while (frame < frameCount) {
      const chunk = this.queue[0];
      if (!chunk) {
        this.underruns += 1;
        this.started = false;
        break;
      }

      const sourceIndex = Math.floor(chunk.position);
      if (sourceIndex >= chunk.frames) {
        this.queue.shift();
        continue;
      }

      for (let channel = 0; channel < output.length; channel += 1) {
        output[channel][frame] = this.sampleChannel(chunk, channel, sourceIndex);
      }

      chunk.position += chunk.sampleRate / sampleRate;
      this.bufferedFrames = Math.max(0, this.bufferedFrames - 1);
      frame += 1;
    }

    this.maybePostStats(frameCount);
    return true;
  }

  sampleChannel(chunk, outputChannel, index) {
    const sourceChannel = this.sourceChannelIndex(chunk, outputChannel);
    const plane = chunk.data[sourceChannel];
    if (!plane) {
      return 0;
    }

    const nextIndex = Math.min(index + 1, chunk.frames - 1);
    const fraction = chunk.position - index;
    const sample = plane[index] + (plane[nextIndex] - plane[index]) * fraction;
    if (!Number.isFinite(sample)) {
      return 0;
    }
    return Math.max(-1, Math.min(1, sample));
  }

  sourceChannelIndex(chunk, outputChannel) {
    if (chunk.channels === 1) {
      return 0;
    }

    return Math.min(outputChannel, chunk.channels - 1);
  }

  outputFramesFor(chunk) {
    return Math.max(0, Math.floor((chunk.frames - chunk.position) * sampleRate / chunk.sampleRate));
  }

  reset() {
    this.queue = [];
    this.bufferedFrames = 0;
    this.started = false;
    this.hasPlayed = false;
    this.underruns = 0;
    this.droppedChunks = 0;
    this.framesSinceStats = 0;
    this.postStats();
  }

  maybePostStats(frameCount) {
    this.framesSinceStats += frameCount;
    if (this.framesSinceStats >= this.statsIntervalFrames) {
      this.framesSinceStats = 0;
      this.postStats();
    }
  }

  postStats() {
    this.port.postMessage({
      type: "audio-stats",
      bufferMs: Math.round(this.bufferedFrames * 1000 / sampleRate),
      underruns: this.underruns,
      dropped: this.droppedChunks
    });
  }
}

registerProcessor("pcm-player", PCMPlayerProcessor);
