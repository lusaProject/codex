export const FRAME_TYPE_VIDEO = 1;
export const FRAME_TYPE_AUDIO = 2;
export const CODEC_H264 = 1;
export const CODEC_H265 = 2;
export const CODEC_AAC = 3;
export const CODEC_PCMU = 4;
export const CODEC_PCMA = 5;
export const HEADER_SIZE = 16;
export const MPEG4_AUDIO_HEADER_SIZE = 8;
export const G711_AUDIO_HEADER_SIZE = 5;

export function peekFrameType(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < HEADER_SIZE) {
    throw new Error("无效 WebSocket 包");
  }

  return new DataView(buffer).getUint8(0);
}

export function parsePacket(buffer) {
  if (!(buffer instanceof ArrayBuffer) || buffer.byteLength < HEADER_SIZE) {
    throw new Error("无效 WebSocket 包");
  }

  const view = new DataView(buffer);
  const frameType = view.getUint8(0);
  const codec = view.getUint8(1);
  const keyframe = view.getUint8(2) === 1;
  const timestampHigh = view.getUint32(4);
  const timestampLow = view.getUint32(8);
  const timestampUs = timestampHigh * 2 ** 32 + timestampLow;
  const payloadLen = view.getUint32(12);

  if (payloadLen > buffer.byteLength - HEADER_SIZE) {
    throw new Error("payloadLen 超出消息长度");
  }

  return {
    frameType,
    codec,
    keyframe,
    timestampUs,
    payload: new Uint8Array(buffer, HEADER_SIZE, payloadLen)
  };
}

export function parseMPEG4AudioPayload(payload) {
  if (payload.byteLength < MPEG4_AUDIO_HEADER_SIZE) {
    throw new Error("无效 AAC 包");
  }

  const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
  const sampleRate = view.getUint32(0);
  const channels = view.getUint8(4);
  const objectType = view.getUint8(5) || 2;
  const configLen = view.getUint16(6);
  const dataOffset = MPEG4_AUDIO_HEADER_SIZE + configLen;

  if (sampleRate === 0 || channels === 0) {
    throw new Error("无效 AAC 参数");
  }

  if (payload.byteLength <= dataOffset) {
    throw new Error("AAC payload 缺少音频数据");
  }

  return {
    sampleRate,
    channels,
    objectType,
    description: payload.slice(MPEG4_AUDIO_HEADER_SIZE, dataOffset),
    data: payload.subarray(dataOffset)
  };
}

export function parseG711AudioPayload(payload) {
  if (payload.byteLength < G711_AUDIO_HEADER_SIZE) {
    throw new Error("Invalid G711 packet");
  }

  const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
  const sampleRate = view.getUint32(0);
  const channels = view.getUint8(4);
  const data = payload.subarray(G711_AUDIO_HEADER_SIZE);

  if (sampleRate === 0 || channels === 0) {
    throw new Error("Invalid G711 parameters");
  }

  if (data.byteLength === 0) {
    throw new Error("G711 payload has no audio data");
  }

  return {
    sampleRate,
    channels,
    data
  };
}

export function copyArrayBuffer(bytes) {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

export function hex(value) {
  return value.toString(16).padStart(2, "0").toUpperCase();
}
