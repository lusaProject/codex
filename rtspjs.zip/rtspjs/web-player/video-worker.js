import {
  CODEC_H264,
  CODEC_H265,
  FRAME_TYPE_VIDEO,
  hex,
  parsePacket
} from "./media-packet.js";

let canvas;
let renderer;
let decoder;
let configured = false;
let frames = 0;
let dropped = 0;
let lastWidth = 0;
let lastHeight = 0;
let decodedFrames = 0;
let textureUploadMode = "video-frame";
let renderQueue = [];
let renderTimer;
let rendering = false;
let renderGeneration = 0;
let needKeyframe = false;
let playbackBaseTimestampUs;
let playbackBaseTimeMs = 0;
let lastRenderedTimestampUs = -Infinity;
let lastStatsAt = 0;
let lastStatsDecoded = 0;
let lastStatsRendered = 0;

const MAX_VIDEO_DECODE_QUEUE = 24;
const MAX_RENDER_QUEUE = 24;
const INITIAL_VIDEO_PREBUFFER_MS = 120;
const EARLY_RENDER_WINDOW_MS = 80;
const LATE_DROP_THRESHOLD_MS = 350;
const STATS_INTERVAL_MS = 500;

self.onmessage = async event => {
  const msg = event.data;

  switch (msg.type) {
    case "init":
      canvas = msg.canvas;
      try {
        renderer = createWebGLRenderer(canvas);
      } catch (err) {
        self.postMessage({ type: "error", message: err.message });
        return;
      }
      if (!renderer) {
        self.postMessage({ type: "error", message: "WebGL unavailable" });
        return;
      }
      self.postMessage({ type: "renderer", renderer: "WebGL Worker" });
      break;
    case "packet":
      try {
        await handleVideoPacket(parsePacket(msg.buffer));
      } catch (err) {
        self.postMessage({ type: "error", message: err.message });
        resetDecoder();
      }
      break;
    case "reset":
      resetVideoState();
      break;
    default:
      break;
  }
};

function postStatus(state, text) {
  self.postMessage({ type: "status", state, text });
}

function createWebGLRenderer(targetCanvas) {
  const gl = targetCanvas.getContext("webgl", {
    alpha: false,
    antialias: false,
    depth: false,
    desynchronized: true,
    preserveDrawingBuffer: false,
    stencil: false
  }) || targetCanvas.getContext("experimental-webgl", {
    alpha: false,
    antialias: false,
    depth: false,
    desynchronized: true,
    preserveDrawingBuffer: false,
    stencil: false
  });

  if (!gl) {
    return undefined;
  }

  const program = createProgram(gl, `
    attribute vec2 a_position;
    attribute vec2 a_texCoord;
    varying vec2 v_texCoord;

    void main() {
      gl_Position = vec4(a_position, 0.0, 1.0);
      v_texCoord = a_texCoord;
    }
  `, `
    precision mediump float;

    uniform sampler2D u_texture;
    varying vec2 v_texCoord;

    void main() {
      gl_FragColor = texture2D(u_texture, v_texCoord);
    }
  `);

  const positionLocation = gl.getAttribLocation(program, "a_position");
  const texCoordLocation = gl.getAttribLocation(program, "a_texCoord");
  const textureLocation = gl.getUniformLocation(program, "u_texture");
  const buffer = gl.createBuffer();
  const texture = gl.createTexture();
  let textureWidth = 0;
  let textureHeight = 0;

  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
    -1, -1, 0, 0,
     1, -1, 1, 0,
    -1,  1, 0, 1,
     1,  1, 1, 1
  ]), gl.STATIC_DRAW);

  gl.useProgram(program);
  gl.enableVertexAttribArray(positionLocation);
  gl.enableVertexAttribArray(texCoordLocation);
  gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 16, 0);
  gl.vertexAttribPointer(texCoordLocation, 2, gl.FLOAT, false, 16, 8);
  gl.uniform1i(textureLocation, 0);

  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.clearColor(0, 0, 0, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);

  return {
    resize(width, height) {
      if (targetCanvas.width !== width || targetCanvas.height !== height) {
        targetCanvas.width = width;
        targetCanvas.height = height;
      }
      gl.viewport(0, 0, targetCanvas.width, targetCanvas.height);
    },
    draw(source, width, height) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, texture);

      if (textureWidth !== width || textureHeight !== height) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
        textureWidth = width;
        textureHeight = height;
      } else {
        try {
          gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, source);
        } catch (err) {
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
        }
      }

      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    },
    resetTexture() {
      textureWidth = 0;
      textureHeight = 0;
    }
  };
}

function createProgram(gl, vertexSource, fragmentSource) {
  const vertexShader = createShader(gl, gl.VERTEX_SHADER, vertexSource);
  const fragmentShader = createShader(gl, gl.FRAGMENT_SHADER, fragmentSource);
  const program = gl.createProgram();

  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const message = gl.getProgramInfoLog(program) || "WebGL program link failed";
    gl.deleteProgram(program);
    throw new Error(message);
  }

  return program;
}

function createShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const message = gl.getShaderInfoLog(shader) || "WebGL shader compile failed";
    gl.deleteShader(shader);
    throw new Error(message);
  }

  return shader;
}

async function handleVideoPacket(packet) {
  if (packet.frameType !== FRAME_TYPE_VIDEO) {
    return;
  }

  if (packet.codec !== CODEC_H264 && packet.codec !== CODEC_H265) {
    throw new Error("Unsupported video codec");
  }

  if (needKeyframe) {
    if (!packet.keyframe) {
      dropFrame();
      return;
    }
    resetDecoder();
    resetRenderState();
    needKeyframe = false;
  }

  if (configured && decoder && decoder.decodeQueueSize >= MAX_VIDEO_DECODE_QUEUE) {
    dropFrame();

    if (!packet.keyframe) {
      needKeyframe = true;
      postStatus("connecting", "Video backlog, waiting for keyframe");
      return;
    }
    resetDecoder();
    resetRenderState();
  }

  if (!configured) {
    const codecCandidates = codecCandidatesForPacket(packet);
    if (codecCandidates.length === 0) {
      if (packet.keyframe) {
        postStatus("connecting", "Waiting for parameter sets");
      }
      return;
    }

    await configureDecoder(packet.codec, codecCandidates);
  }

  if (!decoder || decoder.state !== "configured") {
    resetDecoder();
    if (packet.keyframe) {
      postStatus("connecting", "Waiting for keyframe");
    }
    return;
  }

  try {
    decoder.decode(new EncodedVideoChunk({
      type: packet.keyframe ? "key" : "delta",
      timestamp: packet.timestampUs,
      data: packet.payload
    }));
  } catch {
    resetDecoder();
    postStatus("connecting", "Video decoder reset");
  }
}

async function configureDecoder(videoCodec, codecCandidates) {
  let selectedConfig;
  let selectedCodec;

  for (const codec of codecCandidates) {
    const config = makeVideoDecoderConfig(videoCodec, codec);
    const support = await VideoDecoder.isConfigSupported(config);
    if (support.supported) {
      selectedCodec = codec;
      selectedConfig = support.config || config;
      break;
    }
  }

  if (!selectedConfig) {
    throw new Error(`Browser does not support ${codecCandidates.join(", ")}`);
  }

  decoder = new VideoDecoder({
    output: frame => {
      renderDecodedFrame(frame);
    },
    error: () => {
      postStatus("connecting", "Video decoder reset");
      resetDecoder();
    }
  });

  decoder.configure(selectedConfig);
  configured = true;
  self.postMessage({ type: "configured", codec: selectedCodec });
  postStatus("live", "Playing");
}

function makeVideoDecoderConfig(videoCodec, codec) {
  const config = {
    codec,
    optimizeForLatency: true,
    hardwareAcceleration: "prefer-hardware"
  };

  if (videoCodec === CODEC_H264) {
    config.avc = { format: "annexb" };
  }

  return config;
}

function renderDecodedFrame(frame) {
  decodedFrames += 1;

  const timestampUs = normalizeTimestamp(frame.timestamp);
  if (timestampUs !== undefined && timestampUs <= lastRenderedTimestampUs) {
    dropFrame();
    frame.close();
    return;
  }

  renderQueue.push({
    frame,
    timestampUs,
    width: frame.displayWidth || frame.codedWidth,
    height: frame.displayHeight || frame.codedHeight
  });

  trimRenderQueue();
  maybePostVideoStats();
  scheduleRender();
}

function trimRenderQueue() {
  while (renderQueue.length > MAX_RENDER_QUEUE) {
    const item = renderQueue.shift();
    item.frame.close();
    dropFrame();
    resetPlaybackClock();
  }
}

function scheduleRender(delayMs = 0) {
  if (rendering || renderTimer !== undefined) {
    return;
  }

  renderTimer = setTimeout(() => {
    renderTimer = undefined;
    renderNextFrame();
  }, Math.max(0, delayMs));
}

async function renderNextFrame() {
  if (rendering || renderQueue.length === 0) {
    maybePostVideoStats();
    return;
  }

  const generation = renderGeneration;
  dropLateFrames();

  const item = renderQueue[0];
  if (!item) {
    maybePostVideoStats();
    return;
  }

  const dueInMs = frameDueInMs(item);
  if (dueInMs > EARLY_RENDER_WINDOW_MS) {
    scheduleRender(dueInMs - EARLY_RENDER_WINDOW_MS);
    return;
  }

  renderQueue.shift();
  rendering = true;
  try {
    const drawn = await uploadAndDrawFrame(item, generation);
    if (drawn && generation === renderGeneration) {
      markFrameRendered(item);
    }
  } catch (err) {
    if (generation === renderGeneration) {
      self.postMessage({ type: "error", message: `WebGL render failed: ${err.message}` });
    }
  } finally {
    item.frame.close();
    rendering = false;
    if (generation === renderGeneration) {
      maybePostVideoStats();
      scheduleRender();
    }
  }
}

function dropLateFrames() {
  while (renderQueue.length > 1) {
    const delayMs = frameDueInMs(renderQueue[0]);
    if (delayMs >= -LATE_DROP_THRESHOLD_MS) {
      return;
    }

    const item = renderQueue.shift();
    item.frame.close();
    dropFrame();
    resetPlaybackClock(renderQueue[0]);
  }
}

function frameDueInMs(item) {
  if (item.timestampUs === undefined) {
    return 0;
  }

  const now = performance.now();
  if (playbackBaseTimestampUs === undefined || item.timestampUs < playbackBaseTimestampUs) {
    resetPlaybackClock(item, now);
  }

  let targetTimeMs = playbackBaseTimeMs + (item.timestampUs - playbackBaseTimestampUs) / 1000;
  if (Math.abs(targetTimeMs - now) > 5000) {
    resetPlaybackClock(item, now);
    targetTimeMs = playbackBaseTimeMs + (item.timestampUs - playbackBaseTimestampUs) / 1000;
  }
  return targetTimeMs - now;
}

function resetPlaybackClock(item, now = performance.now()) {
  if (!item || item.timestampUs === undefined) {
    playbackBaseTimestampUs = undefined;
    playbackBaseTimeMs = 0;
    return;
  }

  playbackBaseTimestampUs = item.timestampUs;
  playbackBaseTimeMs = now + INITIAL_VIDEO_PREBUFFER_MS;
}

function markFrameRendered(item) {
  frames += 1;
  if (item.timestampUs !== undefined) {
    lastRenderedTimestampUs = Math.max(lastRenderedTimestampUs, item.timestampUs);
  }

  if (lastWidth !== item.width || lastHeight !== item.height || frames % 30 === 1) {
    lastWidth = item.width;
    lastHeight = item.height;
    self.postMessage({
      type: "frame",
      width: item.width,
      height: item.height,
      frames
    });
  }
}

async function uploadAndDrawFrame(item, generation) {
  if (generation !== renderGeneration) {
    return false;
  }

  renderer.resize(item.width, item.height);

  if (textureUploadMode === "video-frame") {
    try {
      renderer.draw(item.frame, item.width, item.height);
      return true;
    } catch (err) {
      if (!("createImageBitmap" in self)) {
        throw err;
      }
      textureUploadMode = "image-bitmap";
      renderer.resetTexture();
      self.postMessage({ type: "renderer", renderer: "WebGL ImageBitmap Worker" });
    }
  }

  const bitmap = await createImageBitmap(item.frame);
  try {
    if (generation !== renderGeneration) {
      return false;
    }
    renderer.draw(bitmap, item.width, item.height);
    return true;
  } finally {
    bitmap.close();
  }
}

function normalizeTimestamp(timestamp) {
  if (typeof timestamp !== "number" || !Number.isFinite(timestamp)) {
    return undefined;
  }
  return timestamp;
}

function maybePostVideoStats(force = false) {
  const now = performance.now();
  if (!force && now - lastStatsAt < STATS_INTERVAL_MS) {
    return;
  }

  const seconds = Math.max((now - lastStatsAt) / 1000, 0.001);
  const firstQueued = renderQueue[0];
  let videoDelayMs = 0;
  if (firstQueued && firstQueued.timestampUs !== undefined && playbackBaseTimestampUs !== undefined) {
    const targetTimeMs = playbackBaseTimeMs + (firstQueued.timestampUs - playbackBaseTimestampUs) / 1000;
    videoDelayMs = Math.round(now - targetTimeMs);
  }

  self.postMessage({
    type: "video-stats",
    renderFps: Math.round(((frames - lastStatsRendered) / seconds) * 10) / 10,
    decodeFps: Math.round(((decodedFrames - lastStatsDecoded) / seconds) * 10) / 10,
    videoQueue: renderQueue.length,
    videoDelayMs
  });

  lastStatsAt = now;
  lastStatsDecoded = decodedFrames;
  lastStatsRendered = frames;
}

function resetVideoState() {
  frames = 0;
  dropped = 0;
  decodedFrames = 0;
  lastWidth = 0;
  lastHeight = 0;
  needKeyframe = false;
  lastStatsAt = performance.now();
  lastStatsDecoded = 0;
  lastStatsRendered = 0;
  resetDecoder();
  resetRenderState();
  maybePostVideoStats(true);
}

function resetDecoder() {
  configured = false;
  if (decoder) {
    try {
      decoder.close();
    } catch {
      // Decoder can already be closed by the browser after a fatal decode error.
    }
    decoder = undefined;
  }
}

function resetRenderState() {
  renderGeneration += 1;
  if (renderTimer !== undefined) {
    clearTimeout(renderTimer);
    renderTimer = undefined;
  }
  for (const item of renderQueue) {
    item.frame.close();
  }
  renderQueue = [];
  rendering = false;
  textureUploadMode = "video-frame";
  lastRenderedTimestampUs = -Infinity;
  resetPlaybackClock();
  if (renderer) {
    renderer.resetTexture();
  }
}

function dropFrame() {
  dropped += 1;
  self.postMessage({ type: "drops", dropped });
  maybePostVideoStats();
}

function codecCandidatesForPacket(packet) {
  if (packet.codec === CODEC_H264) {
    const sps = findH264SPS(packet.payload);
    return sps ? [codecFromH264SPS(sps)] : [];
  }

  if (packet.codec === CODEC_H265) {
    const sps = findH265SPS(packet.payload);
    return sps ? codecCandidatesFromH265SPS(sps) : [];
  }

  return [];
}

function findH264SPS(payload) {
  for (const nalu of splitAnnexB(payload)) {
    if (nalu.length > 0 && (nalu[0] & 0x1f) === 7) {
      return nalu;
    }
  }
  return undefined;
}

function codecFromH264SPS(sps) {
  if (sps.length < 4) {
    return "avc1.42E01F";
  }

  return `avc1.${hex(sps[1])}${hex(sps[2])}${hex(sps[3])}`;
}

function findH265SPS(payload) {
  for (const nalu of splitAnnexB(payload)) {
    if (nalu.length >= 2 && ((nalu[0] >> 1) & 0x3f) === 33) {
      return nalu;
    }
  }
  return undefined;
}

function codecCandidatesFromH265SPS(sps) {
  const parsed = parseH265SPSCodecInfo(sps);
  const candidates = [];

  if (parsed) {
    candidates.push(hevcCodecString("hev1", parsed));
    candidates.push(hevcCodecString("hvc1", parsed));
    candidates.push(`hev1.1.6.L${parsed.levelIdc}.B0`);
    candidates.push(`hvc1.1.6.L${parsed.levelIdc}.B0`);
  }

  candidates.push("hev1.1.6.L93.B0");
  candidates.push("hvc1.1.6.L93.B0");

  return [...new Set(candidates)];
}

function parseH265SPSCodecInfo(sps) {
  if (sps.length < 8 || ((sps[0] >> 1) & 0x3f) !== 33) {
    return undefined;
  }

  try {
    const reader = new BitReader(removeEmulationPrevention(sps.subarray(1)));
    reader.skipBits(8);
    reader.skipBits(4);
    reader.skipBits(3);
    reader.skipBits(1);

    const profileSpace = reader.readBits(2);
    const tierFlag = reader.readBits(1);
    const profileIdc = reader.readBits(5);
    let profileCompatibility = 0;

    for (let i = 0; i < 32; i += 1) {
      if (reader.readBits(1)) {
        profileCompatibility += 2 ** i;
      }
    }

    const constraintBytes = [];
    for (let i = 0; i < 6; i += 1) {
      constraintBytes.push(reader.readBits(8));
    }

    return {
      profileSpace,
      tierFlag,
      profileIdc,
      profileCompatibility,
      constraintBytes,
      levelIdc: reader.readBits(8)
    };
  } catch {
    return undefined;
  }
}

function hevcCodecString(prefix, info) {
  const profileSpacePrefix = ["", "A", "B", "C"][info.profileSpace] || "";
  const tier = info.tierFlag ? "H" : "L";
  const compatibility = Math.max(0, info.profileCompatibility).toString(16).toUpperCase();
  const constraints = hevcConstraintString(info.constraintBytes);

  return `${prefix}.${profileSpacePrefix}${info.profileIdc}.${compatibility}.${tier}${info.levelIdc}.${constraints}`;
}

function hevcConstraintString(bytes) {
  let last = bytes.length - 1;
  while (last > 0 && bytes[last] === 0) {
    last -= 1;
  }

  return bytes.slice(0, last + 1).map(hex).join(".");
}

function removeEmulationPrevention(bytes) {
  const out = [];
  for (let i = 0; i < bytes.length; i += 1) {
    if (i >= 2 && bytes[i] === 0x03 && bytes[i - 1] === 0 && bytes[i - 2] === 0) {
      continue;
    }
    out.push(bytes[i]);
  }
  return new Uint8Array(out);
}

class BitReader {
  constructor(bytes) {
    this.bytes = bytes;
    this.position = 0;
  }

  readBits(count) {
    if (this.position + count > this.bytes.length * 8) {
      throw new Error("bitstream is too short");
    }

    let value = 0;
    for (let i = 0; i < count; i += 1) {
      const byte = this.bytes[this.position >> 3];
      const bit = (byte >> (7 - (this.position & 7))) & 1;
      value = (value * 2) + bit;
      this.position += 1;
    }

    return value;
  }

  skipBits(count) {
    this.readBits(count);
  }
}

function splitAnnexB(bytes) {
  const ranges = [];
  let start = findStartCode(bytes, 0);

  while (start) {
    const naluStart = start.index + start.length;
    const next = findStartCode(bytes, naluStart);
    const naluEnd = next ? next.index : bytes.length;

    if (naluEnd > naluStart) {
      ranges.push(bytes.subarray(naluStart, naluEnd));
    }

    if (!next) {
      break;
    }
    start = next;
  }

  return ranges;
}

function findStartCode(bytes, offset) {
  for (let i = offset; i + 3 <= bytes.length; i += 1) {
    if (bytes[i] === 0 && bytes[i + 1] === 0) {
      if (bytes[i + 2] === 1) {
        return { index: i, length: 3 };
      }
      if (i + 3 < bytes.length && bytes[i + 2] === 0 && bytes[i + 3] === 1) {
        return { index: i, length: 4 };
      }
    }
  }

  return undefined;
}
