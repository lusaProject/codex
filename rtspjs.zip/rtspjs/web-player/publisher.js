import {
  CODEC_AAC,
  CODEC_H264,
  CODEC_H265,
  CODEC_PCMA,
  CODEC_PCMU,
  FRAME_TYPE_AUDIO,
  FRAME_TYPE_VIDEO,
  HEADER_SIZE
} from "./media-packet.js";

const VIDEO_WIDTH = 1280;
const VIDEO_HEIGHT = 720;
const VIDEO_FPS = 25;
const VIDEO_BITRATE = 1_500_000;
const VIDEO_KEYFRAME_INTERVAL_MS = 2_000;
const MAX_VIDEO_ENCODE_QUEUE = 6;
const MAX_AUDIO_ENCODE_QUEUE = 12;
const MAX_WEBSOCKET_BUFFERED_BYTES = 8 * 1024 * 1024;

const AAC_SAMPLE_RATE = 44100;
const AAC_CHANNELS = 2;
const AAC_BITRATE = 128_000;
const AAC_FRAME_SIZE = 1024;
const G711_SAMPLE_RATE = 8000;
const G711_CHANNELS = 1;
const G711_FRAME_DURATION_MS = 20;
const PUBLISH_AUDIO_WORKLET_VERSION = "20260523-g711-buffer";

const H264_CODEC_CANDIDATES = [
  "avc1.42E01F",
  "avc1.42001F",
  "avc1.4D401F",
  "avc1.64001F"
];

const H265_CODEC_CANDIDATES = [
  "hev1.1.6.L93.B0",
  "hvc1.1.6.L93.B0",
  "hev1.1.6.L120.B0",
  "hvc1.1.6.L120.B0"
];

export class CameraPublisher {
  constructor({ preview, makeWebSocketURL, onStatus, onStats, videoCodec, audioCodec }) {
    this.preview = preview;
    this.makeWebSocketURL = makeWebSocketURL;
    this.onStatus = onStatus || (() => {});
    this.onStats = onStats || (() => {});
    this.requestedVideoCodec = videoCodec || "h264";
    this.requestedAudioCodec = audioCodec || "aac";
    this.resetStats();
  }

  async start(rtspURL) {
    await this.stop({ silent: true });
    this.configureCodecPreferences();
    this.ensureSupported();

    this.running = true;
    this.closedByStop = false;
    this.resetStats();
    this.postStatus("connecting", "Requesting camera");

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: VIDEO_WIDTH },
          height: { ideal: VIDEO_HEIGHT },
          frameRate: { ideal: VIDEO_FPS, max: VIDEO_FPS }
        },
        audio: this.audioCodecName === "none" ? false : {
          channelCount: { ideal: this.audioChannels },
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      this.attachPreview();
      if (this.audioCodecName !== "none") {
        this.prepareAudioContext();
      }
      await this.createVideoEncoder();
      if (this.audioCodecName === "aac") {
        await this.createAudioEncoder();
      } else {
        this.audioCodec = audioCodecDisplayName(this.audioCodecName);
      }
      await this.openWebSocket(rtspURL);
      this.startVideoCapture();
      if (this.audioCodecName !== "none") {
        await this.startAudioCapture();
      }
      this.postStatus("live", "Publishing");
      this.emitStats(true);
    } catch (err) {
      await this.stop({ silent: true });
      this.postStatus("error", err.message || String(err));
      throw err;
    }
  }

  async stop(options = {}) {
    const wasRunning = this.running;
    this.running = false;
    this.closedByStop = true;

    if (this.videoReader) {
      try {
        await this.videoReader.cancel();
      } catch {
        // The reader can already be closed when the track stops.
      }
      this.videoReader = undefined;
    }

    if (this.videoFrameCallbackId !== undefined && this.preview?.cancelVideoFrameCallback) {
      this.preview.cancelVideoFrameCallback(this.videoFrameCallbackId);
      this.videoFrameCallbackId = undefined;
    }
    if (this.videoTimer !== undefined) {
      clearTimeout(this.videoTimer);
      this.videoTimer = undefined;
    }

    if (this.audioNode) {
      this.audioNode.port.onmessage = null;
      try {
        this.audioNode.disconnect();
      } catch {
        // The graph can already be disconnected during context shutdown.
      }
      this.audioNode = undefined;
    }
    if (this.audioSource) {
      try {
        this.audioSource.disconnect();
      } catch {
        // The graph can already be disconnected during context shutdown.
      }
      this.audioSource = undefined;
    }
    if (this.audioMute) {
      try {
        this.audioMute.disconnect();
      } catch {
        // The graph can already be disconnected during context shutdown.
      }
      this.audioMute = undefined;
    }
    if (this.audioContext && this.audioContext.state !== "closed") {
      try {
        await this.audioContext.close();
      } catch {
        // Some browsers reject close() while tearing down capture.
      }
    }
    this.audioContext = undefined;

    if (this.videoEncoder) {
      try {
        this.videoEncoder.close();
      } catch {
        // Encoders can close themselves after a fatal encode error.
      }
      this.videoEncoder = undefined;
    }
    if (this.audioEncoder) {
      try {
        this.audioEncoder.close();
      } catch {
        // Encoders can close themselves after a fatal encode error.
      }
      this.audioEncoder = undefined;
    }

    if (this.ws) {
      const ws = this.ws;
      this.ws = undefined;
      ws.onopen = null;
      ws.onmessage = null;
      ws.onerror = null;
      ws.onclose = null;
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "stop" }));
      }
      if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
        ws.close();
      }
    }

    if (this.stream) {
      for (const track of this.stream.getTracks()) {
        track.stop();
      }
      this.stream = undefined;
    }

    if (this.preview) {
      this.preview.pause();
      this.preview.srcObject = null;
      this.preview.classList.add("hidden");
    }

    if (wasRunning && !options.silent) {
      this.postStatus("idle", "Stopped");
      this.resetStats();
      this.emitStats(true);
    }
  }

  configureCodecPreferences() {
    this.videoCodecName = normalizeVideoCodecName(this.requestedVideoCodec);
    this.audioCodecName = normalizeAudioCodecName(this.requestedAudioCodec);
    this.videoPacketCodec = this.videoCodecName === "h265" ? CODEC_H265 : CODEC_H264;
    this.audioPacketCodec = audioPacketCodec(this.audioCodecName);
    this.audioChannels = this.audioCodecName === "aac" ? AAC_CHANNELS : G711_CHANNELS;
    this.audioTargetSampleRate = this.audioCodecName === "aac" ? AAC_SAMPLE_RATE : G711_SAMPLE_RATE;
  }

  ensureSupported() {
    if (!window.isSecureContext) {
      throw new Error("Camera publishing requires a secure context or localhost");
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("getUserMedia is unavailable");
    }
    if (!("VideoEncoder" in window) || !("VideoFrame" in window)) {
      throw new Error("VideoEncoder is unavailable");
    }
    if (this.audioCodecName === "aac" && (!("AudioEncoder" in window) || !("AudioData" in window))) {
      throw new Error("AudioEncoder is unavailable");
    }
    if (this.audioCodecName !== "none" && !("AudioWorkletNode" in window)) {
      throw new Error("AudioWorklet is unavailable");
    }
  }

  attachPreview() {
    if (!this.preview) {
      return;
    }

    this.preview.srcObject = this.stream;
    this.preview.muted = true;
    this.preview.playsInline = true;
    this.preview.classList.remove("hidden");
    this.preview.play().catch(() => {});
  }

  prepareAudioContext() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error("AudioContext is unavailable");
    }

    this.audioContext = new AudioContextClass({
      sampleRate: this.audioTargetSampleRate,
      latencyHint: "interactive"
    });
    this.audioSampleRate = Math.round(this.audioContext.sampleRate || this.audioTargetSampleRate);
    this.audioFrameSize = this.audioCodecName === "aac"
      ? AAC_FRAME_SIZE
      : Math.max(80, Math.round(this.audioSampleRate * G711_FRAME_DURATION_MS / 1000));
  }

  async createVideoEncoder() {
    const track = this.stream.getVideoTracks()[0];
    if (!track) {
      throw new Error("No camera video track");
    }

    const settings = track.getSettings ? track.getSettings() : {};
    this.videoWidth = settings.width || VIDEO_WIDTH;
    this.videoHeight = settings.height || VIDEO_HEIGHT;
    this.videoFPS = Math.round(settings.frameRate || VIDEO_FPS);

    const codecCandidates = this.videoCodecName === "h265" ? H265_CODEC_CANDIDATES : H264_CODEC_CANDIDATES;
    let selectedConfig;
    for (const codec of codecCandidates) {
      const config = {
        codec,
        width: this.videoWidth,
        height: this.videoHeight,
        bitrate: VIDEO_BITRATE,
        framerate: this.videoFPS,
        latencyMode: "realtime",
        hardwareAcceleration: "prefer-hardware",
        ...videoCodecConfigExtension(this.videoCodecName)
      };

      try {
        const support = await VideoEncoder.isConfigSupported(config);
        if (support.supported) {
          selectedConfig = support.config || config;
          break;
        }
      } catch {
        // Try the next codec string.
      }
    }

    if (!selectedConfig) {
      throw new Error(`Browser does not support ${this.videoCodecName.toUpperCase()} WebCodecs encoding`);
    }

    this.videoCodec = selectedConfig.codec;
    this.videoEncoder = new VideoEncoder({
      output: (chunk, metadata) => this.handleVideoChunk(chunk, metadata),
      error: err => this.handleFatalError(err)
    });
    this.videoEncoder.configure(selectedConfig);
  }

  async createAudioEncoder() {
    const config = {
      codec: "mp4a.40.2",
      sampleRate: this.audioSampleRate,
      numberOfChannels: this.audioChannels,
      bitrate: AAC_BITRATE
    };

    const support = await AudioEncoder.isConfigSupported(config);
    if (!support.supported) {
      throw new Error("Browser does not support AAC WebCodecs encoding");
    }

    this.audioCodec = config.codec;
    this.audioEncoder = new AudioEncoder({
      output: (chunk, metadata) => this.handleAudioChunk(chunk, metadata),
      error: err => this.handleFatalError(err)
    });
    this.audioEncoder.configure(support.config || config);
  }

  async openWebSocket(rtspURL) {
    const ws = new WebSocket(this.makeWebSocketURL(rtspURL));
    this.ws = ws;

    await new Promise((resolve, reject) => {
      let settled = false;

      const fail = err => {
        if (settled) {
          return;
        }
        settled = true;
        reject(err);
      };

      ws.onopen = () => {
        this.postStatus("connecting", "Starting RTSP RECORD");
        ws.send(JSON.stringify({
          type: "start",
          url: rtspURL,
          video: {
            codec: this.videoCodecName,
            width: this.videoWidth,
            height: this.videoHeight,
            fps: this.videoFPS,
            bitrate: VIDEO_BITRATE
          },
          audio: {
            codec: this.audioCodecName,
            sampleRate: this.audioSampleRate || 0,
            channels: this.audioChannels || 0,
            objectType: this.audioCodecName === "aac" ? 2 : 0,
            bitrate: this.audioCodecName === "aac" ? AAC_BITRATE : 0
          }
        }));
      };

      ws.onmessage = event => {
        if (typeof event.data !== "string") {
          return;
        }

        try {
          const msg = JSON.parse(event.data);
          if (msg.type === "publish-status") {
            this.postStatus(msg.state || "connecting", msg.text || "Publishing");
            if (!settled && msg.state === "live") {
              settled = true;
              resolve();
            }
          }
        } catch {
          // Ignore non-control text messages.
        }
      };

      ws.onerror = () => fail(new Error("Publish WebSocket error"));
      ws.onclose = event => {
        if (this.ws === ws) {
          this.ws = undefined;
        }

        const reason = event.reason || "Publish WebSocket closed";
        if (!settled) {
          fail(new Error(reason));
          return;
        }

        if (this.running && !this.closedByStop) {
          this.handleFatalError(new Error(reason));
        }
      };
    });
  }

  startVideoCapture() {
    const track = this.stream.getVideoTracks()[0];
    this.nextVideoKeyframeAt = 0;

    if ("MediaStreamTrackProcessor" in window) {
      this.pumpVideoTrack(track);
      return;
    }

    this.pumpPreviewFrames();
  }

  async pumpVideoTrack(track) {
    try {
      const processor = new MediaStreamTrackProcessor({ track });
      this.videoReader = processor.readable.getReader();

      while (this.running) {
        const result = await this.videoReader.read();
        if (result.done || !result.value) {
          break;
        }

        const frame = result.value;
        try {
          this.encodeVideoFrame(frame);
        } finally {
          frame.close();
        }
      }
    } catch (err) {
      if (this.running) {
        this.handleFatalError(err);
      }
    }
  }

  pumpPreviewFrames() {
    const encode = (_now, metadata) => {
      if (!this.running || !this.preview || this.preview.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
        this.schedulePreviewFrame(encode);
        return;
      }

      try {
        const timestamp = metadata?.mediaTime !== undefined
          ? Math.round(metadata.mediaTime * 1_000_000)
          : Math.round(performance.now() * 1000);
        const frame = new VideoFrame(this.preview, { timestamp });
        try {
          this.encodeVideoFrame(frame);
        } finally {
          frame.close();
        }
      } catch (err) {
        this.handleFatalError(err);
        return;
      }

      this.schedulePreviewFrame(encode);
    };

    this.schedulePreviewFrame(encode);
  }

  schedulePreviewFrame(callback) {
    if (!this.running || !this.preview) {
      return;
    }

    if (this.preview.requestVideoFrameCallback) {
      this.videoFrameCallbackId = this.preview.requestVideoFrameCallback(callback);
      return;
    }

    this.videoTimer = setTimeout(() => callback(), Math.round(1000 / VIDEO_FPS));
  }

  encodeVideoFrame(frame) {
    if (!this.videoEncoder || this.videoEncoder.state !== "configured") {
      return;
    }
    if (this.isWebSocketBacklogged()) {
      this.stats.dropped += 1;
      this.requestVideoKeyframe();
      this.emitStats();
      return;
    }
    if (this.videoEncoder.encodeQueueSize > MAX_VIDEO_ENCODE_QUEUE) {
      this.stats.dropped += 1;
      this.emitStats();
      return;
    }

    const now = performance.now();
    const keyFrame = this.forceNextVideoKeyframe || now >= this.nextVideoKeyframeAt;
    if (keyFrame) {
      this.nextVideoKeyframeAt = now + VIDEO_KEYFRAME_INTERVAL_MS;
      this.forceNextVideoKeyframe = false;
    }

    this.videoEncoder.encode(frame, { keyFrame });
  }

  async startAudioCapture() {
    const audioTrack = this.stream.getAudioTracks()[0];
    if (!audioTrack) {
      throw new Error("No microphone audio track");
    }

    await this.audioContext.audioWorklet.addModule(`./publish-audio-worklet.js?v=${PUBLISH_AUDIO_WORKLET_VERSION}`);
    this.audioSource = this.audioContext.createMediaStreamSource(this.stream);
    this.audioNode = new AudioWorkletNode(this.audioContext, "rtsp-publish-capture", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [this.audioChannels],
      processorOptions: {
        channels: this.audioChannels,
        frameSize: this.audioFrameSize
      }
    });
    this.audioMute = this.audioContext.createGain();
    this.audioMute.gain.value = 0;
    this.audioNode.port.onmessage = event => this.handleAudioBlock(event.data);

    this.audioSource.connect(this.audioNode);
    this.audioNode.connect(this.audioMute);
    this.audioMute.connect(this.audioContext.destination);
    await this.audioContext.resume();
  }

  handleAudioBlock(msg) {
    if (!this.running || !msg || msg.type !== "audio") {
      return;
    }
    if (this.audioCodecName === "aac" && (!this.audioEncoder || this.audioEncoder.state !== "configured")) {
      return;
    }
    if (this.audioCodecName === "aac" && this.audioEncoder.encodeQueueSize > MAX_AUDIO_ENCODE_QUEUE) {
      this.stats.dropped += 1;
      this.emitStats();
      return;
    }

    const frames = msg.frames || 0;
    if (frames <= 0 || !Array.isArray(msg.channelData)) {
      return;
    }

    const planes = msg.channelData.map(buffer => new Float32Array(buffer));
    const interleaved = new Float32Array(frames * this.audioChannels);
    for (let frame = 0; frame < frames; frame += 1) {
      for (let channel = 0; channel < this.audioChannels; channel += 1) {
        const source = planes[channel] || planes[0];
        interleaved[(frame * this.audioChannels) + channel] = source ? source[frame] || 0 : 0;
      }
    }

    const timestamp = Math.round(this.audioFrameCursor * 1_000_000 / this.audioSampleRate);
    this.audioFrameCursor += frames;

    if (this.audioCodecName === "pcmu" || this.audioCodecName === "pcma") {
      const payload = encodeG711(interleaved, this.audioCodecName);
      if (this.sendMediaPacket(FRAME_TYPE_AUDIO, this.audioPacketCodec, true, timestamp, payload)) {
        this.stats.audioFrames += 1;
        this.stats.bytes += payload.byteLength;
        this.emitStats();
      }
      return;
    }

    const audioData = new AudioData({
      format: "f32",
      sampleRate: this.audioSampleRate,
      numberOfFrames: frames,
      numberOfChannels: this.audioChannels,
      timestamp,
      data: interleaved
    });

    try {
      this.audioEncoder.encode(audioData);
    } finally {
      audioData.close();
    }
  }

  handleVideoChunk(chunk, metadata) {
    if (!this.running) {
      return;
    }

    let payload = copyEncodedChunk(chunk);
    const keyframe = chunk.type === "key";
    if (this.videoRecoveryMode && !keyframe) {
      this.stats.dropped += 1;
      this.emitStats();
      return;
    }

    if (this.videoCodecName === "h264") {
      this.updateH264ParameterSets(metadata);
      if (keyframe) {
        payload = ensureH264ParameterSets(payload, this.h264SPS, this.h264PPS);
      }
    } else {
      payload = ensureAnnexB(payload);
      this.updateH265ParameterSets(payload);
      if (keyframe) {
        payload = ensureH265ParameterSets(payload, this.h265VPS, this.h265SPS, this.h265PPS);
      }
    }

    const timestampUs = this.normalizeTimestamp("video", chunk.timestamp);
    if (!this.sendMediaPacket(FRAME_TYPE_VIDEO, this.videoPacketCodec, keyframe, timestampUs, payload)) {
      this.requestVideoKeyframe();
      return;
    }
    if (keyframe) {
      this.videoRecoveryMode = false;
    }

    this.stats.videoFrames += 1;
    this.stats.bytes += payload.byteLength;
    this.emitStats();
  }

  updateH264ParameterSets(metadata) {
    const description = metadata?.decoderConfig?.description;
    if (!description) {
      return;
    }

    const parameterSets = parseAVCDecoderConfig(description);
    if (parameterSets.sps) {
      this.h264SPS = parameterSets.sps;
    }
    if (parameterSets.pps) {
      this.h264PPS = parameterSets.pps;
    }
  }

  updateH265ParameterSets(payload) {
    for (const nalu of splitAnnexB(payload)) {
      const type = h265NALUType(nalu);
      if (type === 32) {
        this.h265VPS = nalu.slice();
      } else if (type === 33) {
        this.h265SPS = nalu.slice();
      } else if (type === 34) {
        this.h265PPS = nalu.slice();
      }
    }
  }

  handleAudioChunk(chunk) {
    if (!this.running) {
      return;
    }

    const payload = copyEncodedChunk(chunk);
    const timestampUs = this.normalizeTimestamp("audio", chunk.timestamp);
    if (this.sendMediaPacket(FRAME_TYPE_AUDIO, CODEC_AAC, true, timestampUs, payload)) {
      this.stats.audioFrames += 1;
      this.stats.bytes += payload.byteLength;
      this.emitStats();
    }
  }

  sendMediaPacket(frameType, codec, keyframe, timestampUs, payload) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return false;
    }
    if (this.ws.bufferedAmount > MAX_WEBSOCKET_BUFFERED_BYTES) {
      this.stats.dropped += 1;
      this.emitStats();
      return false;
    }

    this.ws.send(buildMediaPacket(frameType, codec, keyframe, timestampUs, payload));
    return true;
  }

  isWebSocketBacklogged() {
    return Boolean(this.ws && this.ws.readyState === WebSocket.OPEN &&
      this.ws.bufferedAmount > MAX_WEBSOCKET_BUFFERED_BYTES);
  }

  requestVideoKeyframe() {
    this.videoRecoveryMode = true;
    this.forceNextVideoKeyframe = true;
    this.nextVideoKeyframeAt = 0;
  }

  normalizeTimestamp(kind, timestamp) {
    let value = Number.isFinite(timestamp) ? Math.round(timestamp) : Math.round(performance.now() * 1000);
    if (value < 0) {
      value = 0;
    }

    const key = kind === "audio" ? "audioTimestampBase" : "videoTimestampBase";
    if (this[key] === undefined) {
      this[key] = value;
    }
    return Math.max(0, value - this[key]);
  }

  handleFatalError(err) {
    if (!this.running) {
      return;
    }

    const message = err?.message || String(err);
    this.stop({ silent: true }).finally(() => {
      this.postStatus("error", message);
      this.emitStats(true);
    });
  }

  postStatus(state, text) {
    this.onStatus({ state, text });
  }

  resetStats() {
    this.stats = {
      videoFrames: 0,
      audioFrames: 0,
      dropped: 0,
      bytes: 0
    };
    this.lastStatsAt = 0;
    this.audioFrameCursor = 0;
    this.videoTimestampBase = undefined;
    this.audioTimestampBase = undefined;
    this.h264SPS = undefined;
    this.h264PPS = undefined;
    this.h265VPS = undefined;
    this.h265SPS = undefined;
    this.h265PPS = undefined;
    this.videoRecoveryMode = false;
    this.forceNextVideoKeyframe = false;
  }

  emitStats(force = false) {
    const now = performance.now();
    if (!force && now - this.lastStatsAt < 500) {
      return;
    }

    this.lastStatsAt = now;
    this.onStats({
      ...this.stats,
      bufferedBytes: this.ws?.bufferedAmount || 0,
      videoCodec: this.videoCodec || "-",
      audioCodec: this.audioCodec || "-",
      audioSampleRate: this.audioSampleRate || this.audioTargetSampleRate || AAC_SAMPLE_RATE,
      audioChannels: this.audioChannels || AAC_CHANNELS
    });
  }
}

function normalizeVideoCodecName(codec) {
  const value = String(codec || "h264").trim().toLowerCase();
  if (value === "" || value === "h264" || value === "avc") {
    return "h264";
  }
  if (value === "h265" || value === "hevc") {
    return "h265";
  }
  throw new Error(`Unsupported publish video codec: ${codec}`);
}

function normalizeAudioCodecName(codec) {
  const value = String(codec || "aac").trim().toLowerCase();
  if (value === "" || value === "aac") {
    return "aac";
  }
  if (["pcma", "g711", "g711a", "g.711a", "alaw", "a-law"].includes(value)) {
    return "pcma";
  }
  if (["pcmu", "g711u", "g.711u", "ulaw", "u-law", "mulaw", "mu-law"].includes(value)) {
    return "pcmu";
  }
  if (["none", "off", "disabled"].includes(value)) {
    return "none";
  }
  throw new Error(`Unsupported publish audio codec: ${codec}`);
}

function videoCodecConfigExtension(codec) {
  if (codec === "h265") {
    return { hevc: { format: "annexb" } };
  }
  return { avc: { format: "annexb" } };
}

function audioPacketCodec(codec) {
  if (codec === "pcmu") {
    return CODEC_PCMU;
  }
  if (codec === "pcma") {
    return CODEC_PCMA;
  }
  return CODEC_AAC;
}

function audioCodecDisplayName(codec) {
  if (codec === "pcmu") {
    return "PCMU";
  }
  if (codec === "pcma") {
    return "PCMA";
  }
  if (codec === "none") {
    return "none";
  }
  return "mp4a.40.2";
}

function buildMediaPacket(frameType, codec, keyframe, timestampUs, payload) {
  const packet = new Uint8Array(HEADER_SIZE + payload.byteLength);
  const view = new DataView(packet.buffer);
  const timestamp = Math.max(0, Math.round(timestampUs));
  const timestampHigh = Math.floor(timestamp / 2 ** 32);
  const timestampLow = timestamp - (timestampHigh * 2 ** 32);

  packet[0] = frameType;
  packet[1] = codec;
  packet[2] = keyframe ? 1 : 0;
  view.setUint32(4, timestampHigh);
  view.setUint32(8, timestampLow);
  view.setUint32(12, payload.byteLength);
  packet.set(payload, HEADER_SIZE);

  return packet;
}

function copyEncodedChunk(chunk) {
  const payload = new Uint8Array(chunk.byteLength);
  chunk.copyTo(payload);
  return payload;
}

function encodeG711(samples, codec) {
  const payload = new Uint8Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) {
    const pcm = floatToPCM16(samples[i]);
    payload[i] = codec === "pcmu" ? encodeMuLaw(pcm) : encodeALaw(pcm);
  }
  return payload;
}

function floatToPCM16(sample) {
  const value = Math.max(-1, Math.min(1, Number.isFinite(sample) ? sample : 0));
  return value < 0 ? Math.round(value * 32768) : Math.round(value * 32767);
}

function encodeMuLaw(sample) {
  const bias = 0x84;
  const clip = 32635;
  let sign = 0;
  let magnitude = sample;

  if (magnitude < 0) {
    sign = 0x80;
    magnitude = -magnitude;
  }

  magnitude = Math.min(clip, magnitude) + bias;

  let exponent = 7;
  for (let mask = 0x4000; exponent > 0 && (magnitude & mask) === 0; mask >>= 1) {
    exponent -= 1;
  }

  const mantissa = (magnitude >> (exponent + 3)) & 0x0f;
  return (~(sign | (exponent << 4) | mantissa)) & 0xff;
}

function encodeALaw(sample) {
  let sign = 0x80;
  let magnitude = sample;

  if (magnitude < 0) {
    sign = 0;
    magnitude = -magnitude;
  }

  magnitude = Math.min(32767, magnitude);

  let compressed;
  if (magnitude >= 256) {
    let exponent = 7;
    for (let mask = 0x4000; exponent > 0 && (magnitude & mask) === 0; mask >>= 1) {
      exponent -= 1;
    }
    const mantissa = (magnitude >> (exponent + 3)) & 0x0f;
    compressed = sign | (exponent << 4) | mantissa;
  } else {
    compressed = sign | (magnitude >> 4);
  }

  return (compressed ^ 0x55) & 0xff;
}

function parseAVCDecoderConfig(description) {
  const bytes = bufferSourceBytes(description);
  if (bytes.byteLength < 7 || bytes[0] !== 1) {
    return {};
  }

  let offset = 5;
  const spsCount = bytes[offset] & 0x1f;
  offset += 1;

  let sps;
  for (let i = 0; i < spsCount; i += 1) {
    if (offset + 2 > bytes.byteLength) {
      return { sps };
    }
    const length = (bytes[offset] << 8) | bytes[offset + 1];
    offset += 2;
    if (offset + length > bytes.byteLength) {
      return { sps };
    }
    if (!sps) {
      sps = bytes.slice(offset, offset + length);
    }
    offset += length;
  }

  if (offset >= bytes.byteLength) {
    return { sps };
  }

  const ppsCount = bytes[offset];
  offset += 1;
  let pps;
  for (let i = 0; i < ppsCount; i += 1) {
    if (offset + 2 > bytes.byteLength) {
      return { sps, pps };
    }
    const length = (bytes[offset] << 8) | bytes[offset + 1];
    offset += 2;
    if (offset + length > bytes.byteLength) {
      return { sps, pps };
    }
    if (!pps) {
      pps = bytes.slice(offset, offset + length);
    }
    offset += length;
  }

  return { sps, pps };
}

function ensureH264ParameterSets(payload, sps, pps) {
  if (!sps || !pps) {
    return payload;
  }

  const annexBPayload = isAnnexB(payload) ? payload : avccToAnnexB(payload);
  if (annexBHasNALUType(annexBPayload, 7) && annexBHasNALUType(annexBPayload, 8)) {
    return annexBPayload;
  }

  const out = new Uint8Array(4 + sps.byteLength + 4 + pps.byteLength + annexBPayload.byteLength);
  let offset = 0;
  offset = writeAnnexBNALU(out, offset, sps);
  offset = writeAnnexBNALU(out, offset, pps);
  out.set(annexBPayload, offset);
  return out;
}

function ensureH265ParameterSets(payload, vps, sps, pps) {
  if (!vps || !sps || !pps) {
    return payload;
  }

  const annexBPayload = ensureAnnexB(payload);
  const hasVPS = annexBHasH265NALUType(annexBPayload, 32);
  const hasSPS = annexBHasH265NALUType(annexBPayload, 33);
  const hasPPS = annexBHasH265NALUType(annexBPayload, 34);
  if (hasVPS && hasSPS && hasPPS) {
    return annexBPayload;
  }

  const extraLength = (hasVPS ? 0 : 4 + vps.byteLength) +
    (hasSPS ? 0 : 4 + sps.byteLength) +
    (hasPPS ? 0 : 4 + pps.byteLength);
  const out = new Uint8Array(extraLength + annexBPayload.byteLength);
  let offset = 0;
  if (!hasVPS) {
    offset = writeAnnexBNALU(out, offset, vps);
  }
  if (!hasSPS) {
    offset = writeAnnexBNALU(out, offset, sps);
  }
  if (!hasPPS) {
    offset = writeAnnexBNALU(out, offset, pps);
  }
  out.set(annexBPayload, offset);
  return out;
}

function ensureAnnexB(payload) {
  return isAnnexB(payload) ? payload : lengthPrefixedToAnnexB(payload);
}

function avccToAnnexB(payload) {
  return lengthPrefixedToAnnexB(payload);
}

function lengthPrefixedToAnnexB(payload) {
  let offset = 0;
  const nalus = [];
  let total = 0;

  while (offset + 4 <= payload.byteLength) {
    const length = (
      (payload[offset] << 24) |
      (payload[offset + 1] << 16) |
      (payload[offset + 2] << 8) |
      payload[offset + 3]
    ) >>> 0;
    offset += 4;
    if (length === 0 || offset + length > payload.byteLength) {
      return payload;
    }

    const nalu = payload.subarray(offset, offset + length);
    nalus.push(nalu);
    total += 4 + nalu.byteLength;
    offset += length;
  }

  if (offset !== payload.byteLength || nalus.length === 0) {
    return payload;
  }

  const out = new Uint8Array(total);
  let outOffset = 0;
  for (const nalu of nalus) {
    outOffset = writeAnnexBNALU(out, outOffset, nalu);
  }
  return out;
}

function splitAnnexB(payload) {
  const nalus = [];
  let start = findStartCode(payload, 0);
  while (start) {
    const naluStart = start.index + start.length;
    const next = findStartCode(payload, naluStart);
    let naluEnd = next ? next.index : payload.byteLength;
    while (naluEnd > naluStart && payload[naluEnd - 1] === 0) {
      naluEnd -= 1;
    }
    if (naluEnd > naluStart) {
      nalus.push(payload.subarray(naluStart, naluEnd));
    }
    if (!next) {
      break;
    }
    start = next;
  }
  return nalus;
}

function h265NALUType(nalu) {
  return nalu.length >= 2 ? ((nalu[0] >> 1) & 0x3f) : -1;
}

function annexBHasH265NALUType(payload, type) {
  return splitAnnexB(payload).some(nalu => h265NALUType(nalu) === type);
}

function annexBHasNALUType(payload, type) {
  let start = findStartCode(payload, 0);
  while (start) {
    const naluStart = start.index + start.length;
    const next = findStartCode(payload, naluStart);
    const naluEnd = next ? next.index : payload.byteLength;

    if (naluEnd > naluStart && (payload[naluStart] & 0x1f) === type) {
      return true;
    }

    if (!next) {
      break;
    }
    start = next;
  }

  return false;
}

function isAnnexB(payload) {
  return findStartCode(payload, 0)?.index === 0;
}

function findStartCode(payload, offset) {
  for (let i = offset; i + 3 <= payload.byteLength; i += 1) {
    if (payload[i] === 0 && payload[i + 1] === 0) {
      if (payload[i + 2] === 1) {
        return { index: i, length: 3 };
      }
      if (i + 3 < payload.byteLength && payload[i + 2] === 0 && payload[i + 3] === 1) {
        return { index: i, length: 4 };
      }
    }
  }
  return undefined;
}

function writeAnnexBNALU(target, offset, nalu) {
  target[offset] = 0;
  target[offset + 1] = 0;
  target[offset + 2] = 0;
  target[offset + 3] = 1;
  target.set(nalu, offset + 4);
  return offset + 4 + nalu.byteLength;
}

function bufferSourceBytes(source) {
  if (source instanceof ArrayBuffer) {
    return new Uint8Array(source);
  }
  if (ArrayBuffer.isView(source)) {
    return new Uint8Array(source.buffer, source.byteOffset, source.byteLength);
  }
  return new Uint8Array();
}
