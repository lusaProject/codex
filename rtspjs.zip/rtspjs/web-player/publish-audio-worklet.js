class RTSPPublishCapture extends AudioWorkletProcessor {
  constructor(options) {
    super();

    const processorOptions = options.processorOptions || {};
    this.channels = Math.max(1, Math.min(2, processorOptions.channels || 2));
    this.frameSize = Math.max(128, processorOptions.frameSize || 1024);
    this.pending = Array.from({ length: this.channels }, () => new Float32Array(this.frameSize));
    this.offset = 0;
  }

  process(inputs, outputs) {
    const input = inputs[0] || [];
    const output = outputs[0] || [];
    const frames = input[0]?.length || output[0]?.length || 128;

    for (const channel of output) {
      channel.fill(0);
    }

    let inputOffset = 0;
    while (inputOffset < frames) {
      const copyFrames = Math.min(this.frameSize - this.offset, frames - inputOffset);

      for (let channel = 0; channel < this.channels; channel += 1) {
        const source = input[channel] || input[0];
        const target = this.pending[channel];
        for (let frame = 0; frame < copyFrames; frame += 1) {
          target[this.offset + frame] = source ? source[inputOffset + frame] || 0 : 0;
        }
      }

      this.offset += copyFrames;
      inputOffset += copyFrames;

      if (this.offset === this.frameSize) {
        this.flushPending();
      }
    }

    return true;
  }

  flushPending() {
    const channelData = this.pending.map(samples => samples.buffer);
    this.port.postMessage({
      type: "audio",
      frames: this.frameSize,
      channelData
    }, channelData);

    this.pending = Array.from({ length: this.channels }, () => new Float32Array(this.frameSize));
    this.offset = 0;
  }
}

registerProcessor("rtsp-publish-capture", RTSPPublishCapture);
