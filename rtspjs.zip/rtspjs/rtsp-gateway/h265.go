package gateway

import (
	"fmt"

	"github.com/bluenviron/mediacommon/v2/pkg/codecs/h265"
)

func IsH265Keyframe(au [][]byte) bool {
	return h265.IsRandomAccess(au)
}

func UpdateH265ParameterSets(au [][]byte, vps, sps, pps []byte) ([]byte, []byte, []byte) {
	for _, nalu := range au {
		if len(nalu) < 2 {
			continue
		}

		switch h265NALUType(nalu) {
		case h265.NALUType_VPS_NUT:
			vps = cloneBytes(nalu)
		case h265.NALUType_SPS_NUT:
			sps = cloneBytes(nalu)
		case h265.NALUType_PPS_NUT:
			pps = cloneBytes(nalu)
		}
	}

	return vps, sps, pps
}

func PrependH265ParameterSets(au [][]byte, vps, sps, pps []byte) [][]byte {
	hasVPS := containsH265NALUType(au, h265.NALUType_VPS_NUT)
	hasSPS := containsH265NALUType(au, h265.NALUType_SPS_NUT)
	hasPPS := containsH265NALUType(au, h265.NALUType_PPS_NUT)

	if (vps == nil || hasVPS) && (sps == nil || hasSPS) && (pps == nil || hasPPS) {
		return au
	}

	out := make([][]byte, 0, len(au)+3)
	if vps != nil && !hasVPS {
		out = append(out, cloneBytes(vps))
	}
	if sps != nil && !hasSPS {
		out = append(out, cloneBytes(sps))
	}
	if pps != nil && !hasPPS {
		out = append(out, cloneBytes(pps))
	}
	out = append(out, au...)

	return out
}

func H265AnnexB(au [][]byte) ([]byte, error) {
	if len(au) == 0 {
		return nil, fmt.Errorf("empty H265 access unit")
	}

	size := 0
	for _, nalu := range au {
		if len(nalu) == 0 {
			continue
		}
		size += 4 + len(nalu)
	}

	if size == 0 {
		return nil, fmt.Errorf("empty H265 access unit")
	}

	out := make([]byte, 0, size)
	for _, nalu := range au {
		if len(nalu) == 0 {
			continue
		}
		out = append(out, 0, 0, 0, 1)
		out = append(out, nalu...)
	}

	return out, nil
}

func containsH265NALUType(au [][]byte, typ h265.NALUType) bool {
	for _, nalu := range au {
		if len(nalu) >= 2 && h265NALUType(nalu) == typ {
			return true
		}
	}

	return false
}

func h265NALUType(nalu []byte) h265.NALUType {
	return h265.NALUType((nalu[0] >> 1) & 0b111111)
}
