package gateway

import (
	"encoding/binary"
	"fmt"

	"github.com/bluenviron/gortsplib/v5/pkg/format"
	"github.com/bluenviron/mediacommon/v2/pkg/codecs/mpeg4audio"
)

const MPEG4AudioPayloadHeaderSize = 8

func BuildMPEG4AudioPayload(forma *format.MPEG4Audio, au []byte) ([]byte, error) {
	if forma == nil || forma.Config == nil {
		return nil, fmt.Errorf("missing MPEG-4 audio config")
	}

	description, err := forma.Config.Marshal()
	if err != nil {
		return nil, fmt.Errorf("marshal MPEG-4 audio config: %w", err)
	}
	if len(description) > int(^uint16(0)) {
		return nil, fmt.Errorf("MPEG-4 audio config too large: %d bytes", len(description))
	}

	sampleRate := forma.Config.SampleRate
	if sampleRate <= 0 {
		return nil, fmt.Errorf("invalid MPEG-4 audio sample rate: %d", sampleRate)
	}

	channelCount := mpeg4AudioChannelCount(forma.Config)
	if channelCount <= 0 || channelCount > 255 {
		return nil, fmt.Errorf("invalid MPEG-4 audio channel count: %d", channelCount)
	}

	out := make([]byte, MPEG4AudioPayloadHeaderSize+len(description)+len(au))
	binary.BigEndian.PutUint32(out[0:4], uint32(sampleRate))
	out[4] = byte(channelCount)
	out[5] = byte(forma.Config.Type)
	binary.BigEndian.PutUint16(out[6:8], uint16(len(description)))
	copy(out[MPEG4AudioPayloadHeaderSize:], description)
	copy(out[MPEG4AudioPayloadHeaderSize+len(description):], au)

	return out, nil
}

func mpeg4AudioChannelCount(conf *mpeg4audio.AudioSpecificConfig) int {
	switch conf.ChannelConfig {
	case 1, 2, 3, 4, 5, 6:
		return int(conf.ChannelConfig)
	case 7:
		return 8
	default:
		return 2
	}
}
