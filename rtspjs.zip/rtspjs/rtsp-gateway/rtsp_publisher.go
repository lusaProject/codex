package gateway

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"log"
	"strings"
	"sync"

	"github.com/bluenviron/gortsplib/v5"
	"github.com/bluenviron/gortsplib/v5/pkg/description"
	"github.com/bluenviron/gortsplib/v5/pkg/format"
	"github.com/bluenviron/mediacommon/v2/pkg/codecs/h264"
	"github.com/bluenviron/mediacommon/v2/pkg/codecs/mpeg4audio"
	"github.com/pion/rtp"
)

const (
	publishVideoPayloadType = 96
	publishAudioPayloadType = 97

	defaultPublishAudioSampleRate = 44100
	defaultPublishAudioChannels   = 2
	defaultPublishAudioObjectType = int(mpeg4audio.ObjectTypeAACLC)
	defaultPublishG711SampleRate  = 8000
	defaultPublishG711Channels    = 1
)

type PublishConfig struct {
	Type  string             `json:"type"`
	URL   string             `json:"url"`
	Video PublishVideoConfig `json:"video"`
	Audio PublishAudioConfig `json:"audio"`
}

type PublishVideoConfig struct {
	Codec   string `json:"codec"`
	Width   int    `json:"width"`
	Height  int    `json:"height"`
	FPS     int    `json:"fps"`
	Bitrate int    `json:"bitrate"`
}

type PublishAudioConfig struct {
	Codec      string `json:"codec"`
	SampleRate int    `json:"sampleRate"`
	Channels   int    `json:"channels"`
	ObjectType int    `json:"objectType"`
	Bitrate    int    `json:"bitrate"`
}

type accessUnitRTPEncoder interface {
	Encode([][]byte) ([]*rtp.Packet, error)
}

type sampleRTPEncoder interface {
	Encode([]byte) ([]*rtp.Packet, error)
}

type publishDescription struct {
	session *description.Session

	videoMedia *description.Media
	videoForma format.Format
	h264Forma  *format.H264
	h265Forma  *format.H265

	audioMedia      *description.Media
	audioForma      format.Format
	mpeg4AudioForma *format.MPEG4Audio
	g711Forma       *format.G711
}

type RTSPPublisher struct {
	Logger *log.Logger

	client *gortsplib.Client

	videoMedia      *description.Media
	audioMedia      *description.Media
	videoForma      format.Format
	audioForma      format.Format
	h264VideoForma  *format.H264
	h265VideoForma  *format.H265
	mpeg4AudioForma *format.MPEG4Audio
	g711AudioForma  *format.G711

	videoEncoder       accessUnitRTPEncoder
	audioAUEncoder     accessUnitRTPEncoder
	audioSampleEncoder sampleRTPEncoder

	videoTS rtpTimestampState
	audioTS rtpTimestampState

	h264SPS []byte
	h264PPS []byte
	h265VPS []byte
	h265SPS []byte
	h265PPS []byte

	mu        sync.Mutex
	closeOnce sync.Once
}

func NewRTSPPublisher(
	ctx context.Context,
	rtspURL string,
	cfg PublishConfig,
	logger *log.Logger,
) (*RTSPPublisher, error) {
	publishDesc, err := buildPublishDescription(cfg)
	if err != nil {
		return nil, err
	}

	var videoEncoder accessUnitRTPEncoder
	switch {
	case publishDesc.h264Forma != nil:
		videoEncoder, err = publishDesc.h264Forma.CreateEncoder()
		if err != nil {
			return nil, fmt.Errorf("create H264 RTP encoder: %w", err)
		}
	case publishDesc.h265Forma != nil:
		videoEncoder, err = publishDesc.h265Forma.CreateEncoder()
		if err != nil {
			return nil, fmt.Errorf("create H265 RTP encoder: %w", err)
		}
	default:
		return nil, fmt.Errorf("missing publish video format")
	}

	var audioAUEncoder accessUnitRTPEncoder
	var audioSampleEncoder sampleRTPEncoder
	switch {
	case publishDesc.mpeg4AudioForma != nil:
		audioAUEncoder, err = publishDesc.mpeg4AudioForma.CreateEncoder()
		if err != nil {
			return nil, fmt.Errorf("create AAC RTP encoder: %w", err)
		}
	case publishDesc.g711Forma != nil:
		audioSampleEncoder, err = publishDesc.g711Forma.CreateEncoder()
		if err != nil {
			return nil, fmt.Errorf("create G711 RTP encoder: %w", err)
		}
	}

	videoRandomStart, err := randomUint32()
	if err != nil {
		return nil, fmt.Errorf("create video RTP timestamp base: %w", err)
	}
	audioRandomStart, err := randomUint32()
	if err != nil {
		return nil, fmt.Errorf("create audio RTP timestamp base: %w", err)
	}

	proto := gortsplib.ProtocolTCP
	client := &gortsplib.Client{
		Protocol:       &proto,
		WriteQueueSize: 1024,
	}

	if err := client.StartRecording(rtspURL, publishDesc.session); err != nil {
		return nil, fmt.Errorf("start RTSP RECORD: %w", err)
	}

	p := &RTSPPublisher{
		Logger:             logger,
		client:             client,
		videoMedia:         publishDesc.videoMedia,
		audioMedia:         publishDesc.audioMedia,
		videoForma:         publishDesc.videoForma,
		audioForma:         publishDesc.audioForma,
		h264VideoForma:     publishDesc.h264Forma,
		h265VideoForma:     publishDesc.h265Forma,
		mpeg4AudioForma:    publishDesc.mpeg4AudioForma,
		g711AudioForma:     publishDesc.g711Forma,
		videoEncoder:       videoEncoder,
		audioAUEncoder:     audioAUEncoder,
		audioSampleEncoder: audioSampleEncoder,
		videoTS:            rtpTimestampState{randomStart: videoRandomStart},
		audioTS:            rtpTimestampState{randomStart: audioRandomStart},
	}

	go func() {
		<-ctx.Done()
		p.Close()
	}()

	return p, nil
}

func (p *RTSPPublisher) Close() {
	if p == nil || p.client == nil {
		return
	}

	p.closeOnce.Do(func() {
		p.client.Close()
	})
}

func (p *RTSPPublisher) WritePacket(pkt WebPacket) error {
	p.mu.Lock()
	defer p.mu.Unlock()

	switch pkt.FrameType {
	case FrameTypeVideo:
		return p.writeVideoPacket(pkt)
	case FrameTypeAudio:
		return p.writeAudioPacket(pkt)
	default:
		return fmt.Errorf("unsupported publish frame type: %d", pkt.FrameType)
	}
}

func (p *RTSPPublisher) writeVideoPacket(pkt WebPacket) error {
	switch pkt.Codec {
	case CodecH264:
		return p.writeH264Packet(pkt)
	case CodecH265:
		return p.writeH265Packet(pkt)
	default:
		return fmt.Errorf("unsupported publish video codec: %d", pkt.Codec)
	}
}

func (p *RTSPPublisher) writeH264Packet(pkt WebPacket) error {
	if p.h264VideoForma == nil {
		return fmt.Errorf("publisher is configured for a different video codec")
	}
	if p.videoMedia == nil || p.videoEncoder == nil {
		return nil
	}

	au, err := h264AccessUnitFromPayload(pkt.Payload)
	if err != nil {
		return err
	}

	nextSPS, nextPPS := UpdateH264ParameterSets(au, p.h264SPS, p.h264PPS)
	if !bytes.Equal(nextSPS, p.h264SPS) || !bytes.Equal(nextPPS, p.h264PPS) {
		p.h264SPS = nextSPS
		p.h264PPS = nextPPS
		p.h264VideoForma.SafeSetParams(cloneBytes(p.h264SPS), cloneBytes(p.h264PPS))
	}

	if pkt.Keyframe {
		au = PrependH264ParameterSets(au, p.h264SPS, p.h264PPS)
	}

	rtpPackets, err := p.videoEncoder.Encode(au)
	if err != nil {
		return fmt.Errorf("packetize H264 access unit: %w", err)
	}

	timestamp := p.videoTS.timestamp(pkt.TimestampUs, p.videoForma.ClockRate())
	for _, rtpPacket := range rtpPackets {
		rtpPacket.Timestamp += timestamp
		if err := p.client.WritePacketRTP(p.videoMedia, rtpPacket); err != nil {
			return fmt.Errorf("write H264 RTP packet: %w", err)
		}
	}

	return nil
}

func (p *RTSPPublisher) writeH265Packet(pkt WebPacket) error {
	if p.h265VideoForma == nil {
		return fmt.Errorf("publisher is configured for a different video codec")
	}
	if p.videoMedia == nil || p.videoEncoder == nil {
		return nil
	}

	au, err := h265AccessUnitFromPayload(pkt.Payload)
	if err != nil {
		return err
	}

	nextVPS, nextSPS, nextPPS := UpdateH265ParameterSets(au, p.h265VPS, p.h265SPS, p.h265PPS)
	if !bytes.Equal(nextVPS, p.h265VPS) ||
		!bytes.Equal(nextSPS, p.h265SPS) ||
		!bytes.Equal(nextPPS, p.h265PPS) {
		p.h265VPS = nextVPS
		p.h265SPS = nextSPS
		p.h265PPS = nextPPS
		p.h265VideoForma.SafeSetParams(
			cloneBytes(p.h265VPS),
			cloneBytes(p.h265SPS),
			cloneBytes(p.h265PPS),
		)
	}

	if pkt.Keyframe {
		au = PrependH265ParameterSets(au, p.h265VPS, p.h265SPS, p.h265PPS)
	}

	rtpPackets, err := p.videoEncoder.Encode(au)
	if err != nil {
		return fmt.Errorf("packetize H265 access unit: %w", err)
	}

	timestamp := p.videoTS.timestamp(pkt.TimestampUs, p.videoForma.ClockRate())
	for _, rtpPacket := range rtpPackets {
		rtpPacket.Timestamp += timestamp
		if err := p.client.WritePacketRTP(p.videoMedia, rtpPacket); err != nil {
			return fmt.Errorf("write H265 RTP packet: %w", err)
		}
	}

	return nil
}

func (p *RTSPPublisher) writeAudioPacket(pkt WebPacket) error {
	switch pkt.Codec {
	case CodecAAC:
		return p.writeAACPacket(pkt)
	case CodecPCMU, CodecPCMA:
		return p.writeG711Packet(pkt)
	default:
		return fmt.Errorf("unsupported publish audio codec: %d", pkt.Codec)
	}
}

func (p *RTSPPublisher) writeAACPacket(pkt WebPacket) error {
	if p.mpeg4AudioForma == nil {
		return fmt.Errorf("publisher is configured for a different audio codec")
	}
	if p.audioMedia == nil || p.audioAUEncoder == nil || len(pkt.Payload) == 0 {
		return nil
	}

	aus := mpeg4AudioAccessUnitsFromPayload(pkt.Payload)
	rtpPackets, err := p.audioAUEncoder.Encode(aus)
	if err != nil {
		return fmt.Errorf("packetize AAC access unit: %w", err)
	}

	timestamp := p.audioTS.timestamp(pkt.TimestampUs, p.audioForma.ClockRate())
	for _, rtpPacket := range rtpPackets {
		rtpPacket.Timestamp += timestamp
		if err := p.client.WritePacketRTP(p.audioMedia, rtpPacket); err != nil {
			return fmt.Errorf("write AAC RTP packet: %w", err)
		}
	}

	return nil
}

func (p *RTSPPublisher) writeG711Packet(pkt WebPacket) error {
	if p.g711AudioForma == nil {
		return fmt.Errorf("publisher is configured for a different audio codec")
	}
	if p.g711AudioForma.MULaw && pkt.Codec != CodecPCMU {
		return fmt.Errorf("publisher is configured for PCMU audio")
	}
	if !p.g711AudioForma.MULaw && pkt.Codec != CodecPCMA {
		return fmt.Errorf("publisher is configured for PCMA audio")
	}
	if p.audioMedia == nil || p.audioSampleEncoder == nil || len(pkt.Payload) == 0 {
		return nil
	}

	rtpPackets, err := p.audioSampleEncoder.Encode(pkt.Payload)
	if err != nil {
		return fmt.Errorf("packetize G711 samples: %w", err)
	}

	timestamp := p.audioTS.timestamp(pkt.TimestampUs, p.audioForma.ClockRate())
	for _, rtpPacket := range rtpPackets {
		rtpPacket.Timestamp += timestamp
		if err := p.client.WritePacketRTP(p.audioMedia, rtpPacket); err != nil {
			return fmt.Errorf("write G711 RTP packet: %w", err)
		}
	}

	return nil
}

func buildPublishDescription(
	cfg PublishConfig,
) (*publishDescription, error) {
	videoCodec, err := NormalizePublishVideoCodec(cfg.Video.Codec)
	if err != nil {
		return nil, err
	}

	var videoForma format.Format
	var h264Forma *format.H264
	var h265Forma *format.H265
	switch videoCodec {
	case "h264":
		h264Forma = &format.H264{
			PayloadTyp:        publishVideoPayloadType,
			PacketizationMode: 1,
		}
		videoForma = h264Forma
	case "h265":
		h265Forma = &format.H265{
			PayloadTyp: publishVideoPayloadType,
		}
		videoForma = h265Forma
	default:
		return nil, fmt.Errorf("unsupported publish video codec: %s", videoCodec)
	}

	videoMedia := &description.Media{
		Type:    description.MediaTypeVideo,
		Formats: []format.Format{videoForma},
	}

	medias := []*description.Media{videoMedia}

	audioCodec, err := NormalizePublishAudioCodec(cfg.Audio.Codec)
	if err != nil {
		return nil, err
	}

	var audioMedia *description.Media
	var audioForma format.Format
	var mpeg4AudioForma *format.MPEG4Audio
	var g711Forma *format.G711
	switch audioCodec {
	case "aac":
		sampleRate := cfg.Audio.SampleRate
		if sampleRate == 0 {
			sampleRate = defaultPublishAudioSampleRate
		}
		channels := cfg.Audio.Channels
		if channels == 0 {
			channels = defaultPublishAudioChannels
		}
		objectType := cfg.Audio.ObjectType
		if objectType == 0 {
			objectType = defaultPublishAudioObjectType
		}

		if sampleRate <= 0 {
			return nil, fmt.Errorf("invalid AAC sample rate: %d", sampleRate)
		}
		if channels <= 0 || channels > 8 {
			return nil, fmt.Errorf("invalid AAC channel count: %d", channels)
		}

		mpeg4AudioForma = &format.MPEG4Audio{
			PayloadTyp: publishAudioPayloadType,
			Config: &mpeg4audio.AudioSpecificConfig{
				Type:         mpeg4audio.ObjectType(objectType),
				SampleRate:   sampleRate,
				ChannelCount: channels,
			},
			SizeLength:       13,
			IndexLength:      3,
			IndexDeltaLength: 3,
		}
		audioForma = mpeg4AudioForma
		audioMedia = &description.Media{
			Type:    description.MediaTypeAudio,
			Formats: []format.Format{audioForma},
		}
		medias = append(medias, audioMedia)

	case "pcmu", "pcma":
		sampleRate := cfg.Audio.SampleRate
		if sampleRate == 0 {
			sampleRate = defaultPublishG711SampleRate
		}
		channels := cfg.Audio.Channels
		if channels == 0 {
			channels = defaultPublishG711Channels
		}

		if sampleRate <= 0 {
			return nil, fmt.Errorf("invalid G711 sample rate: %d", sampleRate)
		}
		if channels <= 0 || channels > 255 {
			return nil, fmt.Errorf("invalid G711 channel count: %d", channels)
		}

		mulaw := audioCodec == "pcmu"
		g711Forma = &format.G711{
			PayloadTyp:   g711PayloadType(mulaw, sampleRate, channels),
			MULaw:        mulaw,
			SampleRate:   sampleRate,
			ChannelCount: channels,
		}
		audioForma = g711Forma
		audioMedia = &description.Media{
			Type:    description.MediaTypeAudio,
			Formats: []format.Format{audioForma},
		}
		medias = append(medias, audioMedia)

	case "none":
	default:
		return nil, fmt.Errorf("unsupported publish audio codec: %s", audioCodec)
	}

	return &publishDescription{
		session:         &description.Session{Medias: medias},
		videoMedia:      videoMedia,
		videoForma:      videoForma,
		h264Forma:       h264Forma,
		h265Forma:       h265Forma,
		audioMedia:      audioMedia,
		audioForma:      audioForma,
		mpeg4AudioForma: mpeg4AudioForma,
		g711Forma:       g711Forma,
	}, nil
}

func NormalizePublishVideoCodec(codec string) (string, error) {
	switch strings.ToLower(strings.TrimSpace(codec)) {
	case "", "h264", "avc":
		return "h264", nil
	case "h265", "hevc":
		return "h265", nil
	default:
		return "", fmt.Errorf("unsupported publish video codec %q (supported: h264, h265)", codec)
	}
}

func NormalizePublishAudioCodec(codec string) (string, error) {
	switch strings.ToLower(strings.TrimSpace(codec)) {
	case "", "aac":
		return "aac", nil
	case "pcma", "g711", "g711a", "g.711a", "alaw", "a-law":
		return "pcma", nil
	case "pcmu", "g711u", "g.711u", "ulaw", "u-law", "mulaw", "mu-law":
		return "pcmu", nil
	case "none", "off", "disabled":
		return "none", nil
	default:
		return "", fmt.Errorf("unsupported publish audio codec %q (supported: aac, pcma/g711a, pcmu/g711u, none)", codec)
	}
}

func g711PayloadType(mulaw bool, sampleRate int, channels int) uint8 {
	if sampleRate == defaultPublishG711SampleRate && channels == defaultPublishG711Channels {
		if mulaw {
			return 0
		}
		return 8
	}
	return publishAudioPayloadType
}

func h264AccessUnitFromPayload(payload []byte) ([][]byte, error) {
	var annexB h264.AnnexB
	if err := annexB.Unmarshal(payload); err == nil {
		return annexB, nil
	}

	var avcc h264.AVCC
	if err := avcc.Unmarshal(payload); err == nil {
		return avcc, nil
	}

	return nil, fmt.Errorf("parse H264 payload as AnnexB or AVCC access unit")
}

func h265AccessUnitFromPayload(payload []byte) ([][]byte, error) {
	if au, ok := accessUnitFromAnnexB(payload); ok {
		return au, nil
	}

	if au, ok := accessUnitFromLengthPrefixed(payload); ok {
		return au, nil
	}

	return nil, fmt.Errorf("parse H265 payload as AnnexB or length-prefixed access unit")
}

func accessUnitFromAnnexB(payload []byte) ([][]byte, bool) {
	startIndex, startLength := findAnnexBStartCode(payload, 0)
	if startIndex < 0 {
		return nil, false
	}

	var au [][]byte
	for startIndex >= 0 {
		naluStart := startIndex + startLength
		nextIndex, nextLength := findAnnexBStartCode(payload, naluStart)

		naluEnd := len(payload)
		if nextIndex >= 0 {
			naluEnd = nextIndex
		}
		for naluEnd > naluStart && payload[naluEnd-1] == 0 {
			naluEnd--
		}
		if naluEnd > naluStart {
			au = append(au, payload[naluStart:naluEnd])
		}

		startIndex = nextIndex
		startLength = nextLength
	}

	return au, len(au) > 0
}

func accessUnitFromLengthPrefixed(payload []byte) ([][]byte, bool) {
	var au [][]byte
	for offset := 0; offset < len(payload); {
		if offset+4 > len(payload) {
			return nil, false
		}

		size := int(binary.BigEndian.Uint32(payload[offset : offset+4]))
		offset += 4
		if size <= 0 || offset+size > len(payload) {
			return nil, false
		}

		au = append(au, payload[offset:offset+size])
		offset += size
	}

	return au, len(au) > 0
}

func findAnnexBStartCode(payload []byte, offset int) (int, int) {
	for i := offset; i+3 <= len(payload); i++ {
		if payload[i] != 0 || payload[i+1] != 0 {
			continue
		}
		if payload[i+2] == 1 {
			return i, 3
		}
		if i+3 < len(payload) && payload[i+2] == 0 && payload[i+3] == 1 {
			return i, 4
		}
	}

	return -1, 0
}

func mpeg4AudioAccessUnitsFromPayload(payload []byte) [][]byte {
	var adtsPackets mpeg4audio.ADTSPackets
	if err := adtsPackets.Unmarshal(payload); err == nil && len(adtsPackets) > 0 {
		aus := make([][]byte, 0, len(adtsPackets))
		for _, packet := range adtsPackets {
			if len(packet.AU) > 0 {
				aus = append(aus, packet.AU)
			}
		}
		if len(aus) > 0 {
			return aus
		}
	}

	return [][]byte{payload}
}

type rtpTimestampState struct {
	initialized bool
	baseUs      uint64
	randomStart uint32
}

func (s *rtpTimestampState) timestamp(timestampUs uint64, clockRate int) uint32 {
	if !s.initialized {
		s.initialized = true
		s.baseUs = timestampUs
	}
	if timestampUs < s.baseUs {
		timestampUs = s.baseUs
	}

	elapsed := timestampUs - s.baseUs
	return s.randomStart + uint32(elapsed*uint64(clockRate)/1_000_000)
}

func randomUint32() (uint32, error) {
	var b [4]byte
	if _, err := rand.Read(b[:]); err != nil {
		return 0, err
	}
	return binary.BigEndian.Uint32(b[:]), nil
}
