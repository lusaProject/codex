package gateway

import (
	"encoding/binary"
	"fmt"
)

const (
	HeaderSize = 16

	FrameTypeVideo = 1
	FrameTypeAudio = 2

	CodecH264 = 1
	CodecH265 = 2
	CodecAAC  = 3
	CodecPCMU = 4
	CodecPCMA = 5
)

type WebPacket struct {
	FrameType   byte
	Codec       byte
	Keyframe    bool
	TimestampUs uint64
	Payload     []byte
}

func ParseWebPacket(data []byte) (WebPacket, error) {
	if len(data) < HeaderSize {
		return WebPacket{}, fmt.Errorf("web packet too short: %d bytes", len(data))
	}

	payloadLen := binary.BigEndian.Uint32(data[12:16])
	if uint64(payloadLen) > uint64(len(data)-HeaderSize) {
		return WebPacket{}, fmt.Errorf("payload length %d exceeds message length %d", payloadLen, len(data))
	}

	return WebPacket{
		FrameType:   data[0],
		Codec:       data[1],
		Keyframe:    data[2] == 1,
		TimestampUs: binary.BigEndian.Uint64(data[4:12]),
		Payload:     data[HeaderSize : HeaderSize+int(payloadLen)],
	}, nil
}

func BuildWebPacket(pkt WebPacket) ([]byte, error) {
	if len(pkt.Payload) > int(^uint32(0)) {
		return nil, fmt.Errorf("payload too large: %d bytes", len(pkt.Payload))
	}

	out := make([]byte, HeaderSize+len(pkt.Payload))
	out[0] = pkt.FrameType
	out[1] = pkt.Codec
	if pkt.Keyframe {
		out[2] = 1
	}

	binary.BigEndian.PutUint64(out[4:12], pkt.TimestampUs)
	binary.BigEndian.PutUint32(out[12:16], uint32(len(pkt.Payload)))
	copy(out[HeaderSize:], pkt.Payload)

	return out, nil
}
