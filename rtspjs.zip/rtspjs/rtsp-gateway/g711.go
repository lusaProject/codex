package gateway

import (
	"encoding/binary"
	"fmt"

	"github.com/bluenviron/gortsplib/v5/pkg/format"
)

const G711AudioPayloadHeaderSize = 5

func BuildG711Payload(forma *format.G711, encoded []byte) ([]byte, error) {
	if forma == nil {
		return nil, fmt.Errorf("missing G711 format")
	}

	if forma.SampleRate <= 0 {
		return nil, fmt.Errorf("invalid G711 sample rate: %d", forma.SampleRate)
	}

	if forma.ChannelCount <= 0 || forma.ChannelCount > 255 {
		return nil, fmt.Errorf("invalid G711 channel count: %d", forma.ChannelCount)
	}

	out := make([]byte, G711AudioPayloadHeaderSize+len(encoded))
	binary.BigEndian.PutUint32(out[0:4], uint32(forma.SampleRate))
	out[4] = byte(forma.ChannelCount)
	copy(out[G711AudioPayloadHeaderSize:], encoded)

	return out, nil
}

func G711WebCodec(forma *format.G711) byte {
	if forma.MULaw {
		return CodecPCMU
	}
	return CodecPCMA
}
