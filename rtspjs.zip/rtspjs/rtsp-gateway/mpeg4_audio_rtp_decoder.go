package gateway

import (
	"fmt"

	"github.com/bluenviron/gortsplib/v5/pkg/format"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtpmpeg4audio"
	"github.com/bluenviron/mediacommon/v2/pkg/bits"
	"github.com/bluenviron/mediacommon/v2/pkg/codecs/mpeg4audio"
	"github.com/pion/rtp"
)

type mpeg4AudioRTPDecoder struct {
	forma *format.MPEG4Audio
	base  *rtpmpeg4audio.Decoder

	fragmentHeader     []byte
	fragmentParts      [][]byte
	fragmentSize       int
	fragmentTargetSize int
	fragmentNextSeq    uint16
}

type mpeg4AudioRTPPayload struct {
	auSizes []int
	header  []byte
	data    []byte
}

func newMPEG4AudioRTPDecoder(forma *format.MPEG4Audio) (*mpeg4AudioRTPDecoder, error) {
	base, err := forma.CreateDecoder()
	if err != nil {
		return nil, err
	}

	return &mpeg4AudioRTPDecoder{
		forma: forma,
		base:  base,
	}, nil
}

func (d *mpeg4AudioRTPDecoder) Decode(pkt *rtp.Packet) ([][]byte, error) {
	info, parseErr := d.parsePayload(pkt.Payload)
	if parseErr == nil {
		fragmentedByTotalSize := len(info.auSizes) == 1 && len(info.data) < info.auSizes[0]
		if d.fragmentTargetSize > 0 || fragmentedByTotalSize {
			return d.decodeFragmented(pkt, info)
		}
	}

	return d.base.Decode(pkt)
}

func (d *mpeg4AudioRTPDecoder) decodeFragmented(pkt *rtp.Packet, info mpeg4AudioRTPPayload) ([][]byte, error) {
	if len(info.auSizes) != 1 {
		d.resetFragments()
		return nil, fmt.Errorf("a fragmented packet can only contain one AU")
	}

	auSize := info.auSizes[0]
	if auSize <= 0 {
		d.resetFragments()
		return nil, fmt.Errorf("invalid data length")
	}

	if d.fragmentTargetSize == 0 {
		if pkt.Marker {
			return nil, fmt.Errorf("discarding fragmented MPEG-4 audio packet without start")
		}

		d.fragmentHeader = cloneBytes(info.header)
		d.fragmentTargetSize = auSize
		d.fragmentNextSeq = pkt.SequenceNumber + 1
	} else {
		if pkt.SequenceNumber != d.fragmentNextSeq {
			d.resetFragments()
			return nil, fmt.Errorf("discarding frame since a RTP packet is missing")
		}
		if auSize != d.fragmentTargetSize {
			d.resetFragments()
			return nil, fmt.Errorf("fragmented AU size changed from %d to %d", d.fragmentTargetSize, auSize)
		}
		d.fragmentNextSeq++
	}

	d.fragmentParts = append(d.fragmentParts, cloneBytes(info.data))
	d.fragmentSize += len(info.data)
	if d.fragmentSize > mpeg4audio.MaxAccessUnitSize {
		size := d.fragmentSize
		d.resetFragments()
		return nil, fmt.Errorf("access unit size (%d) is too big, maximum is %d", size, mpeg4audio.MaxAccessUnitSize)
	}

	if !pkt.Marker {
		return nil, rtpmpeg4audio.ErrMorePacketsNeeded
	}

	if d.fragmentSize < d.fragmentTargetSize {
		size := d.fragmentSize
		targetSize := d.fragmentTargetSize
		d.resetFragments()
		return nil, fmt.Errorf("fragmented AU is incomplete: got %d bytes, expected %d", size, targetSize)
	}

	au := joinByteSlices(d.fragmentParts, d.fragmentSize)
	if len(au) > d.fragmentTargetSize {
		au = au[:d.fragmentTargetSize]
	}

	payload := make([]byte, 0, len(d.fragmentHeader)+len(au))
	payload = append(payload, d.fragmentHeader...)
	payload = append(payload, au...)
	d.resetFragments()

	complete := pkt.Clone()
	complete.Marker = true
	complete.Payload = payload
	return d.base.Decode(complete)
}

func (d *mpeg4AudioRTPDecoder) parsePayload(payload []byte) (mpeg4AudioRTPPayload, error) {
	if len(payload) < 2 {
		return mpeg4AudioRTPPayload{}, fmt.Errorf("payload is too short")
	}

	headersLen := int(uint16(payload[0])<<8 | uint16(payload[1]))
	if headersLen == 0 {
		return mpeg4AudioRTPPayload{}, fmt.Errorf("invalid AU-headers-length")
	}

	headerBytes := headersLen / 8
	if (headersLen % 8) != 0 {
		headerBytes++
	}

	headerSize := 2 + headerBytes
	if len(payload) < headerSize {
		return mpeg4AudioRTPPayload{}, fmt.Errorf("payload is too short")
	}

	auSizes, err := d.readAUSizes(payload[2:headerSize], headersLen)
	if err != nil {
		return mpeg4AudioRTPPayload{}, err
	}

	return mpeg4AudioRTPPayload{
		auSizes: auSizes,
		header:  payload[:headerSize],
		data:    payload[headerSize:],
	}, nil
}

func (d *mpeg4AudioRTPDecoder) readAUSizes(buf []byte, headersLen int) ([]int, error) {
	count := 0
	for i := 0; i < headersLen; count++ {
		i += d.forma.SizeLength
		if count == 0 {
			i += d.forma.IndexLength
		} else {
			i += d.forma.IndexDeltaLength
		}
	}

	auSizes := make([]int, 0, count)
	pos := 0
	firstRead := false

	for headersLen > 0 {
		auSize, err := bits.ReadBits(buf, &pos, d.forma.SizeLength)
		if err != nil {
			return nil, err
		}
		headersLen -= d.forma.SizeLength

		if auSize == 0 {
			return nil, fmt.Errorf("invalid data length")
		}

		if !firstRead {
			firstRead = true
			if d.forma.IndexLength > 0 {
				auIndex, err := bits.ReadBits(buf, &pos, d.forma.IndexLength)
				if err != nil {
					return nil, err
				}
				headersLen -= d.forma.IndexLength
				if auIndex != 0 {
					return nil, fmt.Errorf("AU-index different than zero is not supported")
				}
			}
		} else if d.forma.IndexDeltaLength > 0 {
			auIndexDelta, err := bits.ReadBits(buf, &pos, d.forma.IndexDeltaLength)
			if err != nil {
				return nil, err
			}
			headersLen -= d.forma.IndexDeltaLength
			if auIndexDelta != 0 {
				return nil, fmt.Errorf("AU-index-delta different than zero is not supported")
			}
		}

		auSizes = append(auSizes, int(auSize))
	}

	return auSizes, nil
}

func (d *mpeg4AudioRTPDecoder) resetFragments() {
	d.fragmentHeader = nil
	d.fragmentParts = nil
	d.fragmentSize = 0
	d.fragmentTargetSize = 0
	d.fragmentNextSeq = 0
}

func joinByteSlices(parts [][]byte, size int) []byte {
	out := make([]byte, size)
	n := 0
	for _, part := range parts {
		n += copy(out[n:], part)
	}
	return out
}
