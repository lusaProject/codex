package gateway

import (
	"bytes"

	"github.com/bluenviron/mediacommon/v2/pkg/codecs/h264"
)

func IsH264Keyframe(au [][]byte) bool {
	for _, nalu := range au {
		if len(nalu) == 0 {
			continue
		}

		if h264.NALUType(nalu[0]&0x1F) == h264.NALUTypeIDR {
			return true
		}
	}

	return false
}

func UpdateH264ParameterSets(au [][]byte, sps, pps []byte) ([]byte, []byte) {
	for _, nalu := range au {
		if len(nalu) == 0 {
			continue
		}

		switch h264.NALUType(nalu[0] & 0x1F) {
		case h264.NALUTypeSPS:
			sps = cloneBytes(nalu)
		case h264.NALUTypePPS:
			pps = cloneBytes(nalu)
		}
	}

	return sps, pps
}

func PrependH264ParameterSets(au [][]byte, sps, pps []byte) [][]byte {
	hasSPS := containsH264NALUType(au, h264.NALUTypeSPS)
	hasPPS := containsH264NALUType(au, h264.NALUTypePPS)

	if (sps == nil || hasSPS) && (pps == nil || hasPPS) {
		return au
	}

	out := make([][]byte, 0, len(au)+2)
	if sps != nil && !hasSPS {
		out = append(out, cloneBytes(sps))
	}
	if pps != nil && !hasPPS {
		out = append(out, cloneBytes(pps))
	}
	out = append(out, au...)

	return out
}

func AnnexB(au [][]byte) ([]byte, error) {
	return h264.AnnexB(au).Marshal()
}

func containsH264NALUType(au [][]byte, typ h264.NALUType) bool {
	for _, nalu := range au {
		if len(nalu) > 0 && h264.NALUType(nalu[0]&0x1F) == typ {
			return true
		}
	}

	return false
}

func cloneBytes(in []byte) []byte {
	if in == nil {
		return nil
	}

	return bytes.Clone(in)
}
