package gateway

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/gorilla/websocket"
)

type Server struct {
	Logger                   *log.Logger
	DefaultRTSPURL           string
	DefaultPublishURL        string
	DefaultPublishVideoCodec string
	DefaultPublishAudioCodec string
}

const (
	websocketWriteBufferSize = 64 * 1024
	websocketPacketQueueSize = 64
	websocketWriteQueueSize  = 32
	websocketWriteTimeout    = 5 * time.Second
)

func (s *Server) HandleRTSPWebSocket(w http.ResponseWriter, r *http.Request) {
	rtspURL, err := s.resolveRTSPURL(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	upgrader := websocket.Upgrader{
		ReadBufferSize:  1024,
		WriteBufferSize: websocketWriteBufferSize,
		CheckOrigin: func(*http.Request) bool {
			return true
		},
	}

	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		s.logf("websocket upgrade failed: %v", err)
		return
	}
	defer conn.Close()

	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()
	audioForwardCh := make(chan WebPacket, websocketPacketQueueSize)
	videoForwardCh := make(chan WebPacket, websocketPacketQueueSize)
	writeCh := make(chan []byte, websocketWriteQueueSize)
	forwardErrCh := make(chan error, 1)

	reportForwardErr := func(err error) {
		select {
		case forwardErrCh <- err:
			cancel()
		default:
		}
	}

	startForwarder := func(name string, in <-chan WebPacket, dropWhenFull bool, syncOnKeyframe bool) {
		go func() {
			needKeyframe := false

			for {
				select {
				case <-ctx.Done():
					return
				case pkt := <-in:
					if syncOnKeyframe && needKeyframe && !pkt.Keyframe {
						continue
					}

					msg, err := BuildWebPacket(pkt)
					if err != nil {
						reportForwardErr(fmt.Errorf("%s forward packet: %w", name, err))
						return
					}

					if dropWhenFull {
						select {
						case writeCh <- msg:
							if syncOnKeyframe && pkt.Keyframe {
								needKeyframe = false
							}
						case <-ctx.Done():
							return
						default:
							if syncOnKeyframe {
								needKeyframe = true
							}
						}
						continue
					}

					select {
					case writeCh <- msg:
					case <-ctx.Done():
						return
					}
				}
			}
		}()
	}

	startForwarder("audio", audioForwardCh, true, false)
	startForwarder("video", videoForwardCh, true, true)

	go func() {
		defer cancel()
		for {
			if _, _, err := conn.NextReader(); err != nil {
				return
			}
		}
	}()

	go func() {
		for {
			select {
			case <-ctx.Done():
				return
			case msg := <-writeCh:
				_ = conn.SetWriteDeadline(time.Now().Add(websocketWriteTimeout))
				if err := conn.WriteMessage(websocket.BinaryMessage, msg); err != nil {
					cancel()
					return
				}
			}
		}
	}()

	client := &RTSPClient{Logger: s.Logger}
	videoNeedKeyframe := false
	err = client.Play(ctx, rtspURL, func(pkt WebPacket) error {
		if pkt.FrameType == FrameTypeAudio {
			select {
			case audioForwardCh <- pkt:
			default:
			}
			return nil
		}

		if videoNeedKeyframe && !pkt.Keyframe {
			return nil
		}

		select {
		case videoForwardCh <- pkt:
			if pkt.Keyframe {
				videoNeedKeyframe = false
			}
			return nil
		case <-ctx.Done():
			return ctx.Err()
		default:
			videoNeedKeyframe = true
			return nil
		}
	})
	select {
	case forwardErr := <-forwardErrCh:
		if err == nil {
			err = forwardErr
		}
	default:
	}
	if err != nil && ctx.Err() == nil {
		s.logf("stream ended: %v", err)
		_ = conn.WriteControl(
			websocket.CloseMessage,
			websocket.FormatCloseMessage(websocket.CloseInternalServerErr, err.Error()),
			time.Now().Add(time.Second),
		)
	}
}

func (s *Server) HandlePublishWebSocket(w http.ResponseWriter, r *http.Request) {
	rtspURL, err := s.resolvePublishURL(r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	upgrader := websocket.Upgrader{
		ReadBufferSize:  1024,
		WriteBufferSize: websocketWriteBufferSize,
		CheckOrigin: func(*http.Request) bool {
			return true
		},
	}

	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		s.logf("publish websocket upgrade failed: %v", err)
		return
	}
	defer conn.Close()

	messageType, data, err := conn.ReadMessage()
	if err != nil {
		s.logf("read publish start message failed: %v", err)
		return
	}
	if messageType != websocket.TextMessage {
		closeWebSocketWithError(conn, "publish must start with a JSON config message")
		return
	}

	var cfg PublishConfig
	if err := json.Unmarshal(data, &cfg); err != nil {
		closeWebSocketWithError(conn, fmt.Sprintf("invalid publish config: %v", err))
		return
	}
	if cfg.Type != "" && cfg.Type != "start" {
		closeWebSocketWithError(conn, fmt.Sprintf("unexpected publish message type %q", cfg.Type))
		return
	}
	if strings.TrimSpace(cfg.Video.Codec) == "" {
		cfg.Video.Codec = s.DefaultPublishVideoCodec
	}
	if strings.TrimSpace(cfg.Audio.Codec) == "" {
		cfg.Audio.Codec = s.DefaultPublishAudioCodec
	}
	if value := strings.TrimSpace(cfg.URL); value != "" {
		rtspURL, err = resolveRTSPURLString(value)
		if err != nil {
			closeWebSocketWithError(conn, err.Error())
			return
		}
	}

	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()

	publisher, err := NewRTSPPublisher(ctx, rtspURL, cfg, s.Logger)
	if err != nil {
		s.logf("publish start failed: %v", err)
		closeWebSocketWithError(conn, err.Error())
		return
	}
	defer publisher.Close()

	if err := writePublishStatus(conn, "live", "RTSP RECORD started"); err != nil {
		return
	}
	s.logf("publishing browser media to %s", rtspURL)

	for {
		messageType, data, err = conn.ReadMessage()
		if err != nil {
			return
		}

		switch messageType {
		case websocket.BinaryMessage:
			pkt, err := ParseWebPacket(data)
			if err != nil {
				closeWebSocketWithError(conn, err.Error())
				return
			}
			if err := publisher.WritePacket(pkt); err != nil {
				s.logf("publish packet failed: %v", err)
				closeWebSocketWithError(conn, err.Error())
				return
			}

		case websocket.TextMessage:
			var msg struct {
				Type string `json:"type"`
			}
			if err := json.Unmarshal(data, &msg); err != nil {
				closeWebSocketWithError(conn, fmt.Sprintf("invalid publish control message: %v", err))
				return
			}
			if msg.Type == "stop" {
				return
			}
		}
	}
}

func (s *Server) HandleConfig(w http.ResponseWriter, _ *http.Request) {
	videoCodec := s.DefaultPublishVideoCodec
	if videoCodec == "" {
		videoCodec = "h264"
	}
	audioCodec := s.DefaultPublishAudioCodec
	if audioCodec == "" {
		audioCodec = "aac"
	}

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(struct {
		DefaultRTSPURL    string `json:"defaultRTSPURL"`
		DefaultPublishURL string `json:"defaultPublishURL"`
		PublishVideoCodec string `json:"publishVideoCodec"`
		PublishAudioCodec string `json:"publishAudioCodec"`
	}{
		DefaultRTSPURL:    s.DefaultRTSPURL,
		DefaultPublishURL: s.DefaultPublishURL,
		PublishVideoCodec: videoCodec,
		PublishAudioCodec: audioCodec,
	})
}

func (s *Server) resolveRTSPURL(r *http.Request) (string, error) {
	return resolveRTSPURLFromRequest(r, s.DefaultRTSPURL)
}

func (s *Server) resolvePublishURL(r *http.Request) (string, error) {
	return resolveRTSPURLFromRequest(r, s.DefaultPublishURL)
}

func resolveRTSPURLFromRequest(r *http.Request, defaultURL string) (string, error) {
	value := strings.TrimSpace(r.URL.Query().Get("url"))
	if value == "" {
		value = strings.TrimSpace(r.URL.Query().Get("rtsp"))
	}
	if value == "" {
		value = strings.TrimSpace(defaultURL)
	}
	if value == "" {
		return "", fmt.Errorf("missing url query parameter")
	}

	return resolveRTSPURLString(value)
}

func resolveRTSPURLString(value string) (string, error) {
	if strings.HasPrefix(value, "rtsp://") || strings.HasPrefix(value, "rtsps://") {
		return value, nil
	}

	envName := "RTSP_" + aliasEnvName(value)
	if rtspURL := strings.TrimSpace(os.Getenv(envName)); rtspURL != "" {
		return rtspURL, nil
	}

	return "", fmt.Errorf("unknown stream alias %q; set %s or pass a full rtsp:// URL", value, envName)
}

func writePublishStatus(conn *websocket.Conn, state, text string) error {
	payload, err := json.Marshal(struct {
		Type  string `json:"type"`
		State string `json:"state"`
		Text  string `json:"text"`
	}{
		Type:  "publish-status",
		State: state,
		Text:  text,
	})
	if err != nil {
		return err
	}

	_ = conn.SetWriteDeadline(time.Now().Add(websocketWriteTimeout))
	return conn.WriteMessage(websocket.TextMessage, payload)
}

func closeWebSocketWithError(conn *websocket.Conn, message string) {
	_ = conn.WriteControl(
		websocket.CloseMessage,
		websocket.FormatCloseMessage(websocket.CloseInternalServerErr, message),
		time.Now().Add(time.Second),
	)
}

func (s *Server) logf(format string, args ...any) {
	if s.Logger != nil {
		s.Logger.Printf(format, args...)
	}
}

var aliasEnvRe = regexp.MustCompile(`[^A-Z0-9]+`)

func aliasEnvName(alias string) string {
	upper := strings.ToUpper(strings.TrimSpace(alias))
	upper = aliasEnvRe.ReplaceAllString(upper, "_")
	return strings.Trim(upper, "_")
}
