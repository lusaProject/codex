package gateway

import (
	"sync/atomic"

	"github.com/pion/rtp"
)

type aacRTPSync struct {
	needDecoderReset atomic.Bool
	skipUntilMarker  atomic.Bool
}

func (s *aacRTPSync) markPacketDrop(pkt *rtp.Packet) {
	s.needDecoderReset.Store(true)
	if pkt == nil {
		return
	}

	if !pkt.Marker {
		s.skipUntilMarker.Store(true)
	} else {
		s.skipUntilMarker.Store(false)
	}
}

func (s *aacRTPSync) takeDecoderReset() bool {
	return s.needDecoderReset.Swap(false)
}

func (s *aacRTPSync) shouldSkip(pkt *rtp.Packet) bool {
	if !s.skipUntilMarker.Load() {
		return false
	}

	if pkt != nil && pkt.Marker {
		s.skipUntilMarker.Store(false)
	}

	return true
}
