package gateway

import (
	"context"
	"errors"
	"fmt"
	"log"
	"sync"
	"sync/atomic"

	"github.com/bluenviron/gortsplib/v5"
	"github.com/bluenviron/gortsplib/v5/pkg/base"
	"github.com/bluenviron/gortsplib/v5/pkg/description"
	"github.com/bluenviron/gortsplib/v5/pkg/format"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtph264"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtph265"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtpmpeg4audio"
	"github.com/pion/rtp"
)

type AccessUnitHandler func(WebPacket) error

type RTSPClient struct {
	Logger *log.Logger
}

const (
	videoRTPWorkerQueueSize = 512
	audioRTPWorkerQueueSize = 128
)

type rtpPacketWork struct {
	packet *rtp.Packet
	pts    int64
}

type videoRTPDecoder interface {
	Decode(*rtp.Packet) ([][]byte, error)
}

type videoTrack struct {
	media             *description.Media
	forma             format.Format
	name              string
	codec             byte
	createDecoder     func() (videoRTPDecoder, error)
	processAccessUnit func([][]byte) ([]byte, bool, error)
}

type audioTrack struct {
	media          *description.Media
	forma          format.Format
	name           string
	handleWork     func(rtpPacketWork) error
	markPacketDrop func(*rtp.Packet)
}

func (c *RTSPClient) Play(ctx context.Context, rtspURL string, onAccessUnit AccessUnitHandler) error {
	u, err := base.ParseURL(rtspURL)
	if err != nil {
		return fmt.Errorf("parse rtsp url: %w", err)
	}

	proto := gortsplib.ProtocolTCP
	client := &gortsplib.Client{
		Scheme:   u.Scheme,
		Host:     u.Host,
		Protocol: &proto,
	}

	if err := client.Start(); err != nil {
		return fmt.Errorf("connect rtsp server: %w", err)
	}
	defer client.Close()

	desc, _, err := client.Describe(u)
	if err != nil {
		return fmt.Errorf("describe rtsp stream: %w", err)
	}

	video, err := newVideoTrack(desc)
	if err != nil {
		return err
	}

	videoDecoder, err := video.createDecoder()
	if err != nil {
		return fmt.Errorf("create %s rtp decoder: %w", video.name, err)
	}

	if _, err := client.Setup(desc.BaseURL, video.media, 0, 0); err != nil {
		return fmt.Errorf("setup %s media: %w", video.name, err)
	}

	audio, err := c.newAudioTrack(desc, onAccessUnit)
	if err != nil {
		return err
	}

	if audio != nil {
		if _, err := client.Setup(desc.BaseURL, audio.media, 0, 0); err != nil {
			return fmt.Errorf("setup %s media: %w", audio.name, err)
		}
	}

	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	errCh := make(chan error, 1)
	doneCh := make(chan error, 1)
	videoRTPCh := make(chan rtpPacketWork, videoRTPWorkerQueueSize)
	audioRTPCh := make(chan rtpPacketWork, audioRTPWorkerQueueSize)
	var closeOnce sync.Once
	var videoNeedRandomAccess atomic.Bool

	closeClient := func() {
		closeOnce.Do(func() {
			client.Close()
		})
	}

	fail := func(err error) {
		select {
		case errCh <- err:
			cancel()
			closeClient()
		default:
		}
	}

	go func() {
		<-ctx.Done()
		closeClient()
	}()

	go func() {
		firstRandomAccess := false

		resetVideoDecoder := func(reason string) bool {
			nextDecoder, err := video.createDecoder()
			if err != nil {
				fail(fmt.Errorf("recreate %s rtp decoder: %w", video.name, err))
				return false
			}

			videoDecoder = nextDecoder
			firstRandomAccess = false
			drainRTPQueue(videoRTPCh)
			c.debugf("%s: waiting for next %s keyframe", reason, video.name)
			return true
		}

		for {
			select {
			case <-ctx.Done():
				return
			case work := <-videoRTPCh:
				if videoNeedRandomAccess.Swap(false) {
					if !resetVideoDecoder(fmt.Sprintf("drop queued %s RTP packets", video.name)) {
						return
					}
					continue
				}

				au, err := videoDecoder.Decode(work.packet)
				if err != nil {
					if isVideoMorePacketsNeeded(video.codec, err) {
						continue
					}

					if isVideoNonStartingPacketAndNoPrevious(video.codec, err) {
						if firstRandomAccess && !resetVideoDecoder(
							fmt.Sprintf("drop %s RTP continuation without start", video.name),
						) {
							return
						}
						continue
					}

					c.debugRTPDrop(video.name, work.packet, err)

					if !resetVideoDecoder(fmt.Sprintf("drop damaged %s access unit", video.name)) {
						return
					}
					continue
				}

				payload, keyframe, err := video.processAccessUnit(au)
				if err != nil {
					fail(err)
					return
				}

				if !firstRandomAccess {
					if !keyframe {
						c.debugf("waiting for first %s keyframe", video.name)
						continue
					}
					firstRandomAccess = true
				}

				if err := onAccessUnit(WebPacket{
					FrameType:   FrameTypeVideo,
					Codec:       video.codec,
					Keyframe:    keyframe,
					TimestampUs: rtpPTSInMicros(work.pts, video.forma.ClockRate()),
					Payload:     payload,
				}); err != nil {
					fail(err)
					return
				}
			}
		}
	}()

	client.OnPacketRTP(video.media, video.forma, func(pkt *rtp.Packet) {
		pts, ok := client.PacketPTS(video.media, pkt)
		if !ok {
			videoNeedRandomAccess.Store(true)
			c.debugf("waiting for %s RTP timestamp synchronization", video.name)
			return
		}

		work := rtpPacketWork{
			packet: pkt.Clone(),
			pts:    pts,
		}

		select {
		case videoRTPCh <- work:
		case <-ctx.Done():
		default:
			videoNeedRandomAccess.Store(true)
			c.debugf("drop %s RTP packet: worker queue full", video.name)
		}
	})

	if audio != nil {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				case work := <-audioRTPCh:
					if err := audio.handleWork(work); err != nil {
						fail(err)
						return
					}
				}
			}
		}()

		client.OnPacketRTP(audio.media, audio.forma, func(pkt *rtp.Packet) {
			pts, ok := client.PacketPTS(audio.media, pkt)
			if !ok {
				if audio.markPacketDrop != nil {
					audio.markPacketDrop(pkt)
				}
				c.debugf("waiting for %s timestamp synchronization", audio.name)
				return
			}

			work := rtpPacketWork{
				packet: pkt.Clone(),
				pts:    pts,
			}

			select {
			case audioRTPCh <- work:
			case <-ctx.Done():
			default:
				if audio.markPacketDrop != nil {
					audio.markPacketDrop(pkt)
				}
				c.debugf("drop %s RTP packet: worker queue full", audio.name)
			}
		})
	}

	if _, err := client.Play(nil); err != nil {
		return fmt.Errorf("play rtsp stream: %w", err)
	}

	go func() {
		doneCh <- client.Wait()
	}()

	select {
	case err := <-errCh:
		return err
	case err := <-doneCh:
		if ctx.Err() != nil {
			return nil
		}
		return fmt.Errorf("rtsp client stopped: %w", err)
	case <-ctx.Done():
		return nil
	}
}

func (c *RTSPClient) PlayH264(ctx context.Context, rtspURL string, onAccessUnit AccessUnitHandler) error {
	return c.Play(ctx, rtspURL, onAccessUnit)
}

func newVideoTrack(desc *description.Session) (*videoTrack, error) {
	var h264Format *format.H264
	if videoMedia := desc.FindFormat(&h264Format); videoMedia != nil {
		sps, pps := h264Format.SafeParams()
		sps = cloneBytes(sps)
		pps = cloneBytes(pps)

		return &videoTrack{
			media: videoMedia,
			forma: h264Format,
			name:  "H264",
			codec: CodecH264,
			createDecoder: func() (videoRTPDecoder, error) {
				return h264Format.CreateDecoder()
			},
			processAccessUnit: func(au [][]byte) ([]byte, bool, error) {
				sps, pps = UpdateH264ParameterSets(au, sps, pps)
				keyframe := IsH264Keyframe(au)

				if keyframe {
					au = PrependH264ParameterSets(au, sps, pps)
				}

				payload, err := AnnexB(au)
				if err != nil {
					return nil, false, fmt.Errorf("marshal H264 annex-b access unit: %w", err)
				}

				return payload, keyframe, nil
			},
		}, nil
	}

	var h265Format *format.H265
	if videoMedia := desc.FindFormat(&h265Format); videoMedia != nil {
		vps, sps, pps := h265Format.SafeParams()
		vps = cloneBytes(vps)
		sps = cloneBytes(sps)
		pps = cloneBytes(pps)

		return &videoTrack{
			media: videoMedia,
			forma: h265Format,
			name:  "H265",
			codec: CodecH265,
			createDecoder: func() (videoRTPDecoder, error) {
				return h265Format.CreateDecoder()
			},
			processAccessUnit: func(au [][]byte) ([]byte, bool, error) {
				vps, sps, pps = UpdateH265ParameterSets(au, vps, sps, pps)
				keyframe := IsH265Keyframe(au)

				if keyframe {
					au = PrependH265ParameterSets(au, vps, sps, pps)
				}

				payload, err := H265AnnexB(au)
				if err != nil {
					return nil, false, fmt.Errorf("marshal H265 annex-b access unit: %w", err)
				}

				return payload, keyframe, nil
			},
		}, nil
	}

	return nil, fmt.Errorf("H264/H265 video track not found")
}

func (c *RTSPClient) newAudioTrack(desc *description.Session, onAccessUnit AccessUnitHandler) (*audioTrack, error) {
	var mpeg4AudioFormat *format.MPEG4Audio
	if audioMedia := desc.FindFormat(&mpeg4AudioFormat); audioMedia != nil {
		audioDecoder, err := newMPEG4AudioRTPDecoder(mpeg4AudioFormat)
		if err != nil {
			return nil, fmt.Errorf("create MPEG-4 audio rtp decoder: %w", err)
		}

		audioSync := &aacRTPSync{}

		return &audioTrack{
			media:          audioMedia,
			forma:          mpeg4AudioFormat,
			name:           "MPEG-4 audio",
			markPacketDrop: audioSync.markPacketDrop,
			handleWork: func(work rtpPacketWork) error {
				if audioSync.takeDecoderReset() {
					nextDecoder, err := newMPEG4AudioRTPDecoder(mpeg4AudioFormat)
					if err != nil {
						return fmt.Errorf("recreate MPEG-4 audio rtp decoder: %w", err)
					}
					audioDecoder = nextDecoder
				}

				if audioSync.shouldSkip(work.packet) {
					c.debugf("drop MPEG-4 audio RTP packet: resync after fragment loss")
					return nil
				}

				aus, err := audioDecoder.Decode(work.packet)
				if err != nil {
					if !errors.Is(err, rtpmpeg4audio.ErrMorePacketsNeeded) {
						c.debugRTPDrop("MPEG-4 audio", work.packet, err)
					}
					return nil
				}

				for _, au := range aus {
					payload, err := BuildMPEG4AudioPayload(mpeg4AudioFormat, au)
					if err != nil {
						return fmt.Errorf("marshal MPEG-4 audio access unit: %w", err)
					}

					if err := onAccessUnit(WebPacket{
						FrameType:   FrameTypeAudio,
						Codec:       CodecAAC,
						TimestampUs: rtpPTSInMicros(work.pts, mpeg4AudioFormat.ClockRate()),
						Payload:     payload,
					}); err != nil {
						return err
					}
				}

				return nil
			},
		}, nil
	}

	var g711Format *format.G711
	if audioMedia := desc.FindFormat(&g711Format); audioMedia != nil {
		audioDecoder, err := g711Format.CreateDecoder()
		if err != nil {
			return nil, fmt.Errorf("create G711 rtp decoder: %w", err)
		}

		codec := G711WebCodec(g711Format)
		return &audioTrack{
			media: audioMedia,
			forma: g711Format,
			name:  "G711",
			handleWork: func(work rtpPacketWork) error {
				encoded, err := audioDecoder.Decode(work.packet)
				if err != nil {
					c.debugRTPDrop("G711", work.packet, err)
					return nil
				}

				payload, err := BuildG711Payload(g711Format, encoded)
				if err != nil {
					return fmt.Errorf("marshal G711 audio payload: %w", err)
				}

				return onAccessUnit(WebPacket{
					FrameType:   FrameTypeAudio,
					Codec:       codec,
					TimestampUs: rtpPTSInMicros(work.pts, g711Format.ClockRate()),
					Payload:     payload,
				})
			},
		}, nil
	}

	return nil, nil
}

func isVideoMorePacketsNeeded(codec byte, err error) bool {
	switch codec {
	case CodecH264:
		return errors.Is(err, rtph264.ErrMorePacketsNeeded)
	case CodecH265:
		return errors.Is(err, rtph265.ErrMorePacketsNeeded)
	default:
		return false
	}
}

func isVideoNonStartingPacketAndNoPrevious(codec byte, err error) bool {
	switch codec {
	case CodecH264:
		return errors.Is(err, rtph264.ErrNonStartingPacketAndNoPrevious)
	case CodecH265:
		return errors.Is(err, rtph265.ErrNonStartingPacketAndNoPrevious)
	default:
		return false
	}
}

func (c *RTSPClient) debugRTPDrop(name string, pkt *rtp.Packet, err error) {
	if c.Logger == nil || pkt == nil {
		return
	}

	head := pkt.Payload
	if len(head) > 8 {
		head = head[:8]
	}
	c.debugf(
		"drop %s RTP packet: marker=%v seq=%d payload=%d head=% x: %v",
		name,
		pkt.Marker,
		pkt.SequenceNumber,
		len(pkt.Payload),
		head,
		err,
	)
}

func (c *RTSPClient) debugf(format string, args ...any) {
	if c.Logger != nil {
		c.Logger.Printf(format, args...)
	}
}

func rtpPTSInMicros(pts int64, clockRate int) uint64 {
	if pts <= 0 || clockRate <= 0 {
		return 0
	}

	return uint64(pts) * 1_000_000 / uint64(clockRate)
}

func drainRTPQueue(ch <-chan rtpPacketWork) {
	for {
		select {
		case <-ch:
		default:
			return
		}
	}
}
