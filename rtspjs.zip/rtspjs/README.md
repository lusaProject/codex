# RTSP WebCodecs Gateway

一个用 Go 和 WebCodecs 实现的 RTSP H5 播放与浏览器摄像头推流网关。

后端从 RTSP 拉流，将 H264/H265 视频与 AAC/G.711 音频封装成自定义二进制 WebSocket 包；前端在浏览器内用 WebCodecs 解码、WebGL 渲染、AudioWorklet 播放。项目也支持浏览器采集摄像头和麦克风，可按启动参数编码为 H264/H265 视频与 AAC/G.711 音频，再通过网关执行 RTSP RECORD 推流。

## 功能特性

- RTSP over TCP 拉流，HTTP/WebSocket 服务与静态 H5 播放器一体启动。
- 播放 H264/H265 视频，关键帧前自动等待并补齐参数集。
- 播放 AAC/MPEG-4 Audio、G.711 PCMU、G.711 PCMA 音频。
- 前端基于 Worker、OffscreenCanvas、WebGL 和 AudioWorklet，避免主线程承担解码渲染压力。
- 浏览器摄像头推流：WebCodecs 编码 H264/H265 视频，音频可编码为 AAC、G.711 PCMA 或 G.711 PCMU，再由后端推到 RTSP 服务端。
- 支持通过完整 RTSP URL 或环境变量别名选择流地址。

## 项目结构

```text
.
├── main.go                         # 程序入口，启动 HTTP/WebSocket 服务
├── go.mod                          # Go 模块与依赖
├── rtsp-gateway/
│   ├── websocket_server.go         # /rtsp 播放与 /publish 推流 WebSocket 处理
│   ├── rtsp_client.go              # RTSP 拉流、RTP 解包、音视频轨道处理
│   ├── rtsp_publisher.go           # 浏览器媒体包转 RTSP RECORD 推流
│   ├── packet.go                   # 前后端共享的 WebSocket 二进制包格式
│   ├── h264.go / h265.go           # 视频 Annex-B 与参数集处理
│   ├── mpeg4_audio*.go             # AAC/MPEG-4 Audio 处理
│   └── g711.go                     # G.711 音频处理
└── web-player/
    ├── index.html                  # 播放器界面
    ├── render.js                   # UI、WebSocket URL、音频输出调度
    ├── decoder-worker.js           # WebSocket 收包并分发给音视频 Worker
    ├── video-worker.js             # WebCodecs 视频解码与 WebGL 渲染
    ├── audio-worker.js             # AAC/G.711 音频解码或转换
    ├── audio-output-worklet.js      # PCM 播放缓冲
    ├── publisher.js                # 浏览器摄像头/麦克风采集与编码推流
    └── publish-audio-worklet.js    # 推流音频采集
```

## 环境要求

- Go：`go.mod` 声明为 Go `1.26.1`。
- 浏览器：需要支持安全上下文下的 WebCodecs、Worker、OffscreenCanvas、WebGL 和 AudioWorklet。建议使用 Chromium/Edge 类浏览器；H265 播放或推流是否可用取决于浏览器、系统和硬件编解码能力。
- RTSP 源：播放至少需要 H264 或 H265 视频轨，音频可选。
- 推流目标：需要支持 RTSP RECORD，例如可写入的 RTSP 服务器。

> `http://127.0.0.1` 和 `http://localhost` 通常属于浏览器安全上下文；如果通过局域网 IP 或域名访问，播放和摄像头推流可能需要 HTTPS。

## 快速开始

启动时设置默认播放与推流地址：

```powershell
go run . `
  -addr :18080 `
  -web-dir web-player `
  -rtsp-url "rtsp://172.20.173.132/live/test" `
  -publish-url "rtsp://172.20.173.132:554/live/camera1"
```

启动时设置浏览器推流编码：

```powershell
go run . -addr :18080 -publish-video-codec h265  -publish-audio-codec g711
go run . -addr :18080 -publish-video-codec h264  -publish-audio-codec aac
```

推流编码参数：

- `-publish-video-codec`：支持 `h264`、`h265`，默认 `h264`。
- `-publish-audio-codec`：支持 `aac`、`pcma`/`g711a`/`g711`、`pcmu`/`g711u`、`none`，默认 `aac`。其中 `g711` 会按 PCMA/A-law 处理。
- 也可通过环境变量 `RTSP_PUBLISH_VIDEO_CODEC`、`RTSP_PUBLISH_AUDIO_CODEC` 设置默认值。
- 前端 URL 可临时覆盖启动默认值，例如：

```text
http://127.0.0.1:18080/?publishVideoCodec=h265&publishAudioCodec=pcmu
```

### 媒体包格式

- WebSocket 二进制包由 16 字节头和 payload 组成，前后端在 `rtsp-gateway/packet.go` 与 `web-player/media-packet.js` 中保持一致：

| 偏移   | 长度 | 字段           | 说明                                                      |
| ------ | ---- | -------------- | --------------------------------------------------------- |
| `0`  | 1    | frame type     | `1` 视频，`2` 音频                                    |
| `1`  | 1    | codec          | `1` H264，`2` H265，`3` AAC，`4` PCMU，`5` PCMA |
| `2`  | 1    | keyframe       | `1` 表示关键帧                                          |
| `3`  | 1    | reserved       | 保留                                                      |
| `4`  | 8    | timestamp us   | big-endian 微秒时间戳                                     |
| `12` | 4    | payload length | big-endian payload 长度                                   |
| `16` | N    | payload        | 编码后的媒体数据                                          |

视频 payload 使用 Annex-B access unit。播放方向的 AAC payload 额外带有采样率、声道数、对象类型与 AudioSpecificConfig；播放方向的 G.711 payload 额外带有采样率和声道数。推流方向的音频编码参数通过 `/publish` 启动 JSON 配置传递，媒体包 payload 放编码后的音频数据。

## 播放流程

1. 浏览器连接 `/rtsp?url=...`。
2. 后端用 `gortsplib` 通过 RTSP over TCP 拉流。
3. 后端解析 RTP，视频转为 H264/H265 Annex-B access unit，音频转为 AAC/G.711 payload。
4. 浏览器 Worker 收到二进制包后分发给视频和音频 Worker。
5. 视频通过 `VideoDecoder` 解码并用 WebGL 绘制到 canvas；音频通过 `AudioDecoder` 或 G.711 软件转换后交给 AudioWorklet 播放。

## 推流流程

1. 浏览器请求摄像头和麦克风权限。
2. `publisher.js` 根据启动配置选择编码：视频使用 `VideoEncoder` 编码 H264 或 H265；音频使用 `AudioEncoder` 编码 AAC，或在前端把 PCM 转为 G.711 PCMA/PCMU。
3. 浏览器连接 `/publish?url=...`，发送启动配置，包含视频编码、音频编码、采样率、声道数等参数。
4. 后端创建 RTSP RECORD 会话，把收到的 H264/H265 与 AAC/G.711 媒体包重新打包为 RTP 写入目标 RTSP 地址。
