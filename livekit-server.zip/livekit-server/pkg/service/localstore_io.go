package service

import (
	"context"
	"errors"
	"slices"
	"strings"

	"github.com/livekit/protocol/livekit"
	"github.com/livekit/protocol/utils"
	"google.golang.org/protobuf/proto"
)

func (s *LocalStore) StoreEgress(_ context.Context, info *livekit.EgressInfo) error {
	if info == nil || info.EgressId == "" {
		return errors.New("egress id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.egresses[info.EgressId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) LoadEgress(_ context.Context, egressID string) (*livekit.EgressInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	info := s.egresses[egressID]
	if info == nil {
		return nil, ErrEgressNotFound
	}
	return utils.CloneProto(info), nil
}

func (s *LocalStore) ListEgress(_ context.Context, roomName livekit.RoomName, active bool) ([]*livekit.EgressInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	infos := make([]*livekit.EgressInfo, 0, len(s.egresses))
	for _, info := range s.egresses {
		if roomName != "" && info.RoomName != string(roomName) {
			continue
		}
		if active && int32(info.Status) >= int32(livekit.EgressStatus_EGRESS_COMPLETE) {
			continue
		}
		infos = append(infos, utils.CloneProto(info))
	}
	return infos, nil
}

func (s *LocalStore) UpdateEgress(_ context.Context, info *livekit.EgressInfo) error {
	if info == nil || info.EgressId == "" {
		return errors.New("egress id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.egresses[info.EgressId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) StoreIngress(_ context.Context, info *livekit.IngressInfo) error {
	if info == nil || info.IngressId == "" {
		return errors.New("ingress id is not set")
	}
	if info.StreamKey == "" && info.InputType != livekit.IngressInput_URL_INPUT {
		return errors.New("stream key is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.storeIngressLocked(info)
	if _, ok := s.ingressStates[info.IngressId]; !ok {
		s.ingressStates[info.IngressId] = &livekit.IngressState{}
	}
	return nil
}

func (s *LocalStore) LoadIngress(_ context.Context, ingressID string) (*livekit.IngressInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	return s.loadIngressLocked(ingressID)
}

func (s *LocalStore) LoadIngressFromStreamKey(ctx context.Context, streamKey string) (*livekit.IngressInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	ingressID := s.ingressByStreamKey[streamKey]
	if ingressID == "" {
		return nil, ErrIngressNotFound
	}
	return s.loadIngressLocked(ingressID)
}

func (s *LocalStore) ListIngress(_ context.Context, roomName livekit.RoomName) ([]*livekit.IngressInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	infos := make([]*livekit.IngressInfo, 0, len(s.ingresses))
	for _, info := range s.ingresses {
		if roomName != "" && info.RoomName != string(roomName) {
			continue
		}
		clone := utils.CloneProto(info)
		if state := s.ingressStates[clone.IngressId]; state != nil {
			clone.State = utils.CloneProto(state)
		}
		infos = append(infos, clone)
	}
	return infos, nil
}

func (s *LocalStore) UpdateIngress(_ context.Context, info *livekit.IngressInfo) error {
	if info == nil || info.IngressId == "" {
		return errors.New("ingress id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.storeIngressLocked(info)
	return nil
}

func (s *LocalStore) UpdateIngressState(_ context.Context, ingressID string, state *livekit.IngressState) error {
	if ingressID == "" {
		return errors.New("ingress id is not set")
	}
	if state == nil {
		state = &livekit.IngressState{}
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	oldState := s.ingressStates[ingressID]
	if oldState != nil {
		if state.StartedAt < oldState.StartedAt {
			return nil
		}
		if state.StartedAt == oldState.StartedAt && state.UpdatedAt < oldState.UpdatedAt {
			return nil
		}
	}
	s.ingressStates[ingressID] = utils.CloneProto(state)
	return nil
}

func (s *LocalStore) DeleteIngress(_ context.Context, info *livekit.IngressInfo) error {
	if info == nil {
		return nil
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	if old := s.ingresses[info.IngressId]; old != nil && old.StreamKey != "" {
		delete(s.ingressByStreamKey, old.StreamKey)
	}
	delete(s.ingresses, info.IngressId)
	delete(s.ingressStates, info.IngressId)
	return nil
}

func (s *LocalStore) storeIngressLocked(info *livekit.IngressInfo) {
	if old := s.ingresses[info.IngressId]; old != nil && old.StreamKey != "" && old.StreamKey != info.StreamKey {
		delete(s.ingressByStreamKey, old.StreamKey)
	}

	clone := utils.CloneProto(info)
	clone.State = nil
	s.ingresses[info.IngressId] = clone
	if info.StreamKey != "" {
		s.ingressByStreamKey[info.StreamKey] = info.IngressId
	}
}

func (s *LocalStore) loadIngressLocked(ingressID string) (*livekit.IngressInfo, error) {
	info := s.ingresses[ingressID]
	if info == nil {
		return nil, ErrIngressNotFound
	}

	clone := utils.CloneProto(info)
	if state := s.ingressStates[ingressID]; state != nil {
		clone.State = utils.CloneProto(state)
	}
	return clone, nil
}

func (s *LocalStore) StoreSIPTrunk(_ context.Context, info *livekit.SIPTrunkInfo) error {
	if info == nil || info.SipTrunkId == "" {
		return errors.New("sip trunk id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.sipLegacyTrunks[info.SipTrunkId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) StoreSIPInboundTrunk(_ context.Context, info *livekit.SIPInboundTrunkInfo) error {
	if info == nil || info.SipTrunkId == "" {
		return errors.New("sip trunk id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.sipInboundTrunks[info.SipTrunkId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) StoreSIPOutboundTrunk(_ context.Context, info *livekit.SIPOutboundTrunkInfo) error {
	if info == nil || info.SipTrunkId == "" {
		return errors.New("sip trunk id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.sipOutboundTrunks[info.SipTrunkId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) LoadSIPTrunk(_ context.Context, id string) (*livekit.SIPTrunkInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	if trunk := s.sipLegacyTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk), nil
	}
	if trunk := s.sipInboundTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk).AsTrunkInfo(), nil
	}
	if trunk := s.sipOutboundTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk).AsTrunkInfo(), nil
	}
	return nil, ErrSIPTrunkNotFound
}

func (s *LocalStore) LoadSIPInboundTrunk(_ context.Context, id string) (*livekit.SIPInboundTrunkInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	if trunk := s.sipInboundTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk), nil
	}
	if trunk := s.sipLegacyTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk).AsInbound(), nil
	}
	return nil, ErrSIPTrunkNotFound
}

func (s *LocalStore) LoadSIPOutboundTrunk(_ context.Context, id string) (*livekit.SIPOutboundTrunkInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	if trunk := s.sipOutboundTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk), nil
	}
	if trunk := s.sipLegacyTrunks[id]; trunk != nil {
		return utils.CloneProto(trunk).AsOutbound(), nil
	}
	return nil, ErrSIPTrunkNotFound
}

func (s *LocalStore) DeleteSIPTrunk(_ context.Context, id string) error {
	s.lock.Lock()
	defer s.lock.Unlock()

	delete(s.sipLegacyTrunks, id)
	delete(s.sipInboundTrunks, id)
	delete(s.sipOutboundTrunks, id)
	return nil
}

func (s *LocalStore) ListSIPTrunk(_ context.Context, req *livekit.ListSIPTrunkRequest) (*livekit.ListSIPTrunkResponse, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	var items []*livekit.SIPTrunkInfo
	for _, trunk := range s.sipLegacyTrunks {
		v := utils.CloneProto(trunk)
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	for _, trunk := range s.sipInboundTrunks {
		v := utils.CloneProto(trunk).AsTrunkInfo()
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	for _, trunk := range s.sipOutboundTrunks {
		v := utils.CloneProto(trunk).AsTrunkInfo()
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	return &livekit.ListSIPTrunkResponse{Items: sortPage(items, req.Page)}, nil
}

func (s *LocalStore) ListSIPInboundTrunk(_ context.Context, req *livekit.ListSIPInboundTrunkRequest) (*livekit.ListSIPInboundTrunkResponse, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	var items []*livekit.SIPInboundTrunkInfo
	for _, trunk := range s.sipInboundTrunks {
		v := utils.CloneProto(trunk)
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	for _, trunk := range s.sipLegacyTrunks {
		v := utils.CloneProto(trunk).AsInbound()
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	return &livekit.ListSIPInboundTrunkResponse{Items: sortPage(items, req.Page)}, nil
}

func (s *LocalStore) ListSIPOutboundTrunk(_ context.Context, req *livekit.ListSIPOutboundTrunkRequest) (*livekit.ListSIPOutboundTrunkResponse, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	var items []*livekit.SIPOutboundTrunkInfo
	for _, trunk := range s.sipOutboundTrunks {
		v := utils.CloneProto(trunk)
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	for _, trunk := range s.sipLegacyTrunks {
		v := utils.CloneProto(trunk).AsOutbound()
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	return &livekit.ListSIPOutboundTrunkResponse{Items: sortPage(items, req.Page)}, nil
}

func (s *LocalStore) StoreSIPDispatchRule(_ context.Context, info *livekit.SIPDispatchRuleInfo) error {
	if info == nil || info.SipDispatchRuleId == "" {
		return errors.New("sip dispatch rule id is not set")
	}

	s.lock.Lock()
	defer s.lock.Unlock()

	s.sipDispatchRules[info.SipDispatchRuleId] = utils.CloneProto(info)
	return nil
}

func (s *LocalStore) LoadSIPDispatchRule(_ context.Context, id string) (*livekit.SIPDispatchRuleInfo, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	rule := s.sipDispatchRules[id]
	if rule == nil {
		return nil, ErrSIPDispatchRuleNotFound
	}
	return utils.CloneProto(rule), nil
}

func (s *LocalStore) DeleteSIPDispatchRule(_ context.Context, id string) error {
	s.lock.Lock()
	defer s.lock.Unlock()

	delete(s.sipDispatchRules, id)
	return nil
}

func (s *LocalStore) ListSIPDispatchRule(_ context.Context, req *livekit.ListSIPDispatchRuleRequest) (*livekit.ListSIPDispatchRuleResponse, error) {
	s.lock.RLock()
	defer s.lock.RUnlock()

	var items []*livekit.SIPDispatchRuleInfo
	for _, rule := range s.sipDispatchRules {
		v := utils.CloneProto(rule)
		if req.Filter(v) && req.Page.Filter(v) {
			items = append(items, v)
		}
	}
	return &livekit.ListSIPDispatchRuleResponse{Items: sortPage(items, req.Page)}, nil
}

type protoEntity[T any] interface {
	*T
	proto.Message
	ID() string
}

func sortPage[T any, P protoEntity[T]](items []P, page *livekit.Pagination) []P {
	slices.SortFunc(items, func(a, b P) int {
		return strings.Compare(a.ID(), b.ID())
	})
	if page != nil {
		if limit := int(page.Limit); limit > 0 && len(items) > limit {
			items = items[:limit]
		}
	}
	return items
}
