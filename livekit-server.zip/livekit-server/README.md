LiveKit H5 Client

用于连接本仓库 LiveKit 服务端的静态 H5 客户端。

本地运行

先启动服务端开发模式：

```powershell
go run . --config livekit.full.yaml
```

再用任意静态文件服务打开 `h5-client` 目录：

```powershell
python -m http.server 5173
```

浏览器访问 `http://127.0.0.1:5173/`。

开发模式默认使用 `devkey` / `secret` 在浏览器内生成 join token；

生产环境建议在后端签发 token，然后在页面里切换到“粘贴 Token”。

go run . --config livekit.dev.yaml ports

验证配置可以解析，端口是 HTTP 7880、ICE/TCP 7881、ICE/UDP 7882
