package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"github.com/pion/webrtc/v3"
	"github.com/sourcegraph/jsonrpc2"

	sfu "github.com/pion/ion-sfu/pkg"
)

type signalContextKey struct{}

type signalContext struct {
	roomID        string
	participantID string
	peer          *sfu.WebRTCTransport
	negotiation   *negotiationCoordinator
	leaving       atomic.Bool
}

func withSignalContext(ctx context.Context, value *signalContext) context.Context {
	return context.WithValue(ctx, signalContextKey{}, value)
}

func getSignalContext(ctx context.Context) *signalContext {
	value, _ := ctx.Value(signalContextKey{}).(*signalContext)
	return value
}

type RPCHandler struct {
	app *Application
}

type joinSignalRequest struct {
	Offer    webrtc.SessionDescription `json:"offer"`
	Presence ParticipantPresencePatch  `json:"presence"`
}

type joinSignalResponse struct {
	Answer webrtc.SessionDescription `json:"answer"`
	Room   RoomSnapshot              `json:"room"`
	Self   ParticipantSnapshot       `json:"self"`
}

type negotiationRequest struct {
	Desc webrtc.SessionDescription `json:"desc"`
}

type trickleRequest struct {
	Candidate webrtc.ICECandidateInit `json:"candidate"`
}

type negotiationCoordinator struct {
	mu             sync.Mutex
	debounce       time.Duration
	pending        bool
	running        bool
	awaitingAnswer bool
	closed         bool
	sendOffer      func(context.Context) error
}

func newPeerNegotiationCoordinator(peer *sfu.WebRTCTransport, conn *jsonrpc2.Conn) *negotiationCoordinator {
	return newNegotiationCoordinator(func(ctx context.Context) error {
		offer, err := peer.CreateOffer()
		if err != nil {
			return err
		}
		if err := peer.SetLocalDescription(offer); err != nil {
			return err
		}
		return conn.Notify(ctx, "offer", offer)
	}, 120*time.Millisecond)
}

func newNegotiationCoordinator(sendOffer func(context.Context) error, debounce time.Duration) *negotiationCoordinator {
	return &negotiationCoordinator{
		debounce:  debounce,
		sendOffer: sendOffer,
	}
}

func (n *negotiationCoordinator) Request() {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.closed {
		return
	}
	n.pending = true
	n.maybeStartLocked()
}

func (n *negotiationCoordinator) Answered() {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.closed {
		return
	}
	n.awaitingAnswer = false
	n.maybeStartLocked()
}

func (n *negotiationCoordinator) Close() {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.closed = true
	n.pending = false
}

func (n *negotiationCoordinator) maybeStartLocked() {
	if !n.pending || n.running || n.awaitingAnswer {
		return
	}

	n.pending = false
	n.running = true
	go n.run()
}

func (n *negotiationCoordinator) run() {
	if n.debounce > 0 {
		time.Sleep(n.debounce)
	}

	n.mu.Lock()
	if n.closed {
		n.running = false
		n.mu.Unlock()
		return
	}
	n.pending = false
	n.mu.Unlock()

	err := n.sendOffer(context.Background())

	n.mu.Lock()
	defer n.mu.Unlock()

	n.running = false
	if n.closed {
		return
	}
	if err != nil {
		n.maybeStartLocked()
		return
	}
	n.awaitingAnswer = true
}

func (h *RPCHandler) Handle(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request) {
	session := getSignalContext(ctx)
	if session == nil {
		return
	}

	switch req.Method {
	case "join":
		h.handleJoin(ctx, conn, req, session)
	case "offer":
		h.handleOffer(ctx, conn, req, session)
	case "answer":
		h.handleAnswer(ctx, conn, req, session)
	case "trickle":
		h.handleTrickle(ctx, conn, req, session)
	case "update_presence":
		h.handleUpdatePresence(ctx, conn, req, session)
	case "leave":
		session.leaving.Store(true)
		_ = conn.Reply(ctx, req.ID, map[string]bool{"ok": true})
		_ = conn.Close()
	default:
		_ = conn.ReplyWithError(ctx, req.ID, &jsonrpc2.Error{
			Code:    httpMethodNotFound,
			Message: "method not found",
		})
	}
}

func (h *RPCHandler) handleJoin(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, session *signalContext) {
	if session.peer != nil {
		replyError(ctx, conn, req, errors.New("peer already joined"))
		return
	}

	var message joinSignalRequest
	if err := decodeParams(req, &message); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	me := sfu.MediaEngine{}
	if err := me.PopulateFromSDP(message.Offer); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	peer, err := h.app.sfu.NewWebRTCTransport(session.roomID, me)
	if err != nil {
		replyError(ctx, conn, req, err)
		return
	}
	joined := false
	defer func() {
		if !joined {
			_ = peer.Close()
		}
	}()

	if err := peer.SetRemoteDescription(message.Offer); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	answer, err := peer.CreateAnswer()
	if err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if err := peer.SetLocalDescription(answer); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	session.peer = peer
	session.negotiation = newPeerNegotiationCoordinator(peer, conn)
	defer func() {
		if !joined && session.negotiation != nil {
			session.negotiation.Close()
			session.negotiation = nil
			session.peer = nil
		}
	}()

	peer.OnICECandidate(func(candidate *webrtc.ICECandidate) {
		if candidate == nil {
			return
		}
		_ = conn.Notify(context.Background(), "trickle", candidate.ToJSON())
	})

	peer.OnNegotiationNeeded(func() {
		if session.negotiation != nil {
			session.negotiation.Request()
		}
	})

	if err := h.app.conference.BindPeer(session.roomID, session.participantID, peer); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	self, room, err := h.app.conference.UpdateParticipantPresence(session.roomID, session.participantID, message.Presence)
	if err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	h.app.conference.Broadcast(context.Background(), session.roomID, session.participantID, "participant_updated", self)
	joined = true

	_ = conn.Reply(ctx, req.ID, joinSignalResponse{
		Answer: applyVideoBitrateToDescription(answer),
		Room:   room,
		Self:   self,
	})
}

func (h *RPCHandler) handleOffer(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, session *signalContext) {
	if session.peer == nil {
		replyError(ctx, conn, req, errors.New("peer not joined"))
		return
	}

	var message negotiationRequest
	if err := decodeParams(req, &message); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if err := session.peer.SetRemoteDescription(message.Desc); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	answer, err := session.peer.CreateAnswer()
	if err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if err := session.peer.SetLocalDescription(answer); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	_ = conn.Reply(ctx, req.ID, applyVideoBitrateToDescription(answer))
}

func (h *RPCHandler) handleAnswer(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, session *signalContext) {
	if session.peer == nil {
		replyError(ctx, conn, req, errors.New("peer not joined"))
		return
	}

	var message negotiationRequest
	if err := decodeParams(req, &message); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if err := session.peer.SetRemoteDescription(message.Desc); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if session.negotiation != nil {
		session.negotiation.Answered()
	}

	_ = conn.Reply(ctx, req.ID, map[string]bool{"ok": true})
}

func (h *RPCHandler) handleTrickle(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, session *signalContext) {
	if session.peer == nil {
		replyError(ctx, conn, req, errors.New("peer not joined"))
		return
	}

	var message trickleRequest
	if err := decodeParams(req, &message); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	if err := session.peer.AddICECandidate(message.Candidate); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	_ = conn.Reply(ctx, req.ID, map[string]bool{"ok": true})
}

func (h *RPCHandler) handleUpdatePresence(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, session *signalContext) {
	var patch ParticipantPresencePatch
	if err := decodeParams(req, &patch); err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	snapshot, _, err := h.app.conference.UpdateParticipantPresence(session.roomID, session.participantID, patch)
	if err != nil {
		replyError(ctx, conn, req, err)
		return
	}

	h.app.conference.Broadcast(context.Background(), session.roomID, session.participantID, "participant_updated", snapshot)
	_ = conn.Reply(ctx, req.ID, snapshot)
}

func decodeParams(req *jsonrpc2.Request, dst interface{}) error {
	if req.Params == nil {
		return errors.New("missing params")
	}

	if err := json.Unmarshal(*req.Params, dst); err != nil {
		return fmt.Errorf("decode params: %w", err)
	}

	return nil
}

func replyError(ctx context.Context, conn *jsonrpc2.Conn, req *jsonrpc2.Request, err error) {
	_ = conn.ReplyWithError(ctx, req.ID, &jsonrpc2.Error{
		Code:    httpInternalError,
		Message: err.Error(),
	})
}

const (
	httpMethodNotFound = -32601
	httpInternalError  = -32000
)
