package main

import (
	"testing"
	"time"
)

func TestTokenManagerRoundTrip(t *testing.T) {
	manager := NewTokenManager("secret")
	claims := JoinClaims{
		RoomID:        "room_123",
		ParticipantID: "user_456",
		DisplayName:   "Alice",
		Role:          "host",
		ExpiresAt:     time.Now().Add(1 * time.Hour).Unix(),
	}

	token, err := manager.Sign(claims)
	if err != nil {
		t.Fatalf("Sign() error = %v", err)
	}

	got, err := manager.Verify(token)
	if err != nil {
		t.Fatalf("Verify() error = %v", err)
	}

	if got.RoomID != claims.RoomID || got.ParticipantID != claims.ParticipantID || got.DisplayName != claims.DisplayName {
		t.Fatalf("Verify() claims mismatch: got %+v want %+v", got, claims)
	}
}

func TestTokenManagerRejectsExpiredToken(t *testing.T) {
	manager := NewTokenManager("secret")
	token, err := manager.Sign(JoinClaims{
		RoomID:        "room_123",
		ParticipantID: "user_456",
		ExpiresAt:     time.Now().Add(-1 * time.Minute).Unix(),
	})
	if err != nil {
		t.Fatalf("Sign() error = %v", err)
	}

	if _, err := manager.Verify(token); err != ErrExpiredToken {
		t.Fatalf("Verify() error = %v want %v", err, ErrExpiredToken)
	}
}
