package main

import (
	"context"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"strings"
	"sync"
	"time"

	sfu "github.com/pion/ion-sfu/pkg"
	"github.com/pion/sdp/v2"
	"github.com/pion/webrtc/v3"
)

const whipGatherTimeout = 5 * time.Second

type whipSession struct {
	ID            string
	RoomID        string
	ParticipantID string
	Peer          *sfu.WebRTCTransport
	closeOnce     sync.Once
}

type whipOfferMedia struct {
	Audio    bool
	Video    bool
	StreamID string
}

func (a *Application) handleCreateFFmpegSession(w http.ResponseWriter, r *http.Request, roomID string) {
	var input PrepareFFmpegPublishInput
	if err := readJSON(r, &input); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	session, err := a.conference.PrepareFFmpegPublish(roomID, input, a.rtcResponse())
	if err != nil {
		writeDomainError(w, err)
		return
	}

	whipURL := a.whipEndpointURL(r)
	writeJSON(w, http.StatusCreated, map[string]interface{}{
		"room":          session.Room,
		"participant":   session.Participant,
		"token":         session.Token,
		"whipUrl":       whipURL,
		"ffmpegCommand": buildFFmpegCommand(whipURL, session.Token),
	})
}

func (a *Application) handleWHIP(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/api/v1/whip")
	if path == "" || path == "/" {
		switch r.Method {
		case http.MethodPost:
			a.handleWHIPPublish(w, r)
		case http.MethodOptions:
			a.writeWHIPDiscovery(w, r)
			w.WriteHeader(http.StatusNoContent)
		default:
			w.Header().Set("Allow", "OPTIONS, POST")
			writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		}
		return
	}

	parts := splitPath(path)
	if len(parts) != 1 {
		writeError(w, http.StatusNotFound, "route not found")
		return
	}

	switch r.Method {
	case http.MethodPatch:
		a.handleWHIPPatch(w, r, parts[0])
	case http.MethodDelete:
		a.handleWHIPDelete(w, r, parts[0])
	default:
		w.Header().Set("Allow", "DELETE, PATCH")
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
	}
}

func (a *Application) handleWHIPPublish(w http.ResponseWriter, r *http.Request) {
	token := readBearerToken(r)
	if token == "" {
		a.writeWHIPUnauthorized(w, "missing bearer token")
		return
	}

	claims, err := a.tokenManager.Verify(token)
	if err != nil {
		a.writeWHIPUnauthorized(w, "invalid token")
		return
	}
	if !claims.Allows(TokenUseWHIP) {
		a.writeWHIPUnauthorized(w, "token cannot be used for WHIP")
		return
	}

	body, err := ioutil.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		writeError(w, http.StatusBadRequest, "read sdp: "+err.Error())
		return
	}
	offerSDP := strings.TrimSpace(string(body))
	if offerSDP == "" {
		writeError(w, http.StatusBadRequest, "missing SDP offer")
		return
	}

	offer := webrtc.SessionDescription{
		Type: webrtc.SDPTypeOffer,
		SDP:  offerSDP,
	}

	me := sfu.MediaEngine{}
	if err := me.PopulateFromSDP(offer); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	peer, err := a.sfu.NewWebRTCTransport(claims.RoomID, me)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "create transport: "+err.Error())
		return
	}

	gatherDone := make(chan struct{})
	var gatherOnce sync.Once
	peer.OnICECandidate(func(candidate *webrtc.ICECandidate) {
		if candidate == nil {
			gatherOnce.Do(func() {
				close(gatherDone)
			})
		}
	})

	if err := peer.SetRemoteDescription(offer); err != nil {
		_ = peer.Close()
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	answer, err := peer.CreateAnswer()
	if err != nil {
		_ = peer.Close()
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	if err := peer.SetLocalDescription(answer); err != nil {
		_ = peer.Close()
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	select {
	case <-gatherDone:
	case <-time.After(whipGatherTimeout):
	case <-r.Context().Done():
		_ = peer.Close()
		return
	}

	if local := peer.LocalDescription(); local != nil {
		answer = *local
	}
	answer = applyVideoBitrateToDescription(answer)

	_, wasConnected, oldPeer, err := a.conference.AttachWHIPParticipant(claims, peer)
	if err != nil {
		_ = peer.Close()
		writeDomainError(w, err)
		return
	}
	oldSessionID := ""
	if oldPeer != nil {
		oldSessionID = a.currentWHIPSessionID(claims.RoomID, claims.ParticipantID)
	}

	media := parseWHIPMedia(offer.SDP)
	sessionID := randomID("whip", 12)
	session := &whipSession{
		ID:            sessionID,
		RoomID:        claims.RoomID,
		ParticipantID: claims.ParticipantID,
		Peer:          peer,
	}

	peer.OnTrack(func(track *webrtc.Track, _ *webrtc.RTPReceiver) {
		a.applyWHIPTrackUpdate(session.RoomID, session.ParticipantID, track)
	})
	peer.OnConnectionStateChange(func(state webrtc.PeerConnectionState) {
		switch state {
		case webrtc.PeerConnectionStateFailed, webrtc.PeerConnectionStateClosed:
			a.closeWHIPSession(session.ID, false)
		}
	})

	self, _, err := a.conference.UpdateParticipantPresence(claims.RoomID, claims.ParticipantID, media.presencePatch())
	if err != nil {
		_ = peer.Close()
		_, _, _ = a.conference.DetachParticipantPeer(claims.RoomID, claims.ParticipantID, peer, false)
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	if oldSessionID != "" {
		a.closeWHIPSession(oldSessionID, false)
	} else if oldPeer != nil {
		_ = oldPeer.Close()
	}
	a.registerWHIPSession(session)

	if !wasConnected {
		a.conference.Broadcast(context.Background(), claims.RoomID, claims.ParticipantID, "participant_joined", self)
	} else {
		a.conference.Broadcast(context.Background(), claims.RoomID, claims.ParticipantID, "participant_updated", self)
	}

	a.writeWHIPDiscovery(w, r)
	w.Header().Set("Content-Type", "application/sdp")
	w.Header().Set("Location", a.whipSessionURL(r, session.ID))
	w.WriteHeader(http.StatusCreated)
	_, _ = w.Write([]byte(answer.SDP))
}

func (a *Application) handleWHIPPatch(w http.ResponseWriter, r *http.Request, sessionID string) {
	session := a.getWHIPSession(sessionID)
	if session == nil {
		writeError(w, http.StatusNotFound, "WHIP session not found")
		return
	}

	body, err := ioutil.ReadAll(io.LimitReader(r.Body, 64<<10))
	if err != nil {
		writeError(w, http.StatusBadRequest, "read ICE fragment: "+err.Error())
		return
	}

	candidates := parseICECandidates(string(body))
	for _, candidate := range candidates {
		if err := session.Peer.AddICECandidate(webrtc.ICECandidateInit{Candidate: candidate}); err != nil {
			writeError(w, http.StatusBadRequest, "add ICE candidate: "+err.Error())
			return
		}
	}

	w.Header().Set("Accept-Patch", "application/trickle-ice-sdpfrag")
	w.WriteHeader(http.StatusNoContent)
}

func (a *Application) handleWHIPDelete(w http.ResponseWriter, r *http.Request, sessionID string) {
	if !a.closeWHIPSession(sessionID, true) {
		writeError(w, http.StatusNotFound, "WHIP session not found")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (a *Application) writeWHIPDiscovery(w http.ResponseWriter, r *http.Request) {
	for _, link := range buildWHIPLinks(a.cfg.WebRTC.ICEServers) {
		w.Header().Add("Link", link)
	}
	w.Header().Set("Accept-Patch", "application/trickle-ice-sdpfrag")
}

func (a *Application) writeWHIPUnauthorized(w http.ResponseWriter, message string) {
	w.Header().Set("WWW-Authenticate", `Bearer realm="11Meeting WHIP"`)
	writeError(w, http.StatusUnauthorized, message)
}

func (a *Application) whipEndpointURL(r *http.Request) string {
	return strings.TrimRight(requestBaseURL(r), "/") + "/api/v1/whip"
}

func (a *Application) whipSessionURL(r *http.Request, sessionID string) string {
	return strings.TrimRight(requestBaseURL(r), "/") + "/api/v1/whip/" + sessionID
}

func (a *Application) registerWHIPSession(session *whipSession) {
	a.whipMu.Lock()
	defer a.whipMu.Unlock()

	key := whipParticipantKey(session.RoomID, session.ParticipantID)
	a.whipSessions[session.ID] = session
	a.whipIndex[key] = session.ID
}

func (a *Application) getWHIPSession(sessionID string) *whipSession {
	a.whipMu.Lock()
	defer a.whipMu.Unlock()
	return a.whipSessions[sessionID]
}

func (a *Application) currentWHIPSessionID(roomID, participantID string) string {
	a.whipMu.Lock()
	defer a.whipMu.Unlock()
	return a.whipIndex[whipParticipantKey(roomID, participantID)]
}

func (a *Application) closeWHIPSessionByParticipant(roomID, participantID string, permanent bool) bool {
	a.whipMu.Lock()
	sessionID := a.whipIndex[whipParticipantKey(roomID, participantID)]
	a.whipMu.Unlock()
	if sessionID == "" {
		return false
	}
	return a.closeWHIPSession(sessionID, permanent)
}

func (a *Application) closeWHIPSession(sessionID string, permanent bool) bool {
	session := a.getWHIPSession(sessionID)
	if session == nil {
		return false
	}

	session.closeOnce.Do(func() {
		_ = session.Peer.Close()

		snapshot, removed, err := a.conference.DetachParticipantPeer(session.RoomID, session.ParticipantID, session.Peer, permanent)

		a.whipMu.Lock()
		delete(a.whipSessions, session.ID)
		delete(a.whipIndex, whipParticipantKey(session.RoomID, session.ParticipantID))
		a.whipMu.Unlock()

		if err == nil && snapshot.ID != "" {
			if removed {
				a.conference.Broadcast(context.Background(), session.RoomID, session.ParticipantID, "participant_left", map[string]string{
					"id": snapshot.ID,
				})
				return
			}

			a.conference.Broadcast(context.Background(), session.RoomID, session.ParticipantID, "participant_updated", snapshot)
		}
	})

	return true
}

func (a *Application) applyWHIPTrackUpdate(roomID, participantID string, track *webrtc.Track) {
	var (
		audioEnabled bool
		videoEnabled bool
		patch        ParticipantPresencePatch
	)

	streamID := strings.TrimSpace(track.Label())
	if streamID != "" {
		patch.StreamID = &streamID
	}

	switch track.Kind() {
	case webrtc.RTPCodecTypeAudio:
		audioEnabled = true
		patch.AudioEnabled = &audioEnabled
	case webrtc.RTPCodecTypeVideo:
		videoEnabled = true
		patch.VideoEnabled = &videoEnabled
	}

	snapshot, _, err := a.conference.UpdateParticipantPresence(roomID, participantID, patch)
	if err != nil {
		return
	}

	a.conference.Broadcast(context.Background(), roomID, participantID, "participant_updated", snapshot)
}

func parseWHIPMedia(rawSDP string) whipOfferMedia {
	var desc sdp.SessionDescription
	if err := desc.Unmarshal([]byte(rawSDP)); err != nil {
		return whipOfferMedia{}
	}

	media := whipOfferMedia{}
	for _, md := range desc.MediaDescriptions {
		if md == nil || md.MediaName.Port.Value == 0 || !mediaDirectionAllowsSend(md) {
			continue
		}

		switch md.MediaName.Media {
		case "audio":
			media.Audio = true
		case "video":
			media.Video = true
		default:
			continue
		}

		if media.StreamID == "" {
			if msid, ok := md.Attribute("msid"); ok {
				parts := strings.Fields(msid)
				if len(parts) > 0 {
					media.StreamID = strings.TrimSpace(parts[0])
				}
			}
		}
	}

	return media
}

func (m whipOfferMedia) presencePatch() ParticipantPresencePatch {
	patch := ParticipantPresencePatch{}
	patch.AudioEnabled = boolPtr(m.Audio)
	patch.VideoEnabled = boolPtr(m.Video)
	patch.ScreenSharing = boolPtr(false)
	if strings.TrimSpace(m.StreamID) != "" {
		patch.StreamID = &m.StreamID
	}
	return patch
}

func mediaDirectionAllowsSend(md *sdp.MediaDescription) bool {
	for _, attr := range md.Attributes {
		switch attr.Key {
		case "recvonly", "inactive":
			return false
		case "sendonly", "sendrecv":
			return true
		}
	}
	return true
}

func parseICECandidates(fragment string) []string {
	lines := strings.Split(fragment, "\n")
	candidates := make([]string, 0, len(lines))
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "a=") {
			line = strings.TrimPrefix(line, "a=")
		}
		if strings.HasPrefix(line, "candidate:") {
			candidates = append(candidates, line)
		}
	}
	return candidates
}

func buildWHIPLinks(servers []sfu.ICEServerConfig) []string {
	links := make([]string, 0, len(servers))
	for _, server := range servers {
		for _, rawURL := range server.URLs {
			if strings.TrimSpace(rawURL) == "" {
				continue
			}

			link := fmt.Sprintf("<%s>; rel=\"ice-server\"", rawURL)
			if server.Username != "" {
				link += fmt.Sprintf("; username=\"%s\"", escapeLinkParam(server.Username))
			}
			if server.Credential != "" {
				link += fmt.Sprintf("; credential=\"%s\"; credential-type=\"password\"", escapeLinkParam(server.Credential))
			}
			links = append(links, link)
		}
	}
	return links
}

func escapeLinkParam(value string) string {
	replacer := strings.NewReplacer("\\", "\\\\", "\"", "\\\"")
	return replacer.Replace(value)
}

func buildFFmpegCommand(whipURL, token string) string {
	return fmt.Sprintf(
		"ffmpeg -re -stream_loop -1 -i input.mp4 -map 0:v:0 -map 0:a:0? -c:v libx264 -profile:v baseline -tune zerolatency -preset veryfast -bf 0 -pix_fmt yuv420p -s %dx%d -r %d -b:v %dk -minrate %dk -maxrate %dk -bufsize %dk -c:a libopus -ar 48000 -ac 2 -strict experimental -f whip -authorization \"%s\" \"%s\"",
		videoWidth,
		videoHeight,
		videoFrameRate,
		videoMaxBitrateKbps,
		videoMinBitrateKbps,
		videoMaxBitrateKbps,
		videoMaxBitrateKbps*2,
		token,
		whipURL,
	)
}

func readBearerToken(r *http.Request) string {
	header := strings.TrimSpace(r.Header.Get("Authorization"))
	if header != "" {
		parts := strings.SplitN(header, " ", 2)
		if len(parts) == 2 && strings.EqualFold(parts[0], "Bearer") {
			return strings.TrimSpace(parts[1])
		}
	}
	return strings.TrimSpace(r.URL.Query().Get("token"))
}

func whipParticipantKey(roomID, participantID string) string {
	return roomID + ":" + participantID
}

func boolPtr(value bool) *bool {
	return &value
}
