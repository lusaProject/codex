package main

import (
	"context"
	"flag"
	"fmt"
	stdlog "log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

func main() {
	var (
		configFile   string
		addr         string
		certFile     string
		keyFile      string
		publicDir    string
		insecureHTTP bool
	)

	flag.StringVar(&configFile, "c", "config.toml", "path to TOML config")
	flag.StringVar(&addr, "a", ":8443", "listen address")
	flag.StringVar(&certFile, "cert", "cert.pem", "TLS certificate path")
	flag.StringVar(&keyFile, "key", "key.pem", "TLS private key path")
	flag.StringVar(&publicDir, "public", "", "static assets directory")
	flag.BoolVar(&insecureHTTP, "insecure-http", false, "serve plain HTTP (use behind a reverse proxy)")
	flag.Parse()

	cfg, err := loadConfig(configFile)
	if err != nil {
		stdlog.Fatalf("load config: %v", err)
	}

	if publicDir != "" {
		cfg.App.PublicDir = publicDir
	}

	if !insecureHTTP {
		if err := ensureCertificateFiles(certFile, keyFile); err != nil {
			stdlog.Fatalf("prepare TLS certificate: %v", err)
		}
	}

	app, err := NewApplication(cfg)
	if err != nil {
		stdlog.Fatalf("create application: %v", err)
	}

	server := &http.Server{
		Addr:         addr,
		Handler:      app.Routes(),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  90 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		<-ctx.Done()

		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()

		_ = server.Shutdown(shutdownCtx)
		app.Stop()
	}()

	scheme := "https"
	if insecureHTTP {
		scheme = "http"
	}

	if cfg.App.ServerLogEnabled {
		stdlog.Printf("meeting server listening on %s://%s", scheme, addr)
	}

	if insecureHTTP {
		err = server.ListenAndServe()
	} else {
		err = server.ListenAndServeTLS(certFile, keyFile)
	}

	if err != nil && err != http.ErrServerClosed {
		stdlog.Fatalf("server failed: %v", err)
	}

	if cfg.App.ServerLogEnabled {
		fmt.Println("server stopped")
	}
}
