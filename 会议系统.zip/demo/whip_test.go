package main

import (
	"strings"
	"testing"

	sfu "github.com/pion/ion-sfu/pkg"
)

func TestConferencePrepareFFmpegPublish(t *testing.T) {
	service := NewConferenceService(NewTokenManager("test-secret"), testConfig())
	rtc := RTCConfigResponse{}

	roomSession, err := service.CreateRoom(CreateRoomInput{
		Name:     "Producer Room",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	session, err := service.PrepareFFmpegPublish(roomSession.Room.ID, PrepareFFmpegPublishInput{
		DisplayName: "Program Feed",
	}, rtc)
	if err != nil {
		t.Fatalf("PrepareFFmpegPublish() error = %v", err)
	}

	if session.Participant.Role != "stream" {
		t.Fatalf("participant role = %q want stream", session.Participant.Role)
	}

	claims, err := service.tokenManager.Verify(session.Token)
	if err != nil {
		t.Fatalf("Verify() error = %v", err)
	}

	if claims.Use != TokenUseWHIP {
		t.Fatalf("claims use = %q want %q", claims.Use, TokenUseWHIP)
	}

	room, err := service.GetRoom(roomSession.Room.ID)
	if err != nil {
		t.Fatalf("GetRoom() error = %v", err)
	}

	if room.ParticipantCount != 1 {
		t.Fatalf("participant count = %d want 1", room.ParticipantCount)
	}
}

func TestParseWHIPMedia(t *testing.T) {
	rawSDP := strings.Join([]string{
		"v=0",
		"o=- 0 0 IN IP4 127.0.0.1",
		"s=-",
		"t=0 0",
		"m=audio 9 UDP/TLS/RTP/SAVPF 111",
		"a=sendonly",
		"a=msid:feed-stream audio-track",
		"m=video 9 UDP/TLS/RTP/SAVPF 102",
		"a=sendonly",
		"a=msid:feed-stream video-track",
		"",
	}, "\r\n")

	media := parseWHIPMedia(rawSDP)
	if !media.Audio || !media.Video {
		t.Fatalf("media flags = %+v", media)
	}
	if media.StreamID != "feed-stream" {
		t.Fatalf("stream id = %q want feed-stream", media.StreamID)
	}
}

func TestParseICECandidates(t *testing.T) {
	fragment := "a=ice-ufrag:test\r\na=candidate:1 1 UDP 1 127.0.0.1 5000 typ host\r\na=end-of-candidates\r\n"
	candidates := parseICECandidates(fragment)
	if len(candidates) != 1 {
		t.Fatalf("candidate count = %d want 1", len(candidates))
	}
	if candidates[0] != "candidate:1 1 UDP 1 127.0.0.1 5000 typ host" {
		t.Fatalf("candidate = %q", candidates[0])
	}
}

func TestBuildWHIPLinks(t *testing.T) {
	links := buildWHIPLinks([]sfu.ICEServerConfig{
		{
			URLs:       []string{"turn:turn.example.com:3478"},
			Username:   "demo",
			Credential: `pa"ss`,
		},
	})

	if len(links) != 1 {
		t.Fatalf("link count = %d want 1", len(links))
	}
	if !strings.Contains(links[0], `rel="ice-server"`) {
		t.Fatalf("missing rel attribute: %q", links[0])
	}
	if !strings.Contains(links[0], `credential="pa\"ss"`) {
		t.Fatalf("credential not escaped: %q", links[0])
	}
}
