package main

import (
	"context"
	"sync/atomic"
	"testing"
	"time"
)

func TestNegotiationCoordinatorCoalescesAndWaitsForAnswer(t *testing.T) {
	var sends atomic.Int32
	sent := make(chan struct{}, 4)

	coordinator := newNegotiationCoordinator(func(context.Context) error {
		sends.Add(1)
		sent <- struct{}{}
		return nil
	}, time.Millisecond)
	defer coordinator.Close()

	coordinator.Request()
	coordinator.Request()

	waitForNegotiationOffer(t, sent)
	assertNoNegotiationOffer(t, sent)

	coordinator.Request()
	assertNoNegotiationOffer(t, sent)

	coordinator.Answered()
	waitForNegotiationOffer(t, sent)

	if got := sends.Load(); got != 2 {
		t.Fatalf("send count = %d, want 2", got)
	}
}

func waitForNegotiationOffer(t *testing.T, sent <-chan struct{}) {
	t.Helper()

	select {
	case <-sent:
	case <-time.After(200 * time.Millisecond):
		t.Fatal("timed out waiting for negotiation offer")
	}
}

func assertNoNegotiationOffer(t *testing.T, sent <-chan struct{}) {
	t.Helper()

	select {
	case <-sent:
		t.Fatal("unexpected negotiation offer")
	case <-time.After(25 * time.Millisecond):
	}
}
