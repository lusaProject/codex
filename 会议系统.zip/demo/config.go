package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"
	"time"

	sfu "github.com/pion/ion-sfu/pkg"
	ionlog "github.com/pion/ion-sfu/pkg/log"
	"github.com/spf13/viper"
)

const portRangeLimit = 100

type AppConfig struct {
	Name                   string   `mapstructure:"name"`
	PublicBaseURL          string   `mapstructure:"public_base_url"`
	PublicDir              string   `mapstructure:"public_dir"`
	ServerLogEnabled       bool     `mapstructure:"server_log_enabled"`
	AllowedOrigins         []string `mapstructure:"allowed_origins"`
	TokenSecret            string   `mapstructure:"token_secret"`
	TokenTTLMinutes        int      `mapstructure:"token_ttl_minutes"`
	ReconnectGraceSeconds  int      `mapstructure:"reconnect_grace_seconds"`
	DefaultMaxParticipants int      `mapstructure:"default_max_participants"`
	MaxParticipantsLimit   int      `mapstructure:"max_participants_limit"`
	RoomIdleMinutes        int      `mapstructure:"room_idle_minutes"`
}

type RuntimeConfig struct {
	App      AppConfig          `mapstructure:"app"`
	WebRTC   sfu.WebRTCConfig   `mapstructure:"webrtc"`
	Log      ionlog.Config      `mapstructure:"log"`
	Receiver sfu.ReceiverConfig `mapstructure:"receiver"`
}

func (c RuntimeConfig) SFUConfig() sfu.Config {
	return sfu.Config{
		WebRTC:   c.WebRTC,
		Log:      c.Log,
		Receiver: c.Receiver,
	}
}

func (c RuntimeConfig) tokenTTL() time.Duration {
	return time.Duration(c.App.TokenTTLMinutes) * time.Minute
}

func (c RuntimeConfig) reconnectGrace() time.Duration {
	return time.Duration(c.App.ReconnectGraceSeconds) * time.Second
}

func (c RuntimeConfig) roomIdleTTL() time.Duration {
	return time.Duration(c.App.RoomIdleMinutes) * time.Minute
}

func loadConfig(file string) (RuntimeConfig, error) {
	cfg := RuntimeConfig{}

	viper.SetConfigFile(file)
	viper.SetConfigType("toml")
	viper.SetDefault("app.name", "11Meeting")
	viper.SetDefault("app.public_dir", "public")
	viper.SetDefault("app.server_log_enabled", false)
	viper.SetDefault("app.token_ttl_minutes", 240)
	viper.SetDefault("app.reconnect_grace_seconds", 120)
	viper.SetDefault("app.default_max_participants", 12)
	viper.SetDefault("app.max_participants_limit", 64)
	viper.SetDefault("app.room_idle_minutes", 120)
	viper.SetDefault("log.level", "info")
	viper.SetDefault("log.stats", false)
	viper.SetDefault("receiver.video.rembcycle", 2)
	viper.SetDefault("receiver.video.plicycle", 1)
	viper.SetDefault("receiver.video.tcccycle", 1)
	viper.SetDefault("receiver.video.maxbandwidth", videoMaxBitrateKbps)
	viper.SetDefault("receiver.video.maxbuffertime", 1000)

	if _, err := os.Stat(file); err != nil {
		return cfg, fmt.Errorf("config file %q not found", file)
	}

	if err := viper.ReadInConfig(); err != nil {
		return cfg, fmt.Errorf("read config: %w", err)
	}

	if err := viper.Unmarshal(&cfg); err != nil {
		return cfg, fmt.Errorf("unmarshal config: %w", err)
	}

	if len(cfg.WebRTC.ICEPortRange) > 2 {
		return cfg, fmt.Errorf("ICE port range must be [min,max]")
	}

	if len(cfg.WebRTC.ICEPortRange) == 2 {
		if cfg.WebRTC.ICEPortRange[1]-cfg.WebRTC.ICEPortRange[0] < portRangeLimit {
			return cfg, fmt.Errorf("ICE port range max-min must be at least %d", portRangeLimit)
		}
	}

	if cfg.App.PublicDir == "" {
		cfg.App.PublicDir = "public"
	}

	if cfg.App.TokenTTLMinutes <= 0 {
		cfg.App.TokenTTLMinutes = 240
	}

	if cfg.App.ReconnectGraceSeconds <= 0 {
		cfg.App.ReconnectGraceSeconds = 120
	}

	if cfg.App.DefaultMaxParticipants <= 0 {
		cfg.App.DefaultMaxParticipants = 12
	}

	if cfg.App.MaxParticipantsLimit < cfg.App.DefaultMaxParticipants {
		cfg.App.MaxParticipantsLimit = cfg.App.DefaultMaxParticipants
	}

	if cfg.App.RoomIdleMinutes <= 0 {
		cfg.App.RoomIdleMinutes = 120
	}

	if cfg.App.TokenSecret == "" {
		cfg.App.TokenSecret = randomHex(32)
	}

	if !cfg.App.ServerLogEnabled {
		cfg.Log.Level = "error"
		cfg.Log.Stats = false
	}

	return cfg, nil
}

func randomHex(size int) string {
	buf := make([]byte, size)
	if _, err := rand.Read(buf); err != nil {
		panic(err)
	}

	return hex.EncodeToString(buf)
}
