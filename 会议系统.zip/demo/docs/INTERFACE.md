# Interface Overview

当前版本使用两层接口：

## REST API

### 获取前端配置

```http
GET /api/v1/config
```

### 创建房间

```http
POST /api/v1/rooms
Content-Type: application/json

{
  "name": "产品评审会",
  "description": "Q2 roadmap review",
  "hostName": "Alice",
  "maxParticipants": 16
}
```

### 查询房间

```http
GET /api/v1/rooms/{roomId}
```

### 加入房间

```http
POST /api/v1/rooms/{roomId}/join
Content-Type: application/json

{
  "displayName": "Bob"
}
```

`create` 和 `join` 响应会返回：

```json
{
  "room": {},
  "participant": {},
  "token": "signed-token",
  "rtc": {
    "iceServers": []
  },
  "joinUrl": "https://host/?room=room_xxx"
}
```

## WebSocket JSON-RPC

客户端通过 `GET /ws?token=...` 建立信令连接。

### Client -> Server

#### `join`

```json
{
  "method": "join",
  "params": {
    "offer": {},
    "presence": {
      "audioEnabled": true,
      "videoEnabled": true,
      "screenSharing": false,
      "streamId": "local-stream-id"
    }
  },
  "id": "1"
}
```

#### `offer`

客户端发起重协商。

#### `answer`

响应服务端发起的重协商。

#### `trickle`

交换 ICE Candidate。

#### `update_presence`

更新参会者状态：

```json
{
  "method": "update_presence",
  "params": {
    "audioEnabled": false,
    "videoEnabled": true,
    "screenSharing": false
  },
  "id": "2"
}
```

### Server -> Client Notifications

- `offer`
- `trickle`
- `participant_joined`
- `participant_updated`
- `participant_left`

## FFmpeg WHIP

### Create a publish session

```http
POST /api/v1/rooms/{roomId}/ffmpeg
Content-Type: application/json

{
  "displayName": "Program Feed"
}
```

Response:

```json
{
  "room": {},
  "participant": {},
  "token": "signed-token",
  "whipUrl": "https://host/api/v1/whip",
  "ffmpegCommand": "ffmpeg ... -f whip -authorization \"signed-token\" \"https://host/api/v1/whip\""
}
```

### WHIP publish endpoint

```http
POST /api/v1/whip
Authorization: Bearer {token}
Content-Type: application/sdp
```

- `201 Created` returns the SDP answer in the response body
- `Location` points to the WHIP session resource
- `PATCH /api/v1/whip/{sessionId}` accepts `application/trickle-ice-sdpfrag`
- `DELETE /api/v1/whip/{sessionId}` closes the stream participant
