# 11Meeting Android Client

这个目录是 `public/index.html` / `public/app.js` 对应的原生 Android WebRTC 客户端。

## 已实现

- REST：读取 `/api/v1/config`、创建会议、预览会议、加入会议
- WebSocket JSON-RPC：连接 `/ws?token=...`
- WebRTC：本地摄像头/麦克风发布、远端音视频接收、ICE trickle、服务端重协商 offer/answer
- 会议状态：参会者加入、更新、离开，麦克风/摄像头状态同步
- 常用操作：静音、开关摄像头、切换摄像头、复制邀请链接、短线重连、离开会议

移动端版本聚焦会议主链路；H5 里的屏幕共享和 FFmpeg 命令面板没有放进这个首版原生客户端。

## 本地运行服务端

Android 默认不信任本地自签 HTTPS 证书。开发调试建议用明文 HTTP 启动服务：

```bash
go run . -c config.toml -a :8080 -insecure-http
```

模拟器里服务地址填：

```text
http://10.0.2.2:8080
```

真机调试时，把 `10.0.2.2` 换成电脑在同一局域网里的 IP，例如：

```text
http://192.168.1.20:8080
```

## Android Studio

1. 用 Android Studio 打开 `android-client/`
2. 等待 Gradle 同步
3. 运行 `app`
4. 首次进入会议时允许摄像头和麦克风权限

依赖主要是：

- `io.github.webrtc-sdk:android:144.7559.05`
- `com.squareup.okhttp3:okhttp:4.12.0`
- `androidx.annotation:annotation:1.10.0`
