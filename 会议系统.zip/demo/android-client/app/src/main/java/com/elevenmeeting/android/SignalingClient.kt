package com.elevenmeeting.android

import android.os.Handler
import android.os.Looper
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class SignalingClient(
    private val baseUrl: String,
    private val token: String,
    private val client: OkHttpClient,
    private val listener: Listener,
    private val mainHandler: Handler = Handler(Looper.getMainLooper()),
) {
    interface Listener {
        fun onOpen()
        fun onNotification(method: String, params: JSONObject)
        fun onClosed(reason: String)
        fun onError(error: Throwable)
    }

    private val requestId = AtomicInteger(1)
    private val pending = ConcurrentHashMap<String, (Result<JSONObject>) -> Unit>()
    private var webSocket: WebSocket? = null

    fun open() {
        val request = Request.Builder().url(webSocketUrl()).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                mainHandler.post { listener.onOpen() }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                rejectPending(IllegalStateException("信令连接已关闭"))
                mainHandler.post { listener.onClosed(reason.ifBlank { "closed" }) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                rejectPending(t)
                mainHandler.post { listener.onError(t) }
            }
        })
    }

    fun request(method: String, params: JSONObject = JSONObject(), callback: (Result<JSONObject>) -> Unit) {
        val id = requestId.getAndIncrement().toString()
        val payload = JSONObject()
            .put("jsonrpc", "2.0")
            .put("method", method)
            .put("params", params)
            .put("id", id)

        pending[id] = callback
        val sent = webSocket?.send(payload.toString()) == true
        if (!sent) {
            pending.remove(id)
            callback(Result.failure(IllegalStateException("信令连接未建立")))
        }
    }

    fun notify(method: String, params: JSONObject = JSONObject()) {
        val payload = JSONObject()
            .put("jsonrpc", "2.0")
            .put("method", method)
            .put("params", params)
        webSocket?.send(payload.toString())
    }

    fun close(leave: Boolean) {
        val socket = webSocket ?: return
        if (!leave) {
            socket.close(1000, "close")
            webSocket = null
            return
        }

        request("leave", JSONObject()) {
            socket.close(1000, "leave")
            webSocket = null
        }
        mainHandler.postDelayed({
            socket.close(1000, "leave-timeout")
            if (webSocket === socket) {
                webSocket = null
            }
        }, 800)
    }

    private fun handleMessage(text: String) {
        val message = runCatching { JSONObject(text) }.getOrNull() ?: return
        val id = message.optString("id", "")
        if (id.isNotBlank()) {
            val callback = pending.remove(id) ?: return
            val error = message.optJSONObject("error")
            if (error != null) {
                mainHandler.post { callback(Result.failure(IllegalStateException(error.optString("message", "请求失败")))) }
                return
            }

            val rawResult = message.opt("result")
            val result = when (rawResult) {
                is JSONObject -> rawResult
                null -> JSONObject()
                JSONObject.NULL -> JSONObject()
                else -> JSONObject().put("value", rawResult)
            }
            mainHandler.post { callback(Result.success(result)) }
            return
        }

        val method = message.optString("method", "")
        if (method.isBlank()) {
            return
        }
        val params = message.optJSONObject("params") ?: JSONObject()
        mainHandler.post { listener.onNotification(method, params) }
    }

    private fun rejectPending(error: Throwable) {
        val callbacks = pending.values.toList()
        pending.clear()
        callbacks.forEach { callback ->
            mainHandler.post { callback(Result.failure(error)) }
        }
    }

    private fun webSocketUrl(): String {
        val httpUrl = baseUrl.trim().trimEnd('/').toHttpUrl()
        val encodedToken = URLEncoder.encode(token, Charsets.UTF_8.name())
        val url = httpUrl.newBuilder()
            .encodedPath("/ws")
            .encodedQuery("token=$encodedToken")
            .build()
            .toString()
        return if (httpUrl.isHttps) {
            url.replaceFirst("https://", "wss://")
        } else {
            url.replaceFirst("http://", "ws://")
        }
    }
}
