package com.elevenmeeting.android

import org.json.JSONObject
import org.webrtc.IceCandidate
import org.webrtc.SessionDescription

fun SessionDescription.toJson(): JSONObject {
    return JSONObject()
        .put("type", type.canonicalForm())
        .put("sdp", description)
}

fun JSONObject.toSessionDescription(): SessionDescription {
    val type = SessionDescription.Type.fromCanonicalForm(getString("type"))
    return SessionDescription(type, getString("sdp"))
}

fun IceCandidate.toJson(): JSONObject {
    return JSONObject()
        .put("candidate", sdp)
        .put("sdpMid", sdpMid)
        .put("sdpMLineIndex", sdpMLineIndex)
}

fun JSONObject.toIceCandidate(): IceCandidate {
    return IceCandidate(
        optString("sdpMid"),
        optInt("sdpMLineIndex"),
        getString("candidate"),
    )
}
