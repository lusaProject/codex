package com.elevenmeeting.android

import android.os.Handler
import android.os.Looper
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MeetingApi(
    private val client: OkHttpClient,
    private val mainHandler: Handler = Handler(Looper.getMainLooper()),
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    fun loadConfig(baseUrl: String, callback: (Result<AppConfig>) -> Unit) {
        runAsync(callback) {
            AppConfig.fromJson(executeJson(Request.Builder().url(endpoint(baseUrl, "api", "v1", "config")).get().build()))
        }
    }

    fun previewRoom(baseUrl: String, roomId: String, callback: (Result<Pair<Room, String>>) -> Unit) {
        runAsync(callback) {
            val payload = executeJson(Request.Builder().url(endpoint(baseUrl, "api", "v1", "rooms", roomId)).get().build())
            Room.fromJson(payload.getJSONObject("room")) to payload.optString("joinUrl")
        }
    }

    fun createRoom(
        baseUrl: String,
        name: String,
        description: String,
        hostName: String,
        maxParticipants: Int,
        callback: (Result<MeetingSession>) -> Unit,
    ) {
        val body = JSONObject()
            .put("name", name)
            .put("description", description)
            .put("hostName", hostName)
            .put("maxParticipants", maxParticipants)
        runAsync(callback) {
            MeetingSession.fromJson(postJson(endpoint(baseUrl, "api", "v1", "rooms"), body))
        }
    }

    fun joinRoom(baseUrl: String, roomId: String, displayName: String, callback: (Result<MeetingSession>) -> Unit) {
        val body = JSONObject().put("displayName", displayName)
        runAsync(callback) {
            MeetingSession.fromJson(postJson(endpoint(baseUrl, "api", "v1", "rooms", roomId, "join"), body))
        }
    }

    fun close() {
        executor.shutdownNow()
    }

    private fun <T> runAsync(callback: (Result<T>) -> Unit, task: () -> T) {
        executor.execute {
            val result = runCatching(task)
            mainHandler.post { callback(result) }
        }
    }

    private fun postJson(url: HttpUrl, body: JSONObject): JSONObject {
        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()
        return executeJson(request)
    }

    private fun executeJson(request: Request): JSONObject {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            val payload = if (body.isBlank()) JSONObject() else JSONObject(body)
            if (!response.isSuccessful) {
                throw IOException(payload.optString("error", "HTTP ${response.code}"))
            }
            return payload
        }
    }

    private fun endpoint(baseUrl: String, vararg segments: String): HttpUrl {
        val builder = normalizedBase(baseUrl).newBuilder()
        segments.forEach { builder.addPathSegment(it) }
        return builder.build()
    }

    private fun normalizedBase(baseUrl: String): HttpUrl {
        val value = baseUrl.trim().trimEnd('/')
        require(value.isNotBlank()) { "请先填写服务地址" }
        return value.toHttpUrl()
    }
}
