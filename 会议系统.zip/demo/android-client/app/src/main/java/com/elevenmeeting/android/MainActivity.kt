package com.elevenmeeting.android

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import okhttp3.OkHttpClient
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera1Enumerator
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpSender
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoCapturer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : Activity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val okHttpClient = unsafeOkHttpClient()
    private val meetingApi = MeetingApi(okHttpClient, mainHandler)

    private lateinit var rootEglBase: EglBase
    private lateinit var peerFactory: PeerConnectionFactory

    private lateinit var serverInput: EditText
    private lateinit var statusText: TextView
    private lateinit var lobbyView: LinearLayout
    private lateinit var meetingView: LinearLayout
    private lateinit var roomNameInput: EditText
    private lateinit var roomDescriptionInput: EditText
    private lateinit var hostNameInput: EditText
    private lateinit var maxParticipantsInput: EditText
    private lateinit var joinRoomInput: EditText
    private lateinit var joinNameInput: EditText
    private lateinit var meetingTitle: TextView
    private lateinit var meetingSubtitle: TextView
    private lateinit var participantList: TextView
    private lateinit var localRenderer: SurfaceViewRenderer
    private lateinit var remoteVideoGrid: LinearLayout
    private lateinit var micButton: Button
    private lateinit var cameraButton: Button
    private lateinit var reconnectButton: Button
    private lateinit var copyLinkButton: Button

    private var currentSession: MeetingSession? = null
    private var currentParticipant: Participant? = null
    private var currentBaseUrl: String = ""
    private var localStreamId: String = ""

    private var signalingClient: SignalingClient? = null
    private var peerConnection: PeerConnection? = null
    private var joinedSignal = false
    private var makingOffer = AtomicBoolean(false)

    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var cameraCapturer: CameraVideoCapturer? = null
    private var localAudioSource: AudioSource? = null
    private var localVideoSource: VideoSource? = null
    private var localAudioTrack: AudioTrack? = null
    private var localVideoTrack: VideoTrack? = null
    private var audioSender: RtpSender? = null
    private var videoSender: RtpSender? = null
    private var audioEnabled = true
    private var videoEnabled = true

    private val participantMap = linkedMapOf<String, Participant>()
    private val pendingVideoTracksByStreamId = mutableMapOf<String, VideoTrack>()
    private val remoteVideoTracksByParticipantId = mutableMapOf<String, VideoTrack>()
    private val remoteRenderers = mutableListOf<Pair<VideoTrack, SurfaceViewRenderer>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rootEglBase = EglBase.create()
        initializePeerFactory()
        buildUi()
        loadServerConfig()
    }

    override fun onDestroy() {
        releaseTransport(leave = false)
        stopLocalMedia()
        localRenderer.release()
        rootEglBase.release()
        meetingApi.close()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MEDIA_PERMISSION_REQUEST && currentSession != null) {
            beginConference()
        }
    }

    private fun initializePeerFactory() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions(),
        )

        val audioDeviceModule = JavaAudioDeviceModule.builder(applicationContext).createAudioDeviceModule()
        peerFactory = PeerConnectionFactory.builder()
            .setAudioDeviceModule(audioDeviceModule)
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(rootEglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(rootEglBase.eglBaseContext))
            .createPeerConnectionFactory()
        audioDeviceModule.release()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        root.addView(title("11Meeting Android"))
        serverInput = editText("服务地址，例如 http://10.0.2.2:8080").apply {
            setText("https://192.168.1.10:8443")
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        root.addView(serverInput)
        val configButton = button("检查服务").apply { setOnClickListener { loadServerConfig() } }
        root.addView(configButton)
        statusText = TextView(this).apply {
            setTextColor(Color.rgb(81, 93, 110))
            textSize = 14f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(statusText)

        lobbyView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(lobbyView)
        buildLobbyUi(lobbyView)

        meetingView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        root.addView(meetingView)
        buildMeetingUi(meetingView)
    }

    private fun buildLobbyUi(parent: LinearLayout) {
        parent.addView(sectionTitle("创建会议"))
        roomNameInput = editText("会议标题")
        roomDescriptionInput = editText("会议描述，可选")
        hostNameInput = editText("主持人显示名称").apply { setText("lusa") }
        maxParticipantsInput = editText("最大参会人数，留空使用服务端默认").apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        parent.addView(roomNameInput)
        parent.addView(roomDescriptionInput)
        parent.addView(hostNameInput)
        parent.addView(maxParticipantsInput)
        parent.addView(button("创建并进入").apply { setOnClickListener { createRoom() } })

        parent.addView(sectionTitle("加入会议"))
        joinRoomInput = editText("会议室 ID，例如 room_xxxxx").apply { setText("room_onoayqizih") }
        joinNameInput = editText("你的显示名称").apply { setText("lusa") }
        parent.addView(joinRoomInput)
        parent.addView(joinNameInput)
        parent.addView(button("加入会议").apply { setOnClickListener { joinRoom() } })
        parent.addView(button("预览会议室").apply { setOnClickListener { previewRoom() } })
    }

    private fun buildMeetingUi(parent: LinearLayout) {
        meetingTitle = title("会议室")
        meetingSubtitle = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(81, 93, 110))
            setPadding(0, 0, 0, dp(10))
        }
        parent.addView(meetingTitle)
        parent.addView(meetingSubtitle)

        parent.addView(sectionTitle("本机画面"))
        localRenderer = SurfaceViewRenderer(this).apply {
            init(rootEglBase.eglBaseContext, null)
            setMirror(true)
            setEnableHardwareScaler(true)
        }
        parent.addView(localRenderer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))

        parent.addView(sectionTitle("远端画面"))
        remoteVideoGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        parent.addView(remoteVideoGrid)

        parent.addView(sectionTitle("参会成员"))
        participantList = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(42, 51, 65))
            setPadding(0, dp(6), 0, dp(10))
        }
        parent.addView(participantList)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        micButton = button("静音").apply { setOnClickListener { toggleMicrophone() } }
        cameraButton = button("关闭视频").apply { setOnClickListener { toggleCamera() } }
        val switchCameraButton = button("切换摄像头").apply { setOnClickListener { switchCamera() } }
        reconnectButton = button("短线重连").apply { setOnClickListener { reconnectConference() } }
        copyLinkButton = button("复制邀请链接").apply { setOnClickListener { copyInviteLink() } }
        val leaveButton = button("离开会议").apply {
            setTextColor(Color.rgb(180, 36, 36))
            setOnClickListener { leaveMeeting() }
        }
        controls.addView(micButton)
        controls.addView(cameraButton)
        controls.addView(switchCameraButton)
        controls.addView(reconnectButton)
        controls.addView(copyLinkButton)
        controls.addView(leaveButton)
        parent.addView(controls)
    }

    private fun loadServerConfig() {
        val baseUrl = serverBaseUrlOrNull() ?: return
        setStatus("正在检查服务...")
        meetingApi.loadConfig(baseUrl) { result ->
            result.onSuccess { config ->
                setStatus("服务可用：默认容量 ${config.defaultMaxParticipants} 人，ICE 节点 ${config.rtc.iceServers.size} 组")
            }.onFailure { error ->
                setStatus("服务检查失败：${error.message}")
            }
        }
    }

    private fun previewRoom() {
        val baseUrl = serverBaseUrlOrNull() ?: return
        val roomId = joinRoomInput.text.toString().trim()
        if (roomId.isBlank()) {
            setStatus("请先填写会议室 ID")
            return
        }
        setStatus("正在预览会议室...")
        meetingApi.previewRoom(baseUrl, roomId) { result ->
            result.onSuccess { (room, _) ->
                setStatus("${room.name}：${room.participantCount} / ${room.maxParticipants} 人。${room.description}")
            }.onFailure { error ->
                setStatus("预览失败：${error.message}")
            }
        }
    }

    private fun createRoom() {
        val baseUrl = serverBaseUrlOrNull() ?: return
        val name = roomNameInput.text.toString().trim()
        val hostName = hostNameInput.text.toString().trim()
        if (name.isBlank() || hostName.isBlank()) {
            setStatus("会议标题和主持人名称不能为空")
            return
        }
        setStatus("正在创建会议...")
        meetingApi.createRoom(
            baseUrl = baseUrl,
            name = name,
            description = roomDescriptionInput.text.toString().trim(),
            hostName = hostName,
            maxParticipants = maxParticipantsInput.text.toString().toIntOrNull() ?: 0,
        ) { result ->
            result.onSuccess { enterMeeting(baseUrl, it) }
                .onFailure { setStatus("创建失败：${it.message}") }
        }
    }

    private fun joinRoom() {
        val baseUrl = serverBaseUrlOrNull() ?: return
        val roomId = joinRoomInput.text.toString().trim()
        val displayName = joinNameInput.text.toString().trim()
        if (roomId.isBlank() || displayName.isBlank()) {
            setStatus("会议室 ID 和显示名称不能为空")
            return
        }
        setStatus("正在加入会议...")
        meetingApi.joinRoom(baseUrl, roomId, displayName) { result ->
            result.onSuccess { enterMeeting(baseUrl, it) }
                .onFailure { setStatus("加入失败：${it.message}") }
        }
    }

    private fun enterMeeting(baseUrl: String, session: MeetingSession) {
        releaseTransport(leave = false)
        stopLocalMedia()
        currentBaseUrl = baseUrl
        currentSession = session
        currentParticipant = session.participant
        localStreamId = "android_${session.participant.id}_${UUID.randomUUID().toString().replace("-", "")}"
        syncParticipants(session.room.participants)
        lobbyView.visibility = View.GONE
        meetingView.visibility = View.VISIBLE
        syncMeetingHeader()
        renderParticipants()
        setStatus("准备媒体设备...")

        if (needsMediaPermissions()) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), MEDIA_PERMISSION_REQUEST)
            return
        }
        beginConference()
    }

    private fun beginConference() {
        startLocalMedia()
        renderControls()
        setupConferenceConnection()
    }

    private fun startLocalMedia() {
        audioEnabled = true
        videoEnabled = true
        if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
            val audioConstraints = MediaConstraints()
            val audioSource = peerFactory.createAudioSource(audioConstraints)
            localAudioSource = audioSource
            localAudioTrack = peerFactory.createAudioTrack("audio_${localStreamId}", audioSource).apply {
                setEnabled(true)
            }
        } else {
            setStatus("没有麦克风权限，将只接收远端音频")
        }

        if (hasPermission(Manifest.permission.CAMERA)) {
            val capturer = createCameraCapturer()
            if (capturer != null) {
                cameraCapturer = capturer
                val textureHelper = SurfaceTextureHelper.create("CameraCaptureThread", rootEglBase.eglBaseContext)
                val videoSource = peerFactory.createVideoSource(false)
                surfaceTextureHelper = textureHelper
                localVideoSource = videoSource
                capturer.initialize(textureHelper, applicationContext, videoSource.capturerObserver)
                val profile = rtcVideoProfile()
                capturer.startCapture(profile.width, profile.height, profile.frameRate)
                localVideoTrack = peerFactory.createVideoTrack("video_${localStreamId}", localVideoSource).apply {
                    setEnabled(true)
                    addSink(localRenderer)
                }
            } else {
                setStatus("没有找到可用摄像头，将只接收远端视频")
            }
        } else {
            setStatus("没有摄像头权限，将只接收远端视频")
        }
    }

    private fun setupConferenceConnection() {
        val session = currentSession ?: return
        releaseTransport(leave = false)
        setStatus("正在连接信令...")

        signalingClient = SignalingClient(
            baseUrl = currentBaseUrl,
            token = session.token,
            client = okHttpClient,
            listener = object : SignalingClient.Listener {
                override fun onOpen() {
                    setStatus("信令已连接，正在协商媒体...")
                    createPeerConnectionAndJoin()
                }

                override fun onNotification(method: String, params: JSONObject) {
                    handleSignalNotification(method, params)
                }

                override fun onClosed(reason: String) {
                    if (currentSession != null) {
                        setStatus("信令已断开：$reason")
                    }
                }

                override fun onError(error: Throwable) {
                    setStatus("信令异常：${error.message}")
                }
            },
        ).also { it.open() }
    }

    private fun createPeerConnectionAndJoin() {
        val session = currentSession ?: return
        val iceServers = session.rtc.iceServers
            .filter { it.urls.isNotEmpty() }
            .map { server ->
                PeerConnection.IceServer.builder(server.urls)
                    .setUsername(server.username.orEmpty())
                    .setPassword(server.credential.orEmpty())
                    .createIceServer()
            }
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            iceCandidatePoolSize = 4
        }

        peerConnection = peerFactory.createPeerConnection(rtcConfig, peerObserver()) ?: run {
            setStatus("创建 PeerConnection 失败")
            return
        }
        joinedSignal = false
        addLocalTracks()
        createInitialOffer()
    }

    private fun addLocalTracks() {
        val pc = peerConnection ?: return
        val streamIds = listOf(localStreamId)
        val recvOnly = RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY)

        localAudioTrack?.let { audioSender = pc.addTrack(it, streamIds) }
            ?: pc.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO, recvOnly)
        localVideoTrack?.let {
            videoSender = pc.addTrack(it, streamIds)
            configureVideoSender(videoSender)
        } ?: pc.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO, recvOnly)
    }

    private fun createInitialOffer() {
        val pc = peerConnection ?: return
        pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        sendJoinRequest(pc.localDescription ?: desc)
                    }

                    override fun onSetFailure(error: String) {
                        setStatus("设置本地 SDP 失败：$error")
                    }
                }, desc)
            }

            override fun onCreateFailure(error: String) {
                setStatus("创建 Offer 失败：$error")
            }
        }, MediaConstraints())
    }

    private fun sendJoinRequest(offer: SessionDescription) {
        val params = JSONObject()
            .put("offer", offer.toJson())
            .put("presence", currentPresence())

        signalingClient?.request("join", params) { result ->
            result.onSuccess { payload ->
                val answer = payload.getJSONObject("answer").toSessionDescription()
                peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        mainHandler.post {
                            joinedSignal = true
                            val self = Participant.fromJson(payload.getJSONObject("self"))
                            currentSession = currentSession?.copy(
                                room = Room.fromJson(payload.getJSONObject("room")),
                                participant = self,
                            )
                            currentParticipant = self
                            currentSession?.room?.participants?.let { syncParticipants(it) }
                            currentParticipant?.let { participantMap[it.id] = it }
                            syncPendingStreams()
                            syncMeetingHeader()
                            renderParticipants()
                            renderControls()
                            configureVideoSender(videoSender)
                            setStatus("已连接会议")
                        }
                    }

                    override fun onSetFailure(error: String) {
                        setStatus("设置远端 Answer 失败：$error")
                    }
                }, answer)
            }.onFailure { error ->
                setStatus("加入信令失败：${error.message}")
            }
        }
    }

    private fun handleSignalNotification(method: String, params: JSONObject) {
        when (method) {
            "offer" -> handleRemoteOffer(params)
            "trickle" -> peerConnection?.addIceCandidate(params.toIceCandidate())
            "participant_joined" -> {
                val participant = Participant.fromJson(params)
                participantMap[participant.id] = participant
                renderParticipants()
            }
            "participant_updated" -> {
                val participant = Participant.fromJson(params)
                participantMap[participant.id] = participant
                if (participant.id == currentParticipant?.id) {
                    currentParticipant = participant
                }
                syncPendingStreams()
                renderParticipants()
                renderControls()
            }
            "participant_left" -> {
                val id = params.optString("id")
                participantMap.remove(id)
                remoteVideoTracksByParticipantId.remove(id)
                renderParticipants()
            }
        }
    }

    private fun handleRemoteOffer(offerJson: JSONObject) {
        val pc = peerConnection ?: return
        if (pc.signalingState() != PeerConnection.SignalingState.STABLE) {
            mainHandler.postDelayed({ handleRemoteOffer(offerJson) }, 250)
            return
        }

        pc.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                pc.createAnswer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        pc.setLocalDescription(object : SimpleSdpObserver() {
                            override fun onSetSuccess() {
                                signalingClient?.request(
                                    "answer",
                                    JSONObject().put("desc", pc.localDescription?.toJson() ?: desc.toJson()),
                                ) { result ->
                                    result.onFailure { setStatus("发送 Answer 失败：${it.message}") }
                                }
                            }

                            override fun onSetFailure(error: String) {
                                setStatus("设置本地 Answer 失败：$error")
                            }
                        }, desc)
                    }

                    override fun onCreateFailure(error: String) {
                        setStatus("创建 Answer 失败：$error")
                    }
                }, MediaConstraints())
            }

            override fun onSetFailure(error: String) {
                setStatus("设置远端 Offer 失败：$error")
            }
        }, offerJson.toSessionDescription())
    }

    private fun negotiateFromClient() {
        if (!joinedSignal || !makingOffer.compareAndSet(false, true)) {
            return
        }
        val pc = peerConnection ?: run {
            makingOffer.set(false)
            return
        }

        pc.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                pc.setLocalDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        signalingClient?.request(
                            "offer",
                            JSONObject().put("desc", pc.localDescription?.toJson() ?: desc.toJson()),
                        ) { result ->
                            makingOffer.set(false)
                            result.onSuccess { answer ->
                                pc.setRemoteDescription(SimpleSdpObserver(), answer.toSessionDescription())
                            }.onFailure { setStatus("重协商失败：${it.message}") }
                        }
                    }

                    override fun onSetFailure(error: String) {
                        makingOffer.set(false)
                        setStatus("设置重协商 Offer 失败：$error")
                    }
                }, desc)
            }

            override fun onCreateFailure(error: String) {
                makingOffer.set(false)
                setStatus("创建重协商 Offer 失败：$error")
            }
        }, MediaConstraints())
    }

    private fun peerObserver(): PeerConnection.Observer {
        return object : PeerConnection.Observer {
            override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                mainHandler.post { setStatus("ICE 状态：$newState") }
            }

            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                mainHandler.post { setStatus("媒体连接：$newState") }
            }

            override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
            override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit

            override fun onIceCandidate(candidate: IceCandidate) {
                signalingClient?.notify("trickle", JSONObject().put("candidate", candidate.toJson()))
            }

            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = Unit

            override fun onAddStream(stream: MediaStream) {
                mainHandler.post { attachRemoteStream(stream) }
            }

            override fun onRemoveStream(stream: MediaStream) {
                mainHandler.post {
                    participantMap.values
                        .filter { it.streamId == stream.id }
                        .forEach { remoteVideoTracksByParticipantId.remove(it.id) }
                    renderParticipants()
                }
            }

            override fun onDataChannel(dataChannel: DataChannel) = Unit

            override fun onRenegotiationNeeded() {
                mainHandler.post { negotiateFromClient() }
            }

            override fun onAddTrack(receiver: RtpReceiver, mediaStreams: Array<out MediaStream>) {
                mainHandler.post {
                    val track = receiver.track()
                    if (track is VideoTrack) {
                        val streamId = mediaStreams.firstOrNull()?.id.orEmpty()
                        attachRemoteVideo(streamId, track)
                    } else if (track is AudioTrack) {
                        track.setEnabled(true)
                    }
                }
            }
        }
    }

    private fun attachRemoteStream(stream: MediaStream) {
        stream.audioTracks.forEach { it.setEnabled(true) }
        stream.videoTracks.forEach { attachRemoteVideo(stream.id, it) }
    }

    private fun attachRemoteVideo(streamId: String, track: VideoTrack) {
        if (streamId.isBlank()) {
            return
        }

        val participant = findParticipantByStreamId(streamId)
        if (participant == null) {
            pendingVideoTracksByStreamId[streamId] = track
            return
        }
        if (participant.id != currentParticipant?.id) {
            remoteVideoTracksByParticipantId[participant.id] = track
            renderParticipants()
        }
    }

    private fun syncPendingStreams() {
        val iterator = pendingVideoTracksByStreamId.iterator()
        while (iterator.hasNext()) {
            val (streamId, track) = iterator.next()
            val participant = findParticipantByStreamId(streamId) ?: continue
            if (participant.id != currentParticipant?.id) {
                remoteVideoTracksByParticipantId[participant.id] = track
            }
            iterator.remove()
        }
    }

    private fun updatePresence() {
        signalingClient?.request("update_presence", currentPresence()) { result ->
            result.onSuccess { payload ->
                val participant = Participant.fromJson(payload)
                currentParticipant = participant
                participantMap[participant.id] = participant
                renderParticipants()
            }.onFailure { error ->
                setStatus("同步状态失败：${error.message}")
            }
        }
    }

    private fun currentPresence(): JSONObject {
        return JSONObject()
            .put("audioEnabled", localAudioTrack != null && audioEnabled)
            .put("videoEnabled", localVideoTrack != null && videoEnabled)
            .put("screenSharing", false)
            .put("streamId", localStreamId)
    }

    private fun rtcVideoProfile(): RtcVideoConfig {
        return currentSession?.rtc?.video ?: RtcVideoConfig.Default
    }

    private fun configureVideoSender(sender: RtpSender?) {
        sender ?: return
        val parameters = sender.parameters ?: return
        val profile = rtcVideoProfile()

        parameters.encodings.forEach { encoding ->
            encoding.minBitrateBps = profile.minBitrateBps
            encoding.maxBitrateBps = profile.maxBitrateBps
        }
        runCatching { sender.setParameters(parameters) }
    }

    private fun toggleMicrophone() {
        val track = localAudioTrack ?: run {
            setStatus("当前没有可用麦克风轨道")
            return
        }
        audioEnabled = !audioEnabled
        track.setEnabled(audioEnabled)
        updatePresence()
        renderControls()
    }

    private fun toggleCamera() {
        val track = localVideoTrack ?: run {
            setStatus("当前没有可用摄像头轨道")
            return
        }
        videoEnabled = !videoEnabled
        track.setEnabled(videoEnabled)
        updatePresence()
        renderControls()
    }

    private fun switchCamera() {
        val capturer = cameraCapturer ?: run {
            setStatus("当前没有可切换的摄像头")
            return
        }
        capturer.switchCamera(object : CameraVideoCapturer.CameraSwitchHandler {
            override fun onCameraSwitchDone(isFrontCamera: Boolean) {
                localRenderer.setMirror(isFrontCamera)
                setStatus(if (isFrontCamera) "已切换到前置摄像头" else "已切换到后置摄像头")
            }

            override fun onCameraSwitchError(errorDescription: String) {
                setStatus("切换摄像头失败：$errorDescription")
            }
        })
    }

    private fun reconnectConference() {
        if (currentSession == null) {
            return
        }
        setStatus("正在重连...")
        releaseTransport(leave = false)
        setupConferenceConnection()
    }

    private fun leaveMeeting() {
        releaseTransport(leave = true)
        stopLocalMedia()
        currentSession = null
        currentParticipant = null
        participantMap.clear()
        remoteVideoTracksByParticipantId.clear()
        pendingVideoTracksByStreamId.clear()
        lobbyView.visibility = View.VISIBLE
        meetingView.visibility = View.GONE
        setStatus("已离开会议")
    }

    private fun copyInviteLink() {
        val link = currentSession?.joinUrl.orEmpty()
        if (link.isBlank()) {
            setStatus("当前没有邀请链接")
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("11Meeting invite", link))
        setStatus("邀请链接已复制")
    }

    private fun releaseTransport(leave: Boolean) {
        joinedSignal = false
        makingOffer.set(false)
        signalingClient?.close(leave)
        signalingClient = null
        peerConnection?.close()
        peerConnection?.dispose()
        peerConnection = null
        audioSender = null
        videoSender = null
        clearRemoteRenderers()
        remoteVideoTracksByParticipantId.clear()
        pendingVideoTracksByStreamId.clear()
    }

    private fun stopLocalMedia() {
        localVideoTrack?.removeSink(localRenderer)
        localVideoTrack?.dispose()
        localAudioTrack?.dispose()
        try {
            cameraCapturer?.stopCapture()
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: RuntimeException) {
        }
        cameraCapturer?.dispose()
        surfaceTextureHelper?.dispose()
        localVideoSource?.dispose()
        localAudioSource?.dispose()

        cameraCapturer = null
        surfaceTextureHelper = null
        localVideoSource = null
        localAudioSource = null
        localVideoTrack = null
        localAudioTrack = null
    }

    private fun syncParticipants(participants: List<Participant>) {
        participantMap.clear()
        participants.forEach { participantMap[it.id] = it }
    }

    private fun findParticipantByStreamId(streamId: String): Participant? {
        return participantMap.values.firstOrNull { it.streamId == streamId }
    }

    private fun syncMeetingHeader() {
        val session = currentSession ?: return
        meetingTitle.text = session.room.name
        meetingSubtitle.text = "${session.room.id} · ${session.room.description.ifBlank { "点击远端画面可查看会议成员状态" }}"
    }

    private fun renderParticipants() {
        val rows = sortedParticipants().joinToString("\n") { participant ->
            val flags = buildList {
                add(roleLabel(participant))
                add(if (participant.connected) "在线" else "离线")
                if (!participant.audioEnabled) add("静音")
                if (!participant.videoEnabled) add("视频关闭")
                if (participant.screenSharing) add("共享中")
            }.joinToString(" / ")
            "${participant.displayName}  $flags"
        }
        participantList.text = rows.ifBlank { "暂无参会成员" }
        renderRemoteVideos()
    }

    private fun renderRemoteVideos() {
        clearRemoteRenderers()
        remoteVideoGrid.removeAllViews()

        val videos = sortedParticipants()
            .filter { it.id != currentParticipant?.id && it.connected && it.videoEnabled }
            .mapNotNull { participant ->
                remoteVideoTracksByParticipantId[participant.id]?.let { participant to it }
            }

        if (videos.isEmpty()) {
            remoteVideoGrid.addView(TextView(this).apply {
                text = "等待远端视频..."
                setTextColor(Color.rgb(92, 104, 122))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, dp(24))
            })
            return
        }

        videos.forEach { (participant, track) ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val name = TextView(this).apply {
                text = "${participant.displayName} · ${roleLabel(participant)}"
                textSize = 14f
                setTextColor(Color.rgb(42, 51, 65))
                setPadding(0, 0, 0, dp(6))
            }
            val renderer = SurfaceViewRenderer(this).apply {
                init(rootEglBase.eglBaseContext, null)
                setEnableHardwareScaler(true)
                setMirror(false)
            }
            track.addSink(renderer)
            remoteRenderers += track to renderer
            tile.addView(name)
            tile.addView(renderer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)))
            remoteVideoGrid.addView(tile)
        }
    }

    private fun clearRemoteRenderers() {
        remoteRenderers.forEach { (track, renderer) ->
            track.removeSink(renderer)
            renderer.release()
        }
        remoteRenderers.clear()
    }

    private fun renderControls() {
        micButton.text = if (audioEnabled) "静音" else "取消静音"
        cameraButton.text = if (videoEnabled) "关闭视频" else "开启视频"
        reconnectButton.isEnabled = currentSession != null
        copyLinkButton.isEnabled = !currentSession?.joinUrl.isNullOrBlank()
    }

    private fun sortedParticipants(): List<Participant> {
        val selfId = currentParticipant?.id
        return participantMap.values.sortedWith(
            compareByDescending<Participant> { it.screenSharing }
                .thenByDescending { it.connected }
                .thenByDescending { it.id == selfId }
                .thenBy { roleWeight(it.role) }
                .thenBy { it.displayName },
        )
    }

    private fun roleLabel(participant: Participant): String {
        val label = when (participant.role) {
            "host" -> "主持人"
            "stream" -> "推流源"
            else -> "参会者"
        }
        return if (participant.id == currentParticipant?.id) "$label / 你" else label
    }

    private fun roleWeight(role: String): Int {
        return when (role) {
            "host" -> 0
            "stream" -> 1
            else -> 2
        }
    }

    private fun createCameraCapturer(): CameraVideoCapturer? {
        val enumerator = if (Camera2Enumerator.isSupported(this)) Camera2Enumerator(this) else Camera1Enumerator(true)
        val deviceNames = enumerator.deviceNames
        val front = deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
        val fallback = deviceNames.firstOrNull()
        val deviceName = front ?: fallback ?: return null
        return enumerator.createCapturer(deviceName, null)
    }

    private fun needsMediaPermissions(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            (!hasPermission(Manifest.permission.CAMERA) || !hasPermission(Manifest.permission.RECORD_AUDIO))
    }

    private fun hasPermission(permission: String): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun serverBaseUrlOrNull(): String? {
        val value = serverInput.text.toString().trim().trimEnd('/')
        if (value.isBlank()) {
            setStatus("请先填写服务地址")
            return null
        }
        return value
    }

    private fun setStatus(message: String) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            statusText.text = message
        } else {
            mainHandler.post { statusText.text = message }
        }
    }

    private fun title(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 24f
            setTextColor(Color.rgb(20, 28, 38))
            setPadding(0, dp(8), 0, dp(8))
        }
    }

    private fun sectionTitle(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 18f
            setTextColor(Color.rgb(30, 42, 58))
            setPadding(0, dp(18), 0, dp(8))
        }
    }

    private fun editText(hintText: String): EditText {
        return EditText(this).apply {
            hint = hintText
            textSize = 15f
            setSingleLine(false)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun button(text: String): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    companion object {
        private const val MEDIA_PERMISSION_REQUEST = 1101
    }
}

open class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) = Unit
    override fun onSetSuccess() = Unit
    override fun onCreateFailure(error: String) = Unit
    override fun onSetFailure(error: String) = Unit
}

private fun unsafeOkHttpClient(): OkHttpClient {
    val trustManager = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }
    val sslContext = SSLContext.getInstance("TLS").apply {
        init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
    }
    return OkHttpClient.Builder()
        .sslSocketFactory(sslContext.socketFactory, trustManager)
        .hostnameVerifier { _, _ -> true }
        .retryOnConnectionFailure(true)
        .build()
}
