package com.elevenmeeting.android

import org.json.JSONArray
import org.json.JSONObject

data class IceServerConfig(
    val urls: List<String>,
    val username: String? = null,
    val credential: String? = null,
) {
    companion object {
        fun fromJson(json: JSONObject): IceServerConfig {
            val urlsValue = json.opt("urls")
            val urls = when (urlsValue) {
                is JSONArray -> (0 until urlsValue.length()).mapNotNull { urlsValue.optString(it).takeIf(String::isNotBlank) }
                is String -> listOf(urlsValue).filter(String::isNotBlank)
                else -> emptyList()
            }
            return IceServerConfig(
                urls = urls,
                username = json.optNullableString("username"),
                credential = json.optNullableString("credential"),
            )
        }
    }
}

data class RtcConfig(
    val iceServers: List<IceServerConfig> = emptyList(),
    val video: RtcVideoConfig = RtcVideoConfig.Default,
) {
    companion object {
        fun fromJson(json: JSONObject?): RtcConfig {
            val servers = json?.optJSONArray("iceServers") ?: JSONArray()
            return RtcConfig(
                iceServers = (0 until servers.length()).mapNotNull { index ->
                    servers.optJSONObject(index)?.let(IceServerConfig::fromJson)
                },
                video = RtcVideoConfig.fromJson(json?.optJSONObject("video")),
            )
        }
    }
}

data class RtcVideoConfig(
    val width: Int,
    val height: Int,
    val frameRate: Int,
    val minBitrateBps: Int,
    val startBitrateBps: Int,
    val maxBitrateBps: Int,
) {
    companion object {
        val Default = RtcVideoConfig(
            width = 1920,
            height = 1080,
            frameRate = 30,
            minBitrateBps = 2_500_000,
            startBitrateBps = 4_000_000,
            maxBitrateBps = 6_000_000,
        )

        fun fromJson(json: JSONObject?): RtcVideoConfig {
            return RtcVideoConfig(
                width = json?.optInt("width", Default.width)?.takeIf { it > 0 } ?: Default.width,
                height = json?.optInt("height", Default.height)?.takeIf { it > 0 } ?: Default.height,
                frameRate = json?.optInt("frameRate", Default.frameRate)?.takeIf { it > 0 } ?: Default.frameRate,
                minBitrateBps = json?.optInt("minBitrateBps", Default.minBitrateBps)?.takeIf { it > 0 }
                    ?: Default.minBitrateBps,
                startBitrateBps = json?.optInt("startBitrateBps", Default.startBitrateBps)?.takeIf { it > 0 }
                    ?: Default.startBitrateBps,
                maxBitrateBps = json?.optInt("maxBitrateBps", Default.maxBitrateBps)?.takeIf { it > 0 }
                    ?: Default.maxBitrateBps,
            )
        }
    }
}

data class AppConfig(
    val name: String,
    val defaultMaxParticipants: Int,
    val maxParticipantsLimit: Int,
    val rtc: RtcConfig,
) {
    companion object {
        fun fromJson(json: JSONObject): AppConfig {
            return AppConfig(
                name = json.optString("name", "11Meeting"),
                defaultMaxParticipants = json.optInt("defaultMaxParticipants", 12),
                maxParticipantsLimit = json.optInt("maxParticipantsLimit", 64),
                rtc = RtcConfig.fromJson(json.optJSONObject("rtc")),
            )
        }
    }
}

data class Participant(
    val id: String,
    val displayName: String,
    val role: String,
    val joinedAt: String,
    val connected: Boolean,
    val audioEnabled: Boolean,
    val videoEnabled: Boolean,
    val screenSharing: Boolean,
    val streamId: String,
) {
    companion object {
        fun fromJson(json: JSONObject): Participant {
            return Participant(
                id = json.optString("id"),
                displayName = json.optString("displayName", "未命名"),
                role = json.optString("role", "member"),
                joinedAt = json.optString("joinedAt"),
                connected = json.optBoolean("connected", false),
                audioEnabled = json.optBoolean("audioEnabled", false),
                videoEnabled = json.optBoolean("videoEnabled", false),
                screenSharing = json.optBoolean("screenSharing", false),
                streamId = json.optString("streamId"),
            )
        }
    }
}

data class Room(
    val id: String,
    val name: String,
    val description: String,
    val maxParticipants: Int,
    val participantCount: Int,
    val participants: List<Participant>,
) {
    companion object {
        fun fromJson(json: JSONObject): Room {
            val participantsJson = json.optJSONArray("participants") ?: JSONArray()
            return Room(
                id = json.optString("id"),
                name = json.optString("name", "会议室"),
                description = json.optString("description"),
                maxParticipants = json.optInt("maxParticipants", 0),
                participantCount = json.optInt("participantCount", participantsJson.length()),
                participants = (0 until participantsJson.length()).mapNotNull { index ->
                    participantsJson.optJSONObject(index)?.let(Participant::fromJson)
                },
            )
        }
    }
}

data class MeetingSession(
    val room: Room,
    val participant: Participant,
    val token: String,
    val rtc: RtcConfig,
    val joinUrl: String,
) {
    companion object {
        fun fromJson(json: JSONObject): MeetingSession {
            return MeetingSession(
                room = Room.fromJson(json.getJSONObject("room")),
                participant = Participant.fromJson(json.getJSONObject("participant")),
                token = json.getString("token"),
                rtc = RtcConfig.fromJson(json.optJSONObject("rtc")),
                joinUrl = json.optString("joinUrl"),
            )
        }
    }
}

fun JSONObject.optNullableString(name: String): String? {
    if (!has(name) || isNull(name)) {
        return null
    }
    return optString(name).takeIf(String::isNotBlank)
}
