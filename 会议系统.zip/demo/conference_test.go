package main

import (
	"testing"
	"time"

	"github.com/sourcegraph/jsonrpc2"
)

func testConfig() RuntimeConfig {
	return RuntimeConfig{
		App: AppConfig{
			TokenSecret:            "test-secret",
			TokenTTLMinutes:        30,
			ReconnectGraceSeconds:  60,
			DefaultMaxParticipants: 8,
			MaxParticipantsLimit:   16,
			RoomIdleMinutes:        30,
		},
	}
}

func TestConferenceCreateAndJoinRoom(t *testing.T) {
	service := NewConferenceService(NewTokenManager("test-secret"), testConfig())
	rtc := RTCConfigResponse{}

	session, err := service.CreateRoom(CreateRoomInput{
		Name:     "Weekly Sync",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	if session.Room.Name != "Weekly Sync" {
		t.Fatalf("CreateRoom() room name = %q", session.Room.Name)
	}

	joined, err := service.JoinRoom(session.Room.ID, JoinRoomInput{DisplayName: "Bob"}, rtc)
	if err != nil {
		t.Fatalf("JoinRoom() error = %v", err)
	}

	if joined.Participant.DisplayName != "Bob" {
		t.Fatalf("JoinRoom() participant name = %q", joined.Participant.DisplayName)
	}

	room, err := service.GetRoom(session.Room.ID)
	if err != nil {
		t.Fatalf("GetRoom() error = %v", err)
	}

	if room.ParticipantCount != 2 {
		t.Fatalf("participant count = %d want 2", room.ParticipantCount)
	}
}

func TestConferenceUpdatePresence(t *testing.T) {
	service := NewConferenceService(NewTokenManager("test-secret"), testConfig())
	rtc := RTCConfigResponse{}

	session, err := service.CreateRoom(CreateRoomInput{
		Name:     "Design Review",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	audioEnabled := false
	videoEnabled := false
	streamID := "stream-123"
	participant, _, err := service.UpdateParticipantPresence(session.Room.ID, session.Participant.ID, ParticipantPresencePatch{
		AudioEnabled: &audioEnabled,
		VideoEnabled: &videoEnabled,
		StreamID:     &streamID,
	})
	if err != nil {
		t.Fatalf("UpdateParticipantPresence() error = %v", err)
	}

	if participant.AudioEnabled || participant.VideoEnabled || participant.StreamID != streamID {
		t.Fatalf("presence not updated: %+v", participant)
	}
}

func TestConferenceRemovesExpiredReservations(t *testing.T) {
	service := NewConferenceService(NewTokenManager("test-secret"), testConfig())
	rtc := RTCConfigResponse{}

	session, err := service.CreateRoom(CreateRoomInput{
		Name:     "Townhall",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	room := service.rooms[session.Room.ID]
	room.Participants["stale"] = &ParticipantSession{
		ID:        "stale",
		ExpiresAt: time.Now().Add(-1 * time.Minute),
	}

	service.mu.Lock()
	service.cleanupLocked(time.Now().UTC())
	service.mu.Unlock()

	if _, ok := room.Participants["stale"]; ok {
		t.Fatalf("expired participant was not removed")
	}
}

func TestConferenceTemporaryDisconnectAllowsReconnect(t *testing.T) {
	service := NewConferenceService(NewTokenManager("test-secret"), testConfig())
	rtc := RTCConfigResponse{}

	session, err := service.CreateRoom(CreateRoomInput{
		Name:     "Reconnect Demo",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	claims, err := service.tokenManager.Verify(session.Token)
	if err != nil {
		t.Fatalf("Verify() error = %v", err)
	}

	conn1 := new(jsonrpc2.Conn)
	if _, wasConnected, _, _, err := service.AttachParticipantConnection(claims, conn1); err != nil {
		t.Fatalf("AttachParticipantConnection() error = %v", err)
	} else if wasConnected {
		t.Fatalf("expected first attach to start disconnected")
	}

	snapshot, removed, err := service.DetachParticipantConnection(session.Room.ID, session.Participant.ID, conn1, false)
	if err != nil {
		t.Fatalf("DetachParticipantConnection() error = %v", err)
	}
	if removed {
		t.Fatalf("temporary disconnect should not remove participant")
	}
	if snapshot.Connected {
		t.Fatalf("temporary disconnect should mark participant offline")
	}

	conn2 := new(jsonrpc2.Conn)
	snapshot, wasConnected, _, _, err := service.AttachParticipantConnection(claims, conn2)
	if err != nil {
		t.Fatalf("AttachParticipantConnection() reconnect error = %v", err)
	}
	if wasConnected {
		t.Fatalf("reconnect should happen from offline state")
	}
	if !snapshot.Connected {
		t.Fatalf("reconnected participant should be online")
	}
}

func TestConferenceRemovesDisconnectedParticipantAfterReconnectGrace(t *testing.T) {
	cfg := testConfig()
	cfg.App.ReconnectGraceSeconds = 1
	service := NewConferenceService(NewTokenManager("test-secret"), cfg)
	rtc := RTCConfigResponse{}

	session, err := service.CreateRoom(CreateRoomInput{
		Name:     "Grace Window",
		HostName: "Alice",
	}, rtc)
	if err != nil {
		t.Fatalf("CreateRoom() error = %v", err)
	}

	claims, err := service.tokenManager.Verify(session.Token)
	if err != nil {
		t.Fatalf("Verify() error = %v", err)
	}

	conn := new(jsonrpc2.Conn)
	if _, _, _, _, err := service.AttachParticipantConnection(claims, conn); err != nil {
		t.Fatalf("AttachParticipantConnection() error = %v", err)
	}
	if _, _, err := service.DetachParticipantConnection(session.Room.ID, session.Participant.ID, conn, false); err != nil {
		t.Fatalf("DetachParticipantConnection() error = %v", err)
	}

	room := service.rooms[session.Room.ID]
	room.Participants[session.Participant.ID].DisconnectedAt = time.Now().UTC().Add(-2 * time.Second)

	service.mu.Lock()
	service.cleanupLocked(time.Now().UTC())
	service.mu.Unlock()

	if _, ok := room.Participants[session.Participant.ID]; ok {
		t.Fatalf("disconnected participant should be removed after grace window")
	}
}
