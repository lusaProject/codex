package main

import (
	"strings"
	"testing"
)

func TestApplyVideoBitrateToSDP(t *testing.T) {
	raw := strings.Join([]string{
		"v=0",
		"o=- 0 0 IN IP4 127.0.0.1",
		"s=-",
		"t=0 0",
		"m=audio 9 UDP/TLS/RTP/SAVPF 111",
		"c=IN IP4 0.0.0.0",
		"a=rtpmap:111 opus/48000/2",
		"m=video 9 UDP/TLS/RTP/SAVPF 96 97 102",
		"c=IN IP4 0.0.0.0",
		"b=AS:1200",
		"a=rtpmap:96 VP8/90000",
		"a=rtpmap:97 rtx/90000",
		"a=fmtp:97 apt=96",
		"a=rtpmap:102 H264/90000",
		"a=fmtp:102 profile-level-id=42e01f;packetization-mode=1",
		"",
	}, "\r\n")

	got := applyVideoBitrateToSDP(raw)
	if !strings.Contains(got, "\r\nb=AS:6000\r\n") {
		t.Fatalf("missing 1080p video AS bandwidth:\n%s", got)
	}
	if strings.Contains(got, "b=AS:1200") {
		t.Fatalf("old video bandwidth was not replaced:\n%s", got)
	}
	if !strings.Contains(got, "a=fmtp:96 x-google-min-bitrate=2500;x-google-start-bitrate=4000;x-google-max-bitrate=6000") {
		t.Fatalf("missing VP8 bitrate fmtp:\n%s", got)
	}
	if !strings.Contains(got, "a=fmtp:102 profile-level-id=42e01f;packetization-mode=1;x-google-min-bitrate=2500;x-google-start-bitrate=4000;x-google-max-bitrate=6000") {
		t.Fatalf("missing H264 bitrate fmtp:\n%s", got)
	}
	if strings.Contains(got, "a=fmtp:97 apt=96;x-google") {
		t.Fatalf("rtx fmtp should not receive encoder bitrate params:\n%s", got)
	}
}

func TestBuildFFmpegCommandUses1080pBitrate(t *testing.T) {
	got := buildFFmpegCommand("https://example.test/api/v1/whip", "token")
	for _, want := range []string{
		"-s 1920x1080",
		"-r 30",
		"-b:v 6000k",
		"-minrate 2500k",
		"-maxrate 6000k",
		"-bufsize 12000k",
	} {
		if !strings.Contains(got, want) {
			t.Fatalf("ffmpeg command missing %q: %s", want, got)
		}
	}
}
