module meeting

go 1.26.1

require (
	github.com/gorilla/websocket v1.4.2
	github.com/pion/ion-sfu v1.0.7
	github.com/pion/sdp/v2 v2.4.0
	github.com/pion/webrtc/v3 v3.0.0-beta.4.0.20200902134452-789ff0975342
	github.com/sourcegraph/jsonrpc2 v0.0.0-20200429184054-15c2290dcb37
	github.com/spf13/viper v1.7.1
)

require (
	github.com/cheekybits/genny v1.0.0 // indirect
	github.com/fsnotify/fsnotify v1.4.9 // indirect
	github.com/golang/protobuf v1.4.2 // indirect
	github.com/google/uuid v1.1.1 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/lucas-clemente/quic-go v0.18.0 // indirect
	github.com/lucsky/cuid v1.0.2 // indirect
	github.com/magiconair/properties v1.8.1 // indirect
	github.com/marten-seemann/qtls v0.10.0 // indirect
	github.com/marten-seemann/qtls-go1-15 v0.1.0 // indirect
	github.com/mitchellh/mapstructure v1.1.2 // indirect
	github.com/pelletier/go-toml v1.2.0 // indirect
	github.com/pion/datachannel v1.4.20 // indirect
	github.com/pion/dtls/v2 v2.0.2 // indirect
	github.com/pion/ice/v2 v2.0.1 // indirect
	github.com/pion/logging v0.2.2 // indirect
	github.com/pion/mdns v0.0.4 // indirect
	github.com/pion/quic v0.1.4 // indirect
	github.com/pion/randutil v0.1.0 // indirect
	github.com/pion/rtcp v1.2.3 // indirect
	github.com/pion/rtp v1.6.0 // indirect
	github.com/pion/sctp v1.7.9 // indirect
	github.com/pion/srtp v1.5.1 // indirect
	github.com/pion/stun v0.3.5 // indirect
	github.com/pion/transport v0.10.1 // indirect
	github.com/pion/turn/v2 v2.0.4 // indirect
	github.com/pion/udp v0.1.0 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/rs/zerolog v1.19.0 // indirect
	github.com/spf13/afero v1.1.2 // indirect
	github.com/spf13/cast v1.3.0 // indirect
	github.com/spf13/jwalterweatherman v1.0.0 // indirect
	github.com/spf13/pflag v1.0.3 // indirect
	github.com/subosito/gotenv v1.2.0 // indirect
	golang.org/x/crypto v0.0.0-20200709230013-948cd5f35899 // indirect
	golang.org/x/net v0.0.0-20200707034311-ab3426394381 // indirect
	golang.org/x/sys v0.0.0-20200724161237-0e2f3a69832c // indirect
	golang.org/x/text v0.3.2 // indirect
	golang.org/x/xerrors v0.0.0-20191204190536-9bdfabe68543 // indirect
	google.golang.org/protobuf v1.23.0 // indirect
	gopkg.in/ini.v1 v1.51.1 // indirect
	gopkg.in/yaml.v2 v2.3.0 // indirect
)
