package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"
)

var (
	ErrInvalidToken = errors.New("invalid token")
	ErrExpiredToken = errors.New("token expired")
)

const (
	TokenUseSignal = "signal"
	TokenUseWHIP   = "whip"
)

type JoinClaims struct {
	RoomID        string `json:"roomId"`
	ParticipantID string `json:"participantId"`
	DisplayName   string `json:"displayName"`
	Role          string `json:"role"`
	ExpiresAt     int64  `json:"exp"`
	Use           string `json:"use,omitempty"`
}

func (c JoinClaims) Allows(use string) bool {
	return c.Use == "" || c.Use == use
}

type TokenManager struct {
	secret []byte
}

func NewTokenManager(secret string) *TokenManager {
	return &TokenManager{secret: []byte(secret)}
}

func (m *TokenManager) Sign(claims JoinClaims) (string, error) {
	payload, err := json.Marshal(claims)
	if err != nil {
		return "", fmt.Errorf("marshal claims: %w", err)
	}

	encodedPayload := base64.RawURLEncoding.EncodeToString(payload)
	mac := hmac.New(sha256.New, m.secret)
	_, _ = mac.Write([]byte(encodedPayload))
	signature := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))

	return encodedPayload + "." + signature, nil
}

func (m *TokenManager) Verify(token string) (JoinClaims, error) {
	claims := JoinClaims{}
	parts := strings.Split(token, ".")
	if len(parts) != 2 {
		return claims, ErrInvalidToken
	}

	mac := hmac.New(sha256.New, m.secret)
	_, _ = mac.Write([]byte(parts[0]))
	expectedSignature := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))

	if subtle.ConstantTimeCompare([]byte(parts[1]), []byte(expectedSignature)) != 1 {
		return claims, ErrInvalidToken
	}

	payload, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil {
		return claims, ErrInvalidToken
	}

	if err := json.Unmarshal(payload, &claims); err != nil {
		return claims, ErrInvalidToken
	}

	if claims.ExpiresAt > 0 && time.Now().Unix() > claims.ExpiresAt {
		return claims, ErrExpiredToken
	}

	if claims.RoomID == "" || claims.ParticipantID == "" {
		return claims, ErrInvalidToken
	}

	return claims, nil
}
