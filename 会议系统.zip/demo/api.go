package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	sfu "github.com/pion/ion-sfu/pkg"
	"github.com/sourcegraph/jsonrpc2"
	websocketjsonrpc2 "github.com/sourcegraph/jsonrpc2/websocket"
)

type RTCICEServer struct {
	URLs       []string `json:"urls"`
	Username   string   `json:"username,omitempty"`
	Credential string   `json:"credential,omitempty"`
}

type RTCConfigResponse struct {
	ICEServers []RTCICEServer         `json:"iceServers"`
	Video      RTCVideoConfigResponse `json:"video"`
}

type AppConfigResponse struct {
	Name                   string            `json:"name"`
	DefaultMaxParticipants int               `json:"defaultMaxParticipants"`
	MaxParticipantsLimit   int               `json:"maxParticipantsLimit"`
	RTC                    RTCConfigResponse `json:"rtc"`
}

type Application struct {
	cfg          RuntimeConfig
	tokenManager *TokenManager
	conference   *ConferenceService
	sfu          *sfu.SFU
	upgrader     websocket.Upgrader
	janitorStop  context.CancelFunc
	whipMu       sync.Mutex
	whipSessions map[string]*whipSession
	whipIndex    map[string]string
}

func NewApplication(cfg RuntimeConfig) (*Application, error) {
	tokenManager := NewTokenManager(cfg.App.TokenSecret)
	conference := NewConferenceService(tokenManager, cfg)
	ctx, cancel := context.WithCancel(context.Background())

	app := &Application{
		cfg:          cfg,
		tokenManager: tokenManager,
		conference:   conference,
		sfu:          sfu.NewSFU(cfg.SFUConfig()),
		upgrader: websocket.Upgrader{
			ReadBufferSize:  1024,
			WriteBufferSize: 1024,
			CheckOrigin:     buildOriginChecker(cfg.App.AllowedOrigins),
		},
		janitorStop:  cancel,
		whipSessions: make(map[string]*whipSession),
		whipIndex:    make(map[string]string),
	}

	go conference.RunJanitor(ctx)
	return app, nil
}

func (a *Application) Stop() {
	if a.janitorStop != nil {
		a.janitorStop()
	}
}

func (a *Application) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", a.handleHealth)
	mux.HandleFunc("/readyz", a.handleHealth)
	mux.HandleFunc("/api/v1/config", a.handleConfig)
	mux.HandleFunc("/api/v1/rooms", a.handleRooms)
	mux.HandleFunc("/api/v1/rooms/", a.handleRooms)
	mux.HandleFunc("/api/v1/whip", a.handleWHIP)
	mux.HandleFunc("/api/v1/whip/", a.handleWHIP)
	mux.HandleFunc("/ws", a.handleWS)
	mux.Handle("/", http.FileServer(http.Dir(a.cfg.App.PublicDir)))
	return requestLogger(mux, a.cfg.App.ServerLogEnabled)
}

func (a *Application) rtcResponse() RTCConfigResponse {
	servers := make([]RTCICEServer, 0, len(a.cfg.WebRTC.ICEServers))
	for _, server := range a.cfg.WebRTC.ICEServers {
		servers = append(servers, RTCICEServer{
			URLs:       append([]string(nil), server.URLs...),
			Username:   server.Username,
			Credential: server.Credential,
		})
	}

	return RTCConfigResponse{
		ICEServers: servers,
		Video:      rtcVideoConfigResponse(),
	}
}

func (a *Application) handleHealth(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{
		"status": "ok",
		"time":   time.Now().UTC().Format(time.RFC3339),
	})
}

func (a *Application) handleConfig(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, AppConfigResponse{
		Name:                   a.cfg.App.Name,
		DefaultMaxParticipants: a.cfg.App.DefaultMaxParticipants,
		MaxParticipantsLimit:   a.cfg.App.MaxParticipantsLimit,
		RTC:                    a.rtcResponse(),
	})
}

func (a *Application) handleRooms(w http.ResponseWriter, r *http.Request) {
	path := strings.TrimPrefix(r.URL.Path, "/api/v1/rooms")
	if path == "" || path == "/" {
		switch r.Method {
		case http.MethodGet:
			writeJSON(w, http.StatusOK, map[string]interface{}{"rooms": a.conference.ListRooms()})
		case http.MethodPost:
			a.handleCreateRoom(w, r)
		default:
			writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		}
		return
	}

	parts := splitPath(path)
	if len(parts) == 1 && r.Method == http.MethodGet {
		a.handleGetRoom(w, r, parts[0])
		return
	}

	if len(parts) == 2 && parts[1] == "join" && r.Method == http.MethodPost {
		a.handleJoinRoom(w, r, parts[0])
		return
	}

	if len(parts) == 2 && parts[1] == "ffmpeg" && r.Method == http.MethodPost {
		a.handleCreateFFmpegSession(w, r, parts[0])
		return
	}

	writeError(w, http.StatusNotFound, "route not found")
}

func (a *Application) handleCreateRoom(w http.ResponseWriter, r *http.Request) {
	var input CreateRoomInput
	if err := readJSON(r, &input); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	session, err := a.conference.CreateRoom(input, a.rtcResponse())
	if err != nil {
		writeDomainError(w, err)
		return
	}

	writeJSON(w, http.StatusCreated, map[string]interface{}{
		"room":        session.Room,
		"participant": session.Participant,
		"token":       session.Token,
		"rtc":         session.RTC,
		"joinUrl":     a.joinURL(r, session.Room.ID),
	})
}

func (a *Application) handleJoinRoom(w http.ResponseWriter, r *http.Request, roomID string) {
	var input JoinRoomInput
	if err := readJSON(r, &input); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}

	session, err := a.conference.JoinRoom(roomID, input, a.rtcResponse())
	if err != nil {
		writeDomainError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"room":        session.Room,
		"participant": session.Participant,
		"token":       session.Token,
		"rtc":         session.RTC,
		"joinUrl":     a.joinURL(r, session.Room.ID),
	})
}

func (a *Application) handleGetRoom(w http.ResponseWriter, r *http.Request, roomID string) {
	room, err := a.conference.GetRoom(roomID)
	if err != nil {
		writeDomainError(w, err)
		return
	}

	writeJSON(w, http.StatusOK, map[string]interface{}{
		"room":    room,
		"joinUrl": a.joinURL(r, room.ID),
	})
}

func (a *Application) handleWS(w http.ResponseWriter, r *http.Request) {
	token := strings.TrimSpace(r.URL.Query().Get("token"))
	if token == "" {
		writeError(w, http.StatusUnauthorized, "missing token")
		return
	}

	claims, err := a.tokenManager.Verify(token)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "invalid token")
		return
	}
	if !claims.Allows(TokenUseSignal) {
		writeError(w, http.StatusUnauthorized, "token cannot be used for websocket")
		return
	}

	ws, err := a.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}

	session := &signalContext{
		roomID:        claims.RoomID,
		participantID: claims.ParticipantID,
	}

	signalConn := jsonrpc2.NewConn(
		withSignalContext(r.Context(), session),
		websocketjsonrpc2.NewObjectStream(ws),
		&RPCHandler{app: a},
	)

	snapshot, wasConnected, oldPeer, oldConn, err := a.conference.AttachParticipantConnection(claims, signalConn)
	if oldPeer != nil {
		_ = oldPeer.Close()
	}
	if oldConn != nil {
		_ = oldConn.Close()
	}
	if err != nil {
		_ = signalConn.Close()
		return
	}

	if !wasConnected {
		a.conference.Broadcast(context.Background(), claims.RoomID, claims.ParticipantID, "participant_joined", snapshot)
	}

	go func() {
		<-signalConn.DisconnectNotify()

		if session.negotiation != nil {
			session.negotiation.Close()
		}
		if session.peer != nil {
			_ = session.peer.Close()
		}

		snapshot, removed, err := a.conference.DetachParticipantConnection(
			claims.RoomID,
			claims.ParticipantID,
			signalConn,
			session.leaving.Load(),
		)
		if err == nil && snapshot.ID != "" {
			if removed {
				a.conference.Broadcast(context.Background(), claims.RoomID, claims.ParticipantID, "participant_left", map[string]string{
					"id": snapshot.ID,
				})
				return
			}

			a.conference.Broadcast(context.Background(), claims.RoomID, claims.ParticipantID, "participant_updated", snapshot)
		}
	}()
}

func (a *Application) joinURL(r *http.Request, roomID string) string {
	base := strings.TrimSpace(a.cfg.App.PublicBaseURL)
	if base == "" {
		base = requestBaseURL(r)
	}

	return strings.TrimRight(base, "/") + "/?room=" + url.QueryEscape(roomID)
}

func requestBaseURL(r *http.Request) string {
	scheme := r.Header.Get("X-Forwarded-Proto")
	if scheme == "" {
		scheme = "http"
		if r.TLS != nil {
			scheme = "https"
		}
	}

	host := r.Header.Get("X-Forwarded-Host")
	if host == "" {
		host = r.Host
	}

	return scheme + "://" + host
}

func readJSON(r *http.Request, dst interface{}) error {
	defer r.Body.Close()

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(dst); err != nil {
		return err
	}

	return nil
}

func writeJSON(w http.ResponseWriter, status int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]string{"error": message})
}

func writeDomainError(w http.ResponseWriter, err error) {
	switch {
	case errors.Is(err, ErrRoomNotFound):
		writeError(w, http.StatusNotFound, err.Error())
	case errors.Is(err, ErrRoomFull):
		writeError(w, http.StatusConflict, err.Error())
	case errors.Is(err, ErrDisplayNameRequired), errors.Is(err, ErrRoomNameRequired), errors.Is(err, ErrInvalidParticipantCap):
		writeError(w, http.StatusBadRequest, err.Error())
	default:
		writeError(w, http.StatusInternalServerError, "internal server error")
	}
}

func splitPath(path string) []string {
	trimmed := strings.Trim(path, "/")
	if trimmed == "" {
		return nil
	}
	return strings.Split(trimmed, "/")
}

func buildOriginChecker(allowed []string) func(r *http.Request) bool {
	if len(allowed) == 0 {
		return func(r *http.Request) bool {
			origin := r.Header.Get("Origin")
			if origin == "" {
				return true
			}
			parsed, err := url.Parse(origin)
			if err != nil {
				return false
			}
			return strings.EqualFold(parsed.Host, r.Host)
		}
	}

	normalized := make(map[string]struct{}, len(allowed))
	for _, value := range allowed {
		value = strings.TrimSpace(strings.ToLower(value))
		if value != "" {
			normalized[value] = struct{}{}
		}
	}

	return func(r *http.Request) bool {
		origin := strings.TrimSpace(strings.ToLower(r.Header.Get("Origin")))
		if origin == "" {
			return true
		}

		if _, ok := normalized["*"]; ok {
			return true
		}

		if _, ok := normalized[origin]; ok {
			return true
		}

		parsed, err := url.Parse(origin)
		if err != nil {
			return false
		}

		_, hostAllowed := normalized[parsed.Host]
		return hostAllowed
	}
}

func requestLogger(next http.Handler, enabled bool) http.Handler {
	if !enabled {
		return next
	}

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		fmt.Printf("%s %s %s\n", r.Method, r.URL.Path, time.Since(start).String())
	})
}
