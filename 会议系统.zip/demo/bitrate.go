package main

import (
	"fmt"
	"strings"

	"github.com/pion/webrtc/v3"
)

const (
	videoWidth              = 1920
	videoHeight             = 1080
	videoFrameRate          = 30
	videoMinBitrateBps      = 2_500_000
	videoStartBitrateBps    = 4_000_000
	videoMaxBitrateBps      = 6_000_000
	videoMinBitrateKbps     = videoMinBitrateBps / 1000
	videoStartBitrateKbps   = videoStartBitrateBps / 1000
	videoMaxBitrateKbps     = videoMaxBitrateBps / 1000
	videoMaxBitrateASHeader = "b=AS:6000"
)

type RTCVideoConfigResponse struct {
	Width           int `json:"width"`
	Height          int `json:"height"`
	FrameRate       int `json:"frameRate"`
	MinBitrateBps   int `json:"minBitrateBps"`
	StartBitrateBps int `json:"startBitrateBps"`
	MaxBitrateBps   int `json:"maxBitrateBps"`
}

func rtcVideoConfigResponse() RTCVideoConfigResponse {
	return RTCVideoConfigResponse{
		Width:           videoWidth,
		Height:          videoHeight,
		FrameRate:       videoFrameRate,
		MinBitrateBps:   videoMinBitrateBps,
		StartBitrateBps: videoStartBitrateBps,
		MaxBitrateBps:   videoMaxBitrateBps,
	}
}

func applyVideoBitrateToDescription(desc webrtc.SessionDescription) webrtc.SessionDescription {
	desc.SDP = applyVideoBitrateToSDP(desc.SDP)
	return desc
}

func applyVideoBitrateToSDP(raw string) string {
	if raw == "" {
		return raw
	}

	newline := "\n"
	if strings.Contains(raw, "\r\n") {
		newline = "\r\n"
	}

	normalized := strings.ReplaceAll(raw, "\r\n", "\n")
	hasTrailingNewline := strings.HasSuffix(normalized, "\n")
	normalized = strings.TrimSuffix(normalized, "\n")

	lines := strings.Split(normalized, "\n")
	sections := make([][]string, 0, 4)
	current := make([]string, 0, len(lines))

	for _, line := range lines {
		if strings.HasPrefix(line, "m=") && len(current) > 0 {
			sections = append(sections, current)
			current = nil
		}
		current = append(current, line)
	}
	if len(current) > 0 {
		sections = append(sections, current)
	}

	out := make([]string, 0, len(lines)+4)
	for _, section := range sections {
		if isVideoMediaSection(section) {
			section = applyVideoBitrateToMediaSection(section)
		}
		out = append(out, section...)
	}

	result := strings.Join(out, "\n")
	if hasTrailingNewline {
		result += "\n"
	}
	if newline == "\r\n" {
		result = strings.ReplaceAll(result, "\n", "\r\n")
	}
	return result
}

func isVideoMediaSection(lines []string) bool {
	return len(lines) > 0 && strings.HasPrefix(lines[0], "m=video ")
}

func applyVideoBitrateToMediaSection(lines []string) []string {
	codecPayloads := videoCodecPayloads(lines)
	hasFmtp := videoFmtpPayloads(lines, codecPayloads)
	insertAfter := videoBandwidthInsertIndex(lines)
	out := make([]string, 0, len(lines)+len(codecPayloads)+1)

	for i, line := range lines {
		if isVideoBandwidthLine(line) {
			continue
		}
		if payload, params, ok := parseFmtpLine(line); ok && codecPayloads[payload] {
			line = fmt.Sprintf("a=fmtp:%s %s", payload, withGoogleBitrateParams(params))
		}

		out = append(out, line)
		if i == insertAfter {
			out = append(out, videoMaxBitrateASHeader)
		}

		if payload, _, ok := parseRtpmapLine(line); ok && codecPayloads[payload] && !hasFmtp[payload] {
			out = append(out, fmt.Sprintf("a=fmtp:%s %s", payload, googleBitrateParams()))
		}
	}

	return out
}

func videoBandwidthInsertIndex(lines []string) int {
	insertAfter := 0
	for i, line := range lines {
		if strings.HasPrefix(line, "c=") {
			insertAfter = i
			break
		}
		if i > 0 && strings.HasPrefix(line, "a=") {
			break
		}
	}
	return insertAfter
}

func isVideoBandwidthLine(line string) bool {
	return strings.HasPrefix(line, "b=AS:") || strings.HasPrefix(line, "b=TIAS:")
}

func videoCodecPayloads(lines []string) map[string]bool {
	payloads := make(map[string]bool)
	for _, line := range lines {
		payload, codec, ok := parseRtpmapLine(line)
		if !ok {
			continue
		}
		switch strings.ToUpper(codec) {
		case "VP8", "VP9", "H264", "AV1", "H265":
			payloads[payload] = true
		}
	}
	return payloads
}

func videoFmtpPayloads(lines []string, codecPayloads map[string]bool) map[string]bool {
	payloads := make(map[string]bool)
	for _, line := range lines {
		payload, _, ok := parseFmtpLine(line)
		if ok && codecPayloads[payload] {
			payloads[payload] = true
		}
	}
	return payloads
}

func parseRtpmapLine(line string) (string, string, bool) {
	if !strings.HasPrefix(line, "a=rtpmap:") {
		return "", "", false
	}
	value := strings.TrimPrefix(line, "a=rtpmap:")
	parts := strings.Fields(value)
	if len(parts) < 2 {
		return "", "", false
	}
	codec := strings.SplitN(parts[1], "/", 2)[0]
	return parts[0], codec, true
}

func parseFmtpLine(line string) (string, string, bool) {
	if !strings.HasPrefix(line, "a=fmtp:") {
		return "", "", false
	}
	value := strings.TrimPrefix(line, "a=fmtp:")
	parts := strings.SplitN(value, " ", 2)
	if len(parts) == 0 || strings.TrimSpace(parts[0]) == "" {
		return "", "", false
	}
	params := ""
	if len(parts) == 2 {
		params = strings.TrimSpace(parts[1])
	}
	return strings.TrimSpace(parts[0]), params, true
}

func withGoogleBitrateParams(params string) string {
	values := make([]string, 0, 8)
	for _, value := range strings.Split(params, ";") {
		value = strings.TrimSpace(value)
		if value == "" || strings.HasPrefix(value, "x-google-min-bitrate=") ||
			strings.HasPrefix(value, "x-google-start-bitrate=") ||
			strings.HasPrefix(value, "x-google-max-bitrate=") {
			continue
		}
		values = append(values, value)
	}
	values = append(values, strings.Split(googleBitrateParams(), ";")...)
	return strings.Join(values, ";")
}

func googleBitrateParams() string {
	return fmt.Sprintf(
		"x-google-min-bitrate=%d;x-google-start-bitrate=%d;x-google-max-bitrate=%d",
		videoMinBitrateKbps,
		videoStartBitrateKbps,
		videoMaxBitrateKbps,
	)
}
