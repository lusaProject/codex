const state = {
  appConfig: null,
  room: null,
  participant: null,
  token: "",
  joinUrl: "",
  rtc: { iceServers: [] },
  signal: null,
  pc: null,
  localStream: null,
  localPreviewStream: null,
  screenStream: null,
  audioSender: null,
  videoSender: null,
  participantMap: new Map(),
  remoteStreams: new Map(),
  pendingStreams: new Map(),
  ffmpegCommand: "",
  connectionLabel: "未连接",
  reconnecting: false,
  remoteOfferQueue: Promise.resolve(),
  mediaWarningTimer: null,
  mediaFailureTimer: null,
  focusedParticipantId: null,
  zoomedParticipantId: null,
};

const MEDIA_DISCONNECT_NOTICE_DELAY_MS = 8000;
const MEDIA_FAILED_GRACE_MS = 3000;
const DEFAULT_VIDEO_PROFILE = Object.freeze({
  width: 1920,
  height: 1080,
  frameRate: 30,
  minBitrateBps: 2500000,
  startBitrateBps: 4000000,
  maxBitrateBps: 6000000,
});

const elements = {
  serverStatus: document.getElementById("server-status"),
  defaultCapacity: document.getElementById("default-capacity"),
  iceCount: document.getElementById("ice-count"),
  lobbyView: document.getElementById("lobby-view"),
  meetingView: document.getElementById("meeting-view"),
  lobbyNotice: document.getElementById("lobby-notice"),
  createRoomForm: document.getElementById("create-room-form"),
  joinRoomForm: document.getElementById("join-room-form"),
  joinRoomId: document.getElementById("join-room-id"),
  roomPreview: document.getElementById("room-preview"),
  meetingRoomId: document.getElementById("meeting-room-id"),
  meetingTitle: document.getElementById("meeting-title"),
  meetingSubtitle: document.getElementById("meeting-subtitle"),
  connectionPill: document.getElementById("connection-pill"),
  participantCount: document.getElementById("participant-count"),
  participantList: document.getElementById("participant-list"),
  stage: document.getElementById("stage"),
  spotlightTitle: document.getElementById("spotlight-title"),
  spotlightMeta: document.getElementById("spotlight-meta"),
  thumbnailStrip: document.getElementById("thumbnail-strip"),
  thumbnailCount: document.getElementById("thumbnail-count"),
  zoomSelectedButton: document.getElementById("zoom-selected-button"),
  inviteLink: document.getElementById("invite-link"),
  meetingNotice: document.getElementById("meeting-notice"),
  ffmpegForm: document.getElementById("ffmpeg-form"),
  ffmpegDisplayName: document.getElementById("ffmpeg-display-name"),
  ffmpegCommand: document.getElementById("ffmpeg-command"),
  ffmpegHint: document.getElementById("ffmpeg-hint"),
  copyFFmpegButton: document.getElementById("copy-ffmpeg-button"),
  copyLinkButton: document.getElementById("copy-link-button"),
  leaveButton: document.getElementById("leave-button"),
  toggleMicButton: document.getElementById("toggle-mic-button"),
  toggleCameraButton: document.getElementById("toggle-camera-button"),
  toggleScreenButton: document.getElementById("toggle-screen-button"),
  reconnectButton: document.getElementById("reconnect-button"),
  tileTemplate: document.getElementById("tile-template"),
  zoomViewer: document.getElementById("zoom-viewer"),
  zoomBackdrop: document.getElementById("zoom-backdrop"),
  zoomTitle: document.getElementById("zoom-title"),
  zoomMeta: document.getElementById("zoom-meta"),
  zoomVideo: document.getElementById("zoom-video"),
  zoomAvatar: document.getElementById("zoom-avatar"),
  closeZoomButton: document.getElementById("close-zoom-button"),
};

class SignalingClient {
  constructor(token) {
    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    this.url = `${protocol}://${window.location.host}/ws?token=${encodeURIComponent(token)}`;
    this.ws = null;
    this.pending = new Map();
    this.handlers = new Map();
    this.closeHandlers = new Set();
    this.errorHandlers = new Set();
    this.requestId = 1;
  }

  async open() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      return;
    }

    const ws = new WebSocket(this.url);
    this.ws = ws;
    ws.addEventListener("message", (event) => this.handleMessage(event));
    ws.addEventListener("close", (event) => {
      if (this.ws === ws) {
        this.ws = null;
      }
      this.rejectPending(new Error("连接已关闭"));
      this.closeHandlers.forEach((handler) => handler(event));
    });
    ws.addEventListener("error", (event) => {
      this.rejectPending(new Error("信令连接失败"));
      this.errorHandlers.forEach((handler) => handler(event));
    });

    await new Promise((resolve, reject) => {
      const handleOpen = () => {
        cleanup();
        resolve();
      };
      const handleError = () => {
        cleanup();
        reject(new Error("信令连接失败"));
      };
      const cleanup = () => {
        ws.removeEventListener("open", handleOpen);
        ws.removeEventListener("error", handleError);
      };

      ws.addEventListener("open", handleOpen);
      ws.addEventListener("error", handleError);
    });
  }

  on(method, handler) {
    this.handlers.set(method, handler);
  }

  onClose(handler) {
    this.closeHandlers.add(handler);
  }

  onError(handler) {
    this.errorHandlers.add(handler);
  }

  request(method, params) {
    const id = String(this.requestId++);
    this.send({ jsonrpc: "2.0", method, params, id });
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
    });
  }

  notify(method, params) {
    this.send({ jsonrpc: "2.0", method, params });
  }

  send(payload) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      throw new Error("信令连接未建立");
    }
    this.ws.send(JSON.stringify(payload));
  }

  async close({ leave = false } = {}) {
    const ws = this.ws;
    if (!ws) {
      return;
    }

    if (leave && ws.readyState === WebSocket.OPEN) {
      try {
        await Promise.race([
          this.request("leave", {}),
          new Promise((resolve) => window.setTimeout(resolve, 800)),
        ]);
      } catch (error) {
        // Best effort only.
      }
    }

    if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
      ws.close();
    }
    if (this.ws === ws) {
      this.ws = null;
    }
  }

  handleMessage(event) {
    const message = JSON.parse(event.data);

    if (message.id && this.pending.has(String(message.id))) {
      const pending = this.pending.get(String(message.id));
      this.pending.delete(String(message.id));
      if (message.error) {
        pending.reject(new Error(message.error.message || "请求失败"));
        return;
      }
      pending.resolve(message.result);
      return;
    }

    if (message.method && this.handlers.has(message.method)) {
      this.handlers.get(message.method)(message.params);
    }
  }

  rejectPending(error) {
    this.pending.forEach((pending) => pending.reject(error));
    this.pending.clear();
  }
}

async function init() {
  bindEvents();
  renderRoomPreviewHint();
  resetMeetingStage();
  renderParticipantList([]);
  renderControls();
  await loadServerConfig();

  const presetRoomId = new URLSearchParams(window.location.search).get("room");
  if (presetRoomId) {
    elements.joinRoomId.value = presetRoomId;
    await previewRoom(presetRoomId);
  }
}

function bindEvents() {
  elements.createRoomForm.addEventListener("submit", handleCreateRoom);
  elements.joinRoomForm.addEventListener("submit", handleJoinRoom);
  elements.ffmpegForm.addEventListener("submit", handleGenerateFFmpegCommand);
  elements.copyLinkButton.addEventListener("click", copyJoinLink);
  elements.copyFFmpegButton.addEventListener("click", copyFFmpegCommand);
  elements.leaveButton.addEventListener("click", leaveMeeting);
  elements.toggleMicButton.addEventListener("click", toggleMicrophone);
  elements.toggleCameraButton.addEventListener("click", toggleCamera);
  elements.toggleScreenButton.addEventListener("click", toggleScreenShare);
  elements.reconnectButton.addEventListener("click", reconnectConference);
  elements.zoomSelectedButton.addEventListener("click", () => openZoomViewer(state.focusedParticipantId));
  elements.closeZoomButton.addEventListener("click", closeZoomViewer);
  elements.zoomBackdrop.addEventListener("click", closeZoomViewer);

  elements.joinRoomId.addEventListener("blur", async (event) => {
    const roomId = event.target.value.trim();
    if (roomId) {
      await previewRoom(roomId);
      return;
    }
    renderRoomPreviewHint();
  });

  window.addEventListener("beforeunload", () => {
    cleanupMeeting({ leave: false }).catch(() => {});
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && state.zoomedParticipantId) {
      closeZoomViewer();
    }
  });
}

async function loadServerConfig() {
  try {
    const config = await fetchJSON("/api/v1/config");
    state.appConfig = config;
    elements.serverStatus.textContent = "服务可用";
    elements.defaultCapacity.textContent = `${config.defaultMaxParticipants} 人`;
    elements.iceCount.textContent = `${config.rtc.iceServers.length} 组`;
  } catch (error) {
    elements.serverStatus.textContent = "服务异常";
    setNotice(error.message, true, "lobby");
  }
}

function renderRoomPreviewHint(message = "输入会议 ID 后，系统会在这里展示会议名称、人数和描述。", isError = false) {
  elements.roomPreview.innerHTML = `
    <div class="room-preview-card${isError ? " is-error" : ""}">
      <strong>${isError ? "房间预览失败" : "房间预览"}</strong>
      <span>${escapeHTML(message)}</span>
    </div>
  `;
}

async function previewRoom(roomId) {
  try {
    const payload = await fetchJSON(`/api/v1/rooms/${encodeURIComponent(roomId)}`);
    const room = payload.room;
    const description = room.description ? escapeHTML(room.description) : "暂无会议描述";
    elements.roomPreview.innerHTML = `
      <div class="room-preview-card">
        <strong>${escapeHTML(room.name)}</strong>
        <span>会议室 ID：<code>${escapeHTML(room.id)}</code></span>
        <span>当前参会者：${room.participantCount} / ${room.maxParticipants}</span>
        <span>${description}</span>
      </div>
    `;
  } catch (error) {
    renderRoomPreviewHint(error.message, true);
  }
}

async function handleCreateRoom(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const body = {
    name: String(form.get("name") || "").trim(),
    description: String(form.get("description") || "").trim(),
    hostName: String(form.get("hostName") || "").trim(),
    maxParticipants: Number(form.get("maxParticipants") || 0),
  };

  try {
    const session = await fetchJSON("/api/v1/rooms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    await enterMeeting(session);
  } catch (error) {
    setNotice(error.message, true, "lobby");
  }
}

async function handleJoinRoom(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const roomId = String(form.get("roomId") || "").trim();
  const body = {
    displayName: String(form.get("displayName") || "").trim(),
  };

  try {
    const session = await fetchJSON(`/api/v1/rooms/${encodeURIComponent(roomId)}/join`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    await enterMeeting(session);
  } catch (error) {
    setNotice(error.message, true, "lobby");
  }
}

async function enterMeeting(session) {
  await cleanupMeeting({ leave: true });

  state.room = session.room;
  state.participant = session.participant;
  state.token = session.token;
  state.joinUrl = session.joinUrl;
  state.rtc = session.rtc || { iceServers: [] };
  syncParticipants(session.room.participants || []);

  elements.lobbyView.classList.add("hidden");
  elements.meetingView.classList.remove("hidden");
  setMeetingMode(true);
  history.replaceState({}, "", `/?room=${encodeURIComponent(state.room.id)}`);

  syncMeetingHeader();
  resetFFmpegPanel();
  elements.ffmpegDisplayName.value = `${state.room.name} Feed`;
  renderAll();

  setConnectionLabel("准备媒体设备");
  await setupLocalMedia();
  renderAll();

  try {
    await setupConferenceConnection();
  } catch (error) {
    await cleanupMeeting({ leave: false });
    elements.meetingView.classList.add("hidden");
    elements.lobbyView.classList.remove("hidden");
    setMeetingMode(false);
    history.replaceState({}, "", "/");
    setConnectionLabel("未连接");
    setNotice(error.message, true, "lobby");
    return;
  }

  renderAll();
}

async function setupLocalMedia() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: videoCaptureConstraints() });
    state.localStream = stream;
    state.localPreviewStream = stream;
    setNotice("已连接本地摄像头和麦克风。", false, "meeting");
  } catch (error) {
    state.localStream = new MediaStream();
    state.localPreviewStream = null;
    setNotice("未能获取麦克风或摄像头权限，仍可进入会议并接收其他人的音视频。", true, "meeting");
  }
}

async function setupConferenceConnection() {
  const signal = new SignalingClient(state.token);
  await signal.open();
  state.signal = signal;
  registerSignalHandlers(signal);

  const pc = new RTCPeerConnection({
    iceServers: state.rtc.iceServers || [],
    bundlePolicy: "max-bundle",
    iceCandidatePoolSize: 4,
  });
  state.pc = pc;
  bindConferenceLifecycle(signal);

  pc.onicecandidate = (event) => {
    if (!event.candidate || state.signal !== signal) {
      return;
    }
    signal.notify("trickle", { candidate: event.candidate });
  };

  pc.ontrack = (event) => {
    if (state.pc !== pc) {
      return;
    }

    const stream = event.streams[0];
    if (!stream) {
      return;
    }

    const participant = findParticipantByStreamId(stream.id);
    if (participant) {
      state.remoteStreams.set(participant.id, stream);
    } else {
      state.pendingStreams.set(stream.id, stream);
    }
    renderAll();
  };

  pc.onconnectionstatechange = () => {
    if (state.pc !== pc) {
      return;
    }
    handlePeerConnectionState(pc.connectionState);
  };

  attachLocalTracks(pc);

  const offer = applyVideoBitrateToDescription(await pc.createOffer());
  await pc.setLocalDescription(offer);

  setConnectionLabel("正在加入会议");
  const result = await signal.request("join", {
    offer: pc.localDescription,
    presence: currentPresence(),
  });

  if (state.signal !== signal || state.pc !== pc) {
    return;
  }

  await pc.setRemoteDescription(result.answer);
  state.room = result.room;
  state.participant = result.self;
  syncParticipants(result.room.participants || []);
  syncMeetingHeader();
  syncPendingStreams();

  setConnectionLabel("已连接");
  if (state.reconnecting) {
    setNotice("会议连接已恢复。", false, "meeting");
  }

  renderAll();
}

function registerSignalHandlers(signal) {
  signal.on("offer", (offer) => {
    state.remoteOfferQueue = state.remoteOfferQueue
      .catch(() => {})
      .then(() => handleRemoteOffer(signal, offer))
      .catch((error) => {
        if (state.signal === signal) {
          setNotice(error.message || "媒体协商失败，可点击“短线重连”恢复。", true, "meeting");
        }
      });
  });

  signal.on("trickle", async (candidate) => {
    if (state.signal !== signal || !state.pc) {
      return;
    }
    await state.pc.addIceCandidate(candidate);
  });

  signal.on("participant_joined", (participant) => {
    state.participantMap.set(participant.id, participant);
    renderAll();
  });

  signal.on("participant_updated", (participant) => {
    state.participantMap.set(participant.id, participant);
    if (state.participant && participant.id === state.participant.id) {
      state.participant = participant;
    }
    syncPendingStreams();
    renderAll();
  });

  signal.on("participant_left", (payload) => {
    state.participantMap.delete(payload.id);
    state.remoteStreams.delete(payload.id);
    renderAll();
  });
}

async function handleRemoteOffer(signal, offer) {
  const pc = state.pc;
  if (state.signal !== signal || !pc) {
    return;
  }

  if (pc.signalingState !== "stable") {
    await waitForSignalingState(pc, "stable", 2500);
  }
  if (state.signal !== signal || state.pc !== pc || pc.signalingState === "closed") {
    return;
  }

  await pc.setRemoteDescription(offer);
  if (state.signal !== signal || state.pc !== pc) {
    return;
  }

  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  if (state.signal !== signal || state.pc !== pc) {
    return;
  }

  await signal.request("answer", { desc: pc.localDescription });
}

function waitForSignalingState(pc, expectedState, timeoutMs) {
  if (pc.signalingState === expectedState || pc.signalingState === "closed") {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) {
        return;
      }
      settled = true;
      window.clearTimeout(timer);
      pc.removeEventListener("signalingstatechange", handleChange);
      resolve();
    };
    const handleChange = () => {
      if (pc.signalingState === expectedState || pc.signalingState === "closed") {
        finish();
      }
    };
    const timer = window.setTimeout(finish, timeoutMs);
    pc.addEventListener("signalingstatechange", handleChange);
  });
}

function bindConferenceLifecycle(signal) {
  signal.onClose(() => {
    if (state.signal !== signal) {
      return;
    }
    handleTransportInterrupted("信令连接已断开，可点击“短线重连”恢复。").catch(() => {});
  });

  signal.onError(() => {
    if (state.signal !== signal) {
      return;
    }
    setNotice("信令连接出现异常，可点击“短线重连”恢复。", true, "meeting");
  });
}

function attachLocalTracks(pc) {
  if (!pc) {
    return;
  }

  const audioTracks = state.localStream ? state.localStream.getAudioTracks() : [];
  const videoTrack = getPublishedVideoTrack();

  if (audioTracks.length === 0) {
    pc.addTransceiver("audio", { direction: "recvonly" });
  }
  if (!videoTrack) {
    pc.addTransceiver("video", { direction: "recvonly" });
  }

  audioTracks.forEach((track) => {
    state.audioSender = pc.addTrack(track, state.localStream);
  });

  if (videoTrack) {
    state.videoSender = pc.addTrack(videoTrack, state.screenStream || state.localStream);
    configureVideoSender(state.videoSender).catch(() => {});
  }
}

async function toggleMicrophone() {
  const track = getLocalTrack("audio");
  if (!track) {
    setNotice("当前没有可用的麦克风轨道。", true, "meeting");
    return;
  }

  track.enabled = !track.enabled;
  await pushPresence();
  renderAll();
}

async function toggleCamera() {
  const track = getLocalTrack("video");
  if (!track) {
    setNotice("当前没有可用的视频轨道。", true, "meeting");
    return;
  }

  track.enabled = !track.enabled;
  await pushPresence();
  renderAll();
}

async function toggleScreenShare() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
    setNotice("当前浏览器不支持屏幕共享。", true, "meeting");
    return;
  }

  if (state.screenStream) {
    await stopScreenShare();
    return;
  }

  if (!state.videoSender) {
    setNotice("请先连接会议并允许摄像头访问，再使用屏幕共享。", true, "meeting");
    return;
  }

  try {
    const displayStream = await navigator.mediaDevices.getDisplayMedia({ video: videoCaptureConstraints() });
    const displayTrack = displayStream.getVideoTracks()[0];
    displayTrack.onended = () => {
      if (state.screenStream) {
        stopScreenShare().catch(() => {});
      }
    };

    await state.videoSender.replaceTrack(displayTrack);
    await configureVideoSender(state.videoSender);
    state.screenStream = displayStream;
    state.localPreviewStream = displayStream;
    await pushPresence({ screenSharing: true, videoEnabled: true });
    setNotice("屏幕共享已开启。", false, "meeting");
    renderAll();
  } catch (error) {
    setNotice("屏幕共享已取消。", true, "meeting");
  }
}

async function stopScreenShare() {
  if (!state.screenStream) {
    return;
  }

  const cameraTrack = getLocalTrack("video");
  if (state.videoSender) {
    await state.videoSender.replaceTrack(cameraTrack || null);
    await configureVideoSender(state.videoSender);
  }

  state.screenStream.getTracks().forEach((track) => track.stop());
  state.screenStream = null;
  state.localPreviewStream = state.localStream;
  await pushPresence({ screenSharing: false });
  setNotice("已停止屏幕共享。", false, "meeting");
  renderAll();
}

async function pushPresence(overrides = {}) {
  if (!state.signal) {
    return;
  }

  const payload = {
    ...currentPresence(),
    ...overrides,
  };

  const result = await state.signal.request("update_presence", payload);
  state.participant = result;
  state.participantMap.set(result.id, result);
  renderAll();
}

function videoProfile() {
  return {
    ...DEFAULT_VIDEO_PROFILE,
    ...((state.rtc && state.rtc.video) || {}),
  };
}

function videoCaptureConstraints() {
  const profile = videoProfile();
  return {
    width: { ideal: profile.width },
    height: { ideal: profile.height },
    frameRate: { ideal: profile.frameRate, max: profile.frameRate },
  };
}

async function configureVideoSender(sender) {
  if (!sender || !sender.getParameters || !sender.setParameters) {
    return;
  }

  const profile = videoProfile();
  const params = sender.getParameters();
  if (!Array.isArray(params.encodings) || params.encodings.length === 0) {
    return;
  }

  params.encodings.forEach((encoding) => {
    encoding.maxBitrate = profile.maxBitrateBps;
    encoding.minBitrate = profile.minBitrateBps;
  });

  try {
    await sender.setParameters(params);
  } catch (error) {
    params.encodings.forEach((encoding) => {
      delete encoding.minBitrate;
    });
    await sender.setParameters(params).catch(() => {});
  }
}

function applyVideoBitrateToDescription(description) {
  if (!description || !description.sdp) {
    return description;
  }
  return {
    type: description.type,
    sdp: applyVideoBitrateToSDP(description.sdp),
  };
}

function applyVideoBitrateToSDP(sdp) {
  if (!sdp) {
    return sdp;
  }

  const newline = sdp.includes("\r\n") ? "\r\n" : "\n";
  const normalized = sdp.replace(/\r\n/g, "\n");
  const hasTrailingNewline = normalized.endsWith("\n");
  const lines = normalized.replace(/\n$/, "").split("\n");
  const sections = [];
  let current = [];

  lines.forEach((line) => {
    if (line.startsWith("m=") && current.length > 0) {
      sections.push(current);
      current = [];
    }
    current.push(line);
  });
  if (current.length > 0) {
    sections.push(current);
  }

  const output = sections.flatMap((section) =>
    section[0] && section[0].startsWith("m=video ") ? applyVideoBitrateToMediaSection(section) : section
  );
  let result = output.join("\n");
  if (hasTrailingNewline) {
    result += "\n";
  }
  return newline === "\r\n" ? result.replace(/\n/g, "\r\n") : result;
}

function applyVideoBitrateToMediaSection(lines) {
  const profile = videoProfile();
  const codecPayloads = videoCodecPayloads(lines);
  const fmtpPayloads = videoFmtpPayloads(lines, codecPayloads);
  const insertAfter = videoBandwidthInsertIndex(lines);
  const output = [];

  lines.forEach((line, index) => {
    if (line.startsWith("b=AS:") || line.startsWith("b=TIAS:")) {
      return;
    }

    const fmtp = parseFmtpLine(line);
    if (fmtp && codecPayloads.has(fmtp.payload)) {
      line = `a=fmtp:${fmtp.payload} ${withGoogleBitrateParams(fmtp.params, profile)}`;
    }

    output.push(line);
    if (index === insertAfter) {
      output.push(`b=AS:${Math.round(profile.maxBitrateBps / 1000)}`);
    }

    const rtpmap = parseRtpmapLine(line);
    if (rtpmap && codecPayloads.has(rtpmap.payload) && !fmtpPayloads.has(rtpmap.payload)) {
      output.push(`a=fmtp:${rtpmap.payload} ${googleBitrateParams(profile)}`);
    }
  });

  return output;
}

function videoBandwidthInsertIndex(lines) {
  let insertAfter = 0;
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    if (line.startsWith("c=")) {
      insertAfter = index;
      break;
    }
    if (index > 0 && line.startsWith("a=")) {
      break;
    }
  }
  return insertAfter;
}

function videoCodecPayloads(lines) {
  const payloads = new Set();
  lines.forEach((line) => {
    const rtpmap = parseRtpmapLine(line);
    if (rtpmap && ["VP8", "VP9", "H264", "AV1", "H265"].includes(rtpmap.codec.toUpperCase())) {
      payloads.add(rtpmap.payload);
    }
  });
  return payloads;
}

function videoFmtpPayloads(lines, codecPayloads) {
  const payloads = new Set();
  lines.forEach((line) => {
    const fmtp = parseFmtpLine(line);
    if (fmtp && codecPayloads.has(fmtp.payload)) {
      payloads.add(fmtp.payload);
    }
  });
  return payloads;
}

function parseRtpmapLine(line) {
  const match = line.match(/^a=rtpmap:(\S+)\s+([^/\s]+)/);
  return match ? { payload: match[1], codec: match[2] } : null;
}

function parseFmtpLine(line) {
  const match = line.match(/^a=fmtp:(\S+)(?:\s+(.*))?$/);
  return match ? { payload: match[1], params: match[2] || "" } : null;
}

function withGoogleBitrateParams(params, profile) {
  const values = params
    .split(";")
    .map((value) => value.trim())
    .filter(
      (value) =>
        value &&
        !value.startsWith("x-google-min-bitrate=") &&
        !value.startsWith("x-google-start-bitrate=") &&
        !value.startsWith("x-google-max-bitrate=")
    );
  values.push(...googleBitrateParams(profile).split(";"));
  return values.join(";");
}

function googleBitrateParams(profile) {
  return [
    `x-google-min-bitrate=${Math.round(profile.minBitrateBps / 1000)}`,
    `x-google-start-bitrate=${Math.round(profile.startBitrateBps / 1000)}`,
    `x-google-max-bitrate=${Math.round(profile.maxBitrateBps / 1000)}`,
  ].join(";");
}

function currentPresence() {
  const audioTrack = getLocalTrack("audio");
  const videoTrack = getPublishedVideoTrack();

  return {
    audioEnabled: Boolean(audioTrack && audioTrack.enabled),
    videoEnabled: Boolean(videoTrack && videoTrack.enabled),
    screenSharing: Boolean(state.screenStream),
    streamId: getPublishedStreamID(),
  };
}

function getPublishedVideoTrack() {
  if (state.screenStream) {
    const screenTracks = state.screenStream.getVideoTracks();
    if (screenTracks.length > 0) {
      return screenTracks[0];
    }
  }
  return getLocalTrack("video");
}

function getPublishedStreamID() {
  if (state.screenStream && state.screenStream.id) {
    return state.screenStream.id;
  }
  if (state.localStream && state.localStream.id) {
    return state.localStream.id;
  }
  return "";
}

function getLocalTrack(kind) {
  if (!state.localStream) {
    return null;
  }

  const tracks = kind === "audio" ? state.localStream.getAudioTracks() : state.localStream.getVideoTracks();
  return tracks.length > 0 ? tracks[0] : null;
}

function syncParticipants(participants) {
  state.participantMap.clear();
  participants.forEach((participant) => {
    state.participantMap.set(participant.id, participant);
  });
}

function syncPendingStreams() {
  Array.from(state.pendingStreams.entries()).forEach(([streamId, stream]) => {
    const participant = findParticipantByStreamId(streamId);
    if (!participant) {
      return;
    }
    state.remoteStreams.set(participant.id, stream);
    state.pendingStreams.delete(streamId);
  });
}

function findParticipantByStreamId(streamId) {
  return Array.from(state.participantMap.values()).find((participant) => participant.streamId === streamId);
}

function syncMeetingHeader() {
  elements.meetingRoomId.textContent = state.room ? state.room.id : "Room";
  elements.meetingTitle.textContent = state.room ? state.room.name : "会议室";
  elements.meetingSubtitle.textContent =
    state.room && state.room.description
      ? state.room.description
      : "点击下方缩略画面切换选看，主画面支持放大查看。";
  elements.inviteLink.textContent = state.joinUrl || "-";
}

function renderAll() {
  const participants = getRenderableParticipants();
  ensureFocusedParticipant(participants);
  renderStage(participants);
  renderParticipantList(participants);
  renderControls();
  renderZoomViewer(participants);
}

function getRenderableParticipants() {
  const participants = [];
  const localParticipant = buildLocalParticipant();
  if (localParticipant) {
    participants.push(localParticipant);
  }

  Array.from(state.participantMap.values())
    .filter((participant) => !state.participant || participant.id !== state.participant.id)
    .forEach((participant) => {
      participants.push({
        ...participant,
        rawDisplayName: participant.displayName || "未命名",
        displayName: participant.displayName || "未命名",
        isLocal: false,
      });
    });

  return sortParticipants(participants);
}

function buildLocalParticipant() {
  if (!state.participant && !state.localStream && !state.localPreviewStream) {
    return null;
  }

  const name = state.participant ? state.participant.displayName || "我" : "我";
  return {
    id: "local",
    sourceId: state.participant ? state.participant.id : "local",
    rawDisplayName: name,
    displayName: `${name}（你）`,
    role: state.participant ? state.participant.role : "local",
    joinedAt: state.participant ? state.participant.joinedAt : "",
    connected: state.participant ? state.participant.connected !== false : true,
    audioEnabled: Boolean(getLocalTrack("audio") && getLocalTrack("audio").enabled),
    videoEnabled: Boolean(state.screenStream || (getLocalTrack("video") && getLocalTrack("video").enabled)),
    screenSharing: Boolean(state.screenStream),
    streamId: getPublishedStreamID(),
    isLocal: true,
  };
}

function sortParticipants(participants) {
  const roleWeight = {
    host: 0,
    stream: 1,
    guest: 2,
    participant: 2,
    local: 3,
  };

  return [...participants].sort((left, right) => {
    if (left.screenSharing !== right.screenSharing) {
      return left.screenSharing ? -1 : 1;
    }
    if (left.connected !== right.connected) {
      return left.connected ? -1 : 1;
    }
    if (left.isLocal !== right.isLocal) {
      return left.isLocal ? -1 : 1;
    }

    const leftRole = roleWeight[left.role] ?? 9;
    const rightRole = roleWeight[right.role] ?? 9;
    if (leftRole !== rightRole) {
      return leftRole - rightRole;
    }

    return String(left.rawDisplayName || left.displayName || "").localeCompare(
      String(right.rawDisplayName || right.displayName || ""),
      "zh-Hans-CN",
      { sensitivity: "base" }
    );
  });
}

function ensureFocusedParticipant(participants) {
  if (participants.length === 0) {
    state.focusedParticipantId = null;
    if (state.zoomedParticipantId) {
      closeZoomViewer();
    }
    return;
  }

  const focusedExists = participants.some((participant) => participant.id === state.focusedParticipantId);
  if (!focusedExists) {
    state.focusedParticipantId = pickDefaultFocus(participants);
  }

  const zoomedExists = participants.some((participant) => participant.id === state.zoomedParticipantId);
  if (state.zoomedParticipantId && !zoomedExists) {
    closeZoomViewer();
  }
}

function pickDefaultFocus(participants) {
  const shared = participants.find((participant) => participant.screenSharing);
  if (shared) {
    return shared.id;
  }

  const remoteWithVideo = participants.find(
    (participant) => !participant.isLocal && participant.connected && (participant.videoEnabled || participant.screenSharing)
  );
  if (remoteWithVideo) {
    return remoteWithVideo.id;
  }

  const local = participants.find((participant) => participant.isLocal);
  if (local) {
    return local.id;
  }

  return participants[0].id;
}

function renderStage(participants) {
  elements.thumbnailStrip.innerHTML = "";

  if (participants.length === 0) {
    resetMeetingStage();
    return;
  }

  const focused = participants.find((participant) => participant.id === state.focusedParticipantId) || participants[0];
  elements.spotlightTitle.textContent = focused.displayName;
  elements.spotlightMeta.textContent = participantMetaText(focused);
  elements.thumbnailCount.textContent = `${participants.length} 路`;
  elements.zoomSelectedButton.disabled = false;

  elements.stage.innerHTML = "";
  elements.stage.appendChild(createSpotlightCard(focused));

  const fragment = document.createDocumentFragment();
  participants.forEach((participant) => {
    fragment.appendChild(createThumbnailTile(participant, participant.id === focused.id));
  });
  elements.thumbnailStrip.appendChild(fragment);
}

function createSpotlightCard(participant) {
  const card = document.createElement("article");
  card.className = `spotlight-card${participant.screenSharing ? " is-sharing" : ""}`;

  const mediaFrame = document.createElement("div");
  mediaFrame.className = "media-frame spotlight-media";
  mediaFrame.addEventListener("click", () => openZoomViewer(participant.id));

  const video = document.createElement("video");
  video.autoplay = true;
  video.playsInline = true;

  const avatar = document.createElement("div");
  avatar.className = "avatar-fallback spotlight-avatar";

  const overlay = document.createElement("div");
  overlay.className = "spotlight-overlay";

  const cue = document.createElement("span");
  cue.className = "spotlight-cue";
  cue.textContent = participant.screenSharing ? "共享画面已置顶，点击可放大" : "主画面，点击可放大";

  const zoomButton = document.createElement("button");
  zoomButton.type = "button";
  zoomButton.className = "spotlight-zoom-button";
  zoomButton.textContent = "放大查看";
  zoomButton.addEventListener("click", (event) => {
    event.stopPropagation();
    openZoomViewer(participant.id);
  });

  overlay.append(cue, zoomButton);
  mediaFrame.append(video, avatar, overlay);

  const footer = document.createElement("div");
  footer.className = "spotlight-footer";

  const info = document.createElement("div");
  const name = document.createElement("strong");
  name.className = "spotlight-name";
  name.textContent = participant.displayName;

  const role = document.createElement("span");
  role.className = "spotlight-role";
  role.textContent = `${roleLabel(participant)} · ${participantStatusSummary(participant)}`;

  info.append(name, role);

  const badges = document.createElement("div");
  badges.className = "badges";
  appendBadges(badges, participant);

  footer.append(info, badges);
  card.append(mediaFrame, footer);
  bindMediaElements(video, avatar, participant);

  return card;
}

function createThumbnailTile(participant, isSelected) {
  const fragment = elements.tileTemplate.content.cloneNode(true);
  const tile = fragment.querySelector(".tile");
  const mediaFrame = fragment.querySelector(".media-frame");
  const video = fragment.querySelector("video");
  const avatar = fragment.querySelector(".avatar-fallback");
  const hint = fragment.querySelector(".tile-hint");
  const zoomButton = fragment.querySelector(".tile-zoom-button");
  const name = fragment.querySelector(".tile-name");
  const role = fragment.querySelector(".tile-role");
  const status = fragment.querySelector(".tile-status");
  const badges = fragment.querySelector(".badges");

  tile.dataset.participantId = participant.id;
  tile.classList.toggle("selected", isSelected);
  tile.setAttribute("aria-pressed", String(isSelected));

  name.textContent = participant.displayName;
  role.textContent = roleLabel(participant);
  status.textContent = participantStatusSummary(participant);
  hint.textContent = isSelected ? "当前选看" : "点击选看";

  tile.addEventListener("click", () => setFocusedParticipant(participant.id));
  tile.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      setFocusedParticipant(participant.id);
    }
  });

  mediaFrame.addEventListener("dblclick", () => openZoomViewer(participant.id));
  zoomButton.addEventListener("click", (event) => {
    event.stopPropagation();
    openZoomViewer(participant.id);
  });

  appendBadges(badges, participant);
  bindMediaElements(video, avatar, participant);
  return tile;
}

function appendBadges(container, participant) {
  container.innerHTML = "";
  badgeList(participant).forEach((badge) => {
    const node = document.createElement("span");
    node.className = `badge${badge.warning ? " warning" : ""}`;
    node.textContent = badge.text;
    container.appendChild(node);
  });
}

function badgeList(participant) {
  const badges = [];
  if (participant.isLocal) {
    badges.push({ text: "本机" });
  }
  if (participant.role === "stream") {
    badges.push({ text: "推流" });
  }
  if (!participant.connected) {
    badges.push({ text: "离线", warning: true });
  }
  if (!participant.audioEnabled) {
    badges.push({ text: "静音" });
  }
  if (!participant.videoEnabled) {
    badges.push({ text: "视频关闭" });
  }
  if (participant.screenSharing) {
    badges.push({ text: "共享中", warning: true });
  }
  return badges;
}

function renderParticipantList(participants) {
  elements.participantCount.textContent = `${participants.length} 人`;
  elements.participantList.innerHTML = "";

  if (participants.length === 0) {
    const empty = document.createElement("div");
    empty.className = "participant-row";
    empty.innerHTML = `
      <div class="participant-text">
        <strong>暂无参会者</strong>
        <span>进入会议后，会在这里显示成员状态。</span>
      </div>
    `;
    elements.participantList.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();

  participants.forEach((participant) => {
    const row = document.createElement("div");
    row.className = `participant-row${participant.id === state.focusedParticipantId ? " selected" : ""}`;
    row.tabIndex = 0;

    row.addEventListener("click", () => setFocusedParticipant(participant.id));
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        setFocusedParticipant(participant.id);
      }
    });

    const identity = document.createElement("div");
    identity.className = "participant-identity";

    const avatar = document.createElement("span");
    avatar.className = "participant-avatar";
    avatar.textContent = initials(participant.rawDisplayName || participant.displayName);

    const text = document.createElement("div");
    text.className = "participant-text";

    const strong = document.createElement("strong");
    strong.textContent = participant.displayName;

    const role = document.createElement("span");
    role.textContent = roleLabel(participant);

    text.append(strong, role);
    identity.append(avatar, text);

    const stateText = document.createElement("span");
    stateText.className = "participant-state";
    stateText.textContent = participantStatusLine(participant);

    row.append(identity, stateText);
    fragment.appendChild(row);
  });

  elements.participantList.appendChild(fragment);
}

function renderControls() {
  const micTrack = getLocalTrack("audio");
  const cameraTrack = getLocalTrack("video");

  elements.toggleMicButton.classList.toggle("active", Boolean(micTrack && micTrack.enabled));
  elements.toggleMicButton.textContent = micTrack && micTrack.enabled ? "静音" : "取消静音";

  elements.toggleCameraButton.classList.toggle("active", Boolean(cameraTrack && cameraTrack.enabled));
  elements.toggleCameraButton.textContent = cameraTrack && cameraTrack.enabled ? "关闭视频" : "开启视频";

  elements.toggleScreenButton.classList.toggle("active", Boolean(state.screenStream));
  elements.toggleScreenButton.textContent = state.screenStream ? "停止共享" : "共享屏幕";

  elements.reconnectButton.disabled = !state.room || !state.token || state.reconnecting;
  elements.reconnectButton.textContent = state.reconnecting ? "重连中..." : "短线重连";

  elements.copyLinkButton.disabled = !state.joinUrl;
  elements.copyFFmpegButton.disabled = !state.ffmpegCommand;
  elements.zoomSelectedButton.disabled = !state.focusedParticipantId;
}

function setFocusedParticipant(participantId) {
  if (!participantId) {
    return;
  }

  state.focusedParticipantId = participantId;
  renderAll();
}

function openZoomViewer(participantId) {
  if (!participantId) {
    return;
  }

  state.focusedParticipantId = participantId;
  state.zoomedParticipantId = participantId;
  renderAll();
}

function closeZoomViewer() {
  state.zoomedParticipantId = null;
  hideZoomViewer();
}

function renderZoomViewer(participants) {
  if (!state.zoomedParticipantId) {
    hideZoomViewer();
    return;
  }

  const participant = participants.find((item) => item.id === state.zoomedParticipantId);
  if (!participant) {
    hideZoomViewer();
    return;
  }

  elements.zoomViewer.classList.remove("hidden");
  elements.zoomViewer.setAttribute("aria-hidden", "false");
  elements.zoomTitle.textContent = participant.displayName;
  elements.zoomMeta.textContent = participantMetaText(participant);
  bindMediaElements(elements.zoomVideo, elements.zoomAvatar, participant);
}

function hideZoomViewer() {
  elements.zoomViewer.classList.add("hidden");
  elements.zoomViewer.setAttribute("aria-hidden", "true");
  elements.zoomTitle.textContent = "主画面";
  elements.zoomMeta.textContent = "";
  elements.zoomVideo.srcObject = null;
  elements.zoomVideo.hidden = true;
  elements.zoomAvatar.textContent = "";
  elements.zoomAvatar.style.display = "";
}

function bindMediaElements(videoElement, avatarElement, participant) {
  const stream = getStreamForParticipant(participant);
  const showVideo = Boolean(stream && participant.videoEnabled);

  avatarElement.textContent = initials(participant.rawDisplayName || participant.displayName || "U");

  if (!showVideo) {
    videoElement.srcObject = null;
    videoElement.hidden = true;
    avatarElement.style.display = "";
    return;
  }

  if (videoElement.srcObject !== stream) {
    videoElement.srcObject = stream;
  }
  videoElement.muted = Boolean(participant.isLocal);
  videoElement.hidden = false;
  avatarElement.style.display = "none";
  videoElement.play().catch(() => {});
}

function getStreamForParticipant(participant) {
  if (!participant) {
    return null;
  }
  if (participant.isLocal) {
    return state.localPreviewStream;
  }
  return state.remoteStreams.get(participant.id) || null;
}

function roleLabel(participant) {
  if (!participant) {
    return "参会者";
  }

  if (participant.role === "host") {
    return participant.isLocal ? "主持人 / 你" : "主持人";
  }
  if (participant.role === "stream") {
    return "推流源";
  }
  if (participant.isLocal) {
    return "参会者 / 你";
  }
  return "参会者";
}

function participantMetaText(participant) {
  const parts = [roleLabel(participant)];

  if (participant.screenSharing) {
    parts.push("正在共享屏幕");
  } else {
    parts.push(participant.videoEnabled ? "视频已开启" : "视频已关闭");
  }

  parts.push(participant.audioEnabled ? "语音可用" : "已静音");
  parts.push(participant.connected ? "在线" : "离线");

  return parts.join(" · ");
}

function participantStatusSummary(participant) {
  if (!participant.connected) {
    return "离线";
  }
  if (participant.screenSharing) {
    return "共享中";
  }
  if (!participant.audioEnabled && !participant.videoEnabled) {
    return "静音 / 视频关闭";
  }
  if (!participant.audioEnabled) {
    return "已静音";
  }
  if (!participant.videoEnabled) {
    return "视频关闭";
  }
  return "在线";
}

function participantStatusLine(participant) {
  const status = [];
  if (!participant.connected) {
    status.push("离线");
  } else {
    status.push("在线");
  }
  if (!participant.audioEnabled) {
    status.push("静音");
  }
  if (!participant.videoEnabled) {
    status.push("视频关闭");
  }
  if (participant.screenSharing) {
    status.push("共享中");
  }
  return status.join(" / ");
}

async function copyJoinLink() {
  if (!state.joinUrl) {
    return;
  }

  try {
    await copyText(state.joinUrl);
    setNotice("邀请链接已复制。", false, "meeting");
  } catch (error) {
    setNotice(error.message, true, "meeting");
  }
}

async function handleGenerateFFmpegCommand(event) {
  event.preventDefault();
  if (!state.room) {
    return;
  }

  const form = new FormData(event.currentTarget);
  const body = {
    displayName: String(form.get("displayName") || "").trim(),
  };

  try {
    const payload = await fetchJSON(`/api/v1/rooms/${encodeURIComponent(state.room.id)}/ffmpeg`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    state.ffmpegCommand = payload.ffmpegCommand || "";
    elements.ffmpegCommand.value = state.ffmpegCommand;
    elements.ffmpegHint.innerHTML = `WHIP endpoint：<code>${escapeHTML(payload.whipUrl || "")}</code><br />如果当前页面使用的是本地自签 HTTPS 证书，测试时更建议用 <code>-insecure-http</code> 启动服务。`;
    setNotice("FFmpeg 推流命令已生成，可直接复制到终端执行。", false, "meeting");
    renderControls();
  } catch (error) {
    setNotice(error.message, true, "meeting");
  }
}

async function copyFFmpegCommand() {
  if (!state.ffmpegCommand) {
    return;
  }

  try {
    await copyText(state.ffmpegCommand);
    setNotice("FFmpeg 推流命令已复制。", false, "meeting");
  } catch (error) {
    setNotice(error.message, true, "meeting");
  }
}

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.setAttribute("readonly", "readonly");
  textArea.style.position = "fixed";
  textArea.style.top = "-9999px";
  document.body.appendChild(textArea);
  textArea.select();
  textArea.setSelectionRange(0, text.length);

  const succeeded = document.execCommand("copy");
  document.body.removeChild(textArea);

  if (!succeeded) {
    throw new Error("当前环境不支持自动复制，请手动复制。");
  }
}

async function leaveMeeting() {
  await cleanupMeeting({ leave: true });
  elements.meetingView.classList.add("hidden");
  elements.lobbyView.classList.remove("hidden");
  setMeetingMode(false);
  history.replaceState({}, "", "/");
  setConnectionLabel("未连接");
  setNotice("你已离开会议。", false, "lobby");
}

async function reconnectConference() {
  if (!state.room || !state.token || state.reconnecting) {
    return;
  }

  state.reconnecting = true;
  renderControls();
  setConnectionLabel("重连中");
  setNotice("正在恢复会议连接...", false, "meeting");

  try {
    await releaseConferenceTransport({ leave: false });
    await setupConferenceConnection();
  } catch (error) {
    await releaseConferenceTransport({ leave: false });
    markSelfDisconnected();
    setConnectionLabel("重连失败");
    setNotice(error.message || "会议重连失败，请稍后再试。", true, "meeting");
    renderAll();
  } finally {
    state.reconnecting = false;
    renderControls();
  }
}

async function handleTransportInterrupted(message) {
  if (!state.room) {
    return;
  }

  clearMediaRecoveryTimers();
  await releaseConferenceTransport({ leave: false });
  markSelfDisconnected();
  setConnectionLabel("已断开");
  setNotice(message, true, "meeting");
  renderAll();
}

function handlePeerConnectionState(connectionState) {
  if (!connectionState || connectionState === "new") {
    setConnectionLabel("准备连接");
    return;
  }

  if (connectionState === "connecting") {
    setConnectionLabel("连接中");
    return;
  }

  if (connectionState === "connected") {
    clearMediaRecoveryTimers();
    setConnectionLabel("已连接");
    return;
  }

  if (connectionState === "disconnected") {
    setConnectionLabel("连接波动");
    scheduleMediaWarning();
    return;
  }

  if (connectionState === "failed") {
    setConnectionLabel("恢复连接");
    scheduleMediaFailure();
    return;
  }

  if (connectionState === "closed") {
    clearMediaRecoveryTimers();
    setConnectionLabel("已关闭");
  }
}

function scheduleMediaWarning() {
  if (state.mediaWarningTimer) {
    return;
  }

  state.mediaWarningTimer = window.setTimeout(() => {
    state.mediaWarningTimer = null;
    if (!state.pc || !["disconnected", "failed"].includes(state.pc.connectionState)) {
      return;
    }
    setNotice("媒体连接仍在恢复中，可点击“短线重连”手动恢复。", true, "meeting");
  }, MEDIA_DISCONNECT_NOTICE_DELAY_MS);
}

function scheduleMediaFailure() {
  if (state.mediaFailureTimer) {
    return;
  }

  state.mediaFailureTimer = window.setTimeout(() => {
    state.mediaFailureTimer = null;
    if (!state.pc || state.pc.connectionState !== "failed") {
      return;
    }
    handleTransportInterrupted("媒体连接已经中断，可点击“短线重连”恢复。").catch(() => {});
  }, MEDIA_FAILED_GRACE_MS);
}

function clearMediaRecoveryTimers() {
  if (state.mediaWarningTimer) {
    window.clearTimeout(state.mediaWarningTimer);
    state.mediaWarningTimer = null;
  }
  if (state.mediaFailureTimer) {
    window.clearTimeout(state.mediaFailureTimer);
    state.mediaFailureTimer = null;
  }
}

async function cleanupMeeting({ leave = false, preserveLocalMedia = false, preserveSession = false } = {}) {
  await releaseConferenceTransport({ leave });
  if (!preserveLocalMedia) {
    stopLocalMedia();
  }
  if (!preserveSession) {
    resetMeetingSession();
  }
}

async function releaseConferenceTransport({ leave = false } = {}) {
  const signal = state.signal;
  const pc = state.pc;

  clearMediaRecoveryTimers();
  state.signal = null;
  state.pc = null;
  state.audioSender = null;
  state.videoSender = null;
  state.remoteOfferQueue = Promise.resolve();
  state.remoteStreams.clear();
  state.pendingStreams.clear();

  if (pc) {
    pc.close();
  }
  if (signal) {
    try {
      await signal.close({ leave });
    } catch (error) {
      // Socket closure is best effort.
    }
  }
}

function stopLocalMedia() {
  if (state.localStream) {
    state.localStream.getTracks().forEach((track) => track.stop());
  }
  if (state.screenStream) {
    state.screenStream.getTracks().forEach((track) => track.stop());
  }

  state.localStream = null;
  state.localPreviewStream = null;
  state.screenStream = null;
}

function resetMeetingSession() {
  state.room = null;
  state.participant = null;
  state.token = "";
  state.joinUrl = "";
  state.rtc = { iceServers: [] };
  state.reconnecting = false;
  state.ffmpegCommand = "";
  state.focusedParticipantId = null;
  state.zoomedParticipantId = null;
  state.participantMap.clear();

  syncMeetingHeader();
  resetFFmpegPanel();
  resetMeetingStage();
  renderParticipantList([]);
  renderControls();
  hideZoomViewer();
}

function markSelfDisconnected() {
  if (!state.participant) {
    return;
  }

  state.participant = {
    ...state.participant,
    connected: false,
  };
  state.participantMap.set(state.participant.id, state.participant);
}

function resetMeetingStage() {
  elements.spotlightTitle.textContent = "暂无主画面";
  elements.spotlightMeta.textContent = "进入会议后，可点击缩略画面切换主视图。";
  elements.thumbnailCount.textContent = "0 路";
  elements.zoomSelectedButton.disabled = true;
  elements.stage.innerHTML = `
    <div class="stage-empty">
      <strong>等待会议画面</strong>
      <span>加入会议后，可以从下方缩略画面中选择当前主画面，并使用放大查看功能。</span>
    </div>
  `;
  elements.thumbnailStrip.innerHTML = "";
}

function setNotice(message, isError = false, scope = "auto") {
  const currentScope =
    scope === "auto"
      ? elements.meetingView.classList.contains("hidden")
        ? "lobby"
        : "meeting"
      : scope;

  if (currentScope === "meeting") {
    updateNoticeElement(elements.meetingNotice, message, isError);
    if (scope !== "all") {
      updateNoticeElement(elements.lobbyNotice, "", false);
    }
    return;
  }

  updateNoticeElement(elements.lobbyNotice, message, isError);
  if (scope !== "all") {
    updateNoticeElement(elements.meetingNotice, "", false);
  }
}

function updateNoticeElement(element, message, isError) {
  element.textContent = message || "";
  element.classList.toggle("is-error", Boolean(message && isError));
  element.classList.toggle("is-empty", !message);
}

function setConnectionLabel(label) {
  state.connectionLabel = label;
  elements.connectionPill.textContent = label;
}

function setMeetingMode(enabled) {
  document.body.classList.toggle("meeting-mode", enabled);
}

function resetFFmpegPanel() {
  state.ffmpegCommand = "";
  elements.ffmpegCommand.value = "";
  elements.ffmpegHint.innerHTML =
    '生成后可直接复制到终端执行。如果当前页面使用的是本地自签 HTTPS 证书，测试时更建议用 <code>-insecure-http</code> 启动服务。';
}

async function fetchJSON(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(payload.error || "请求失败");
  }

  return payload;
}

function initials(text) {
  const value = String(text || "").trim();
  if (!value) {
    return "U";
  }

  const words = value.split(/\s+/).filter(Boolean);
  if (words.length > 1) {
    return words
      .slice(0, 2)
      .map((word) => Array.from(word)[0])
      .join("")
      .toUpperCase();
  }

  return Array.from(value).slice(0, 2).join("").toUpperCase();
}

function escapeHTML(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

init().catch((error) => {
  elements.serverStatus.textContent = "初始化失败";
  setNotice(error.message, true, "lobby");
});
