package main

import (
	"context"
	"crypto/rand"
	"encoding/base32"
	"errors"
	"sort"
	"strings"
	"sync"
	"time"

	sfu "github.com/pion/ion-sfu/pkg"
	"github.com/sourcegraph/jsonrpc2"
)

var (
	ErrRoomNotFound          = errors.New("room not found")
	ErrParticipantNotFound   = errors.New("participant not found")
	ErrRoomFull              = errors.New("room is full")
	ErrParticipantConnected  = errors.New("participant is already connected")
	ErrDisplayNameRequired   = errors.New("display name is required")
	ErrRoomNameRequired      = errors.New("room name is required")
	ErrInvalidParticipantCap = errors.New("invalid participant limit")
)

type ParticipantPresencePatch struct {
	AudioEnabled  *bool   `json:"audioEnabled,omitempty"`
	VideoEnabled  *bool   `json:"videoEnabled,omitempty"`
	ScreenSharing *bool   `json:"screenSharing,omitempty"`
	StreamID      *string `json:"streamId,omitempty"`
}

type ParticipantSnapshot struct {
	ID            string    `json:"id"`
	DisplayName   string    `json:"displayName"`
	Role          string    `json:"role"`
	JoinedAt      time.Time `json:"joinedAt"`
	Connected     bool      `json:"connected"`
	AudioEnabled  bool      `json:"audioEnabled"`
	VideoEnabled  bool      `json:"videoEnabled"`
	ScreenSharing bool      `json:"screenSharing"`
	StreamID      string    `json:"streamId,omitempty"`
}

type RoomSnapshot struct {
	ID               string                `json:"id"`
	Name             string                `json:"name"`
	Description      string                `json:"description,omitempty"`
	MaxParticipants  int                   `json:"maxParticipants"`
	ParticipantCount int                   `json:"participantCount"`
	CreatedAt        time.Time             `json:"createdAt"`
	UpdatedAt        time.Time             `json:"updatedAt"`
	Participants     []ParticipantSnapshot `json:"participants"`
}

type ParticipantSession struct {
	ID             string
	DisplayName    string
	Role           string
	JoinedAt       time.Time
	Connected      bool
	AudioEnabled   bool
	VideoEnabled   bool
	ScreenSharing  bool
	StreamID       string
	ExpiresAt      time.Time
	DisconnectedAt time.Time
	LastSeenAt     time.Time

	conn *jsonrpc2.Conn
	peer *sfu.WebRTCTransport
}

func (p *ParticipantSession) snapshot() ParticipantSnapshot {
	return ParticipantSnapshot{
		ID:            p.ID,
		DisplayName:   p.DisplayName,
		Role:          p.Role,
		JoinedAt:      p.JoinedAt,
		Connected:     p.Connected,
		AudioEnabled:  p.AudioEnabled,
		VideoEnabled:  p.VideoEnabled,
		ScreenSharing: p.ScreenSharing,
		StreamID:      p.StreamID,
	}
}

type Room struct {
	ID              string
	Name            string
	Description     string
	MaxParticipants int
	CreatedAt       time.Time
	UpdatedAt       time.Time
	EmptySince      time.Time
	Participants    map[string]*ParticipantSession
}

func (r *Room) snapshot() RoomSnapshot {
	participants := make([]ParticipantSnapshot, 0, len(r.Participants))
	for _, participant := range r.Participants {
		participants = append(participants, participant.snapshot())
	}

	sort.Slice(participants, func(i, j int) bool {
		if participants[i].Role != participants[j].Role {
			return participants[i].Role < participants[j].Role
		}
		if participants[i].JoinedAt.Equal(participants[j].JoinedAt) {
			return participants[i].DisplayName < participants[j].DisplayName
		}
		return participants[i].JoinedAt.Before(participants[j].JoinedAt)
	})

	return RoomSnapshot{
		ID:               r.ID,
		Name:             r.Name,
		Description:      r.Description,
		MaxParticipants:  r.MaxParticipants,
		ParticipantCount: len(participants),
		CreatedAt:        r.CreatedAt,
		UpdatedAt:        r.UpdatedAt,
		Participants:     participants,
	}
}

type SessionBundle struct {
	Room        RoomSnapshot        `json:"room"`
	Participant ParticipantSnapshot `json:"participant"`
	Token       string              `json:"token"`
	RTC         RTCConfigResponse   `json:"rtc"`
}

type ConferenceService struct {
	mu                    sync.RWMutex
	rooms                 map[string]*Room
	tokenManager          *TokenManager
	tokenTTL              time.Duration
	reconnectGrace        time.Duration
	roomIdleTTL           time.Duration
	defaultParticipantCap int
	maxParticipantCap     int
}

func NewConferenceService(tokenManager *TokenManager, cfg RuntimeConfig) *ConferenceService {
	return &ConferenceService{
		rooms:                 make(map[string]*Room),
		tokenManager:          tokenManager,
		tokenTTL:              cfg.tokenTTL(),
		reconnectGrace:        cfg.reconnectGrace(),
		roomIdleTTL:           cfg.roomIdleTTL(),
		defaultParticipantCap: cfg.App.DefaultMaxParticipants,
		maxParticipantCap:     cfg.App.MaxParticipantsLimit,
	}
}

type CreateRoomInput struct {
	Name            string `json:"name"`
	Description     string `json:"description"`
	HostName        string `json:"hostName"`
	MaxParticipants int    `json:"maxParticipants"`
}

type JoinRoomInput struct {
	DisplayName string `json:"displayName"`
}

type PrepareFFmpegPublishInput struct {
	DisplayName string `json:"displayName"`
}

func (s *ConferenceService) CreateRoom(input CreateRoomInput, rtc RTCConfigResponse) (SessionBundle, error) {
	name := strings.TrimSpace(input.Name)
	hostName := strings.TrimSpace(input.HostName)

	if name == "" {
		return SessionBundle{}, ErrRoomNameRequired
	}

	if hostName == "" {
		return SessionBundle{}, ErrDisplayNameRequired
	}

	maxParticipants := input.MaxParticipants
	if maxParticipants <= 0 {
		maxParticipants = s.defaultParticipantCap
	}
	if maxParticipants > s.maxParticipantCap {
		return SessionBundle{}, ErrInvalidParticipantCap
	}

	now := time.Now().UTC()
	room := &Room{
		ID:              randomID("room", 10),
		Name:            name,
		Description:     strings.TrimSpace(input.Description),
		MaxParticipants: maxParticipants,
		CreatedAt:       now,
		UpdatedAt:       now,
		Participants:    make(map[string]*ParticipantSession),
	}

	host := &ParticipantSession{
		ID:           randomID("user", 12),
		DisplayName:  hostName,
		Role:         "host",
		JoinedAt:     now,
		AudioEnabled: true,
		VideoEnabled: true,
		ExpiresAt:    now.Add(s.tokenTTL),
		LastSeenAt:   now,
	}

	room.Participants[host.ID] = host

	claims := JoinClaims{
		RoomID:        room.ID,
		ParticipantID: host.ID,
		DisplayName:   host.DisplayName,
		Role:          host.Role,
		ExpiresAt:     host.ExpiresAt.Unix(),
		Use:           TokenUseSignal,
	}

	token, err := s.tokenManager.Sign(claims)
	if err != nil {
		return SessionBundle{}, err
	}

	s.mu.Lock()
	s.rooms[room.ID] = room
	s.mu.Unlock()

	return SessionBundle{
		Room:        room.snapshot(),
		Participant: host.snapshot(),
		Token:       token,
		RTC:         rtc,
	}, nil
}

func (s *ConferenceService) JoinRoom(roomID string, input JoinRoomInput, rtc RTCConfigResponse) (SessionBundle, error) {
	displayName := strings.TrimSpace(input.DisplayName)
	if displayName == "" {
		return SessionBundle{}, ErrDisplayNameRequired
	}

	now := time.Now().UTC()

	s.mu.Lock()
	defer s.mu.Unlock()

	s.cleanupLocked(now)

	room := s.rooms[roomID]
	if room == nil {
		return SessionBundle{}, ErrRoomNotFound
	}

	if len(room.Participants) >= room.MaxParticipants {
		return SessionBundle{}, ErrRoomFull
	}

	participant := &ParticipantSession{
		ID:           randomID("user", 12),
		DisplayName:  displayName,
		Role:         "member",
		JoinedAt:     now,
		AudioEnabled: true,
		VideoEnabled: true,
		ExpiresAt:    now.Add(s.tokenTTL),
		LastSeenAt:   now,
	}

	room.Participants[participant.ID] = participant
	room.UpdatedAt = now
	room.EmptySince = time.Time{}

	claims := JoinClaims{
		RoomID:        room.ID,
		ParticipantID: participant.ID,
		DisplayName:   participant.DisplayName,
		Role:          participant.Role,
		ExpiresAt:     participant.ExpiresAt.Unix(),
		Use:           TokenUseSignal,
	}

	token, err := s.tokenManager.Sign(claims)
	if err != nil {
		delete(room.Participants, participant.ID)
		return SessionBundle{}, err
	}

	return SessionBundle{
		Room:        room.snapshot(),
		Participant: participant.snapshot(),
		Token:       token,
		RTC:         rtc,
	}, nil
}

func (s *ConferenceService) PrepareFFmpegPublish(roomID string, input PrepareFFmpegPublishInput, rtc RTCConfigResponse) (SessionBundle, error) {
	displayName := strings.TrimSpace(input.DisplayName)
	if displayName == "" {
		return SessionBundle{}, ErrDisplayNameRequired
	}

	now := time.Now().UTC()

	s.mu.Lock()
	defer s.mu.Unlock()

	s.cleanupLocked(now)

	room := s.rooms[roomID]
	if room == nil {
		return SessionBundle{}, ErrRoomNotFound
	}

	participant := &ParticipantSession{
		ID:           randomID("stream", 12),
		DisplayName:  displayName,
		Role:         "stream",
		JoinedAt:     now,
		AudioEnabled: false,
		VideoEnabled: false,
		ExpiresAt:    now.Add(s.tokenTTL),
		LastSeenAt:   now,
	}

	claims := JoinClaims{
		RoomID:        room.ID,
		ParticipantID: participant.ID,
		DisplayName:   participant.DisplayName,
		Role:          participant.Role,
		ExpiresAt:     participant.ExpiresAt.Unix(),
		Use:           TokenUseWHIP,
	}

	token, err := s.tokenManager.Sign(claims)
	if err != nil {
		return SessionBundle{}, err
	}

	return SessionBundle{
		Room:        room.snapshot(),
		Participant: participant.snapshot(),
		Token:       token,
		RTC:         rtc,
	}, nil
}

func (s *ConferenceService) GetRoom(roomID string) (RoomSnapshot, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()

	room := s.rooms[roomID]
	if room == nil {
		return RoomSnapshot{}, ErrRoomNotFound
	}

	return room.snapshot(), nil
}

func (s *ConferenceService) ListRooms() []RoomSnapshot {
	s.mu.RLock()
	defer s.mu.RUnlock()

	rooms := make([]RoomSnapshot, 0, len(s.rooms))
	for _, room := range s.rooms {
		rooms = append(rooms, room.snapshot())
	}

	sort.Slice(rooms, func(i, j int) bool {
		return rooms[i].CreatedAt.After(rooms[j].CreatedAt)
	})

	return rooms
}

func (s *ConferenceService) AttachParticipantConnection(claims JoinClaims, conn *jsonrpc2.Conn) (ParticipantSnapshot, bool, *sfu.WebRTCTransport, *jsonrpc2.Conn, error) {
	now := time.Now().UTC()

	s.mu.Lock()
	defer s.mu.Unlock()

	s.cleanupLocked(now)

	room := s.rooms[claims.RoomID]
	if room == nil {
		return ParticipantSnapshot{}, false, nil, nil, ErrRoomNotFound
	}

	participant := room.Participants[claims.ParticipantID]
	if participant == nil {
		return ParticipantSnapshot{}, false, nil, nil, ErrParticipantNotFound
	}

	if now.After(participant.ExpiresAt) {
		delete(room.Participants, claims.ParticipantID)
		return ParticipantSnapshot{}, false, nil, nil, ErrExpiredToken
	}

	wasConnected := participant.Connected
	oldPeer := participant.peer
	oldConn := participant.conn

	participant.DisplayName = claims.DisplayName
	participant.Role = claims.Role
	participant.Connected = true
	participant.DisconnectedAt = time.Time{}
	participant.LastSeenAt = now
	participant.ExpiresAt = time.Unix(claims.ExpiresAt, 0).UTC()
	participant.conn = conn
	participant.peer = nil
	room.UpdatedAt = now
	room.EmptySince = time.Time{}

	return participant.snapshot(), wasConnected, oldPeer, oldConn, nil
}

func (s *ConferenceService) AttachWHIPParticipant(claims JoinClaims, peer *sfu.WebRTCTransport) (ParticipantSnapshot, bool, *sfu.WebRTCTransport, error) {
	now := time.Now().UTC()

	s.mu.Lock()
	defer s.mu.Unlock()

	s.cleanupLocked(now)

	room := s.rooms[claims.RoomID]
	if room == nil {
		return ParticipantSnapshot{}, false, nil, ErrRoomNotFound
	}

	participant := room.Participants[claims.ParticipantID]
	if participant == nil {
		if len(room.Participants) >= room.MaxParticipants {
			return ParticipantSnapshot{}, false, nil, ErrRoomFull
		}

		participant = &ParticipantSession{
			ID:        claims.ParticipantID,
			JoinedAt:  now,
			ExpiresAt: time.Unix(claims.ExpiresAt, 0).UTC(),
		}
		room.Participants[participant.ID] = participant
	}

	if now.After(participant.ExpiresAt) {
		delete(room.Participants, claims.ParticipantID)
		return ParticipantSnapshot{}, false, nil, ErrExpiredToken
	}

	wasConnected := participant.Connected
	oldPeer := participant.peer

	if participant.JoinedAt.IsZero() {
		participant.JoinedAt = now
	}
	participant.DisplayName = claims.DisplayName
	participant.Role = claims.Role
	participant.Connected = true
	participant.DisconnectedAt = time.Time{}
	participant.LastSeenAt = now
	participant.ExpiresAt = time.Unix(claims.ExpiresAt, 0).UTC()
	participant.conn = nil
	participant.peer = peer
	room.UpdatedAt = now
	room.EmptySince = time.Time{}

	return participant.snapshot(), wasConnected, oldPeer, nil
}

func (s *ConferenceService) BindPeer(roomID, participantID string, peer *sfu.WebRTCTransport) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	room := s.rooms[roomID]
	if room == nil {
		return ErrRoomNotFound
	}

	participant := room.Participants[participantID]
	if participant == nil {
		return ErrParticipantNotFound
	}

	participant.peer = peer
	participant.LastSeenAt = time.Now().UTC()
	room.UpdatedAt = participant.LastSeenAt
	return nil
}

func (s *ConferenceService) UpdateParticipantPresence(roomID, participantID string, patch ParticipantPresencePatch) (ParticipantSnapshot, RoomSnapshot, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	room := s.rooms[roomID]
	if room == nil {
		return ParticipantSnapshot{}, RoomSnapshot{}, ErrRoomNotFound
	}

	participant := room.Participants[participantID]
	if participant == nil {
		return ParticipantSnapshot{}, RoomSnapshot{}, ErrParticipantNotFound
	}

	if patch.AudioEnabled != nil {
		participant.AudioEnabled = *patch.AudioEnabled
	}
	if patch.VideoEnabled != nil {
		participant.VideoEnabled = *patch.VideoEnabled
	}
	if patch.ScreenSharing != nil {
		participant.ScreenSharing = *patch.ScreenSharing
	}
	if patch.StreamID != nil {
		participant.StreamID = strings.TrimSpace(*patch.StreamID)
	}

	participant.LastSeenAt = time.Now().UTC()
	room.UpdatedAt = participant.LastSeenAt

	return participant.snapshot(), room.snapshot(), nil
}

func (s *ConferenceService) DetachParticipantConnection(roomID, participantID string, conn *jsonrpc2.Conn, permanent bool) (ParticipantSnapshot, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	room := s.rooms[roomID]
	if room == nil {
		return ParticipantSnapshot{}, false, ErrRoomNotFound
	}

	participant := room.Participants[participantID]
	if participant == nil {
		return ParticipantSnapshot{}, false, ErrParticipantNotFound
	}

	if participant.conn != conn {
		return ParticipantSnapshot{}, false, nil
	}

	now := time.Now().UTC()

	if permanent {
		snapshot := participant.snapshot()
		delete(room.Participants, participantID)
		room.UpdatedAt = now
		if len(room.Participants) == 0 {
			room.EmptySince = room.UpdatedAt
		}
		return snapshot, true, nil
	}

	participant.Connected = false
	participant.DisconnectedAt = now
	participant.LastSeenAt = now
	participant.conn = nil
	participant.peer = nil
	room.UpdatedAt = now

	return participant.snapshot(), false, nil
}

func (s *ConferenceService) DetachParticipantPeer(roomID, participantID string, peer *sfu.WebRTCTransport, permanent bool) (ParticipantSnapshot, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	room := s.rooms[roomID]
	if room == nil {
		return ParticipantSnapshot{}, false, ErrRoomNotFound
	}

	participant := room.Participants[participantID]
	if participant == nil {
		return ParticipantSnapshot{}, false, ErrParticipantNotFound
	}

	if participant.peer != peer {
		return ParticipantSnapshot{}, false, nil
	}

	now := time.Now().UTC()

	if permanent {
		snapshot := participant.snapshot()
		delete(room.Participants, participantID)
		room.UpdatedAt = now
		if len(room.Participants) == 0 {
			room.EmptySince = room.UpdatedAt
		}
		return snapshot, true, nil
	}

	participant.Connected = false
	participant.DisconnectedAt = now
	participant.LastSeenAt = now
	participant.conn = nil
	participant.peer = nil
	room.UpdatedAt = now

	return participant.snapshot(), false, nil
}

func (s *ConferenceService) Broadcast(ctx context.Context, roomID, excludeParticipantID, method string, params interface{}) {
	recipients := make([]*jsonrpc2.Conn, 0, 4)

	s.mu.RLock()
	room := s.rooms[roomID]
	if room != nil {
		for participantID, participant := range room.Participants {
			if participantID == excludeParticipantID || !participant.Connected || participant.conn == nil {
				continue
			}
			recipients = append(recipients, participant.conn)
		}
	}
	s.mu.RUnlock()

	for _, conn := range recipients {
		_ = conn.Notify(ctx, method, params)
	}
}

func (s *ConferenceService) RunJanitor(ctx context.Context) {
	ticker := time.NewTicker(1 * time.Minute)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.mu.Lock()
			s.cleanupLocked(time.Now().UTC())
			s.mu.Unlock()
		}
	}
}

func (s *ConferenceService) cleanupLocked(now time.Time) {
	for roomID, room := range s.rooms {
		removedParticipant := false
		for participantID, participant := range room.Participants {
			expired := !participant.ExpiresAt.IsZero() && now.After(participant.ExpiresAt)
			reconnectExpired := !participant.DisconnectedAt.IsZero() && now.Sub(participant.DisconnectedAt) > s.reconnectGrace
			if !participant.Connected && (expired || reconnectExpired) {
				delete(room.Participants, participantID)
				removedParticipant = true
			}
		}

		if removedParticipant {
			room.UpdatedAt = now
		}

		if len(room.Participants) == 0 {
			if room.EmptySince.IsZero() {
				room.EmptySince = room.UpdatedAt
			}
			if !room.EmptySince.IsZero() && now.Sub(room.EmptySince) > s.roomIdleTTL {
				delete(s.rooms, roomID)
			}
		}
	}
}

func randomID(prefix string, size int) string {
	buf := make([]byte, size)
	if _, err := rand.Read(buf); err != nil {
		panic(err)
	}

	encoded := strings.ToLower(strings.TrimRight(base32.StdEncoding.EncodeToString(buf), "="))
	if len(encoded) > size {
		encoded = encoded[:size]
	}

	return prefix + "_" + encoded
}
