# 11Meeting

`11Meeting` 是在原始 `11LiveChat` Demo 基础上重构的一版单机会议系统基础版，保留 `ion-sfu` 作为媒体核心，并补上了更接近商用系统的关键部分：

- 房间创建、入会和查询 API
- 加入 Token 鉴权
- 多人会议页
- 参与者列表与入会/离会/状态同步
- 麦克风、摄像头、共享屏幕控制
- 只暴露 `public/` 静态资源目录
- `healthz` / `readyz` 健康检查
- 基础单元测试

## 运行

1. 启动服务

```bash
go run . -c config.toml -a :8443
```

2. 打开浏览器访问

```text
https://localhost:8443
```

首次启动如果没有 `cert.pem` / `key.pem`，程序会自动生成本地开发证书。

如果你把 TLS 终止放在 Nginx、Caddy 或云负载均衡前面，可以用明文 HTTP 启动：

```bash
go run . -c config.toml -a :8080 -insecure-http
```

## API

### 获取前端配置

```http
GET /api/v1/config
```

### 创建会议室

```http
POST /api/v1/rooms
Content-Type: application/json

{
  "name": "产品评审会",
  "description": "Q2 roadmap review",
  "hostName": "Alice",
  "maxParticipants": 16
}
```

### 获取会议室信息

```http
GET /api/v1/rooms/{roomId}
```

### 加入会议室

```http
POST /api/v1/rooms/{roomId}/join
Content-Type: application/json

{
  "displayName": "Bob"
}
```

`create` 和 `join` 响应里都会返回：

- `room`
- `participant`
- `token`
- `rtc`
- `joinUrl`

前端使用 `token` 连接 `/ws?token=...` 完成 WebRTC 信令。

## 配置

`config.toml` 继续复用 `ion-sfu` 配置，同时新增 `[app]`：

```toml
[app]
name = "11Meeting"
public_dir = "public"
server_log_enabled = false
public_base_url = "https://meeting.example.com"
token_secret = "replace-with-a-strong-secret"
token_ttl_minutes = 240
default_max_participants = 12
max_participants_limit = 64
room_idle_minutes = 120
allowed_origins = ["meeting.example.com", "https://meeting.example.com"]
```

说明：

- `server_log_enabled` 默认是 `false`，关闭时不会输出常规服务日志，并会把 SFU 日志压到错误级别
- `token_secret` 在生产环境必须配置成固定高强度密钥
- `public_base_url` 建议在反向代理场景下显式配置
- `allowed_origins` 为空时默认只允许同源 WebSocket 连接

## 当前边界

这版已经从 Demo 升级到了可上线的单机基础版，但距离完整商用 SaaS 还差几块典型能力：

- 持久化数据库
- 用户账户与组织体系
- 录制、回放、转写
- 分布式房间调度和多节点 SFU
- 设备选择、弱网自适应策略面板
- 聊天、举手、主持人权限控制

如果要继续往生产体系推进，建议下一步先补数据库、鉴权系统和反向代理部署方案。

## FFmpeg WHIP

### Create a publish session

```http
POST /api/v1/rooms/{roomId}/ffmpeg
Content-Type: application/json

{
  "displayName": "Program Feed"
}
```

Response fields:

- `token`
- `whipUrl`
- `ffmpegCommand`

### Push into the room with FFmpeg

```bash
ffmpeg -re -stream_loop -1 -i input.mp4 \
  -map 0:v:0 -map 0:a:0? \
  -c:v libx264 -profile:v baseline -tune zerolatency -preset veryfast -bf 0 -pix_fmt yuv420p \
  -c:a libopus -ar 48000 -ac 2 \
  -strict experimental \
  -f whip -authorization "<token>" "http://host/api/v1/whip"
```

Notes:

- The server exposes the FFmpeg source as a room participant with `role=stream`.
- The WHIP session resource is returned in the `Location` header of the `201 Created` response.
- For local testing with a self-signed certificate, prefer starting the server with `-insecure-http`, or use a certificate trusted by `ffmpeg`.
