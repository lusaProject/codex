# LiveKit Minimal RTC/SFU Conference Server

这个仓库已经裁剪为单节点最小会议系统，只保留浏览器客户端加入房间、信令、房间自动创建、Pion WebRTC、SFU 音视频转发和 data track 所需代码。

已删除或从默认运行路径移除：egress、ingress、SIP、agent、WHIP、内置 TURN 服务、全量 LiveKit HTTP API、测试伪造辅助和旧构建产物。

## 启动后端

```powershell
go run . --config livekit.minimal.yaml
```

不传配置也可以启动本地开发模式：

```powershell
go run .
```

默认开发密钥：

```text
API Key: devkey
API Secret: secret
```

默认端口：

```text
HTTP/WebSocket: 7880
ICE/TCP:        7881
ICE/UDP:        7882
```

健康检查：

```powershell
curl http://127.0.0.1:7880/healthz
```

## 启动 H5 客户端

另开一个终端：

```powershell
cd h5-client
python -m http.server 5173
```

浏览器访问 `http://127.0.0.1:5173/`，服务地址使用 `ws://127.0.0.1:7880`。开发模式下可以直接用 `devkey` / `secret` 生成 join token，也可以粘贴外部生成的 token。

## 运行边界

最小后端入口是 `service.InitializeMinimalServer`。它只注册 RTC 信令、房间管理、节点路由和 `/healthz`，不会启动 egress、ingress、SIP、agent、WHIP 或内置 TURN 服务。

公网或跨 NAT 使用时，请配置可被客户端访问的 `rtc.node_ip` / `rtc.use_external_ip`，并按需要配置外部 TURN：`rtc.turn_servers`。
