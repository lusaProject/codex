package rtc

import (
	"context"
	"testing"
	"time"

	"github.com/livekit/livekit-server/pkg/telemetry"
	"github.com/livekit/protocol/livekit"
)

func TestBytesSignalStatsWithNullTelemetry(t *testing.T) {
	stats := NewBytesSignalStats(context.Background(), telemetry.NullTelemetryService{})
	stats.ResolveRoom(&livekit.Room{
		Sid:  "RM_test",
		Name: "room",
	})
	stats.ResolveParticipant(&livekit.ParticipantInfo{
		Sid:      "PA_test",
		Identity: "participant",
	})

	stats.AddBytes(1, true)
	stats.AddBytes(2, false)
	stats.Stop()

	select {
	case <-stats.stopped:
	case <-time.After(time.Second):
		t.Fatal("timed out waiting for signal stats worker to stop")
	}
}
