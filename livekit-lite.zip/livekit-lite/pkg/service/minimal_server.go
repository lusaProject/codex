// Copyright 2023 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package service

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"time"

	"github.com/rs/cors"
	"github.com/urfave/negroni/v3"
	"go.uber.org/atomic"
	"golang.org/x/sync/errgroup"

	"github.com/livekit/protocol/auth"
	"github.com/livekit/protocol/logger"
	"github.com/livekit/protocol/rpc"
	protocolutils "github.com/livekit/protocol/utils"
	"github.com/livekit/psrpc"
	"github.com/livekit/psrpc/pkg/middleware/otelpsrpc"

	"github.com/livekit/livekit-server/pkg/config"
	"github.com/livekit/livekit-server/pkg/routing"
	"github.com/livekit/livekit-server/pkg/telemetry"
	"github.com/livekit/livekit-server/pkg/telemetry/prometheus"
	"github.com/livekit/livekit-server/version"
)

type MinimalLiveKitServer struct {
	config       *config.Config
	httpServer   *http.Server
	router       routing.Router
	roomManager  *RoomManager
	signalServer *SignalServer
	currentNode  routing.LocalNode
	running      atomic.Bool
	doneChan     chan struct{}
	closedChan   chan struct{}
}

func InitializeMinimalServer(conf *config.Config, currentNode routing.LocalNode) (*MinimalLiveKitServer, error) {
	keyProvider, err := createMinimalKeyProvider(conf)
	if err != nil {
		return nil, err
	}

	if err := prometheus.Init(string(currentNode.NodeID()), currentNode.NodeType()); err != nil {
		return nil, err
	}

	messageBus := psrpc.NewLocalMessageBus()
	signalClient, err := routing.NewSignalClient(currentNode.NodeID(), messageBus, conf.SignalRelay)
	if err != nil {
		return nil, err
	}

	clientParams := rpc.NewClientParams(
		conf.PSRPC,
		messageBus,
		logger.GetLogger(),
		rpc.PSRPCMetricsObserver{},
		otelpsrpc.ClientOptions(otelpsrpc.Config{}),
	)
	roomManagerClient, err := routing.NewRoomManagerClient(clientParams, conf.Room)
	if err != nil {
		return nil, err
	}
	router := routing.CreateRouter(currentNode, signalClient, roomManagerClient, conf.NodeStats)

	objectStore := NewLocalStore()
	roomAllocator, err := NewRoomAllocator(conf, router, objectStore)
	if err != nil {
		return nil, err
	}

	telemetryService := telemetry.NullTelemetryService{}
	turnAuthHandler := NewTURNAuthHandler(keyProvider)
	roomManager, err := NewMinimalRoomManager(
		conf,
		objectStore,
		currentNode,
		router,
		roomAllocator,
		telemetryService,
		protocolutils.NewDefaultTimedVersionGenerator(),
		turnAuthHandler,
		messageBus,
	)
	if err != nil {
		return nil, err
	}

	signalServer, err := NewDefaultSignalServer(currentNode, messageBus, conf.SignalRelay, router, roomManager)
	if err != nil {
		return nil, err
	}

	rtcService := NewRTCService(conf, roomAllocator, router, telemetryService)
	return NewMinimalLiveKitServer(conf, rtcService, keyProvider, router, roomManager, signalServer, currentNode), nil
}

func NewMinimalLiveKitServer(
	conf *config.Config,
	rtcService *RTCService,
	keyProvider auth.KeyProvider,
	router routing.Router,
	roomManager *RoomManager,
	signalServer *SignalServer,
	currentNode routing.LocalNode,
) *MinimalLiveKitServer {
	mux := http.NewServeMux()
	rtcService.SetupRoutes(mux)
	mux.HandleFunc("/healthz", minimalHealthCheck)
	mux.HandleFunc("/readyz", minimalHealthCheck)

	s := &MinimalLiveKitServer{
		config:       conf,
		router:       router,
		roomManager:  roomManager,
		signalServer: signalServer,
		currentNode:  currentNode,
		closedChan:   make(chan struct{}),
	}
	mux.HandleFunc("/", s.defaultHandler)

	middlewares := []negroni.Handler{
		negroni.NewRecovery(),
		cors.New(cors.Options{
			AllowOriginFunc: func(origin string) bool {
				return true
			},
			AllowedMethods: []string{"OPTIONS", "HEAD", "GET", "POST", "PATCH", "DELETE"},
			AllowedHeaders: []string{"*"},
			ExposedHeaders: []string{"*"},
			MaxAge:         86400,
		}),
		negroni.HandlerFunc(RemoveDoubleSlashes),
	}
	if keyProvider != nil {
		middlewares = append(middlewares, NewAPIKeyAuthMiddleware(keyProvider))
	}

	s.httpServer = &http.Server{
		Handler: configureMinimalMiddlewares(mux, middlewares...),
	}

	return s
}

func configureMinimalMiddlewares(handler http.Handler, middlewares ...negroni.Handler) *negroni.Negroni {
	n := negroni.New()
	for _, middleware := range middlewares {
		n.Use(middleware)
	}
	n.UseHandler(handler)
	return n
}

func (s *MinimalLiveKitServer) Start() error {
	if s.running.Load() {
		return errors.New("already running")
	}
	s.doneChan = make(chan struct{})

	if err := s.router.RegisterNode(); err != nil {
		return err
	}
	defer func() {
		if err := s.router.UnregisterNode(); err != nil {
			logger.Errorw("could not unregister node", err)
		}
	}()

	if err := s.router.Start(); err != nil {
		return err
	}

	addresses := s.config.BindAddresses
	if addresses == nil {
		addresses = []string{""}
	}

	listeners := make([]net.Listener, 0, len(addresses))
	started := false
	defer func() {
		if !started {
			for _, ln := range listeners {
				_ = ln.Close()
			}
		}
	}()

	for _, addr := range addresses {
		ln, err := net.Listen("tcp", net.JoinHostPort(addr, strconv.Itoa(int(s.config.Port))))
		if err != nil {
			return err
		}
		listeners = append(listeners, ln)
	}

	values := []any{
		"portHttp", s.config.Port,
		"nodeID", s.currentNode.NodeID(),
		"nodeIP", s.currentNode.NodeIP(),
		"version", version.Version,
	}
	if s.config.BindAddresses != nil {
		values = append(values, "bindAddresses", s.config.BindAddresses)
	}
	if s.config.RTC.TCPPort != 0 {
		values = append(values, "rtc.portTCP", s.config.RTC.TCPPort)
	}
	if !s.config.RTC.ForceTCP && s.config.RTC.UDPPort.Valid() {
		values = append(values, "rtc.portUDP", s.config.RTC.UDPPort)
	} else {
		values = append(values, "rtc.portICERange", []uint32{s.config.RTC.ICEPortRangeStart, s.config.RTC.ICEPortRangeEnd})
	}
	if s.config.Region != "" {
		values = append(values, "region", s.config.Region)
	}
	logger.Infow("starting minimal LiveKit RTC/SFU server", values...)

	if err := s.signalServer.Start(); err != nil {
		return err
	}

	httpGroup := &errgroup.Group{}
	for _, ln := range listeners {
		listener := ln
		httpGroup.Go(func() error {
			return s.httpServer.Serve(listener)
		})
	}
	go func() {
		if err := httpGroup.Wait(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			logger.Errorw("could not start server", err)
			s.Stop(true)
		}
	}()

	go s.backgroundWorker()

	time.Sleep(100 * time.Millisecond)
	started = true
	s.running.Store(true)

	<-s.doneChan

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = s.httpServer.Shutdown(ctx)

	s.roomManager.Stop()
	s.signalServer.Stop()

	close(s.closedChan)
	return nil
}

func (s *MinimalLiveKitServer) Stop(force bool) {
	s.router.Drain()

	partTicker := time.NewTicker(5 * time.Second)
	waitingForParticipants := !force && s.roomManager.HasParticipants()
	for waitingForParticipants {
		<-partTicker.C
		logger.Infow("waiting for participants to exit")
		waitingForParticipants = s.roomManager.HasParticipants()
	}
	partTicker.Stop()

	if !s.running.Swap(false) {
		return
	}

	s.router.Stop()
	close(s.doneChan)
	<-s.closedChan
}

func (s *MinimalLiveKitServer) defaultHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/" {
		minimalHealthCheck(w, r)
		return
	}
	http.NotFound(w, r)
}

func (s *MinimalLiveKitServer) backgroundWorker() {
	roomTicker := time.NewTicker(time.Second)
	defer roomTicker.Stop()
	for {
		select {
		case <-s.doneChan:
			return
		case <-roomTicker.C:
			s.roomManager.CloseIdleRooms()
		}
	}
}

func createMinimalKeyProvider(conf *config.Config) (auth.KeyProvider, error) {
	if len(conf.Keys) == 0 {
		return nil, config.ErrKeysNotSet
	}
	return auth.NewFileBasedKeyProviderFromMap(conf.Keys), nil
}

func minimalHealthCheck(w http.ResponseWriter, _ *http.Request) {
	w.WriteHeader(http.StatusOK)
	_, _ = fmt.Fprintln(w, "OK")
}
