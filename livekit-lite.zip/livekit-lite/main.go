// Copyright 2023 LiveKit, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"context"
	"fmt"
	"net"
	"os"
	"os/signal"
	"syscall"

	"github.com/urfave/cli/v3"

	"github.com/livekit/protocol/logger"

	"github.com/livekit/livekit-server/pkg/config"
	"github.com/livekit/livekit-server/pkg/routing"
	"github.com/livekit/livekit-server/pkg/rtc"
	"github.com/livekit/livekit-server/pkg/service"
	"github.com/livekit/livekit-server/version"
)

var baseFlags = []cli.Flag{
	&cli.StringSliceFlag{
		Name:  "bind",
		Usage: "IP address to listen on; use multiple times to listen on multiple addresses",
	},
	&cli.StringFlag{
		Name:  "config",
		Usage: "path to LiveKit config file",
	},
	&cli.StringFlag{
		Name:    "config-body",
		Usage:   "LiveKit config in YAML, typically passed as an environment variable",
		Sources: cli.EnvVars("LIVEKIT_CONFIG"),
	},
	&cli.StringFlag{
		Name:  "key-file",
		Usage: "path to file that contains API keys/secrets",
	},
	&cli.StringFlag{
		Name:    "keys",
		Usage:   "api keys (key: secret\\n)",
		Sources: cli.EnvVars("LIVEKIT_KEYS"),
	},
	&cli.StringFlag{
		Name:    "region",
		Usage:   "region of the current node",
		Sources: cli.EnvVars("LIVEKIT_REGION"),
	},
	&cli.StringFlag{
		Name:    "node-ip",
		Usage:   "IP address advertised to clients. Automatically determined by default",
		Sources: cli.EnvVars("NODE_IP"),
	},
	&cli.StringFlag{
		Name:    "udp-port",
		Usage:   "UDP port(s) to use for WebRTC traffic",
		Sources: cli.EnvVars("UDP_PORT"),
	},
	&cli.BoolFlag{
		Name:  "dev",
		Usage: "enable local development defaults",
	},
	&cli.BoolFlag{
		Name:   "disable-strict-config",
		Usage:  "disables strict config parsing",
		Hidden: true,
	},
}

func main() {
	defer func() {
		if rtc.Recover(logger.GetLogger()) != nil {
			os.Exit(1)
		}
	}()

	generatedFlags, err := config.GenerateCLIFlags(baseFlags, true)
	if err != nil {
		fmt.Println(err)
	}

	cmd := &cli.Command{
		Name:        "livekit-minimal",
		Usage:       "Minimal single-node LiveKit RTC/SFU conference server",
		Description: "starts only the pieces required for browser clients to join rooms and publish/subscribe media",
		Flags:       append(baseFlags, generatedFlags...),
		Action:      startServer,
		Version:     version.Version,
	}

	if err := cmd.Run(context.Background(), os.Args); err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
}

func getConfig(c *cli.Command) (*config.Config, error) {
	confString, err := getConfigString(c.String("config"), c.String("config-body"))
	if err != nil {
		return nil, err
	}

	implicitDev := confString == "" && !c.IsSet("dev") && !c.IsSet("keys") && !c.IsSet("key-file")
	if implicitDev {
		confString = "development: true\n"
	}

	conf, err := config.NewConfig(confString, !c.Bool("disable-strict-config"), c, baseFlags)
	if err != nil {
		return nil, err
	}

	config.InitLoggerFromConfig(&conf.Logging)
	applyDevelopmentDefaults(conf)
	disableUnsupportedRuntimeFeatures(conf)

	return conf, nil
}

func applyDevelopmentDefaults(conf *config.Config) {
	if !conf.Development {
		return
	}

	logger.Infow("starting minimal conference server in development mode")

	if len(conf.Keys) == 0 {
		logger.Infow("no keys provided, using placeholder keys",
			"API Key", "devkey",
			"API Secret", "secret",
		)
		conf.Keys = map[string]string{
			"devkey": "secret",
		}
	}

	if conf.BindAddresses == nil {
		conf.BindAddresses = []string{"127.0.0.1", "::1"}
		return
	}

	shouldMatchRTCIP := false
	for _, addr := range conf.BindAddresses {
		ip := net.ParseIP(addr)
		if ip != nil && !ip.IsLoopback() && !ip.IsUnspecified() {
			shouldMatchRTCIP = true
			break
		}
	}
	if shouldMatchRTCIP {
		for _, bindAddr := range conf.BindAddresses {
			conf.RTC.IPs.Includes = append(conf.RTC.IPs.Includes, bindAddr+"/24")
		}
	}
}

func disableUnsupportedRuntimeFeatures(conf *config.Config) {
	if conf.TURN.Enabled {
		logger.Warnw("embedded TURN is disabled in the minimal conference build; configure external rtc.turn_servers if needed", nil)
		conf.TURN.Enabled = false
	}

	conf.Prometheus.Port = 0
	conf.PrometheusPort = 0
	conf.Trace.JaegerURL = ""
}

func startServer(_ context.Context, c *cli.Command) error {
	conf, err := getConfig(c)
	if err != nil {
		return err
	}

	if err = conf.ValidateKeys(); err != nil {
		return err
	}

	currentNode, err := routing.NewLocalNode(conf)
	if err != nil {
		return err
	}

	server, err := service.InitializeMinimalServer(conf, currentNode)
	if err != nil {
		return err
	}

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	go func() {
		for i := range 2 {
			sig := <-sigChan
			force := i > 0
			logger.Infow("exit requested, shutting down", "signal", sig, "force", force)
			go server.Stop(force)
		}
	}()

	return server.Start()
}

func getConfigString(configFile string, inConfigBody string) (string, error) {
	if inConfigBody != "" || configFile == "" {
		return inConfigBody, nil
	}

	outConfigBody, err := os.ReadFile(configFile)
	if err != nil {
		return "", err
	}

	return string(outConfigBody), nil
}
