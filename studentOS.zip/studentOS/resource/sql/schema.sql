CREATE TABLE IF NOT EXISTS students (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    student_no VARCHAR(32) NOT NULL UNIQUE,
    name VARCHAR(64) NOT NULL,
    gender TINYINT NOT NULL DEFAULT 0,
    class_name VARCHAR(64) NOT NULL,
    major VARCHAR(64) NOT NULL,
    college VARCHAR(64) NOT NULL,
    mobile VARCHAR(32) NULL,
    email VARCHAR(128) NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    deleted_at DATETIME NULL,
    INDEX idx_student_name (name),
    INDEX idx_student_class (class_name),
    INDEX idx_student_status (status)
);

CREATE TABLE IF NOT EXISTS courses (
    id BIGINT PRIMARY KEY,
    course_code VARCHAR(32) NOT NULL UNIQUE,
    course_name VARCHAR(128) NOT NULL,
    teacher_id BIGINT NOT NULL,
    teacher_name VARCHAR(64) NOT NULL,
    credit DECIMAL(4,1) NOT NULL,
    capacity INT NOT NULL,
    selected_count INT NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    deleted_at DATETIME NULL,
    INDEX idx_course_teacher (teacher_id),
    INDEX idx_course_status (status)
);

CREATE TABLE IF NOT EXISTS course_enrollments (
    id BIGINT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    status TINYINT NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE(student_id, course_id),
    INDEX idx_course_enrollments_course_id (course_id),
    INDEX idx_course_enrollments_student_id (student_id)
);

CREATE TABLE IF NOT EXISTS grades (
    id BIGINT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    course_id BIGINT NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    grade_level VARCHAR(8) NOT NULL,
    remark VARCHAR(255) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    UNIQUE(student_id, course_id),
    INDEX idx_grade_student (student_id),
    INDEX idx_grade_course (course_id)
);
