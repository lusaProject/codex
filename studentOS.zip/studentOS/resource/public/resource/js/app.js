(function () {
  "use strict";

  const STORAGE_KEY = "student-management:h5:api-base";
  const PAGE_SIZE = 10;
  const REFERENCE_SIZE = 100;

  const state = {
    currentView: "dashboard",
    apiBase: localStorage.getItem(STORAGE_KEY) || "",
    students: {
      page: 1,
      size: PAGE_SIZE,
      total: 0,
      filters: { name: "", class_name: "", status: 0 },
      list: [],
    },
    courses: {
      page: 1,
      size: PAGE_SIZE,
      total: 0,
      filters: { course_name: "", teacher_id: 0, status: 0 },
      list: [],
    },
    references: {
      students: [],
      courses: [],
      grades: [],
    },
    lastStudentCourseId: "",
    lastCourseStudentId: "",
    lastStudentGradeId: "",
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const api = {
    students: "/api/v1/students",
    courses: "/api/v1/courses",
    enrollments: "/api/v1/enrollments",
    grades: "/api/v1/grades",
  };

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    bindActions();
    bindForms();
    renderApiBase();
    renderStats();
    switchView("dashboard");
    refreshAll({ silent: true });
  }

  function bindActions() {
    document.addEventListener("click", async (event) => {
      const target = event.target.closest("[data-action], [data-view]");
      if (!target) return;

      const action = target.dataset.action;
      const view = target.dataset.view;

      if (view) {
        switchView(view);
        return;
      }

      const id = target.dataset.id;
      const kind = target.dataset.kind;

      try {
        switch (action) {
          case "open-menu":
            document.body.classList.add("menu-open");
            break;
          case "close-menu":
            document.body.classList.remove("menu-open");
            break;
          case "refresh-current":
            await refreshCurrent();
            break;
          case "quick-create":
            state.currentView === "courses" ? openCourseModal() : openStudentModal();
            break;
          case "open-student-modal":
            openStudentModal();
            break;
          case "open-course-modal":
            openCourseModal();
            break;
          case "open-api-modal":
            openApiModal();
            break;
          case "close-modal":
            closeModals();
            break;
          case "edit-student":
            openStudentModal(state.students.list.find((item) => String(item.student_id) === id));
            break;
          case "student-status":
            await updateStudentStatus(id, Number(target.dataset.status));
            break;
          case "view-student":
            await viewStudent(id);
            break;
          case "student-courses":
            state.lastStudentCourseId = id;
            switchView("enrollments");
            $("#studentCoursesForm [name=student_id]").value = id;
            await loadStudentCourses(id);
            break;
          case "student-grades":
            state.lastStudentGradeId = id;
            switchView("grades");
            $("#studentGradesForm [name=student_id]").value = id;
            await loadStudentGrades(id);
            break;
          case "edit-course":
            openCourseModal(state.courses.list.find((item) => String(item.course_id) === id));
            break;
          case "course-status":
            await updateCourseStatus(id, Number(target.dataset.status));
            break;
          case "view-course":
            await viewCourse(id);
            break;
          case "course-students":
            state.lastCourseStudentId = id;
            switchView("enrollments");
            $("#courseStudentsForm [name=course_id]").value = id;
            await loadCourseStudents(id);
            break;
          case "drop-enrollment":
            await dropEnrollment(id, kind);
            break;
          case "edit-grade":
            fillGradeUpdate(target.dataset.gradeId, target.dataset.score, target.dataset.remark || "");
            switchView("grades");
            break;
          case "student-page":
            await loadStudents(Number(target.dataset.page));
            break;
          case "course-page":
            await loadCourses(Number(target.dataset.page));
            break;
          default:
            break;
        }
      } catch (error) {
        showToast(error.message || "操作失败", "error");
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeModals();
        document.body.classList.remove("menu-open");
      }
    });
  }

  function bindForms() {
    $("#studentFilterForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = formValues(event.currentTarget);
      state.students.filters = {
        name: values.name,
        class_name: values.class_name,
        status: toNumber(values.status),
      };
      await loadStudents(1);
    });

    $("#courseFilterForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = formValues(event.currentTarget);
      state.courses.filters = {
        course_name: values.course_name,
        teacher_id: toNumber(values.teacher_id),
        status: toNumber(values.status),
      };
      await loadCourses(1);
    });

    $("#studentForm").addEventListener("submit", submitStudent);
    $("#courseForm").addEventListener("submit", submitCourse);
    $("#enrollForm").addEventListener("submit", submitEnrollment);
    $("#studentCoursesForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = formValues(event.currentTarget).student_id;
      if (!id) {
        showToast("请先选择学生", "error");
        return;
      }
      state.lastStudentCourseId = id;
      await loadStudentCourses(id);
    });
    $("#courseStudentsForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = formValues(event.currentTarget).course_id;
      if (!id) {
        showToast("请先选择课程", "error");
        return;
      }
      state.lastCourseStudentId = id;
      await loadCourseStudents(id);
    });
    $("#gradeSubmitForm").addEventListener("submit", submitGrade);
    $("#gradeSubmitForm [name=student_id]").addEventListener("change", async (event) => {
      try {
        await loadGradeCourseOptions(event.currentTarget.value);
      } catch (error) {
        showToast(error.message || "已选课程加载失败", "error");
      }
    });
    $("#gradeUpdateForm").addEventListener("submit", updateGrade);
    $("#gradeUpdateForm [name=grade_id]").addEventListener("change", fillGradeUpdateFromSelection);
    $("#studentGradesForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const id = formValues(event.currentTarget).student_id;
      if (!id) {
        showToast("请先选择学生", "error");
        return;
      }
      state.lastStudentGradeId = id;
      await loadStudentGrades(id);
    });
    $("#apiBaseForm").addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = formValues(event.currentTarget);
      state.apiBase = normalizeApiBase(values.api_base);
      localStorage.setItem(STORAGE_KEY, state.apiBase);
      renderApiBase();
      closeModals();
      await refreshAll();
    });
  }

  function switchView(view) {
    state.currentView = view;
    document.body.classList.remove("menu-open");
    $$(".nav-item").forEach((item) => item.classList.toggle("is-active", item.dataset.view === view));
    $$(".view-panel").forEach((panel) => panel.classList.toggle("is-active", panel.dataset.panel === view));
    $("#pageTitle").textContent = {
      dashboard: "学生管理系统",
      students: "学生档案",
      courses: "课程管理",
      enrollments: "选课管理",
      grades: "成绩管理",
    }[view] || "学生管理系统";
  }

  async function refreshCurrent() {
    if (state.currentView === "students") {
      await loadStudents(state.students.page);
    } else if (state.currentView === "courses") {
      await loadCourses(state.courses.page);
    } else if (state.currentView === "enrollments") {
      await Promise.all([loadReferences(), refreshEnrollmentQueries()]);
    } else if (state.currentView === "grades") {
      await Promise.all([loadReferences(), refreshGradeQueries()]);
      const gradeStudentId = $("#gradeSubmitForm [name=student_id]").value;
      if (gradeStudentId) {
        await loadGradeCourseOptions(gradeStudentId);
      }
    } else {
      await refreshAll();
    }
  }

  async function refreshAll(options = {}) {
    try {
      await Promise.all([
        loadStudents(1, { silent: true }),
        loadCourses(1, { silent: true }),
        loadReferences({ silent: true }),
      ]);
      setHealth(true);
      if (!options.silent) showToast("数据已刷新");
    } catch (error) {
      setHealth(false, error.message);
      if (!options.silent) showToast(error.message || "服务连接失败", "error");
    }
  }

  async function loadStudents(page = 1, options = {}) {
    state.students.page = page;
    const query = toQuery({
      page,
      size: state.students.size,
      ...state.students.filters,
    });
    const data = await request(`${api.students}?${query}`);
    state.students.list = data.list || [];
    state.students.total = Number(data.total || 0);
    renderStudents();
    renderStats();
    renderReferenceSelects();
    if (!options.silent) setHealth(true);
  }

  async function loadCourses(page = 1, options = {}) {
    state.courses.page = page;
    const query = toQuery({
      page,
      size: state.courses.size,
      ...state.courses.filters,
    });
    const data = await request(`${api.courses}?${query}`);
    state.courses.list = data.list || [];
    state.courses.total = Number(data.total || 0);
    renderCourses();
    renderStats();
    renderReferenceSelects();
    if (!options.silent) setHealth(true);
  }

  async function loadReferences() {
    const [studentData, courseData] = await Promise.all([
      request(`${api.students}?${toQuery({ page: 1, size: REFERENCE_SIZE })}`),
      request(`${api.courses}?${toQuery({ page: 1, size: REFERENCE_SIZE })}`),
    ]);
    state.references.students = studentData.list || [];
    state.references.courses = courseData.list || [];
    renderReferenceSelects();
  }

  function renderStudents() {
    const rows = $("#studentRows");
    rows.innerHTML = state.students.list.map((student) => `
      <tr>
        <td>${escapeHtml(student.student_id)}</td>
        <td><strong>${escapeHtml(student.student_no)}</strong></td>
        <td>
          <div class="cell-title">
            <strong>${escapeHtml(student.name)}</strong>
            <small>${genderLabel(student.gender)}</small>
          </div>
        </td>
        <td>${escapeHtml(student.class_name)}</td>
        <td>
          <div class="cell-title">
            <strong>${escapeHtml(student.major)}</strong>
            <small>${escapeHtml(student.college)}</small>
          </div>
        </td>
        <td>
          <div class="cell-title">
            <small>${escapeHtml(student.mobile || "-")}</small>
            <small>${escapeHtml(student.email || "-")}</small>
          </div>
        </td>
        <td>${statusBadge(student.status, "student")}</td>
        <td>
          <div class="row-actions">
            <button class="tiny-button" type="button" data-action="view-student" data-id="${student.student_id}">详情</button>
            <button class="tiny-button" type="button" data-action="edit-student" data-id="${student.student_id}">编辑</button>
            <button class="tiny-button" type="button" data-action="student-courses" data-id="${student.student_id}">课表</button>
            <button class="tiny-button" type="button" data-action="student-grades" data-id="${student.student_id}">成绩</button>
            <button class="${student.status === 1 ? "danger-button" : "tiny-button"}" type="button" data-action="student-status" data-id="${student.student_id}" data-status="${student.status === 1 ? 2 : 1}">
              ${student.status === 1 ? "禁用" : "启用"}
            </button>
          </div>
        </td>
      </tr>
    `).join("");
    $("#studentEmpty").classList.toggle("is-visible", state.students.list.length === 0);
    renderPagination("#studentPagination", state.students, "student-page");
  }

  function renderCourses() {
    const rows = $("#courseRows");
    rows.innerHTML = state.courses.list.map((course) => `
      <tr>
        <td>${escapeHtml(course.course_id)}</td>
        <td><strong>${escapeHtml(course.course_code)}</strong></td>
        <td>${escapeHtml(course.course_name)}</td>
        <td>
          <div class="cell-title">
            <strong>${escapeHtml(course.teacher_name)}</strong>
            <small>ID ${escapeHtml(course.teacher_id)}</small>
          </div>
        </td>
        <td>${escapeHtml(course.credit)}</td>
        <td>
          <div class="cell-title">
            <strong>${escapeHtml(course.selected_count)} / ${escapeHtml(course.capacity)}</strong>
            <small>${capacityLabel(course)}</small>
          </div>
        </td>
        <td>${statusBadge(course.status, "course")}</td>
        <td>
          <div class="row-actions">
            <button class="tiny-button" type="button" data-action="view-course" data-id="${course.course_id}">详情</button>
            <button class="tiny-button" type="button" data-action="edit-course" data-id="${course.course_id}">编辑</button>
            <button class="tiny-button" type="button" data-action="course-students" data-id="${course.course_id}">名单</button>
            <button class="${course.status === 1 ? "danger-button" : "tiny-button"}" type="button" data-action="course-status" data-id="${course.course_id}" data-status="${course.status === 1 ? 2 : 1}">
              ${course.status === 1 ? "停用" : "启用"}
            </button>
          </div>
        </td>
      </tr>
    `).join("");
    $("#courseEmpty").classList.toggle("is-visible", state.courses.list.length === 0);
    renderPagination("#coursePagination", state.courses, "course-page");
  }

  function renderStats() {
    const activeStudents = state.students.list.filter((item) => item.status === 1).length;
    const activeCourses = state.courses.list.filter((item) => item.status === 1).length;
    const selectedCount = state.courses.list.reduce((sum, item) => sum + Number(item.selected_count || 0), 0);
    const capacity = state.courses.list.reduce((sum, item) => sum + Number(item.capacity || 0), 0);
    const usage = capacity ? Math.round((selectedCount / capacity) * 100) : 0;
    $("#statCards").innerHTML = [
      statCard("学生总数", state.students.total, `当前页启用 ${activeStudents} 人`),
      statCard("课程总数", state.courses.total, `当前页启用 ${activeCourses} 门`),
      statCard("已选人次", selectedCount, `当前页课程容量 ${capacity}`),
      statCard("容量使用率", `${usage}%`, "基于当前页课程计算"),
    ].join("");
  }

  function statCard(title, value, meta) {
    return `
      <article class="stat-card">
        <span>${title}</span>
        <strong>${escapeHtml(value)}</strong>
        <span>${escapeHtml(meta)}</span>
      </article>
    `;
  }

  function renderPagination(selector, pageState, action) {
    const totalPages = Math.max(1, Math.ceil(pageState.total / pageState.size));
    const current = Math.min(pageState.page, totalPages);
    $(selector).innerHTML = `
      <span class="muted-text">共 ${pageState.total} 条，第 ${current} / ${totalPages} 页</span>
      <button class="tiny-button" type="button" data-action="${action}" data-page="${Math.max(1, current - 1)}" ${current <= 1 ? "disabled" : ""}>上一页</button>
      <button class="tiny-button" type="button" data-action="${action}" data-page="${Math.min(totalPages, current + 1)}" ${current >= totalPages ? "disabled" : ""}>下一页</button>
    `;
  }

  function renderReferenceSelects() {
    const students = uniqueBy([...state.references.students, ...state.students.list], (item) => item.student_id);
    const courses = uniqueBy([...state.references.courses, ...state.courses.list], (item) => item.course_id);
    const activeStudents = students.filter(isActiveStudent);

    renderSelectOptions("#enrollForm [name=student_id]", activeStudents, {
      placeholder: "请选择启用学生",
      value: (student) => student.student_id,
      label: studentOptionLabel,
      disableWhenEmpty: true,
    });
    renderSelectOptions("#studentCoursesForm [name=student_id]", students, {
      placeholder: "请选择学生",
      value: (student) => student.student_id,
      label: studentOptionLabel,
      disableWhenEmpty: true,
    });
    renderSelectOptions("#gradeSubmitForm [name=student_id]", activeStudents, {
      placeholder: "请选择启用学生",
      value: (student) => student.student_id,
      label: studentOptionLabel,
      disableWhenEmpty: true,
    });
    renderSelectOptions("#studentGradesForm [name=student_id]", students, {
      placeholder: "请选择学生",
      value: (student) => student.student_id,
      label: studentOptionLabel,
      disableWhenEmpty: true,
    });
    renderSelectOptions("#enrollForm [name=course_id]", courses.filter(isSelectableCourse), {
      placeholder: "请选择可选课程",
      value: (course) => course.course_id,
      label: courseOptionLabel,
      disableWhenEmpty: true,
    });
    renderSelectOptions("#courseStudentsForm [name=course_id]", courses, {
      placeholder: "请选择课程",
      value: (course) => course.course_id,
      label: courseOptionLabel,
      disableWhenEmpty: true,
    });
    if (!$("#gradeSubmitForm [name=student_id]")?.value) {
      renderSelectLoading("#gradeSubmitForm [name=course_id]", "请先选择学生");
    }
  }

  function renderSelectOptions(selector, items, config) {
    const select = $(selector);
    if (!select) return;
    const currentValue = select.value;
    const getValue = config.value;
    const getLabel = config.label;
    select.innerHTML = `<option value="">${escapeHtml(config.placeholder || "请选择")}</option>${items.map((item) => {
      const value = String(getValue(item));
      return `<option value="${escapeAttribute(value)}">${escapeHtml(getLabel(item))}</option>`;
    }).join("")}`;
    select.disabled = Boolean(config.disableWhenEmpty && items.length === 0);
    if (currentValue && items.some((item) => String(getValue(item)) === currentValue)) {
      select.value = currentValue;
    }
  }

  function renderSelectLoading(selector, message) {
    const select = $(selector);
    if (!select) return;
    select.innerHTML = `<option value="">${escapeHtml(message)}</option>`;
    select.disabled = true;
  }

  function renderGradeUpdateOptions(selectedGradeId) {
    const grades = state.references.grades.filter((item) => Number(item.grade?.grade_id) > 0);
    renderSelectOptions("#gradeUpdateForm [name=grade_id]", grades, {
      placeholder: "请先查询学生成绩",
      value: (item) => item.grade?.grade_id,
      label: gradeOptionLabel,
      disableWhenEmpty: true,
    });
    if (selectedGradeId) {
      $("#gradeUpdateForm [name=grade_id]").value = selectedGradeId;
    }
  }

  function uniqueBy(items, getKey) {
    const map = new Map();
    items.forEach((item) => {
      const key = getKey(item);
      if (key) {
        map.set(String(key), item);
      }
    });
    return Array.from(map.values());
  }

  function isActiveStudent(student) {
    return Number(student.status) === 1;
  }

  function isSelectableCourse(course) {
    return Number(course.status) === 1 && courseRemaining(course) > 0;
  }

  function courseRemaining(course) {
    return Number(course.capacity || 0) - Number(course.selected_count || 0);
  }

  function studentOptionLabel(student) {
    const disabled = Number(student.status) === 2 ? "（禁用）" : "";
    return `${student.name || "-"}（${student.student_no || `ID ${student.student_id}`}）${disabled}`;
  }

  function courseOptionLabel(course) {
    const remain = courseRemaining(course);
    const suffix = Number(course.status) === 2 ? "（停用）" : `（余 ${Math.max(0, remain)}）`;
    return `${course.course_name || "-"}（${course.course_code || `ID ${course.course_id}`}）${suffix}`;
  }

  function gradeOptionLabel(item) {
    const grade = item.grade || {};
    const course = item.course || {};
    return `${course.course_name || "课程"} - ${grade.score ?? "-"} 分（${grade.grade_level || "-"}）`;
  }

  async function submitStudent(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = formValues(form);
    const studentId = values.student_id;
    const payload = {
      name: values.name,
      gender: toNumber(values.gender),
      class_name: values.class_name,
      major: values.major,
      college: values.college,
      mobile: values.mobile,
      email: values.email,
    };

    if (studentId) {
      await request(`${api.students}/${studentId}`, { method: "PUT", body: payload });
      showToast("学生信息已更新");
    } else {
      await request(api.students, { method: "POST", body: { ...payload, student_no: values.student_no } });
      showToast("学生已创建");
    }
    closeModals();
    form.reset();
    await Promise.all([loadStudents(studentId ? state.students.page : 1), loadReferences()]);
  }

  async function submitCourse(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = formValues(form);
    const courseId = values.course_id;
    const payload = {
      course_name: values.course_name,
      teacher_id: toNumber(values.teacher_id),
      teacher_name: values.teacher_name,
      credit: toNumber(values.credit),
      capacity: toNumber(values.capacity),
    };

    if (courseId) {
      await request(`${api.courses}/${courseId}`, { method: "PUT", body: payload });
      showToast("课程信息已更新");
    } else {
      await request(api.courses, { method: "POST", body: { ...payload, course_code: values.course_code } });
      showToast("课程已创建");
    }
    closeModals();
    form.reset();
    await Promise.all([loadCourses(courseId ? state.courses.page : 1), loadReferences()]);
  }

  async function submitEnrollment(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = formValues(form);
    if (!values.student_id || !values.course_id) {
      showToast("请先选择学生和课程", "error");
      return;
    }
    const data = await request(api.enrollments, {
      method: "POST",
      body: {
        student_id: toNumber(values.student_id),
        course_id: toNumber(values.course_id),
      },
    });
    showToast(`选课成功，选课 ID：${data.enrollment_id || "-"}`);
    state.lastStudentCourseId = values.student_id;
    state.lastCourseStudentId = values.course_id;
    await Promise.all([
      loadCourses(state.courses.page, { silent: true }),
      loadReferences(),
      loadStudentCourses(values.student_id),
      loadCourseStudents(values.course_id),
    ]);
    if ($("#gradeSubmitForm [name=student_id]").value === values.student_id) {
      await loadGradeCourseOptions(values.student_id);
    }
  }

  async function submitGrade(event) {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    if (!values.student_id || !values.course_id) {
      showToast("请先选择学生和已选课程", "error");
      return;
    }
    const data = await request(api.grades, {
      method: "POST",
      body: {
        student_id: toNumber(values.student_id),
        course_id: toNumber(values.course_id),
        score: toNumber(values.score),
        remark: values.remark,
      },
    });
    showToast(`成绩已提交，等级：${data.grade_level || "-"}`);
    state.lastStudentGradeId = values.student_id;
    await loadStudentGrades(values.student_id);
  }

  async function updateGrade(event) {
    event.preventDefault();
    const values = formValues(event.currentTarget);
    if (!values.grade_id) {
      showToast("请先选择要修改的成绩", "error");
      return;
    }
    const data = await request(`${api.grades}/${values.grade_id}`, {
      method: "PUT",
      body: {
        score: toNumber(values.score),
        remark: values.remark,
      },
    });
    showToast(`成绩已修改，等级：${data.grade_level || "-"}`);
    await refreshGradeQueries();
  }

  async function updateStudentStatus(id, status) {
    await request(`${api.students}/${id}/status`, { method: "PATCH", body: { status } });
    showToast(status === 1 ? "学生已启用" : "学生已禁用");
    await Promise.all([loadStudents(state.students.page), loadReferences()]);
  }

  async function updateCourseStatus(id, status) {
    await request(`${api.courses}/${id}/status`, { method: "PATCH", body: { status } });
    showToast(status === 1 ? "课程已启用" : "课程已停用");
    await Promise.all([loadCourses(state.courses.page), loadReferences()]);
  }

  async function viewStudent(id) {
    const data = await request(`${api.students}/${id}`);
    const student = data.student || {};
    showToast(`${student.name || "学生"}：${student.student_no || "-"}，${student.class_name || "-"}`);
  }

  async function viewCourse(id) {
    const data = await request(`${api.courses}/${id}`);
    const course = data.course || {};
    showToast(`${course.course_name || "课程"}：已选 ${course.selected_count || 0}/${course.capacity || 0}`);
  }

  async function fetchStudentCourses(studentId) {
    const data = await request(`${api.students}/${studentId}/courses`);
    return data.list || [];
  }

  async function loadGradeCourseOptions(studentId) {
    if (!studentId) {
      renderSelectLoading("#gradeSubmitForm [name=course_id]", "请先选择学生");
      return;
    }
    renderSelectLoading("#gradeSubmitForm [name=course_id]", "正在加载已选课程");
    const list = await fetchStudentCourses(studentId);
    const selectedCourses = list.map((item) => item.course).filter((course) => Number(course?.course_id) > 0);
    renderSelectOptions("#gradeSubmitForm [name=course_id]", selectedCourses, {
      placeholder: selectedCourses.length ? "请选择已选课程" : "该学生暂无已选课程",
      value: (course) => course.course_id,
      label: courseOptionLabel,
      disableWhenEmpty: true,
    });
  }

  async function loadStudentCourses(studentId) {
    const list = await fetchStudentCourses(studentId);
    $("#studentCourseList").innerHTML = list.length ? list.map((item) => `
      <div class="result-item">
        <div>
          <strong>${escapeHtml(item.course?.course_name || "-")}</strong>
          <small>选课 ID ${escapeHtml(item.enrollment_id)} · ${escapeHtml(item.course?.course_code || "-")} · ${formatTime(item.enrolled_at)}</small>
        </div>
        <button class="danger-button" type="button" data-action="drop-enrollment" data-id="${item.enrollment_id}" data-kind="student-course">退课</button>
      </div>
    `).join("") : `<div class="empty-state is-visible">该学生暂无已选课程。</div>`;
  }

  async function loadCourseStudents(courseId) {
    const data = await request(`${api.courses}/${courseId}/students`);
    const list = data.list || [];
    $("#courseStudentRows").innerHTML = list.map((item) => `
      <tr>
        <td>${escapeHtml(item.enrollment_id)}</td>
        <td>${escapeHtml(item.student_id)}</td>
        <td>${escapeHtml(item.student_no)}</td>
        <td>${escapeHtml(item.name)}</td>
        <td>${escapeHtml(item.class_name)}</td>
        <td>${formatTime(item.enrolled_at)}</td>
        <td><button class="danger-button" type="button" data-action="drop-enrollment" data-id="${item.enrollment_id}" data-kind="course-students">退课</button></td>
      </tr>
    `).join("");
    $("#courseStudentEmpty").classList.toggle("is-visible", list.length === 0);
  }

  async function loadStudentGrades(studentId) {
    const data = await request(`${api.students}/${studentId}/grades`);
    const list = data.list || [];
    state.references.grades = list;
    renderGradeUpdateOptions();
    if (!list.length) {
      setFormValues($("#gradeUpdateForm"), { score: "", remark: "" });
    }
    $("#studentGradeRows").innerHTML = list.map((item) => {
      const grade = item.grade || {};
      const course = item.course || {};
      return `
        <tr>
          <td>${escapeHtml(grade.grade_id)}</td>
          <td>
            <div class="cell-title">
              <strong>${escapeHtml(course.course_name || "-")}</strong>
              <small>${escapeHtml(course.course_code || "-")}</small>
            </div>
          </td>
          <td>${escapeHtml(grade.score)}</td>
          <td>${gradeBadge(grade.grade_level)}</td>
          <td>${escapeHtml(grade.remark || "-")}</td>
          <td>${formatTime(grade.updated_at)}</td>
          <td>
            <button class="tiny-button" type="button" data-action="edit-grade" data-grade-id="${grade.grade_id}" data-score="${grade.score}" data-remark="${escapeAttribute(grade.remark || "")}">修改</button>
          </td>
        </tr>
      `;
    }).join("");
    $("#studentGradeEmpty").classList.toggle("is-visible", list.length === 0);
  }

  async function dropEnrollment(id, kind) {
    if (!window.confirm(`确认退课？选课 ID：${id}`)) return;
    await request(`${api.enrollments}/${id}`, { method: "DELETE" });
    showToast("退课成功");
    await Promise.all([
      loadCourses(state.courses.page, { silent: true }),
      loadReferences(),
      kind === "student-course" && state.lastStudentCourseId ? loadStudentCourses(state.lastStudentCourseId) : Promise.resolve(),
      kind === "course-students" && state.lastCourseStudentId ? loadCourseStudents(state.lastCourseStudentId) : Promise.resolve(),
    ]);
    const gradeStudentId = $("#gradeSubmitForm [name=student_id]").value;
    if (gradeStudentId) {
      await loadGradeCourseOptions(gradeStudentId);
    }
  }

  async function refreshEnrollmentQueries() {
    await Promise.all([
      state.lastStudentCourseId ? loadStudentCourses(state.lastStudentCourseId) : Promise.resolve(),
      state.lastCourseStudentId ? loadCourseStudents(state.lastCourseStudentId) : Promise.resolve(),
    ]);
  }

  async function refreshGradeQueries() {
    if (state.lastStudentGradeId) {
      await loadStudentGrades(state.lastStudentGradeId);
    }
  }

  function openStudentModal(student) {
    const form = $("#studentForm");
    form.reset();
    $("#studentModalTitle").textContent = student ? "编辑学生" : "新增学生";
    form.student_no.disabled = Boolean(student);
    if (student) {
      setFormValues(form, {
        student_id: student.student_id,
        student_no: student.student_no,
        name: student.name,
        gender: student.gender,
        class_name: student.class_name,
        major: student.major,
        college: student.college,
        mobile: student.mobile,
        email: student.email,
      });
    }
    openModal("#studentModal");
  }

  function openCourseModal(course) {
    const form = $("#courseForm");
    form.reset();
    $("#courseModalTitle").textContent = course ? "编辑课程" : "新增课程";
    form.course_code.disabled = Boolean(course);
    if (course) {
      setFormValues(form, {
        course_id: course.course_id,
        course_code: course.course_code,
        course_name: course.course_name,
        teacher_id: course.teacher_id,
        teacher_name: course.teacher_name,
        credit: course.credit,
        capacity: course.capacity,
      });
    }
    openModal("#courseModal");
  }

  function openApiModal() {
    const form = $("#apiBaseForm");
    form.api_base.value = state.apiBase;
    openModal("#apiModal");
  }

  function openModal(selector) {
    closeModals();
    $(selector).classList.add("is-open");
  }

  function closeModals() {
    $$(".modal").forEach((modal) => modal.classList.remove("is-open"));
  }

  function fillGradeUpdate(gradeId, score, remark) {
    renderGradeUpdateOptions(gradeId);
    setFormValues($("#gradeUpdateForm"), {
      grade_id: gradeId,
      score,
      remark,
    });
    showToast("已填入成绩修改表单");
  }

  function fillGradeUpdateFromSelection(event) {
    const gradeId = event.currentTarget.value;
    const item = state.references.grades.find((entry) => String(entry.grade?.grade_id) === String(gradeId));
    if (!item) return;
    const grade = item.grade || {};
    setFormValues($("#gradeUpdateForm"), {
      score: grade.score,
      remark: grade.remark || "",
    });
  }

  async function request(path, options = {}) {
    const url = `${state.apiBase}${path}`;
    const fetchOptions = {
      method: options.method || "GET",
      headers: {
        Accept: "application/json",
      },
    };

    if (options.body !== undefined) {
      fetchOptions.headers["Content-Type"] = "application/json";
      fetchOptions.body = JSON.stringify(options.body);
    }

    const response = await fetch(url, fetchOptions);
    const text = await response.text();
    const payload = parsePayload(text);

    if (!response.ok) {
      throw new Error(extractMessage(payload) || `HTTP ${response.status}`);
    }

    const data = unwrapPayload(payload);
    const businessCode = Number(payload && payload.code);
    if (payload && Number.isFinite(businessCode) && businessCode !== 0) {
      throw new Error(extractMessage(payload) || "业务处理失败");
    }
    return data;
  }

  function parsePayload(text) {
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch (error) {
      return { message: text };
    }
  }

  function unwrapPayload(payload) {
    if (payload && Object.prototype.hasOwnProperty.call(payload, "data")) {
      return payload.data || {};
    }
    return payload || {};
  }

  function extractMessage(payload) {
    if (!payload) return "";
    if (typeof payload === "string") return payload;
    return payload.message || payload.error || payload.detail || payload.msg || "";
  }

  function setHealth(ok, message) {
    $("#healthLabel").textContent = ok ? "服务在线" : "连接异常";
    $("#healthMeta").textContent = ok ? "REST API 已可用" : (message || "请检查 API 地址");
  }

  function renderApiBase() {
    $("#apiBaseLabel").textContent = state.apiBase || "同源服务";
  }

  function formValues(form) {
    return Object.fromEntries(new FormData(form).entries());
  }

  function setFormValues(form, values) {
    Object.entries(values).forEach(([key, value]) => {
      if (form.elements[key]) {
        form.elements[key].value = value ?? "";
      }
    });
  }

  function toQuery(params) {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== "" && value !== null && value !== undefined && value !== 0) {
        query.set(key, value);
      }
    });
    return query.toString();
  }

  function toNumber(value) {
    if (value === "" || value === null || value === undefined) return 0;
    return Number(value);
  }

  function normalizeApiBase(value) {
    return String(value || "").trim().replace(/\/+$/, "");
  }

  function genderLabel(value) {
    return ({ 1: "男", 2: "女", 0: "未知" })[Number(value)] || "未知";
  }

  function statusBadge(value, type) {
    const active = Number(value) === 1;
    const text = active ? "启用" : (type === "course" ? "停用" : "禁用");
    return `<span class="badge ${active ? "ok" : "bad"}">${text}</span>`;
  }

  function gradeBadge(level) {
    const tone = level === "A" || level === "B" ? "ok" : (level === "F" ? "bad" : "warn");
    return `<span class="badge ${tone}">${escapeHtml(level || "-")}</span>`;
  }

  function capacityLabel(course) {
    const selected = Number(course.selected_count || 0);
    const capacity = Number(course.capacity || 0);
    if (!capacity) return "未设置容量";
    if (selected >= capacity) return "已满";
    return `剩余 ${capacity - selected} 人`;
  }

  function formatTime(value) {
    const timestamp = Number(value || 0);
    if (!timestamp) return "-";
    return new Date(timestamp * 1000).toLocaleString("zh-CN", { hour12: false });
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/`/g, "&#96;");
  }

  function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type === "error" ? "error" : ""}`;
    toast.textContent = message;
    $("#toastHost").appendChild(toast);
    window.setTimeout(() => toast.remove(), 3600);
  }
})();
