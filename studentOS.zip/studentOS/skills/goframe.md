# GoFrame 工程配置规范与示例

1. 适用范围

- GoFrame HTTP/API 层配置，例如 `server`、`logger`、`viewer`。
- GoFrame ORM 配置，例如 `database.default`、`database.user`。
- Redis 配置，例如 `redis.default`、`redis.cache`。
- 项目自定义业务配置，例如 `app`、`jwt`、`upload`、`cors`、`graceful`。
- gf gen dao 根据数据库表结构，自动生成 DAO (Data Access Object)、Entity (实体类) 和 DO (Domain Object)。
- gf gen service 根据项目的 logic 层代码，自动生成 service 层接口定义。
- gf gen ctrl 根据 api 层的定义，生成对应的 controller 实现代码模版。

本文只定义配置文件结构和读取方式，不替代 `skills/rules.md` 中关于 Controller、Logic、DAO、Kitex 和测试的工程规则。

## 2. 配置加载约定

GoFrame 的配置组件支持 `toml/yaml/yml/json/ini/xml/properties` 等格式，项目内统一推荐使用 `yaml`。

常用读取方式：

- `g.Cfg()`：读取默认配置单例，默认检索 `config.yaml` 等默认配置文件。
- `g.Cfg("redis")`：读取名为 `redis` 的配置单例，优先检索 `redis.yaml` 等同名配置文件，适合业务自定义配置或手动装配组件配置。
- 如果同名单例配置文件不存在，GoFrame 会回退到默认配置文件，例如 `config.yaml`。
- 配置项支持用英文点号访问层级，例如 `app.name`、`redis.cache.db`。
- `g.Server()`、`g.DB()`、`g.Redis()`、`g.Log()` 等框架单例默认从 `g.Cfg()` 对应的默认配置对象读取 `server`、`database`、`redis`、`logger` 节点。

建议将配置放在：

```text
manifest/
  config/
    config.yaml      # server、logger、database、redis、业务配置
```

当配置增长后，可以拆分业务配置或手动装配的组件配置：

```text
manifest/
  config/
    config.yaml      # 框架自动读取的主配置
    redis.yaml       # 仅供 g.Cfg("redis") 手动读取或启动阶段装配
    jwt.yaml         # 业务自定义配置
```

原则：如果没有启动阶段的显式装配代码，不要只把 `database` 或 `redis` 放到独立文件里，否则 `g.DB()`、`g.Redis()` 可能找不到配置。单文件适合小项目和本地开发；多文件适合服务边界清晰、配置项较多或需要按组件独立维护的项目。

## 3. 推荐配置结构

下面的 `config.yaml`、`database`、`redis` 示例默认组成同一个 `manifest/config/config.yaml`。为了阅读清晰，数据库和 Redis 单独拆成小节展示。

### 3.1 config.yaml

```yaml
# 项目基础配置。业务代码通过 g.Cfg().Get/MustGet 读取。
app:
  name: "student-management"
  version: "1.0.0"
  env: "dev"
  domain: "http://127.0.0.1:8000"
  timezone: "Asia/Shanghai"

# HTTP 服务配置。g.Server() 会自动读取 server 配置项。
server:
  address: ":8000"
  serverAgent: "Student Management API"
  dumpRouterMap: true

  openapiPath: "/api.json"
  swaggerPath: "/swagger"

  readTimeout: "60s"
  writeTimeout: "60s"
  idleTimeout: "60s"
  maxHeaderBytes: "20KB"
  clientMaxBodySize: "50MB"
  keepAlive: true

  accessLogEnabled: true
  errorLogEnabled: true
  pprofEnabled: false

  sessionIdName: "sid"
  sessionMaxAge: "24h"
  sessionPath: "manifest/runtime/session"
  cookieMaxAge: "365d"
  cookiePath: "/"

  logger:
    path: "manifest/runtime/log/server"
    file: "{Y-m-d}.log"
    level: "all"
    stdout: true
    rotateSize: "100M"
    rotateBackupLimit: 7
    rotateBackupExpire: "30d"
    rotateBackupCompress: 9
    rotateCheckInterval: "24h"

# 全局日志配置。业务日志使用 g.Log().Ctx(ctx) 输出。
logger:
  path: "manifest/runtime/log/app"
  file: "{Y-m-d}.log"
  level: "all"
  stdout: true
  flags: 44

# 视图模板配置。仅在项目使用模板引擎时保留。
viewer:
  paths: ["template"]
  defaultFile: "index.html"
  delimiters: ["{{", "}}"]

# 业务自定义配置。
jwt:
  secret: "replace-with-env-or-secret-manager"
  expire: "7d"
  issuer: "student-management"

upload:
  path: "resource/upload"
  urlPrefix: "/upload"

cors:
  allowDomain: "*"
  allowMethods: "GET,POST,PUT,DELETE,OPTIONS"
  allowHeaders: "*"
  exposeHeaders: "Content-Length,Content-Type"

cache:
  model: "redis"

graceful:
  timeout: "20s"
```

### 3.2 database 配置

以下片段默认放在 `config.yaml` 的顶级 `database` 节点下，供 `g.DB()` 自动读取。

```yaml
database:
  default:
    link: "mysql:root:123456@tcp(127.0.0.1:3306)/student_management?charset=utf8mb4&parseTime=True&loc=Local"
    debug: true
    prefix: ""
    charset: "utf8mb4"
    maxIdle: 10
    maxOpen: 100
    maxLifetime: "1h"
    maxIdleConnTime: "30m"
    queryTimeout: "30s"
    execTimeout: "30s"
    tranTimeout: "60s"

  user:
    link: "mysql:root:123456@tcp(127.0.0.1:3306)/user_center?charset=utf8mb4&parseTime=True&loc=Local"
    debug: true
    prefix: "uc_"
    maxIdle: 5
    maxOpen: 50
    maxLifetime: "1h"
    maxIdleConnTime: "30m"
```

说明：

- 优先使用 `link` 简化连接配置，便于统一复制和部署。
- `debug` 只建议在开发环境打开，生产环境应关闭。
- `maxIdleConnTime` 是 GoFrame 2.10 新增配置，可用于控制空闲连接存活时间。
- 多数据源使用 `g.DB("分组名")` 读取，例如 `g.DB("user")`。
- 如果要放入独立 `database.yaml`，需要在启动阶段读取并显式装配到 `gdb`，或者保留一份等价配置在 `config.yaml`。

### 3.3 redis 配置

以下片段默认放在 `config.yaml` 的顶级 `redis` 节点下，供 `g.Redis()` 自动读取。

```yaml
redis:
  default:
    address: "127.0.0.1:6379"
    db: 0
    pass: ""
    idleTimeout: "60s"
    maxConnLifetime: "30m"

  cache:
    address: "127.0.0.1:6379"
    db: 1
    pass: ""
    idleTimeout: "60s"
    maxConnLifetime: "30m"
```

说明：

- 默认 Redis 使用 `g.Redis()` 读取，对应 `redis.default`。
- 其他分组使用 `g.Redis("cache")` 读取，对应 `redis.cache`。
- 密码、地址、DB 编号在生产环境建议通过部署配置或密钥管理系统注入。
- 如果要放入独立 `redis.yaml`，需要在启动阶段读取并显式装配到 `gredis`，或者保留一份等价配置在 `config.yaml`。

## 4. 代码读取示例

```go
package main

import (
    "fmt"

    _ "github.com/gogf/gf/contrib/drivers/mysql/v2"
    _ "github.com/gogf/gf/contrib/nosql/redis/v2"
    "github.com/gogf/gf/v2/frame/g"
    "github.com/gogf/gf/v2/os/gctx"
)

func main() {
    ctx := gctx.New()

    appName := g.Cfg().MustGet(ctx, "app.name").String()
    redisDB := g.Cfg().MustGet(ctx, "redis.cache.db").Int()

    db := g.DB()              // database.default
    userDB := g.DB("user")    // database.user
    redis := g.Redis()        // redis.default
    cache := g.Redis("cache") // redis.cache，默认从 config.yaml 的 redis.cache 读取

    fmt.Println(appName, redisDB)
    _, _, _, _ = db, userDB, redis, cache
}
```

业务代码读取自定义配置时，优先集中封装配置结构，避免到处散落字符串 key。例如：

```go
type JWTConfig struct {
    Secret string `json:"secret"`
    Expire string `json:"expire"`
    Issuer string `json:"issuer"`
}
```

## 5. 配置归属边界

| 配置项                                                          | 归属              | 读取方式                                    |
| --------------------------------------------------------------- | ----------------- | ------------------------------------------- |
| `server`                                                      | GoFrame HTTP 服务 | `g.Server()` 自动读取                     |
| `logger`                                                      | GoFrame 日志组件  | `g.Log()` 自动读取                        |
| `database`                                                    | GoFrame ORM       | `g.DB()`、`g.DB("name")` 自动读取       |
| `redis`                                                       | GoFrame Redis     | `g.Redis()`、`g.Redis("name")` 自动读取 |
| `viewer`                                                      | GoFrame 模板引擎  | 模板组件自动读取                            |
| `app`、`jwt`、`upload`、`cors`、`cache`、`graceful` | 业务自定义配置    | `g.Cfg().Get/MustGet` 或配置封装读取      |

原则：

- 框架约定配置放在框架识别的顶级 key 下。
- 业务配置不要混进 `server`、`database`、`redis` 等框架 key。
- 业务配置应有明确结构体承载，减少硬编码字符串。

## 6. 环境建议

### 6.1 开发环境

- `logger.stdout` 保持 `true`，便于直接看日志。
- `server.dumpRouterMap` 可以保持 `true`，方便检查路由。
- `database.*.debug` 可以保持 `true`，方便排查 SQL。
- `server.pprofEnabled` 只在确实需要性能分析时打开。

### 6.2 测试环境

- 使用独立数据库和 Redis DB，避免污染开发或生产数据。
- 固定 `app.env: "test"`，便于代码判断环境。
- 日志建议同时输出到 stdout 和文件，方便 CI 收集。
- 数据库连接池参数应接近生产，但账号权限可以更收敛。

### 6.3 生产环境

- 关闭 `database.*.debug`、`server.dumpRouterMap`、`server.pprofEnabled`。
- 不在仓库中提交真实数据库密码、Redis 密码、JWT 密钥。
- `cors.allowDomain` 不使用 `"*"`，改为明确域名白名单。
- 日志必须配置滚动策略，避免磁盘被打满。
- 数据库连接池、超时时间和上传大小必须按真实容量评估。

## 7. 安全与维护检查清单

提交配置变更前检查：

- 是否误提交了真实密码、Token、JWT 密钥。
- 是否关闭了生产环境调试项。
- 是否为新增数据源配置了连接池和超时。
- 是否为新增 Redis 分组明确了用途和 DB 编号。
- 是否确认 `clientMaxBodySize` 与真实上传需求一致。
- 是否保留了日志滚动配置。
- 是否让业务代码通过统一配置结构读取，而不是散落 key。
