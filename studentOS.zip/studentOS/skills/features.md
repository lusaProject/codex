# 学生管理系统特性设计文档

## 1. 背景说明

本系统用于学校内部学生信息、课程信息、选课信息和成绩信息管理。系统面向管理员、教师和学生三类角色，提供学生档案维护、课程维护、选课管理、成绩录入与查询等能力。

系统采用 GoFrame v2 作为 HTTP API/BFF 层，采用 CloudWeGo-Kitex 拆分内部 RPC 服务。设计必须遵守以下核心规约：

- Controller 保持极薄，只做请求接收、参数转换和 service 调用。
- 业务逻辑放入 `internal/logic/`。
- 跨模块调用走 `internal/service/` 接口。
- 跨服务调用走 Kitex RPC。
- Kitex 采用 IDL First，禁止手动修改 `kitex_gen/`。
- 数据库写入使用 `do` 模型，不使用 `map` 写库。
- DAO 调用使用 `dao.Xxx.Ctx(ctx)`。
- 错误使用 `gerror/gcode`。
- 日志必须使用 `g.Log().Ctx(ctx)`。
- 每个业务 Go 文件必须有同目录 `_test.go`。
- 每个功能必须有测试清单和覆盖率目标。

---

## 2. 设计目标

### 2.1 功能目标

学生管理系统需要支持：

1. 学生档案管理

   - 新增学生
   - 查询学生详情
   - 分页查询学生列表
   - 修改学生基础信息
   - 启用/禁用学生状态
2. 课程管理

   - 新增课程
   - 查询课程详情
   - 分页查询课程列表
   - 修改课程信息
   - 启用/停用课程
3. 选课管理

   - 学生选课
   - 学生退课
   - 查询学生已选课程
   - 查询课程选课名单
4. 成绩管理

   - 教师录入成绩
   - 教师修改成绩
   - 学生查询个人成绩
   - 管理员查询成绩统计

### 2.2 架构目标

系统内部至少拆分为 2 个 Kitex 服务：

| 服务名               | 服务职责                             |
| -------------------- | ------------------------------------ |
| `student-service`  | 管理学生档案、学生状态、学生基础信息 |
| `academic-service` | 管理课程、选课、成绩                 |

GoFrame HTTP 层不直接访问数据库，也不直接写业务逻辑，只通过 service/logic 和 RPC Client 调用后端服务。

---

## 3. 非目标范围

本期暂不实现：

- 登录注册与统一认证中心。
- 复杂排课算法。
- 教务系统外部同步。
- 消息队列异步通知。
- 分布式事务强一致性。
- 财务缴费、宿舍管理、奖惩管理等扩展模块。

后续可拆分为：

- `auth-service`
- `notification-service`
- `exam-service`
- `dormitory-service`

---

## 4. 总体架构设计

### 4.1 架构链路

```text
用户请求
  -> GoFrame HTTP API
  -> api/<module>/v1
  -> internal/controller/<module>
  -> internal/service/<module>
  -> internal/logic/<module>
  -> internal/rpc/<service> Client Wrapper
  -> Kitex RPC Service
  -> internal/handler/<service>
  -> internal/service/<module>
  -> internal/logic/<module>
  -> dao.Ctx(ctx)
  -> database
```

### 4.2 服务边界

```text
student-management-api
  ├── GoFrame HTTP/BFF 层
  ├── 调用 student-service
  └── 调用 academic-service

student-service
  ├── 学生档案
  ├── 学生状态
  └── 学生基础校验

academic-service
  ├── 课程信息
  ├── 选课记录
  ├── 成绩记录
  └── 需要通过 RPC 查询 student-service 校验学生是否存在
```

---

## 5. Kitex 服务拆分设计

### 5.1 StudentService

#### 5.1.1 服务职责

`student-service` 负责学生档案相关能力。

包括：

- 创建学生档案
- 查询学生详情
- 分页查询学生
- 修改学生信息
- 修改学生状态
- 校验学生是否存在且状态正常

#### 5.1.2 IDL 文件

路径：

```text
idl/student.thrift
```

#### 5.1.3 RPC 方法设计

| 方法名                  | 说明                   |
| ----------------------- | ---------------------- |
| `CreateStudent`       | 创建学生               |
| `GetStudent`          | 查询学生详情           |
| `ListStudents`        | 分页查询学生           |
| `UpdateStudent`       | 修改学生基础信息       |
| `UpdateStudentStatus` | 修改学生状态           |
| `CheckStudentActive`  | 校验学生是否存在且启用 |

#### 5.1.4 核心字段

| 字段           | 类型   | 说明                     |
| -------------- | ------ | ------------------------ |
| `student_id` | int64  | 学生 ID                  |
| `student_no` | string | 学号，全局唯一           |
| `name`       | string | 学生姓名                 |
| `gender`     | int32  | 性别：1 男，2 女，0 未知 |
| `class_name` | string | 班级                     |
| `major`      | string | 专业                     |
| `college`    | string | 学院                     |
| `mobile`     | string | 手机号                   |
| `email`      | string | 邮箱                     |
| `status`     | int32  | 状态：1 启用，2 禁用     |
| `created_at` | int64  | 创建时间                 |
| `updated_at` | int64  | 更新时间                 |

#### 5.1.5 服务边界约束

`student-service` 只管理学生基础信息，不直接处理课程、选课和成绩数据。

`academic-service` 如需判断学生是否存在，必须通过 `StudentService.CheckStudentActive` 调用，不允许直接访问学生库表。

---

### 5.2 AcademicService

#### 5.2.1 服务职责

`academic-service` 负责课程、选课和成绩管理。

包括：

- 创建课程
- 查询课程
- 学生选课
- 学生退课
- 查询学生课表
- 教师录入成绩
- 查询学生成绩

#### 5.2.2 IDL 文件

路径：

```text
idl/academic.thrift
```

#### 5.2.3 RPC 方法设计

| 方法名                 | 说明             |
| ---------------------- | ---------------- |
| `CreateCourse`       | 创建课程         |
| `GetCourse`          | 查询课程详情     |
| `ListCourses`        | 分页查询课程     |
| `UpdateCourse`       | 修改课程信息     |
| `UpdateCourseStatus` | 修改课程状态     |
| `EnrollCourse`       | 学生选课         |
| `DropCourse`         | 学生退课         |
| `ListStudentCourses` | 查询学生已选课程 |
| `ListCourseStudents` | 查询课程学生名单 |
| `SubmitGrade`        | 录入或修改成绩   |
| `ListStudentGrades`  | 查询学生成绩     |

#### 5.2.4 核心字段

课程字段：

| 字段               | 类型   | 说明               |
| ------------------ | ------ | ------------------ |
| `course_id`      | int64  | 课程 ID            |
| `course_code`    | string | 课程编号，全局唯一 |
| `course_name`    | string | 课程名称           |
| `teacher_id`     | int64  | 教师 ID            |
| `teacher_name`   | string | 教师姓名           |
| `credit`         | double | 学分               |
| `capacity`       | int32  | 最大选课人数       |
| `selected_count` | int32  | 已选人数           |
| `status`         | int32  | 1 启用，2 停用     |

选课字段：

| 字段              | 类型  | 说明             |
| ----------------- | ----- | ---------------- |
| `enrollment_id` | int64 | 选课 ID          |
| `student_id`    | int64 | 学生 ID          |
| `course_id`     | int64 | 课程 ID          |
| `status`        | int32 | 1 已选，2 已退课 |
| `created_at`    | int64 | 选课时间         |

成绩字段：

| 字段            | 类型   | 说明               |
| --------------- | ------ | ------------------ |
| `grade_id`    | int64  | 成绩 ID            |
| `student_id`  | int64  | 学生 ID            |
| `course_id`   | int64  | 课程 ID            |
| `score`       | double | 分数               |
| `grade_level` | string | 等级，如 A/B/C/D/F |
| `remark`      | string | 备注               |

#### 5.2.5 服务边界约束

`academic-service` 不维护学生基础信息。

在执行选课、成绩录入、成绩查询前，如果需要确认学生有效性，应通过 `student-service` 的 `CheckStudentActive` RPC 接口校验。

---

## 6. HTTP API 设计

HTTP API 由 GoFrame 提供，对外暴露 REST 风格接口。

### 6.1 学生接口

| HTTP 方法 | 路径                             | 说明         | 调用链路                                      |
| --------- | -------------------------------- | ------------ | --------------------------------------------- |
| POST      | `/api/v1/students`             | 新增学生     | controller → service → logic → student RPC |
| GET       | `/api/v1/students/{id}`        | 查询学生详情 | controller → service → logic → student RPC |
| GET       | `/api/v1/students`             | 分页查询学生 | controller → service → logic → student RPC |
| PUT       | `/api/v1/students/{id}`        | 修改学生信息 | controller → service → logic → student RPC |
| PATCH     | `/api/v1/students/{id}/status` | 修改学生状态 | controller → service → logic → student RPC |

### 6.2 课程接口

| HTTP 方法 | 路径                            | 说明         | 调用链路                                       |
| --------- | ------------------------------- | ------------ | ---------------------------------------------- |
| POST      | `/api/v1/courses`             | 新增课程     | controller → service → logic → academic RPC |
| GET       | `/api/v1/courses/{id}`        | 查询课程详情 | controller → service → logic → academic RPC |
| GET       | `/api/v1/courses`             | 分页查询课程 | controller → service → logic → academic RPC |
| PUT       | `/api/v1/courses/{id}`        | 修改课程信息 | controller → service → logic → academic RPC |
| PATCH     | `/api/v1/courses/{id}/status` | 修改课程状态 | controller → service → logic → academic RPC |

### 6.3 选课接口

| HTTP 方法 | 路径                              | 说明             | 调用链路                                       |
| --------- | --------------------------------- | ---------------- | ---------------------------------------------- |
| POST      | `/api/v1/enrollments`           | 学生选课         | controller → service → logic → academic RPC |
| DELETE    | `/api/v1/enrollments/{id}`      | 学生退课         | controller → service → logic → academic RPC |
| GET       | `/api/v1/students/{id}/courses` | 查询学生已选课程 | controller → service → logic → academic RPC |
| GET       | `/api/v1/courses/{id}/students` | 查询课程学生名单 | controller → service → logic → academic RPC |

### 6.4 成绩接口

| HTTP 方法 | 路径                             | 说明         | 调用链路                                       |
| --------- | -------------------------------- | ------------ | ---------------------------------------------- |
| POST      | `/api/v1/grades`               | 录入成绩     | controller → service → logic → academic RPC |
| PUT       | `/api/v1/grades/{id}`          | 修改成绩     | controller → service → logic → academic RPC |
| GET       | `/api/v1/students/{id}/grades` | 查询学生成绩 | controller → service → logic → academic RPC |

---

## 7. 数据库模型设计

### 7.1 `students` 表

| 字段           | 类型         | 约束               | 说明       |
| -------------- | ------------ | ------------------ | ---------- |
| `id`         | bigint       | PK                 | 学生 ID    |
| `student_no` | varchar(32)  | unique not null    | 学号       |
| `name`       | varchar(64)  | not null           | 姓名       |
| `gender`     | tinyint      | not null default 0 | 性别       |
| `class_name` | varchar(64)  | not null           | 班级       |
| `major`      | varchar(64)  | not null           | 专业       |
| `college`    | varchar(64)  | not null           | 学院       |
| `mobile`     | varchar(32)  | nullable           | 手机号     |
| `email`      | varchar(128) | nullable           | 邮箱       |
| `status`     | tinyint      | not null default 1 | 状态       |
| `created_at` | datetime     | not null           | 创建时间   |
| `updated_at` | datetime     | not null           | 更新时间   |
| `deleted_at` | datetime     | nullable           | 软删除时间 |

索引：

```text
unique idx_student_no(student_no)
idx_student_name(name)
idx_student_class(class_name)
idx_student_status(status)
```

### 7.2 `courses` 表

| 字段               | 类型         | 约束               | 说明       |
| ------------------ | ------------ | ------------------ | ---------- |
| `id`             | bigint       | PK                 | 课程 ID    |
| `course_code`    | varchar(32)  | unique not null    | 课程编号   |
| `course_name`    | varchar(128) | not null           | 课程名称   |
| `teacher_id`     | bigint       | not null           | 教师 ID    |
| `teacher_name`   | varchar(64)  | not null           | 教师姓名   |
| `credit`         | decimal(4,1) | not null           | 学分       |
| `capacity`       | int          | not null           | 容量       |
| `selected_count` | int          | not null default 0 | 已选人数   |
| `status`         | tinyint      | not null default 1 | 状态       |
| `created_at`     | datetime     | not null           | 创建时间   |
| `updated_at`     | datetime     | not null           | 更新时间   |
| `deleted_at`     | datetime     | nullable           | 软删除时间 |

索引：

```text
unique idx_course_code(course_code)
idx_course_teacher(teacher_id)
idx_course_status(status)
```

### 7.3 `course_enrollments` 表

| 字段           | 类型     | 约束               | 说明             |
| -------------- | -------- | ------------------ | ---------------- |
| `id`         | bigint   | PK                 | 选课 ID          |
| `student_id` | bigint   | not null           | 学生 ID          |
| `course_id`  | bigint   | not null           | 课程 ID          |
| `status`     | tinyint  | not null default 1 | 1 已选，2 已退课 |
| `created_at` | datetime | not null           | 创建时间         |
| `updated_at` | datetime | not null           | 更新时间         |

索引：

```text
unique idx_student_course(student_id, course_id)
idx_course_id(course_id)
idx_student_id(student_id)
```

### 7.4 `grades` 表

| 字段            | 类型         | 约束     | 说明     |
| --------------- | ------------ | -------- | -------- |
| `id`          | bigint       | PK       | 成绩 ID  |
| `student_id`  | bigint       | not null | 学生 ID  |
| `course_id`   | bigint       | not null | 课程 ID  |
| `score`       | decimal(5,2) | not null | 分数     |
| `grade_level` | varchar(8)   | not null | 等级     |
| `remark`      | varchar(255) | nullable | 备注     |
| `created_at`  | datetime     | not null | 创建时间 |
| `updated_at`  | datetime     | not null | 更新时间 |

索引：

```text
unique idx_student_course_grade(student_id, course_id)
idx_grade_student(student_id)
idx_grade_course(course_id)
```

---

## 8. 核心业务流程

### 8.1 新增学生流程

```text
HTTP POST /api/v1/students
  -> controller 校验基础参数
  -> service.Student().Create(ctx, input)
  -> logic 组装 RPC 请求
  -> internal/rpc/student 调用 StudentService.CreateStudent
  -> student-service handler 转换参数
  -> student logic 校验 student_no 是否重复
  -> dao.Students.Ctx(ctx).Data(do.Students{...}).Insert()
  -> 返回 student_id
```

业务规则：

- 学号必填且唯一。
- 姓名、班级、专业、学院必填。
- 手机号和邮箱格式由 API `v` 标签做基础校验。
- 学生默认状态为启用。
- 数据库写入必须使用 `do.Students`。
- 业务错误使用 `gerror.NewCode`。
- DAO 异常使用 `gerror.WrapCode` 包装。

### 8.2 学生选课流程

```text
HTTP POST /api/v1/enrollments
  -> controller 参数转换
  -> service.Enrollment().Enroll(ctx, input)
  -> logic 调用 academic RPC
  -> academic-service 校验课程存在且启用
  -> academic-service 通过 student RPC 校验学生存在且启用
  -> academic-service 开启事务
      -> 检查是否重复选课
      -> 检查课程容量是否已满
      -> 写入 course_enrollments
      -> 更新 courses.selected_count + 1
  -> 提交事务
  -> 返回 enrollment_id
```

业务规则：

- 禁用学生不能选课。
- 停用课程不能选。
- 已满课程不能选。
- 同一学生不能重复选择同一课程。
- 写入选课记录和更新课程人数必须在同一个事务中。
- 跨服务调用失败不得继续提交本地事务。

### 8.3 成绩录入流程

```text
HTTP POST /api/v1/grades
  -> controller 参数转换
  -> service.Grade().Submit(ctx, input)
  -> logic 调用 academic RPC
  -> academic-service 校验学生是否已选该课程
  -> 校验分数范围 0 到 100
  -> 根据分数计算等级
  -> 插入或更新 grades
  -> 返回 grade_id
```

业务规则：

- 分数范围必须为 0 到 100。
- 未选课学生不能录入成绩。
- 同一学生同一课程只能有一条成绩记录。
- 修改成绩需要记录更新时间。
- 后续如果增加审计表，成绩修改和审计写入必须使用事务。

---

## 9. 异常流程设计

| 场景           | 错误类型 | 处理方式                              |
| -------------- | -------- | ------------------------------------- |
| 参数缺失       | 参数错误 | API `v` 标签拦截，返回参数错误      |
| 学号重复       | 业务错误 | 返回 `CodeBusinessValidationFailed` |
| 学生不存在     | 业务错误 | 返回学生不存在                        |
| 学生已禁用     | 业务错误 | 返回学生状态不可用                    |
| 课程不存在     | 业务错误 | 返回课程不存在                        |
| 课程已停用     | 业务错误 | 返回课程不可选                        |
| 课程容量已满   | 业务错误 | 返回课程容量已满                      |
| 重复选课       | 业务错误 | 返回不能重复选课                      |
| 未选课录入成绩 | 业务错误 | 返回未选课不能录入成绩                |
| RPC 超时       | 系统错误 | 记录 `ctx` 日志，返回服务暂不可用   |
| DAO 写入失败   | 系统错误 | `gerror.WrapCode` 包装后返回        |
| 事务提交失败   | 系统错误 | 回滚事务，记录错误日志                |

---

## 10. 权限设计

本期按角色进行权限划分。

| 角色   | 权限                                                 |
| ------ | ---------------------------------------------------- |
| 管理员 | 学生管理、课程管理、选课管理、成绩查询               |
| 教师   | 查询学生、查询课程、录入和修改自己课程的成绩         |
| 学生   | 查询个人信息、查询可选课程、选课、退课、查询个人成绩 |

权限判断建议放在 HTTP BFF 层或统一鉴权中间件中。

业务 logic 中仍需做关键状态校验，例如：

- 学生是否启用。
- 课程是否启用。
- 教师是否有该课程成绩录入权限。
- 学生是否只能查询自己的成绩。

---

## 11. 幂等与并发设计

### 11.1 幂等设计

| 功能     | 幂等方式                                       |
| -------- | ---------------------------------------------- |
| 新增学生 | 通过 `student_no` 唯一索引防重复             |
| 新增课程 | 通过 `course_code` 唯一索引防重复            |
| 学生选课 | 通过 `student_id + course_id` 唯一索引防重复 |
| 成绩录入 | 通过 `student_id + course_id` 唯一索引防重复 |

### 11.2 并发控制

选课场景需要重点处理并发：

- 选课写入和课程人数更新必须使用事务。
- 更新课程人数时必须判断 `selected_count < capacity`。
- 建议使用条件更新：

```text
UPDATE courses
SET selected_count = selected_count + 1
WHERE id = ? AND selected_count < capacity AND status = 1
```

如果影响行数为 0，则表示课程已满或课程不可用。

## 13. IDL 设计摘要

### 13.1 `idl/student.thrift`

```thrift
namespace go student

struct CreateStudentReq {
  1: string student_no
  2: string name
  3: i32 gender
  4: string class_name
  5: string major
  6: string college
  7: optional string mobile
  8: optional string email
}

struct CreateStudentResp {
  1: i64 student_id
}

struct GetStudentReq {
  1: i64 student_id
}

struct StudentInfo {
  1: i64 student_id
  2: string student_no
  3: string name
  4: i32 gender
  5: string class_name
  6: string major
  7: string college
  8: optional string mobile
  9: optional string email
  10: i32 status
  11: i64 created_at
  12: i64 updated_at
}

struct GetStudentResp {
  1: StudentInfo student
}

struct CheckStudentActiveReq {
  1: i64 student_id
}

struct CheckStudentActiveResp {
  1: bool active
}

service StudentService {
  CreateStudentResp CreateStudent(1: CreateStudentReq req)
  GetStudentResp GetStudent(1: GetStudentReq req)
  CheckStudentActiveResp CheckStudentActive(1: CheckStudentActiveReq req)
}
```

### 13.2 `idl/academic.thrift`

```thrift
namespace go academic

struct CreateCourseReq {
  1: string course_code
  2: string course_name
  3: i64 teacher_id
  4: string teacher_name
  5: double credit
  6: i32 capacity
}

struct CreateCourseResp {
  1: i64 course_id
}

struct EnrollCourseReq {
  1: i64 student_id
  2: i64 course_id
}

struct EnrollCourseResp {
  1: i64 enrollment_id
}

struct SubmitGradeReq {
  1: i64 student_id
  2: i64 course_id
  3: double score
  4: optional string remark
}

struct SubmitGradeResp {
  1: i64 grade_id
  2: string grade_level
}

service AcademicService {
  CreateCourseResp CreateCourse(1: CreateCourseReq req)
  EnrollCourseResp EnrollCourse(1: EnrollCourseReq req)
  SubmitGradeResp SubmitGrade(1: SubmitGradeReq req)
}
```

正式实现时可继续补充：

- `ListCourses`
- `GetCourse`
- `DropCourse`
- `ListStudentCourses`
- `ListCourseStudents`
- `ListStudentGrades`

---

## 14. 生成命令要求

涉及数据库表结构后，需要运行：

```bash
gf gen dao
```

涉及新增或修改 service 方法后，需要运行：

```bash
gf gen service
```

涉及新增或修改 Kitex IDL 后，需要运行：

```bash
kitex -module your/module/path -service student idl/student.thrift
kitex -module your/module/path -service academic idl/academic.thrift
```

注意：

- 不允许手动修改 `kitex_gen/`。
- 不允许手动修改 `internal/dao/`。
- 不允许手动修改 `internal/model/do/`。
- 不允许手动修改 `internal/model/entity/`。
- 不允许手动修改 `internal/service/`。

## 18. 验收标准

### 18.1 功能验收

- 能新增、查询、修改、禁用学生。
- 能新增、查询、修改、停用课程。
- 能完成学生选课和退课。
- 能限制重复选课。
- 能限制课程容量。
- 能录入和查询成绩。
- 能限制未选课学生录入成绩。
- 能处理 RPC 超时、DAO 失败和事务失败。

### 18.2 架构验收

- 至少存在 `student-service` 和 `academic-service` 两个 Kitex 服务。
- 所有 RPC 接口先定义 IDL。
- `kitex_gen/` 不手动修改。
- HTTP controller 不直接访问 DAO。
- Kitex handler 不直接访问 DAO。
- RPC Client 集中放在 `internal/rpc/<service>/`。
- 跨服务访问必须走 RPC。
- 数据库写入使用 `do` 模型。
- 所有入口函数传递 `ctx context.Context`。
- 日志使用 `g.Log().Ctx(ctx)`。
- 错误使用 `gerror/gcode`。


---
