# GoFrame + Kitex Agent 规则

本规则用于约束 Agent 在本项目中生成、修改和审查 Go 代码。目标是交付符合生产标准的 GoFrame v2 + Kitex 工程代码。

## 1. 核心原则

- 遵守 GoFrame v2 分层：`api`、`controller`、`logic`、`service`、`dao`、`model` 各司其职。
- 所有入口、业务、DAO、RPC 调用必须传递 `ctx context.Context`。
- 不手动修改 `gf gen` 或 `kitex` 自动生成文件。
- 数据库写入使用 `internal/model/do`，禁止裸 `map` 写库。
- 跨模块调用走 `service.Xxx().Method(ctx, ...)`，禁止 logic 直接 import 其他 logic。
- 跨服务调用走 RPC 契约，并通过集中封装的 client。
- 错误使用 `gerror/gcode` 或项目统一错误码。
- 日志使用 `g.Log().Ctx(ctx)`，保留 Trace 上下文。
- 新增或修改业务 Go 文件时，同步补充同目录 `_test.go` 或说明已有测试如何更新。

## 2. 标准执行流程

收到新增、修改、重构、实现接口、实现 RPC、接入数据库或第三方服务等需求时：

1. 先判断任务类型、涉及规约和影响范围。
2. 确认代码应该放在哪些目录。
3. 如用户未提供设计文档，补充最小可用设计说明。
4. 实现代码时同步考虑测试、异常流程和边界条件。
5. 涉及生成文件时只提示生成命令，不直接改生成目录。
6. 如果项目可运行，执行测试并给出真实结果；不能运行时说明原因。

## 3. 分层边界

| 职责 | 目录 | 约束 |
| --- | --- | --- |
| HTTP 接口定义 | `api/` | 定义 `Req/Res`、路由、校验标签 |
| 请求转换和响应组装 | `internal/controller/` | 只调用 `service`，不写业务和 SQL |
| 业务逻辑 | `internal/logic/` | 业务归宿，可调用 dao 或其他 service |
| 服务接口 | `internal/service/` | 只由 `gf gen service` 生成 |
| 数据访问 | `internal/dao/` | 只由 `gf gen dao` 生成 |
| Entity/DO | `internal/model/entity/`、`internal/model/do/` | 只由 `gf gen dao` 生成 |
| 自定义 DTO | `internal/model/` | 放业务输入输出结构 |
| RPC 契约 | `idl/` | 先改 IDL，再生成代码 |
| RPC 生成代码 | `kitex_gen/` | 只由 `kitex` 生成 |
| RPC Handler | `internal/handler/<service>/` | 只做参数适配和 service 调用 |
| RPC Client | `internal/rpc/<service>/` 或既有 client 目录 | 集中封装 client、超时、重试、治理能力 |

## 4. GoFrame 硬规则

### Controller 保持极薄

Controller 只做三件事：接收请求、调用 `service`、返回响应。

禁止在 controller 中写 SQL、事务、复杂业务判断、多表组装、跨模块逻辑或直接调用 `dao`。

### Logic 承载业务

业务逻辑必须放在 `internal/logic/<module>/`。跨模块调用必须通过 `service` 接口：

```go
service.Order().Create(ctx, input)
```

禁止：

```go
import "project/internal/logic/order"
```

### 写库使用 DO

正确：

```go
dao.User.Ctx(ctx).Data(do.User{Username: in.Username}).Insert()
```

禁止：

```go
dao.User.Ctx(ctx).Data(g.Map{"username": in.Username}).Insert()
```

### DAO、事务、错误、日志

- DAO 默认使用 `dao.Name.Ctx(ctx)`。
- 多写操作、状态流转、余额/库存变动、跨表一致性必须使用事务。
- 业务错误使用 `gerror.NewCode`，包装底层错误使用 `gerror.WrapCode`。
- 日志必须使用 `g.Log().Ctx(ctx)`。

## 5. Kitex 硬规则

- 新增或修改 RPC 接口必须 IDL First：先改 `idl/`，再运行 `kitex`。
- 禁止手动修改 `kitex_gen/`。
- Handler 只做入参转换、调用 service/logic、出参转换和错误转换。
- Handler 禁止写 SQL、直接调 DAO、临时创建 RPC client、吞错返回假成功。
- RPC client 必须集中封装，业务代码不得到处 `NewClient`。
- RPC 链路必须继续传递原始 `ctx`，禁止替换为 `context.Background()`。
- RPC 错误要区分参数错误、业务错误、系统/RPC 错误，禁止出错后返回 `nil, nil`。

## 6. 生成命令提醒

涉及以下变更时必须提醒用户：

```bash
gf gen service   # 新增或修改 service 接口
gf gen dao       # 新增或修改表、字段、dao/entity/do
kitex ...        # 新增或修改 RPC IDL
```

只提醒命令，不手动改生成文件。

## 7. 输出要求

- Go 代码块第一行标注文件路径：`// File: path/to/file.go`。
- 修改已有代码时，只展示相关差异，用 `// ... (existing code)` 表示未变内容。
- 公有类型、变量、方法必须有中文注释。
- 不输出伪代码，除非用户明确要求。
- 每次功能实现必须说明测试清单、覆盖率命令和实际测试结果；无法运行时说明原因。
- 代码审查时先列问题，按严重程度排序，再给总结。

## 8. 违规请求处理

| 用户要求 | 正确处理 |
| --- | --- |
| 在 controller 里写 SQL | 拒绝，改为 controller 调 service，logic 调 dao |
| 手动改 `internal/dao` | 拒绝，提醒 `gf gen dao` |
| 手动改 `internal/service` | 拒绝，提醒 `gf gen service` |
| 手动改 `kitex_gen` | 拒绝，提醒改 IDL 后运行 `kitex` |
| logic 直接调用另一个 logic | 拒绝，改用 `service` 接口 |
| 用 `map` 写数据库 | 改为 `do` 模型 |
| 不传 `ctx` | 补上 `ctx` |
| 日志不带 `ctx` | 改为 `g.Log().Ctx(ctx)` |
| 直接返回 `errors.New` | 改为 `gerror.NewCode` 或 `gerror.WrapCode` |

拒绝时必须说明原因，并给出符合规范的替代方案。

## 9. 最终自检

最终回答前检查：

- 是否传递 `ctx`。
- 是否误改生成目录。
- 是否把业务写进 controller/handler。
- 是否用 DO 写库。
- 是否遗漏事务、错误码、ctx 日志。
- 是否提醒必要生成命令。
- 是否补充或说明测试。

## 10. 一句话总规则

**Controller/Handler 薄，Logic 厚；跨模块走 Service，跨服务走 RPC；写库用 DO；日志带 Context；错误用 GError；生成文件不手改；业务代码要有测试。**
