namespace go student

struct CreateStudentReq {
  1: string student_no
  2: string name
  3: i32 gender
  4: string class_name
  5: string major
  6: string college
  7: optional string mobile
  8: optional string email
}

struct CreateStudentResp {
  1: i64 student_id
}

struct GetStudentReq {
  1: i64 student_id
}

struct ListStudentsReq {
  1: i32 page
  2: i32 size
  3: optional string name
  4: optional string class_name
  5: optional i32 status
}

struct UpdateStudentReq {
  1: i64 student_id
  2: string name
  3: i32 gender
  4: string class_name
  5: string major
  6: string college
  7: optional string mobile
  8: optional string email
}

struct UpdateStudentStatusReq {
  1: i64 student_id
  2: i32 status
}

struct StudentInfo {
  1: i64 student_id
  2: string student_no
  3: string name
  4: i32 gender
  5: string class_name
  6: string major
  7: string college
  8: optional string mobile
  9: optional string email
  10: i32 status
  11: i64 created_at
  12: i64 updated_at
}

struct GetStudentResp {
  1: StudentInfo student
}

struct ListStudentsResp {
  1: list<StudentInfo> list
  2: i32 total
}

struct UpdateStudentResp {}

struct UpdateStudentStatusResp {}

struct CheckStudentActiveReq {
  1: i64 student_id
}

struct CheckStudentActiveResp {
  1: bool active
}

service StudentService {
  CreateStudentResp CreateStudent(1: CreateStudentReq req)
  GetStudentResp GetStudent(1: GetStudentReq req)
  ListStudentsResp ListStudents(1: ListStudentsReq req)
  UpdateStudentResp UpdateStudent(1: UpdateStudentReq req)
  UpdateStudentStatusResp UpdateStudentStatus(1: UpdateStudentStatusReq req)
  CheckStudentActiveResp CheckStudentActive(1: CheckStudentActiveReq req)
}

