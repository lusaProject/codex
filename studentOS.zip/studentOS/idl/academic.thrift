namespace go academic

struct CourseInfo {
  1: i64 course_id
  2: string course_code
  3: string course_name
  4: i64 teacher_id
  5: string teacher_name
  6: double credit
  7: i32 capacity
  8: i32 selected_count
  9: i32 status
  10: i64 created_at
  11: i64 updated_at
}

struct CreateCourseReq {
  1: string course_code
  2: string course_name
  3: i64 teacher_id
  4: string teacher_name
  5: double credit
  6: i32 capacity
}

struct CreateCourseResp {
  1: i64 course_id
}

struct GetCourseReq {
  1: i64 course_id
}

struct GetCourseResp {
  1: CourseInfo course
}

struct ListCoursesReq {
  1: i32 page
  2: i32 size
  3: optional string course_name
  4: optional i64 teacher_id
  5: optional i32 status
}

struct ListCoursesResp {
  1: list<CourseInfo> list
  2: i32 total
}

struct UpdateCourseReq {
  1: i64 course_id
  2: string course_name
  3: i64 teacher_id
  4: string teacher_name
  5: double credit
  6: i32 capacity
}

struct UpdateCourseResp {}

struct UpdateCourseStatusReq {
  1: i64 course_id
  2: i32 status
}

struct UpdateCourseStatusResp {}

struct EnrollCourseReq {
  1: i64 student_id
  2: i64 course_id
}

struct EnrollCourseResp {
  1: i64 enrollment_id
}

struct DropCourseReq {
  1: i64 enrollment_id
}

struct DropCourseResp {}

struct EnrollmentCourseInfo {
  1: i64 enrollment_id
  2: CourseInfo course
  3: i64 enrolled_at
}

struct ListStudentCoursesReq {
  1: i64 student_id
}

struct ListStudentCoursesResp {
  1: list<EnrollmentCourseInfo> list
}

struct CourseStudentInfo {
  1: i64 enrollment_id
  2: i64 student_id
  3: string student_no
  4: string name
  5: string class_name
  6: i64 enrolled_at
}

struct ListCourseStudentsReq {
  1: i64 course_id
}

struct ListCourseStudentsResp {
  1: list<CourseStudentInfo> list
}

struct SubmitGradeReq {
  1: i64 student_id
  2: i64 course_id
  3: double score
  4: optional string remark
}

struct SubmitGradeResp {
  1: i64 grade_id
  2: string grade_level
}

struct UpdateGradeReq {
  1: i64 grade_id
  2: double score
  3: optional string remark
}

struct UpdateGradeResp {
  1: string grade_level
}

struct GradeInfo {
  1: i64 grade_id
  2: i64 student_id
  3: i64 course_id
  4: double score
  5: string grade_level
  6: optional string remark
  7: i64 created_at
  8: i64 updated_at
}

struct StudentGradeInfo {
  1: GradeInfo grade
  2: CourseInfo course
}

struct ListStudentGradesReq {
  1: i64 student_id
}

struct ListStudentGradesResp {
  1: list<StudentGradeInfo> list
}

service AcademicService {
  CreateCourseResp CreateCourse(1: CreateCourseReq req)
  GetCourseResp GetCourse(1: GetCourseReq req)
  ListCoursesResp ListCourses(1: ListCoursesReq req)
  UpdateCourseResp UpdateCourse(1: UpdateCourseReq req)
  UpdateCourseStatusResp UpdateCourseStatus(1: UpdateCourseStatusReq req)
  EnrollCourseResp EnrollCourse(1: EnrollCourseReq req)
  DropCourseResp DropCourse(1: DropCourseReq req)
  ListStudentCoursesResp ListStudentCourses(1: ListStudentCoursesReq req)
  ListCourseStudentsResp ListCourseStudents(1: ListCourseStudentsReq req)
  SubmitGradeResp SubmitGrade(1: SubmitGradeReq req)
  UpdateGradeResp UpdateGrade(1: UpdateGradeReq req)
  ListStudentGradesResp ListStudentGrades(1: ListStudentGradesReq req)
}

