package cmd

import (
	"context"
	"log"

	"student-management/internal/bootstrap"
	"student-management/internal/controller/course"
	"student-management/internal/controller/enrollment"
	"student-management/internal/controller/grade"
	"student-management/internal/controller/student"
	_ "student-management/internal/logic"

	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/net/ghttp"
	"github.com/gogf/gf/v2/os/gcmd"
)

var (
	Main = gcmd.Command{
		Name:  "main",
		Usage: "main",
		Brief: "start http server",
		Func: func(ctx context.Context, parser *gcmd.Parser) (err error) {
			if err := bootstrap.PrepareProductionRuntime(ctx); err != nil {
				return err
			}

			rpcServices, err := bootstrap.StartRPCServices()
			if err != nil {
				return err
			}
			rpcServices.MonitorFatal()

			s := g.Server()
			s.SetServerRoot("resource/public")
			s.BindHandler("/", func(r *ghttp.Request) {
				r.Response.RedirectTo("/html/index.html")
			})
			s.BindHandler("/h5", func(r *ghttp.Request) {
				r.Response.RedirectTo("/html/index.html")
			})
			s.Group("/", func(group *ghttp.RouterGroup) {
				group.Middleware(ghttp.MiddlewareHandlerResponse)
				group.Bind(
					student.NewV1(),
					course.NewV1(),
					enrollment.NewV1(),
					grade.NewV1(),
				)
			})
			log.Println("[startup] HTTP server starting")
			s.Run()
			return nil
		},
	}
)
