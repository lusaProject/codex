// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package internal

import (
	"context"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

// GradesDao is the data access object for the table grades.
type GradesDao struct {
	table    string             // table is the underlying table name of the DAO.
	group    string             // group is the database configuration group name of the current DAO.
	columns  GradesColumns      // columns contains all the column names of Table for convenient usage.
	handlers []gdb.ModelHandler // handlers for customized model modification.
}

// GradesColumns defines and stores column names for the table grades.
type GradesColumns struct {
	Id         string //
	StudentId  string //
	CourseId   string //
	Score      string //
	GradeLevel string //
	Remark     string //
	CreatedAt  string //
	UpdatedAt  string //
}

// gradesColumns holds the columns for the table grades.
var gradesColumns = GradesColumns{
	Id:         "id",
	StudentId:  "student_id",
	CourseId:   "course_id",
	Score:      "score",
	GradeLevel: "grade_level",
	Remark:     "remark",
	CreatedAt:  "created_at",
	UpdatedAt:  "updated_at",
}

// NewGradesDao creates and returns a new DAO object for table data access.
func NewGradesDao(handlers ...gdb.ModelHandler) *GradesDao {
	return &GradesDao{
		group:    "default",
		table:    "grades",
		columns:  gradesColumns,
		handlers: handlers,
	}
}

// DB retrieves and returns the underlying raw database management object of the current DAO.
func (dao *GradesDao) DB() gdb.DB {
	return g.DB(dao.group)
}

// Table returns the table name of the current DAO.
func (dao *GradesDao) Table() string {
	return dao.table
}

// Columns returns all column names of the current DAO.
func (dao *GradesDao) Columns() GradesColumns {
	return dao.columns
}

// Group returns the database configuration group name of the current DAO.
func (dao *GradesDao) Group() string {
	return dao.group
}

// Ctx creates and returns a Model for the current DAO. It automatically sets the context for the current operation.
func (dao *GradesDao) Ctx(ctx context.Context) *gdb.Model {
	model := dao.DB().Model(dao.table)
	for _, handler := range dao.handlers {
		model = handler(model)
	}
	return model.Safe().Ctx(ctx)
}

// Transaction wraps the transaction logic using function f.
// It rolls back the transaction and returns the error if function f returns a non-nil error.
// It commits the transaction and returns nil if function f returns nil.
//
// Note: Do not commit or roll back the transaction in function f,
// as it is automatically handled by this function.
func (dao *GradesDao) Transaction(ctx context.Context, f func(ctx context.Context, tx gdb.TX) error) (err error) {
	return dao.Ctx(ctx).Transaction(ctx, f)
}
