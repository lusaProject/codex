package student

import (
	"context"
	"testing"

	"student-management/internal/model"
	"student-management/internal/service"
	studentkitex "student-management/kitex_gen/student"

	"github.com/cloudwego/kitex/client/callopt"
	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestStudentClientTimeout(t *testing.T) {
	client := NewKitexClient(fakeKitexStudentClient{err: context.DeadlineExceeded})
	_, err := client.CheckStudentActive(context.Background(), 1)
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestStudentClientDownstreamError(t *testing.T) {
	client := NewKitexClient(fakeKitexStudentClient{err: context.DeadlineExceeded})
	_, err := client.Create(context.Background(), validStudentInput())
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestStudentClientEmptyResponse(t *testing.T) {
	client := NewKitexClient(fakeKitexStudentClient{empty: true})
	_, err := client.Get(context.Background(), 1)
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestStudentClientEmptyResponses(t *testing.T) {
	client := NewKitexClient(fakeKitexStudentClient{empty: true})
	ctx := context.Background()
	if _, err := client.Create(ctx, validStudentInput()); gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("Create empty expected internal error, got %v", gerror.Code(err))
	}
	if _, err := client.List(ctx, model.StudentListInput{Page: 1, Size: 10}); gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("List empty expected internal error, got %v", gerror.Code(err))
	}
	if err := client.Update(ctx, model.StudentUpdateInput{StudentID: 1}); gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("Update empty expected internal error, got %v", gerror.Code(err))
	}
	if err := client.UpdateStatus(ctx, model.StudentStatusInput{StudentID: 1, Status: model.StudentStatusActive}); gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("UpdateStatus empty expected internal error, got %v", gerror.Code(err))
	}
	if _, err := client.CheckStudentActive(ctx, 1); gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("CheckStudentActive empty expected internal error, got %v", gerror.Code(err))
	}
}

func TestStudentClientSuccessPaths(t *testing.T) {
	client := NewKitexClient(fakeKitexStudentClient{active: true})
	ctx := context.Background()
	if id, err := client.Create(ctx, validStudentInput()); err != nil || id != 1 {
		t.Fatalf("Create() id=%d err=%v", id, err)
	}
	if _, err := client.Get(ctx, 1); err != nil {
		t.Fatalf("Get() error = %v", err)
	}
	if _, err := client.List(ctx, model.StudentListInput{Page: 1, Size: 10}); err != nil {
		t.Fatalf("List() error = %v", err)
	}
	if err := client.Update(ctx, model.StudentUpdateInput{StudentID: 1, Name: "李四", ClassName: "二班", Major: "软件工程", College: "计算机学院"}); err != nil {
		t.Fatalf("Update() error = %v", err)
	}
	if err := client.UpdateStatus(ctx, model.StudentStatusInput{StudentID: 1, Status: model.StudentStatusActive}); err != nil {
		t.Fatalf("UpdateStatus() error = %v", err)
	}
	if active, err := client.CheckStudentActive(ctx, 1); err != nil || !active {
		t.Fatalf("CheckStudentActive() active=%v err=%v", active, err)
	}
}

func TestStudentServiceClient(t *testing.T) {
	service.RegisterStudent(fakeStudentService{createID: 5})
	client := NewServiceClient()
	ctx := context.Background()
	if id, err := client.Create(ctx, validStudentInput()); err != nil || id != 5 {
		t.Fatalf("Create() id=%d err=%v", id, err)
	}
	if _, err := client.Get(ctx, 5); err != nil {
		t.Fatalf("Get() error = %v", err)
	}
	if _, err := client.List(ctx, model.StudentListInput{Page: 1, Size: 10}); err != nil {
		t.Fatalf("List() error = %v", err)
	}
	if err := client.Update(ctx, model.StudentUpdateInput{StudentID: 5}); err != nil {
		t.Fatalf("Update() error = %v", err)
	}
	if err := client.UpdateStatus(ctx, model.StudentStatusInput{StudentID: 5, Status: model.StudentStatusActive}); err != nil {
		t.Fatalf("UpdateStatus() error = %v", err)
	}
	if active, err := client.CheckStudentActive(ctx, 5); err != nil || !active {
		t.Fatalf("CheckStudentActive() active=%v err=%v", active, err)
	}
}

type fakeKitexStudentClient struct {
	err    error
	active bool
	empty  bool
}

func (f fakeKitexStudentClient) CreateStudent(ctx context.Context, req *studentkitex.CreateStudentReq, callOptions ...callopt.Option) (*studentkitex.CreateStudentResp, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.empty {
		return nil, nil
	}
	return &studentkitex.CreateStudentResp{StudentId: 1}, nil
}

func (f fakeKitexStudentClient) GetStudent(ctx context.Context, req *studentkitex.GetStudentReq, callOptions ...callopt.Option) (*studentkitex.GetStudentResp, error) {
	if f.err != nil || f.empty {
		return nil, f.err
	}
	return &studentkitex.GetStudentResp{Student: &studentkitex.StudentInfo{StudentId: req.StudentId, StudentNo: "S1", Name: "张三"}}, nil
}

func (f fakeKitexStudentClient) ListStudents(ctx context.Context, req *studentkitex.ListStudentsReq, callOptions ...callopt.Option) (*studentkitex.ListStudentsResp, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.empty {
		return nil, nil
	}
	return &studentkitex.ListStudentsResp{List: []*studentkitex.StudentInfo{{StudentId: 1, StudentNo: "S1", Name: "张三"}}, Total: 1}, nil
}

func (f fakeKitexStudentClient) UpdateStudent(ctx context.Context, req *studentkitex.UpdateStudentReq, callOptions ...callopt.Option) (*studentkitex.UpdateStudentResp, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.empty {
		return nil, nil
	}
	return &studentkitex.UpdateStudentResp{}, nil
}

func (f fakeKitexStudentClient) UpdateStudentStatus(ctx context.Context, req *studentkitex.UpdateStudentStatusReq, callOptions ...callopt.Option) (*studentkitex.UpdateStudentStatusResp, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.empty {
		return nil, nil
	}
	return &studentkitex.UpdateStudentStatusResp{}, nil
}

func (f fakeKitexStudentClient) CheckStudentActive(ctx context.Context, req *studentkitex.CheckStudentActiveReq, callOptions ...callopt.Option) (*studentkitex.CheckStudentActiveResp, error) {
	if f.err != nil {
		return nil, f.err
	}
	if f.empty {
		return nil, nil
	}
	return &studentkitex.CheckStudentActiveResp{Active: f.active}, nil
}

func validStudentInput() model.StudentCreateInput {
	return model.StudentCreateInput{
		StudentNo: "S20260001",
		Name:      "张三",
		ClassName: "软件一班",
		Major:     "软件工程",
		College:   "计算机学院",
	}
}

type fakeStudentService struct {
	createID int64
}

func (f fakeStudentService) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	return f.createID, nil
}

func (f fakeStudentService) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	return &model.Student{StudentID: studentID}, nil
}

func (f fakeStudentService) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	return &model.StudentListOutput{List: []model.Student{{StudentID: 1}}, Total: 1}, nil
}

func (f fakeStudentService) Update(ctx context.Context, in model.StudentUpdateInput) error {
	return nil
}

func (f fakeStudentService) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	return nil
}

func (f fakeStudentService) CheckActive(ctx context.Context, studentID int64) (bool, error) {
	return true, nil
}
