package student

import (
	"context"

	"student-management/internal/model"
	"student-management/internal/service"
	studentkitex "student-management/kitex_gen/student"
	"student-management/kitex_gen/student/studentservice"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
)

// Client 定义 student-service RPC 客户端封装。
type Client interface {
	Create(ctx context.Context, in model.StudentCreateInput) (int64, error)
	Get(ctx context.Context, studentID int64) (*model.Student, error)
	List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error)
	Update(ctx context.Context, in model.StudentUpdateInput) error
	UpdateStatus(ctx context.Context, in model.StudentStatusInput) error
	CheckStudentActive(ctx context.Context, studentID int64) (bool, error)
}

// NewKitexClient 创建 Kitex student-service 客户端封装。
func NewKitexClient(c studentservice.Client) Client {
	return &kitexClient{client: c}
}

// NewServiceClient 创建进程内 service 客户端，主要用于本地开发与单元测试。
func NewServiceClient() Client {
	return serviceClient{}
}

type kitexClient struct {
	client studentservice.Client
}

func (c *kitexClient) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	resp, err := c.client.CreateStudent(ctx, &studentkitex.CreateStudentReq{
		StudentNo: in.StudentNo,
		Name:      in.Name,
		Gender:    in.Gender,
		ClassName: in.ClassName,
		Major:     in.Major,
		College:   in.College,
		Mobile:    stringPtr(in.Mobile),
		Email:     stringPtr(in.Email),
	})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc CreateStudent failed: %+v", err)
		return 0, gerror.WrapCode(gcode.CodeInternalError, err, "student-service 创建学生失败")
	}
	if resp == nil {
		return 0, gerror.NewCode(gcode.CodeInternalError, "student-service 创建学生返回空响应")
	}
	return resp.StudentId, nil
}

func (c *kitexClient) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	resp, err := c.client.GetStudent(ctx, &studentkitex.GetStudentReq{StudentId: studentID})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc GetStudent failed: %+v", err)
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "student-service 查询学生失败")
	}
	if resp == nil || resp.Student == nil {
		return nil, gerror.NewCode(gcode.CodeInternalError, "student-service 查询学生返回空响应")
	}
	student := fromRPCStudent(resp.Student)
	return &student, nil
}

func (c *kitexClient) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	resp, err := c.client.ListStudents(ctx, &studentkitex.ListStudentsReq{
		Page:      int32(in.Page),
		Size:      int32(in.Size),
		Name:      optionalString(in.Name),
		ClassName: optionalString(in.ClassName),
		Status:    optionalInt32(in.Status),
	})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc ListStudents failed: %+v", err)
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "student-service 查询学生列表失败")
	}
	if resp == nil {
		return nil, gerror.NewCode(gcode.CodeInternalError, "student-service 查询学生列表返回空响应")
	}
	list := make([]model.Student, 0, len(resp.List))
	for _, item := range resp.List {
		if item == nil {
			continue
		}
		list = append(list, fromRPCStudent(item))
	}
	return &model.StudentListOutput{List: list, Total: int(resp.Total)}, nil
}

func (c *kitexClient) Update(ctx context.Context, in model.StudentUpdateInput) error {
	resp, err := c.client.UpdateStudent(ctx, &studentkitex.UpdateStudentReq{
		StudentId: in.StudentID,
		Name:      in.Name,
		Gender:    in.Gender,
		ClassName: in.ClassName,
		Major:     in.Major,
		College:   in.College,
		Mobile:    stringPtr(in.Mobile),
		Email:     stringPtr(in.Email),
	})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc UpdateStudent failed: %+v", err)
		return gerror.WrapCode(gcode.CodeInternalError, err, "student-service 修改学生失败")
	}
	if resp == nil {
		return gerror.NewCode(gcode.CodeInternalError, "student-service 修改学生返回空响应")
	}
	return nil
}

func (c *kitexClient) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	resp, err := c.client.UpdateStudentStatus(ctx, &studentkitex.UpdateStudentStatusReq{
		StudentId: in.StudentID,
		Status:    in.Status,
	})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc UpdateStudentStatus failed: %+v", err)
		return gerror.WrapCode(gcode.CodeInternalError, err, "student-service 修改学生状态失败")
	}
	if resp == nil {
		return gerror.NewCode(gcode.CodeInternalError, "student-service 修改学生状态返回空响应")
	}
	return nil
}

func (c *kitexClient) CheckStudentActive(ctx context.Context, studentID int64) (bool, error) {
	resp, err := c.client.CheckStudentActive(ctx, &studentkitex.CheckStudentActiveReq{StudentId: studentID})
	if err != nil {
		g.Log().Errorf(ctx, "student rpc CheckStudentActive failed: %+v", err)
		return false, gerror.WrapCode(gcode.CodeInternalError, err, "student-service 校验学生状态失败")
	}
	if resp == nil {
		return false, gerror.NewCode(gcode.CodeInternalError, "student-service 校验学生状态返回空响应")
	}
	return resp.Active, nil
}

type serviceClient struct{}

func (serviceClient) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	return service.Student().Create(ctx, in)
}

func (serviceClient) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	return service.Student().Get(ctx, studentID)
}

func (serviceClient) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	return service.Student().List(ctx, in)
}

func (serviceClient) Update(ctx context.Context, in model.StudentUpdateInput) error {
	return service.Student().Update(ctx, in)
}

func (serviceClient) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	return service.Student().UpdateStatus(ctx, in)
}

func (serviceClient) CheckStudentActive(ctx context.Context, studentID int64) (bool, error) {
	return service.Student().CheckActive(ctx, studentID)
}

func fromRPCStudent(item *studentkitex.StudentInfo) model.Student {
	return model.Student{
		StudentID: item.StudentId,
		StudentNo: item.StudentNo,
		Name:      item.Name,
		Gender:    item.Gender,
		ClassName: item.ClassName,
		Major:     item.Major,
		College:   item.College,
		Mobile:    item.GetMobile(),
		Email:     item.GetEmail(),
		Status:    item.Status,
		CreatedAt: item.CreatedAt,
		UpdatedAt: item.UpdatedAt,
	}
}

func stringPtr(v string) *string {
	if v == "" {
		return nil
	}
	return &v
}

func optionalString(v string) *string {
	if v == "" {
		return nil
	}
	return &v
}

func optionalInt32(v int32) *int32 {
	if v == 0 {
		return nil
	}
	return &v
}
