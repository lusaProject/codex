package academic

import (
	"context"

	"student-management/internal/model"
	"student-management/internal/service"
	academickitex "student-management/kitex_gen/academic"
	"student-management/kitex_gen/academic/academicservice"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
)

// Client 定义 academic-service RPC 客户端封装。
type Client interface {
	CreateCourse(ctx context.Context, in model.CourseCreateInput) (int64, error)
	EnrollCourse(ctx context.Context, in model.EnrollmentCreateInput) (int64, error)
	SubmitGrade(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error)
}

// NewKitexClient 创建 Kitex academic-service 客户端封装。
func NewKitexClient(c academicservice.Client) Client {
	return &kitexClient{client: c}
}

// NewServiceClient 创建进程内 service 客户端，主要用于本地开发与单元测试。
func NewServiceClient() Client {
	return serviceClient{}
}

type kitexClient struct {
	client academicservice.Client
}

func (c *kitexClient) CreateCourse(ctx context.Context, in model.CourseCreateInput) (int64, error) {
	resp, err := c.client.CreateCourse(ctx, &academickitex.CreateCourseReq{
		CourseCode:  in.CourseCode,
		CourseName:  in.CourseName,
		TeacherId:   in.TeacherID,
		TeacherName: in.TeacherName,
		Credit:      in.Credit,
		Capacity:    in.Capacity,
	})
	if err != nil {
		g.Log().Errorf(ctx, "academic rpc CreateCourse failed: %+v", err)
		return 0, gerror.WrapCode(gcode.CodeInternalError, err, "academic-service 创建课程失败")
	}
	if resp == nil {
		return 0, gerror.NewCode(gcode.CodeInternalError, "academic-service 创建课程返回空响应")
	}
	return resp.CourseId, nil
}

func (c *kitexClient) EnrollCourse(ctx context.Context, in model.EnrollmentCreateInput) (int64, error) {
	resp, err := c.client.EnrollCourse(ctx, &academickitex.EnrollCourseReq{
		StudentId: in.StudentID,
		CourseId:  in.CourseID,
	})
	if err != nil {
		g.Log().Errorf(ctx, "academic rpc EnrollCourse failed: %+v", err)
		return 0, gerror.WrapCode(gcode.CodeInternalError, err, "academic-service 选课失败")
	}
	if resp == nil {
		return 0, gerror.NewCode(gcode.CodeInternalError, "academic-service 选课返回空响应")
	}
	return resp.EnrollmentId, nil
}

func (c *kitexClient) SubmitGrade(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error) {
	resp, err := c.client.SubmitGrade(ctx, &academickitex.SubmitGradeReq{
		StudentId: in.StudentID,
		CourseId:  in.CourseID,
		Score:     in.Score,
		Remark:    optionalString(in.Remark),
	})
	if err != nil {
		g.Log().Errorf(ctx, "academic rpc SubmitGrade failed: %+v", err)
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "academic-service 录入成绩失败")
	}
	if resp == nil {
		return nil, gerror.NewCode(gcode.CodeInternalError, "academic-service 录入成绩返回空响应")
	}
	return &model.GradeSubmitOutput{GradeID: resp.GradeId, GradeLevel: resp.GradeLevel}, nil
}

type serviceClient struct{}

func (serviceClient) CreateCourse(ctx context.Context, in model.CourseCreateInput) (int64, error) {
	return service.Course().Create(ctx, in)
}

func (serviceClient) EnrollCourse(ctx context.Context, in model.EnrollmentCreateInput) (int64, error) {
	return service.Enrollment().Enroll(ctx, in)
}

func (serviceClient) SubmitGrade(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error) {
	return service.Grade().Submit(ctx, in)
}

func optionalString(v string) *string {
	if v == "" {
		return nil
	}
	return &v
}
