package academic

import (
	"context"
	"testing"

	"student-management/internal/model"
	"student-management/internal/service"
	academickitex "student-management/kitex_gen/academic"

	"github.com/cloudwego/kitex/client/callopt"
	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestAcademicClientEmptyResponse(t *testing.T) {
	client := NewKitexClient(fakeKitexAcademicClient{})
	_, err := client.CreateCourse(context.Background(), validCourseInput())
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestAcademicClientSubmitGradeEmptyResponse(t *testing.T) {
	client := NewKitexClient(fakeKitexAcademicClient{})
	_, err := client.SubmitGrade(context.Background(), model.GradeSubmitInput{StudentID: 1, CourseID: 2, Score: 80})
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestAcademicClientDownstreamError(t *testing.T) {
	client := NewKitexClient(fakeKitexAcademicClient{err: context.DeadlineExceeded})
	_, err := client.EnrollCourse(context.Background(), validEnrollmentInput())
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestAcademicClientSuccessPaths(t *testing.T) {
	client := NewKitexClient(fakeKitexAcademicClient{success: true})
	ctx := context.Background()
	if id, err := client.CreateCourse(ctx, validCourseInput()); err != nil || id != 1 {
		t.Fatalf("CreateCourse() id=%d err=%v", id, err)
	}
	if id, err := client.EnrollCourse(ctx, validEnrollmentInput()); err != nil || id != 2 {
		t.Fatalf("EnrollCourse() id=%d err=%v", id, err)
	}
	out, err := client.SubmitGrade(ctx, model.GradeSubmitInput{StudentID: 1, CourseID: 2, Score: 95, Remark: "优秀"})
	if err != nil {
		t.Fatalf("SubmitGrade() error = %v", err)
	}
	if out.GradeID != 3 || out.GradeLevel != "A" {
		t.Fatalf("unexpected output: %+v", out)
	}
}

func TestAcademicServiceClient(t *testing.T) {
	service.RegisterCourse(fakeCourseService{createID: 6})
	service.RegisterEnrollment(fakeEnrollmentService{enrollmentID: 7})
	service.RegisterGrade(fakeGradeService{gradeID: 8, level: "A"})
	client := NewServiceClient()
	ctx := context.Background()
	if id, err := client.CreateCourse(ctx, validCourseInput()); err != nil || id != 6 {
		t.Fatalf("CreateCourse() id=%d err=%v", id, err)
	}
	if id, err := client.EnrollCourse(ctx, validEnrollmentInput()); err != nil || id != 7 {
		t.Fatalf("EnrollCourse() id=%d err=%v", id, err)
	}
	if out, err := client.SubmitGrade(ctx, model.GradeSubmitInput{StudentID: 1, CourseID: 2, Score: 95}); err != nil || out.GradeID != 8 {
		t.Fatalf("SubmitGrade() out=%+v err=%v", out, err)
	}
}

type fakeKitexAcademicClient struct {
	err     error
	success bool
}

func (f fakeKitexAcademicClient) CreateCourse(ctx context.Context, req *academickitex.CreateCourseReq, callOptions ...callopt.Option) (*academickitex.CreateCourseResp, error) {
	if f.success {
		return &academickitex.CreateCourseResp{CourseId: 1}, nil
	}
	return nil, f.err
}

func (f fakeKitexAcademicClient) GetCourse(ctx context.Context, req *academickitex.GetCourseReq, callOptions ...callopt.Option) (*academickitex.GetCourseResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) ListCourses(ctx context.Context, req *academickitex.ListCoursesReq, callOptions ...callopt.Option) (*academickitex.ListCoursesResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) UpdateCourse(ctx context.Context, req *academickitex.UpdateCourseReq, callOptions ...callopt.Option) (*academickitex.UpdateCourseResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) UpdateCourseStatus(ctx context.Context, req *academickitex.UpdateCourseStatusReq, callOptions ...callopt.Option) (*academickitex.UpdateCourseStatusResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) EnrollCourse(ctx context.Context, req *academickitex.EnrollCourseReq, callOptions ...callopt.Option) (*academickitex.EnrollCourseResp, error) {
	if f.success {
		return &academickitex.EnrollCourseResp{EnrollmentId: 2}, nil
	}
	return nil, f.err
}

func (f fakeKitexAcademicClient) DropCourse(ctx context.Context, req *academickitex.DropCourseReq, callOptions ...callopt.Option) (*academickitex.DropCourseResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) ListStudentCourses(ctx context.Context, req *academickitex.ListStudentCoursesReq, callOptions ...callopt.Option) (*academickitex.ListStudentCoursesResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) ListCourseStudents(ctx context.Context, req *academickitex.ListCourseStudentsReq, callOptions ...callopt.Option) (*academickitex.ListCourseStudentsResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) SubmitGrade(ctx context.Context, req *academickitex.SubmitGradeReq, callOptions ...callopt.Option) (*academickitex.SubmitGradeResp, error) {
	if f.success {
		return &academickitex.SubmitGradeResp{GradeId: 3, GradeLevel: "A"}, nil
	}
	return nil, f.err
}

func (f fakeKitexAcademicClient) UpdateGrade(ctx context.Context, req *academickitex.UpdateGradeReq, callOptions ...callopt.Option) (*academickitex.UpdateGradeResp, error) {
	return nil, f.err
}

func (f fakeKitexAcademicClient) ListStudentGrades(ctx context.Context, req *academickitex.ListStudentGradesReq, callOptions ...callopt.Option) (*academickitex.ListStudentGradesResp, error) {
	return nil, f.err
}

func validCourseInput() model.CourseCreateInput {
	return model.CourseCreateInput{
		CourseCode:  "CS101",
		CourseName:  "Go 后端开发",
		TeacherID:   1001,
		TeacherName: "李老师",
		Credit:      3,
		Capacity:    30,
	}
}

func validEnrollmentInput() model.EnrollmentCreateInput {
	return model.EnrollmentCreateInput{StudentID: 1, CourseID: 2}
}

type fakeCourseService struct {
	createID int64
}

func (f fakeCourseService) Create(ctx context.Context, in model.CourseCreateInput) (int64, error) {
	return f.createID, nil
}

func (f fakeCourseService) Get(ctx context.Context, courseID int64) (*model.Course, error) {
	return &model.Course{CourseID: courseID}, nil
}

func (f fakeCourseService) List(ctx context.Context, in model.CourseListInput) (*model.CourseListOutput, error) {
	return &model.CourseListOutput{}, nil
}

func (f fakeCourseService) Update(ctx context.Context, in model.CourseUpdateInput) error {
	return nil
}

func (f fakeCourseService) UpdateStatus(ctx context.Context, in model.CourseStatusInput) error {
	return nil
}

type fakeEnrollmentService struct {
	enrollmentID int64
}

func (f fakeEnrollmentService) Enroll(ctx context.Context, in model.EnrollmentCreateInput) (int64, error) {
	return f.enrollmentID, nil
}

func (f fakeEnrollmentService) Drop(ctx context.Context, in model.EnrollmentDropInput) error {
	return nil
}

func (f fakeEnrollmentService) ListStudentCourses(ctx context.Context, studentID int64) ([]model.StudentCourse, error) {
	return nil, nil
}

func (f fakeEnrollmentService) ListCourseStudents(ctx context.Context, courseID int64) ([]model.CourseStudent, error) {
	return nil, nil
}

type fakeGradeService struct {
	gradeID int64
	level   string
}

func (f fakeGradeService) Submit(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error) {
	return &model.GradeSubmitOutput{GradeID: f.gradeID, GradeLevel: f.level}, nil
}

func (f fakeGradeService) Update(ctx context.Context, in model.GradeUpdateInput) (*model.GradeUpdateOutput, error) {
	return &model.GradeUpdateOutput{GradeLevel: f.level}, nil
}

func (f fakeGradeService) ListStudentGrades(ctx context.Context, studentID int64) ([]model.StudentGrade, error) {
	return nil, nil
}
