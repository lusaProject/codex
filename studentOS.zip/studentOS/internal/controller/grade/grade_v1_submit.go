package grade

import (
	"context"

	"student-management/api/grade/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Submit(ctx context.Context, req *v1.SubmitReq) (res *v1.SubmitRes, err error) {
	out, err := service.Grade().Submit(ctx, model.GradeSubmitInput{
		StudentID: req.StudentID,
		CourseID:  req.CourseID,
		Score:     req.Score,
		Remark:    req.Remark,
	})
	if err != nil {
		return nil, err
	}
	return &v1.SubmitRes{GradeID: out.GradeID, GradeLevel: out.GradeLevel}, nil
}
