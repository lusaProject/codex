package grade

import (
	"context"

	"student-management/api/grade/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Update(ctx context.Context, req *v1.UpdateReq) (res *v1.UpdateRes, err error) {
	out, err := service.Grade().Update(ctx, model.GradeUpdateInput{
		GradeID: req.ID,
		Score:   req.Score,
		Remark:  req.Remark,
	})
	if err != nil {
		return nil, err
	}
	return &v1.UpdateRes{GradeLevel: out.GradeLevel}, nil
}
