package grade

import (
	"context"

	"student-management/api/grade/v1"
	"student-management/internal/service"
)

func (c *ControllerV1) ListStudentGrades(ctx context.Context, req *v1.ListStudentGradesReq) (res *v1.ListStudentGradesRes, err error) {
	list, err := service.Grade().ListStudentGrades(ctx, req.ID)
	if err != nil {
		return nil, err
	}
	return &v1.ListStudentGradesRes{List: list}, nil
}
