package enrollment

import (
	"context"

	"student-management/api/enrollment/v1"
	"student-management/internal/service"
)

func (c *ControllerV1) ListCourseStudents(ctx context.Context, req *v1.ListCourseStudentsReq) (res *v1.ListCourseStudentsRes, err error) {
	list, err := service.Enrollment().ListCourseStudents(ctx, req.ID)
	if err != nil {
		return nil, err
	}
	return &v1.ListCourseStudentsRes{List: list}, nil
}
