package enrollment

import (
	"context"

	"student-management/api/enrollment/v1"
	"student-management/internal/service"
)

func (c *ControllerV1) ListStudentCourses(ctx context.Context, req *v1.ListStudentCoursesReq) (res *v1.ListStudentCoursesRes, err error) {
	list, err := service.Enrollment().ListStudentCourses(ctx, req.ID)
	if err != nil {
		return nil, err
	}
	return &v1.ListStudentCoursesRes{List: list}, nil
}
