package enrollment

import (
	"context"

	"student-management/api/enrollment/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Enroll(ctx context.Context, req *v1.EnrollReq) (res *v1.EnrollRes, err error) {
	id, err := service.Enrollment().Enroll(ctx, model.EnrollmentCreateInput{
		StudentID: req.StudentID,
		CourseID:  req.CourseID,
	})
	if err != nil {
		return nil, err
	}
	return &v1.EnrollRes{EnrollmentID: id}, nil
}
