package enrollment

import (
	"context"

	"student-management/api/enrollment/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Drop(ctx context.Context, req *v1.DropReq) (res *v1.DropRes, err error) {
	err = service.Enrollment().Drop(ctx, model.EnrollmentDropInput{EnrollmentID: req.ID})
	if err != nil {
		return nil, err
	}
	return &v1.DropRes{}, nil
}
