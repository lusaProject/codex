package student

import (
	"context"

	"student-management/api/student/v1"
	"student-management/internal/service"
)

func (c *ControllerV1) Get(ctx context.Context, req *v1.GetReq) (res *v1.GetRes, err error) {
	student, err := service.Student().Get(ctx, req.ID)
	if err != nil {
		return nil, err
	}
	return &v1.GetRes{Student: *student}, nil
}
