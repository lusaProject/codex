package student

import (
	"context"

	"student-management/api/student/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Update(ctx context.Context, req *v1.UpdateReq) (res *v1.UpdateRes, err error) {
	err = service.Student().Update(ctx, model.StudentUpdateInput{
		StudentID: req.ID,
		Name:      req.Name,
		Gender:    req.Gender,
		ClassName: req.ClassName,
		Major:     req.Major,
		College:   req.College,
		Mobile:    req.Mobile,
		Email:     req.Email,
	})
	if err != nil {
		return nil, err
	}
	return &v1.UpdateRes{}, nil
}
