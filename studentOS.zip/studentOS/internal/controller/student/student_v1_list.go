package student

import (
	"context"

	"student-management/api/student/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) List(ctx context.Context, req *v1.ListReq) (res *v1.ListRes, err error) {
	out, err := service.Student().List(ctx, model.StudentListInput{
		Page:      req.Page,
		Size:      req.Size,
		Name:      req.Name,
		ClassName: req.ClassName,
		Status:    req.Status,
	})
	if err != nil {
		return nil, err
	}
	return &v1.ListRes{List: out.List, Total: out.Total}, nil
}
