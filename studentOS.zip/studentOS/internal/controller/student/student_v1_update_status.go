package student

import (
	"context"

	"student-management/api/student/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) UpdateStatus(ctx context.Context, req *v1.UpdateStatusReq) (res *v1.UpdateStatusRes, err error) {
	err = service.Student().UpdateStatus(ctx, model.StudentStatusInput{
		StudentID: req.ID,
		Status:    req.Status,
	})
	if err != nil {
		return nil, err
	}
	return &v1.UpdateStatusRes{}, nil
}
