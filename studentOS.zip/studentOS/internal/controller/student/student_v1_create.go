package student

import (
	"context"

	"student-management/api/student/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Create(ctx context.Context, req *v1.CreateReq) (res *v1.CreateRes, err error) {
	id, err := service.Student().Create(ctx, model.StudentCreateInput{
		StudentNo: req.StudentNo,
		Name:      req.Name,
		Gender:    req.Gender,
		ClassName: req.ClassName,
		Major:     req.Major,
		College:   req.College,
		Mobile:    req.Mobile,
		Email:     req.Email,
	})
	if err != nil {
		return nil, err
	}
	return &v1.CreateRes{StudentID: id}, nil
}
