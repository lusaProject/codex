package course

import (
	"context"

	"student-management/api/course/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Create(ctx context.Context, req *v1.CreateReq) (res *v1.CreateRes, err error) {
	id, err := service.Course().Create(ctx, model.CourseCreateInput{
		CourseCode:  req.CourseCode,
		CourseName:  req.CourseName,
		TeacherID:   req.TeacherID,
		TeacherName: req.TeacherName,
		Credit:      req.Credit,
		Capacity:    req.Capacity,
	})
	if err != nil {
		return nil, err
	}
	return &v1.CreateRes{CourseID: id}, nil
}
