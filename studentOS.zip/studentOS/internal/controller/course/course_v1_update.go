package course

import (
	"context"

	"student-management/api/course/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) Update(ctx context.Context, req *v1.UpdateReq) (res *v1.UpdateRes, err error) {
	err = service.Course().Update(ctx, model.CourseUpdateInput{
		CourseID:    req.ID,
		CourseName:  req.CourseName,
		TeacherID:   req.TeacherID,
		TeacherName: req.TeacherName,
		Credit:      req.Credit,
		Capacity:    req.Capacity,
	})
	if err != nil {
		return nil, err
	}
	return &v1.UpdateRes{}, nil
}
