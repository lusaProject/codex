package course

import (
	"context"

	"student-management/api/course/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) UpdateStatus(ctx context.Context, req *v1.UpdateStatusReq) (res *v1.UpdateStatusRes, err error) {
	err = service.Course().UpdateStatus(ctx, model.CourseStatusInput{
		CourseID: req.ID,
		Status:   req.Status,
	})
	if err != nil {
		return nil, err
	}
	return &v1.UpdateStatusRes{}, nil
}
