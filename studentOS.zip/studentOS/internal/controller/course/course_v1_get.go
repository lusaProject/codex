package course

import (
	"context"

	"student-management/api/course/v1"
	"student-management/internal/service"
)

func (c *ControllerV1) Get(ctx context.Context, req *v1.GetReq) (res *v1.GetRes, err error) {
	course, err := service.Course().Get(ctx, req.ID)
	if err != nil {
		return nil, err
	}
	return &v1.GetRes{Course: *course}, nil
}
