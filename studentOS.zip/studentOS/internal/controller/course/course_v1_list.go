package course

import (
	"context"

	"student-management/api/course/v1"
	"student-management/internal/model"
	"student-management/internal/service"
)

func (c *ControllerV1) List(ctx context.Context, req *v1.ListReq) (res *v1.ListRes, err error) {
	out, err := service.Course().List(ctx, model.CourseListInput{
		Page:       req.Page,
		Size:       req.Size,
		CourseName: req.CourseName,
		TeacherID:  req.TeacherID,
		Status:     req.Status,
	})
	if err != nil {
		return nil, err
	}
	return &v1.ListRes{List: out.List, Total: out.Total}, nil
}
