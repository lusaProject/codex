package codes

import "github.com/gogf/gf/v2/errors/gcode"

// CodeBusinessValidationFailed 表示业务校验未通过。
var CodeBusinessValidationFailed = gcode.New(10001, "business validation failed", nil)
