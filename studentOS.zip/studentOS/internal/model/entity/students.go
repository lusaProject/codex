// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package entity

import (
	"github.com/gogf/gf/v2/os/gtime"
)

// Students is the golang structure for table students.
type Students struct {
	Id        int64       `json:"id"        orm:"id"         description:""` //
	StudentNo string      `json:"studentNo" orm:"student_no" description:""` //
	Name      string      `json:"name"      orm:"name"       description:""` //
	Gender    int         `json:"gender"    orm:"gender"     description:""` //
	ClassName string      `json:"className" orm:"class_name" description:""` //
	Major     string      `json:"major"     orm:"major"      description:""` //
	College   string      `json:"college"   orm:"college"    description:""` //
	Mobile    string      `json:"mobile"    orm:"mobile"     description:""` //
	Email     string      `json:"email"     orm:"email"      description:""` //
	Status    int         `json:"status"    orm:"status"     description:""` //
	CreatedAt *gtime.Time `json:"createdAt" orm:"created_at" description:""` //
	UpdatedAt *gtime.Time `json:"updatedAt" orm:"updated_at" description:""` //
	DeletedAt *gtime.Time `json:"deletedAt" orm:"deleted_at" description:""` //
}
