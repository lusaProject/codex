// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package entity

import (
	"github.com/gogf/gf/v2/os/gtime"
)

// CourseEnrollments is the golang structure for table course_enrollments.
type CourseEnrollments struct {
	Id        int64       `json:"id"        orm:"id"         description:""` //
	StudentId int64       `json:"studentId" orm:"student_id" description:""` //
	CourseId  int64       `json:"courseId"  orm:"course_id"  description:""` //
	Status    int         `json:"status"    orm:"status"     description:""` //
	CreatedAt *gtime.Time `json:"createdAt" orm:"created_at" description:""` //
	UpdatedAt *gtime.Time `json:"updatedAt" orm:"updated_at" description:""` //
}
