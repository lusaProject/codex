// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package entity

import (
	"github.com/gogf/gf/v2/os/gtime"
)

// Grades is the golang structure for table grades.
type Grades struct {
	Id         int64       `json:"id"         orm:"id"          description:""` //
	StudentId  int64       `json:"studentId"  orm:"student_id"  description:""` //
	CourseId   int64       `json:"courseId"   orm:"course_id"   description:""` //
	Score      float64     `json:"score"      orm:"score"       description:""` //
	GradeLevel string      `json:"gradeLevel" orm:"grade_level" description:""` //
	Remark     string      `json:"remark"     orm:"remark"      description:""` //
	CreatedAt  *gtime.Time `json:"createdAt"  orm:"created_at"  description:""` //
	UpdatedAt  *gtime.Time `json:"updatedAt"  orm:"updated_at"  description:""` //
}
