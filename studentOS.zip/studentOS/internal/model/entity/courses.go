// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package entity

import (
	"github.com/gogf/gf/v2/os/gtime"
)

// Courses is the golang structure for table courses.
type Courses struct {
	Id            int64       `json:"id"            orm:"id"             description:""` //
	CourseCode    string      `json:"courseCode"    orm:"course_code"    description:""` //
	CourseName    string      `json:"courseName"    orm:"course_name"    description:""` //
	TeacherId     int64       `json:"teacherId"     orm:"teacher_id"     description:""` //
	TeacherName   string      `json:"teacherName"   orm:"teacher_name"   description:""` //
	Credit        float64     `json:"credit"        orm:"credit"         description:""` //
	Capacity      int         `json:"capacity"      orm:"capacity"       description:""` //
	SelectedCount int         `json:"selectedCount" orm:"selected_count" description:""` //
	Status        int         `json:"status"        orm:"status"         description:""` //
	CreatedAt     *gtime.Time `json:"createdAt"     orm:"created_at"     description:""` //
	UpdatedAt     *gtime.Time `json:"updatedAt"     orm:"updated_at"     description:""` //
	DeletedAt     *gtime.Time `json:"deletedAt"     orm:"deleted_at"     description:""` //
}
