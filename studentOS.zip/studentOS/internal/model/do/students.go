// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package do

import (
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

// Students is the golang structure of table students for DAO operations like Where/Data.
type Students struct {
	g.Meta    `orm:"table:students, do:true"`
	Id        any         //
	StudentNo any         //
	Name      any         //
	Gender    any         //
	ClassName any         //
	Major     any         //
	College   any         //
	Mobile    any         //
	Email     any         //
	Status    any         //
	CreatedAt *gtime.Time //
	UpdatedAt *gtime.Time //
	DeletedAt *gtime.Time //
}
