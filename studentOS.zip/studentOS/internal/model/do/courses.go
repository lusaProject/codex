// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package do

import (
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

// Courses is the golang structure of table courses for DAO operations like Where/Data.
type Courses struct {
	g.Meta        `orm:"table:courses, do:true"`
	Id            any         //
	CourseCode    any         //
	CourseName    any         //
	TeacherId     any         //
	TeacherName   any         //
	Credit        any         //
	Capacity      any         //
	SelectedCount any         //
	Status        any         //
	CreatedAt     *gtime.Time //
	UpdatedAt     *gtime.Time //
	DeletedAt     *gtime.Time //
}
