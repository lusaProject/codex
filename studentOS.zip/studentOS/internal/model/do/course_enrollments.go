// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package do

import (
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

// CourseEnrollments is the golang structure of table course_enrollments for DAO operations like Where/Data.
type CourseEnrollments struct {
	g.Meta    `orm:"table:course_enrollments, do:true"`
	Id        any         //
	StudentId any         //
	CourseId  any         //
	Status    any         //
	CreatedAt *gtime.Time //
	UpdatedAt *gtime.Time //
}
