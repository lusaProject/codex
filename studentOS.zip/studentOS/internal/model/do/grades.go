// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package do

import (
	"github.com/gogf/gf/v2/frame/g"
	"github.com/gogf/gf/v2/os/gtime"
)

// Grades is the golang structure of table grades for DAO operations like Where/Data.
type Grades struct {
	g.Meta     `orm:"table:grades, do:true"`
	Id         any         //
	StudentId  any         //
	CourseId   any         //
	Score      any         //
	GradeLevel any         //
	Remark     any         //
	CreatedAt  *gtime.Time //
	UpdatedAt  *gtime.Time //
}
