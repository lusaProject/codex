package model

const (
	StudentStatusActive   int32 = 1
	StudentStatusDisabled int32 = 2

	CourseStatusActive   int32 = 1
	CourseStatusDisabled int32 = 2

	EnrollmentStatusSelected int32 = 1
	EnrollmentStatusDropped  int32 = 2
)

type Student struct {
	StudentID int64  `json:"student_id"`
	StudentNo string `json:"student_no"`
	Name      string `json:"name"`
	Gender    int32  `json:"gender"`
	ClassName string `json:"class_name"`
	Major     string `json:"major"`
	College   string `json:"college"`
	Mobile    string `json:"mobile"`
	Email     string `json:"email"`
	Status    int32  `json:"status"`
	CreatedAt int64  `json:"created_at"`
	UpdatedAt int64  `json:"updated_at"`
}

type StudentCreateInput struct {
	StudentNo string
	Name      string
	Gender    int32
	ClassName string
	Major     string
	College   string
	Mobile    string
	Email     string
}

type StudentUpdateInput struct {
	StudentID int64
	Name      string
	Gender    int32
	ClassName string
	Major     string
	College   string
	Mobile    string
	Email     string
}

type StudentStatusInput struct {
	StudentID int64
	Status    int32
}

type StudentListInput struct {
	Page      int
	Size      int
	Name      string
	ClassName string
	Status    int32
}

type StudentListOutput struct {
	List  []Student
	Total int
}

type Course struct {
	CourseID      int64   `json:"course_id"`
	CourseCode    string  `json:"course_code"`
	CourseName    string  `json:"course_name"`
	TeacherID     int64   `json:"teacher_id"`
	TeacherName   string  `json:"teacher_name"`
	Credit        float64 `json:"credit"`
	Capacity      int32   `json:"capacity"`
	SelectedCount int32   `json:"selected_count"`
	Status        int32   `json:"status"`
	CreatedAt     int64   `json:"created_at"`
	UpdatedAt     int64   `json:"updated_at"`
}

type CourseCreateInput struct {
	CourseCode  string
	CourseName  string
	TeacherID   int64
	TeacherName string
	Credit      float64
	Capacity    int32
}

type CourseUpdateInput struct {
	CourseID    int64
	CourseName  string
	TeacherID   int64
	TeacherName string
	Credit      float64
	Capacity    int32
}

type CourseStatusInput struct {
	CourseID int64
	Status   int32
}

type CourseListInput struct {
	Page       int
	Size       int
	CourseName string
	TeacherID  int64
	Status     int32
}

type CourseListOutput struct {
	List  []Course
	Total int
}

type Enrollment struct {
	EnrollmentID int64 `json:"enrollment_id"`
	StudentID    int64 `json:"student_id"`
	CourseID     int64 `json:"course_id"`
	Status       int32 `json:"status"`
	CreatedAt    int64 `json:"created_at"`
	UpdatedAt    int64 `json:"updated_at"`
}

type EnrollmentCreateInput struct {
	StudentID int64
	CourseID  int64
}

type EnrollmentDropInput struct {
	EnrollmentID int64
}

type StudentCourse struct {
	EnrollmentID int64  `json:"enrollment_id"`
	Course       Course `json:"course"`
	EnrolledAt   int64  `json:"enrolled_at"`
}

type CourseStudent struct {
	EnrollmentID int64  `json:"enrollment_id"`
	StudentID    int64  `json:"student_id"`
	StudentNo    string `json:"student_no"`
	Name         string `json:"name"`
	ClassName    string `json:"class_name"`
	EnrolledAt   int64  `json:"enrolled_at"`
}

type Grade struct {
	GradeID    int64   `json:"grade_id"`
	StudentID  int64   `json:"student_id"`
	CourseID   int64   `json:"course_id"`
	Score      float64 `json:"score"`
	GradeLevel string  `json:"grade_level"`
	Remark     string  `json:"remark"`
	CreatedAt  int64   `json:"created_at"`
	UpdatedAt  int64   `json:"updated_at"`
}

type GradeSubmitInput struct {
	StudentID int64
	CourseID  int64
	Score     float64
	Remark    string
}

type GradeSubmitOutput struct {
	GradeID    int64
	GradeLevel string
}

type GradeUpdateInput struct {
	GradeID int64
	Score   float64
	Remark  string
}

type GradeUpdateOutput struct {
	GradeLevel string
}

type StudentGrade struct {
	Grade  Grade  `json:"grade"`
	Course Course `json:"course"`
}
