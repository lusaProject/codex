package enrollment

import (
	"context"
	"errors"
	"testing"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestEnrollCourseSuccess(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 2)
	id, err := NewWithStudentClient(fakeStudentClient{active: true}).Enroll(context.Background(), model.EnrollmentCreateInput{
		StudentID: 1,
		CourseID:  courseID,
	})
	if err != nil {
		t.Fatalf("Enroll() error = %v", err)
	}
	if id == 0 {
		t.Fatalf("Enroll() id = 0")
	}
}

func TestEnrollCourseDuplicate(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 2)
	svc := NewWithStudentClient(fakeStudentClient{active: true})
	in := model.EnrollmentCreateInput{StudentID: 1, CourseID: courseID}
	if _, err := svc.Enroll(context.Background(), in); err != nil {
		t.Fatalf("Enroll() first error = %v", err)
	}
	_, err := svc.Enroll(context.Background(), in)
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestEnrollCourseStudentInactive(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 2)
	_, err := NewWithStudentClient(fakeStudentClient{active: false}).Enroll(context.Background(), model.EnrollmentCreateInput{
		StudentID: 1,
		CourseID:  courseID,
	})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestEnrollCourseFull(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 1)
	svc := NewWithStudentClient(fakeStudentClient{active: true})
	if _, err := svc.Enroll(context.Background(), model.EnrollmentCreateInput{StudentID: 1, CourseID: courseID}); err != nil {
		t.Fatalf("Enroll() first error = %v", err)
	}
	_, err := svc.Enroll(context.Background(), model.EnrollmentCreateInput{StudentID: 2, CourseID: courseID})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestEnrollCourseInvalidID(t *testing.T) {
	store.ResetForTest()
	_, err := NewWithStudentClient(fakeStudentClient{active: true}).Enroll(context.Background(), model.EnrollmentCreateInput{})
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestEnrollCourseStudentRPCFailed(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 1)
	_, err := NewWithStudentClient(fakeStudentClient{err: errors.New("rpc timeout")}).Enroll(context.Background(), model.EnrollmentCreateInput{
		StudentID: 1,
		CourseID:  courseID,
	})
	if gerror.Code(err) != gcode.CodeInternalError {
		t.Fatalf("expected internal error, got %v", gerror.Code(err))
	}
}

func TestDropAndList(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 2)
	svc := NewWithStudentClient(fakeStudentClient{active: true})
	enrollmentID, err := svc.Enroll(context.Background(), model.EnrollmentCreateInput{StudentID: 1, CourseID: courseID})
	if err != nil {
		t.Fatalf("Enroll() error = %v", err)
	}
	courses, err := svc.ListStudentCourses(context.Background(), 1)
	if err != nil {
		t.Fatalf("ListStudentCourses() error = %v", err)
	}
	if len(courses) != 1 {
		t.Fatalf("courses len = %d", len(courses))
	}
	students, err := svc.ListCourseStudents(context.Background(), courseID)
	if err != nil {
		t.Fatalf("ListCourseStudents() error = %v", err)
	}
	if len(students) != 0 {
		t.Fatalf("students len = %d, want 0 because seed has no student base info", len(students))
	}
	if err := svc.Drop(context.Background(), model.EnrollmentDropInput{EnrollmentID: enrollmentID}); err != nil {
		t.Fatalf("Drop() error = %v", err)
	}
	err = svc.Drop(context.Background(), model.EnrollmentDropInput{EnrollmentID: enrollmentID})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestEnrollmentInvalidBranches(t *testing.T) {
	store.ResetForTest()
	svc := NewWithStudentClient(fakeStudentClient{active: true})
	if _, err := svc.Enroll(context.Background(), model.EnrollmentCreateInput{StudentID: 1, CourseID: 404}); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected course not found, got %v", gerror.Code(err))
	}
	if err := svc.Drop(context.Background(), model.EnrollmentDropInput{}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid drop id, got %v", gerror.Code(err))
	}
	if err := svc.Drop(context.Background(), model.EnrollmentDropInput{EnrollmentID: 404}); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected drop not found, got %v", gerror.Code(err))
	}
	if _, err := svc.ListStudentCourses(context.Background(), 0); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid student id, got %v", gerror.Code(err))
	}
	if _, err := svc.ListCourseStudents(context.Background(), 0); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid course id, got %v", gerror.Code(err))
	}
	if _, err := svc.ListCourseStudents(context.Background(), 404); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected course not found, got %v", gerror.Code(err))
	}
}

func TestEnrollCourseDisabled(t *testing.T) {
	store.ResetForTest()
	courseID := seedCourse(t, 2)
	if ok := store.Default().UpdateCourseStatus(model.CourseStatusInput{CourseID: courseID, Status: model.CourseStatusDisabled}); !ok {
		t.Fatalf("disable course failed")
	}
	_, err := NewWithStudentClient(fakeStudentClient{active: true}).Enroll(context.Background(), model.EnrollmentCreateInput{StudentID: 1, CourseID: courseID})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected disabled course business error, got %v", gerror.Code(err))
	}
}

type fakeStudentClient struct {
	active bool
	err    error
}

func (f fakeStudentClient) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	return 0, nil
}

func (f fakeStudentClient) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	return nil, nil
}

func (f fakeStudentClient) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	return nil, nil
}

func (f fakeStudentClient) Update(ctx context.Context, in model.StudentUpdateInput) error {
	return nil
}

func (f fakeStudentClient) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	return nil
}

func (f fakeStudentClient) CheckStudentActive(ctx context.Context, studentID int64) (bool, error) {
	return f.active, f.err
}

func seedCourse(t *testing.T, capacity int32) int64 {
	t.Helper()
	id, duplicate := store.Default().CreateCourse(model.CourseCreateInput{
		CourseCode:  "CS101",
		CourseName:  "Go 后端开发",
		TeacherID:   1001,
		TeacherName: "李老师",
		Credit:      3,
		Capacity:    capacity,
	})
	if duplicate {
		t.Fatalf("seed course duplicate")
	}
	return id
}
