package enrollment

import (
	"context"

	"student-management/internal/codes"
	"student-management/internal/model"
	rpcstudent "student-management/internal/rpc/student"
	"student-management/internal/service"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
	"github.com/gogf/gf/v2/frame/g"
)

// sEnrollment 选课业务逻辑实现。
type sEnrollment struct {
	studentClient rpcstudent.Client
}

func init() {
	service.RegisterEnrollment(New())
}

// New 创建选课业务逻辑实例。
func New() *sEnrollment {
	return NewWithStudentClient(rpcstudent.NewServiceClient())
}

// NewWithStudentClient 创建带学生 RPC 客户端的选课业务逻辑实例。
func NewWithStudentClient(studentClient rpcstudent.Client) *sEnrollment {
	return &sEnrollment{studentClient: studentClient}
}

// Enroll 学生选课。
func (s *sEnrollment) Enroll(ctx context.Context, in model.EnrollmentCreateInput) (int64, error) {
	if in.StudentID <= 0 || in.CourseID <= 0 {
		return 0, gerror.NewCode(gcode.CodeInvalidParameter, "学生ID和课程ID必须大于0")
	}
	active, err := s.studentClient.CheckStudentActive(ctx, in.StudentID)
	if err != nil {
		g.Log().Errorf(ctx, "check student active failed: %+v", err)
		return 0, gerror.WrapCode(gcode.CodeInternalError, err, "学生状态校验失败")
	}
	if !active {
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "学生状态不可用")
	}
	id, reason := store.Default().EnrollCourse(in)
	switch reason {
	case "":
		return id, nil
	case "course_not_found":
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	case "course_disabled":
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不可选")
	case "course_full":
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程容量已满")
	case "duplicate":
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "不能重复选课")
	default:
		return 0, gerror.NewCode(gcode.CodeInternalError, "选课失败")
	}
}

// Drop 学生退课。
func (s *sEnrollment) Drop(ctx context.Context, in model.EnrollmentDropInput) error {
	if in.EnrollmentID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "选课ID必须大于0")
	}
	switch reason := store.Default().DropEnrollment(in.EnrollmentID); reason {
	case "":
		return nil
	case "enrollment_not_found":
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "选课记录不存在")
	case "already_dropped":
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程已退选")
	case "course_not_found":
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	default:
		return gerror.NewCode(gcode.CodeInternalError, "退课失败")
	}
}

// ListStudentCourses 查询学生已选课程。
func (s *sEnrollment) ListStudentCourses(ctx context.Context, studentID int64) ([]model.StudentCourse, error) {
	if studentID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "学生ID必须大于0")
	}
	return store.Default().ListStudentCourses(studentID), nil
}

// ListCourseStudents 查询课程选课名单。
func (s *sEnrollment) ListCourseStudents(ctx context.Context, courseID int64) ([]model.CourseStudent, error) {
	if courseID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "课程ID必须大于0")
	}
	if _, ok := store.Default().GetCourse(courseID); !ok {
		return nil, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	}
	list, err := store.Default().ListCourseStudents(ctx, courseID)
	if err != nil {
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "课程选课名单读取失败")
	}
	return list, nil
}
