// ==========================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// ==========================================================================

package logic

import (
	_ "student-management/internal/logic/course"
	_ "student-management/internal/logic/enrollment"
	_ "student-management/internal/logic/grade"
	_ "student-management/internal/logic/student"
)
