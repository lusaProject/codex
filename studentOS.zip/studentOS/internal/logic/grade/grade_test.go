package grade

import (
	"context"
	"testing"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestSubmitGradeSuccess(t *testing.T) {
	store.ResetForTest()
	courseID := seedEnrollment(t)
	out, err := New().Submit(context.Background(), model.GradeSubmitInput{
		StudentID: 1,
		CourseID:  courseID,
		Score:     95,
	})
	if err != nil {
		t.Fatalf("Submit() error = %v", err)
	}
	if out.GradeID == 0 || out.GradeLevel != "A" {
		t.Fatalf("unexpected output: %+v", out)
	}
}

func TestSubmitGradeScoreLessThanZero(t *testing.T) {
	store.ResetForTest()
	_, err := New().Submit(context.Background(), model.GradeSubmitInput{StudentID: 1, CourseID: 1, Score: -1})
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestSubmitGradeScoreGreaterThanHundred(t *testing.T) {
	store.ResetForTest()
	_, err := New().Submit(context.Background(), model.GradeSubmitInput{StudentID: 1, CourseID: 1, Score: 101})
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestSubmitGradeWithoutEnrollment(t *testing.T) {
	store.ResetForTest()
	_, err := New().Submit(context.Background(), model.GradeSubmitInput{StudentID: 1, CourseID: 1, Score: 90})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestUpdateAndListStudentGrades(t *testing.T) {
	store.ResetForTest()
	courseID := seedEnrollment(t)
	svc := New()
	out, err := svc.Submit(context.Background(), model.GradeSubmitInput{StudentID: 1, CourseID: courseID, Score: 88})
	if err != nil {
		t.Fatalf("Submit() error = %v", err)
	}
	update, err := svc.Update(context.Background(), model.GradeUpdateInput{GradeID: out.GradeID, Score: 72})
	if err != nil {
		t.Fatalf("Update() error = %v", err)
	}
	if update.GradeLevel != "C" {
		t.Fatalf("GradeLevel = %s", update.GradeLevel)
	}
	list, err := svc.ListStudentGrades(context.Background(), 1)
	if err != nil {
		t.Fatalf("ListStudentGrades() error = %v", err)
	}
	if len(list) != 1 {
		t.Fatalf("grades len = %d", len(list))
	}
}

func TestUpdateGradeNotFound(t *testing.T) {
	store.ResetForTest()
	_, err := New().Update(context.Background(), model.GradeUpdateInput{GradeID: 404, Score: 60})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestCalculateGradeLevel(t *testing.T) {
	cases := map[float64]string{
		95: "A",
		85: "B",
		75: "C",
		65: "D",
		59: "F",
	}
	for score, want := range cases {
		if got := CalculateGradeLevel(score); got != want {
			t.Fatalf("CalculateGradeLevel(%v) = %s, want %s", score, got, want)
		}
	}
}

func seedEnrollment(t *testing.T) int64 {
	t.Helper()
	courseID, duplicate := store.Default().CreateCourse(model.CourseCreateInput{
		CourseCode:  "CS101",
		CourseName:  "Go 后端开发",
		TeacherID:   1001,
		TeacherName: "李老师",
		Credit:      3,
		Capacity:    2,
	})
	if duplicate {
		t.Fatalf("seed course duplicate")
	}
	if _, reason := store.Default().EnrollCourse(model.EnrollmentCreateInput{StudentID: 1, CourseID: courseID}); reason != "" {
		t.Fatalf("seed enrollment failed: %s", reason)
	}
	return courseID
}
