package grade

import (
	"context"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/service"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

// sGrade 成绩业务逻辑实现。
type sGrade struct{}

func init() {
	service.RegisterGrade(New())
}

// New 创建成绩业务逻辑实例。
func New() *sGrade {
	return &sGrade{}
}

// Submit 录入或修改成绩。
func (s *sGrade) Submit(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error) {
	if err := validateSubmit(in.StudentID, in.CourseID, in.Score); err != nil {
		return nil, err
	}
	if !store.Default().HasActiveEnrollment(in.StudentID, in.CourseID) {
		return nil, gerror.NewCode(codes.CodeBusinessValidationFailed, "未选课不能录入成绩")
	}
	level := CalculateGradeLevel(in.Score)
	id, _ := store.Default().SubmitGrade(in, level)
	return &model.GradeSubmitOutput{GradeID: id, GradeLevel: level}, nil
}

// Update 修改成绩。
func (s *sGrade) Update(ctx context.Context, in model.GradeUpdateInput) (*model.GradeUpdateOutput, error) {
	if in.GradeID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "成绩ID必须大于0")
	}
	if err := validateScore(in.Score); err != nil {
		return nil, err
	}
	level := CalculateGradeLevel(in.Score)
	if ok := store.Default().UpdateGrade(in, level); !ok {
		return nil, gerror.NewCode(codes.CodeBusinessValidationFailed, "成绩不存在")
	}
	return &model.GradeUpdateOutput{GradeLevel: level}, nil
}

// ListStudentGrades 查询学生成绩。
func (s *sGrade) ListStudentGrades(ctx context.Context, studentID int64) ([]model.StudentGrade, error) {
	if studentID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "学生ID必须大于0")
	}
	return store.Default().ListStudentGrades(studentID), nil
}

// CalculateGradeLevel 根据分数计算成绩等级。
func CalculateGradeLevel(score float64) string {
	switch {
	case score >= 90:
		return "A"
	case score >= 80:
		return "B"
	case score >= 70:
		return "C"
	case score >= 60:
		return "D"
	default:
		return "F"
	}
}

func validateSubmit(studentID, courseID int64, score float64) error {
	if studentID <= 0 || courseID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学生ID和课程ID必须大于0")
	}
	return validateScore(score)
}

func validateScore(score float64) error {
	if score < 0 || score > 100 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "分数范围必须为0到100")
	}
	return nil
}
