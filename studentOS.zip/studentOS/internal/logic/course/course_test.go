package course

import (
	"context"
	"testing"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestCreateCourseSuccess(t *testing.T) {
	store.ResetForTest()
	id, err := New().Create(context.Background(), validCourse())
	if err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	if id == 0 {
		t.Fatalf("Create() id = 0")
	}
}

func TestCreateCourseDuplicateCode(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	course := New()
	if _, err := course.Create(ctx, validCourse()); err != nil {
		t.Fatalf("Create() first error = %v", err)
	}
	_, err := course.Create(ctx, validCourse())
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestCreateCourseInvalidCapacity(t *testing.T) {
	store.ResetForTest()
	in := validCourse()
	in.Capacity = 0
	_, err := New().Create(context.Background(), in)
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestGetListUpdateAndStatusCourse(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	course := New()
	id, err := course.Create(ctx, validCourse())
	if err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	got, err := course.Get(ctx, id)
	if err != nil {
		t.Fatalf("Get() error = %v", err)
	}
	if got.CourseCode != "CS101" {
		t.Fatalf("CourseCode = %s", got.CourseCode)
	}
	list, err := course.List(ctx, model.CourseListInput{Page: 1, Size: 10, CourseName: "Go"})
	if err != nil {
		t.Fatalf("List() error = %v", err)
	}
	if list.Total != 1 {
		t.Fatalf("List() total = %d", list.Total)
	}
	if err := course.Update(ctx, model.CourseUpdateInput{
		CourseID:    id,
		CourseName:  "Go 微服务开发",
		TeacherID:   1002,
		TeacherName: "王老师",
		Credit:      4,
		Capacity:    3,
	}); err != nil {
		t.Fatalf("Update() error = %v", err)
	}
	if err := course.UpdateStatus(ctx, model.CourseStatusInput{CourseID: id, Status: model.CourseStatusDisabled}); err != nil {
		t.Fatalf("UpdateStatus() error = %v", err)
	}
}

func TestGetCourseNotFound(t *testing.T) {
	store.ResetForTest()
	_, err := New().Get(context.Background(), 404)
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestCourseInvalidBranches(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	svc := New()
	in := validCourse()
	in.CourseCode = ""
	if _, err := svc.Create(ctx, in); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid course code, got %v", gerror.Code(err))
	}
	in = validCourse()
	in.TeacherID = 0
	if _, err := svc.Create(ctx, in); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid teacher, got %v", gerror.Code(err))
	}
	if _, err := svc.List(ctx, model.CourseListInput{Page: 1, Size: 101}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid page size, got %v", gerror.Code(err))
	}
	if err := svc.Update(ctx, model.CourseUpdateInput{CourseID: 404, CourseName: "Go", TeacherID: 1, TeacherName: "李老师", Credit: 1, Capacity: 1}); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected update not found, got %v", gerror.Code(err))
	}
	if err := svc.UpdateStatus(ctx, model.CourseStatusInput{CourseID: 1, Status: 9}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid status, got %v", gerror.Code(err))
	}
	if err := svc.Update(ctx, model.CourseUpdateInput{}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid update id, got %v", gerror.Code(err))
	}
	for name, mutate := range map[string]func(*model.CourseCreateInput){
		"empty name":    func(in *model.CourseCreateInput) { in.CourseName = "" },
		"empty teacher": func(in *model.CourseCreateInput) { in.TeacherName = "" },
		"zero credit":   func(in *model.CourseCreateInput) { in.Credit = 0 },
	} {
		item := validCourse()
		mutate(&item)
		if _, err := svc.Create(ctx, item); gerror.Code(err) != gcode.CodeInvalidParameter {
			t.Fatalf("%s: expected invalid parameter, got %v", name, gerror.Code(err))
		}
	}
}

func TestUpdateCourseCapacityLessThanSelected(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	svc := New()
	id, err := svc.Create(ctx, validCourse())
	if err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	if _, reason := store.Default().EnrollCourse(model.EnrollmentCreateInput{StudentID: 1, CourseID: id}); reason != "" {
		t.Fatalf("seed enrollment failed: %s", reason)
	}
	if _, reason := store.Default().EnrollCourse(model.EnrollmentCreateInput{StudentID: 2, CourseID: id}); reason != "" {
		t.Fatalf("seed enrollment failed: %s", reason)
	}
	err = svc.Update(ctx, model.CourseUpdateInput{
		CourseID:    id,
		CourseName:  "Go",
		TeacherID:   1,
		TeacherName: "李老师",
		Credit:      1,
		Capacity:    1,
	})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected capacity business error, got %v", gerror.Code(err))
	}
	err = svc.Update(ctx, model.CourseUpdateInput{
		CourseID:    id,
		CourseName:  "Go",
		TeacherID:   1,
		TeacherName: "李老师",
		Credit:      1,
		Capacity:    2,
	})
	if err != nil {
		t.Fatalf("Update() with equal capacity error = %v", err)
	}
}

func validCourse() model.CourseCreateInput {
	return model.CourseCreateInput{
		CourseCode:  "CS101",
		CourseName:  "Go 后端开发",
		TeacherID:   1001,
		TeacherName: "李老师",
		Credit:      3,
		Capacity:    2,
	}
}
