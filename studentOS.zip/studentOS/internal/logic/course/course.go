package course

import (
	"context"
	"strings"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/service"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

// sCourse 课程业务逻辑实现。
type sCourse struct{}

func init() {
	service.RegisterCourse(New())
}

// New 创建课程业务逻辑实例。
func New() *sCourse {
	return &sCourse{}
}

// Create 创建课程。
func (s *sCourse) Create(ctx context.Context, in model.CourseCreateInput) (int64, error) {
	if err := validateCourseCreate(in); err != nil {
		return 0, err
	}
	id, duplicate := store.Default().CreateCourse(in)
	if duplicate {
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程编号已存在")
	}
	return id, nil
}

// Get 查询课程详情。
func (s *sCourse) Get(ctx context.Context, courseID int64) (*model.Course, error) {
	if courseID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "课程ID必须大于0")
	}
	course, ok := store.Default().GetCourse(courseID)
	if !ok {
		return nil, gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	}
	return &course, nil
}

// List 分页查询课程。
func (s *sCourse) List(ctx context.Context, in model.CourseListInput) (*model.CourseListOutput, error) {
	if in.Page <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "页码不能小于1")
	}
	if in.Size <= 0 || in.Size > 100 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "分页大小范围为1到100")
	}
	out := store.Default().ListCourses(in)
	return &out, nil
}

// Update 修改课程信息。
func (s *sCourse) Update(ctx context.Context, in model.CourseUpdateInput) error {
	if in.CourseID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程ID必须大于0")
	}
	if err := validateCourseBase(in.CourseName, in.TeacherID, in.TeacherName, in.Credit, in.Capacity); err != nil {
		return err
	}
	course, ok := store.Default().GetCourse(in.CourseID)
	if !ok {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	}
	if in.Capacity < course.SelectedCount {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程容量不能小于已选人数")
	}
	if ok := store.Default().UpdateCourse(in); !ok {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	}
	return nil
}

// UpdateStatus 修改课程状态。
func (s *sCourse) UpdateStatus(ctx context.Context, in model.CourseStatusInput) error {
	if in.CourseID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程ID必须大于0")
	}
	if in.Status != model.CourseStatusActive && in.Status != model.CourseStatusDisabled {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程状态不合法")
	}
	if ok := store.Default().UpdateCourseStatus(in); !ok {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "课程不存在")
	}
	return nil
}

func validateCourseCreate(in model.CourseCreateInput) error {
	if strings.TrimSpace(in.CourseCode) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程编号不能为空")
	}
	return validateCourseBase(in.CourseName, in.TeacherID, in.TeacherName, in.Credit, in.Capacity)
}

func validateCourseBase(courseName string, teacherID int64, teacherName string, credit float64, capacity int32) error {
	if strings.TrimSpace(courseName) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程名称不能为空")
	}
	if teacherID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "教师ID必须大于0")
	}
	if strings.TrimSpace(teacherName) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "教师姓名不能为空")
	}
	if credit <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学分必须大于0")
	}
	if capacity <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "课程容量必须大于0")
	}
	return nil
}
