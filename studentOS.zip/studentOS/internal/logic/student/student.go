package student

import (
	"context"
	"strings"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/service"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

// sStudent 学生业务逻辑实现。
type sStudent struct{}

func init() {
	service.RegisterStudent(New())
}

// New 创建学生业务逻辑实例。
func New() *sStudent {
	return &sStudent{}
}

// Create 创建学生。
func (s *sStudent) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	if err := validateStudentBase(in.StudentNo, in.Name, in.Gender, in.ClassName, in.Major, in.College); err != nil {
		return 0, err
	}
	id, duplicate, err := store.Default().CreateStudent(ctx, in)
	if err != nil {
		return 0, gerror.WrapCode(gcode.CodeInternalError, err, "学生数据写入失败")
	}
	if duplicate {
		return 0, gerror.NewCode(codes.CodeBusinessValidationFailed, "学号已存在")
	}
	return id, nil
}

// Get 查询学生详情。
func (s *sStudent) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	if studentID <= 0 {
		return nil, gerror.NewCode(gcode.CodeInvalidParameter, "学生ID必须大于0")
	}
	student, ok, err := store.Default().GetStudent(ctx, studentID)
	if err != nil {
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "学生数据读取失败")
	}
	if !ok {
		return nil, gerror.NewCode(codes.CodeBusinessValidationFailed, "学生不存在")
	}
	return &student, nil
}

// List 分页查询学生。
func (s *sStudent) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	if err := validatePage(in.Page, in.Size); err != nil {
		return nil, err
	}
	out, err := store.Default().ListStudents(ctx, in)
	if err != nil {
		return nil, gerror.WrapCode(gcode.CodeInternalError, err, "学生列表读取失败")
	}
	return &out, nil
}

// Update 修改学生信息。
func (s *sStudent) Update(ctx context.Context, in model.StudentUpdateInput) error {
	if in.StudentID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学生ID必须大于0")
	}
	if err := validateStudentBase("skip", in.Name, in.Gender, in.ClassName, in.Major, in.College); err != nil {
		return err
	}
	ok, err := store.Default().UpdateStudent(ctx, in)
	if err != nil {
		return gerror.WrapCode(gcode.CodeInternalError, err, "学生数据更新失败")
	}
	if !ok {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "学生不存在")
	}
	return nil
}

// UpdateStatus 修改学生状态。
func (s *sStudent) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	if in.StudentID <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学生ID必须大于0")
	}
	if in.Status != model.StudentStatusActive && in.Status != model.StudentStatusDisabled {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学生状态不合法")
	}
	ok, err := store.Default().UpdateStudentStatus(ctx, in)
	if err != nil {
		return gerror.WrapCode(gcode.CodeInternalError, err, "学生状态更新失败")
	}
	if !ok {
		return gerror.NewCode(codes.CodeBusinessValidationFailed, "学生不存在")
	}
	return nil
}

// CheckActive 校验学生是否存在且启用。
func (s *sStudent) CheckActive(ctx context.Context, studentID int64) (bool, error) {
	student, err := s.Get(ctx, studentID)
	if err != nil {
		return false, err
	}
	return student.Status == model.StudentStatusActive, nil
}

func validateStudentBase(studentNo, name string, gender int32, className, major, college string) error {
	if strings.TrimSpace(studentNo) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学号不能为空")
	}
	if strings.TrimSpace(name) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "姓名不能为空")
	}
	if gender != 0 && gender != 1 && gender != 2 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "性别值不合法")
	}
	if strings.TrimSpace(className) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "班级不能为空")
	}
	if strings.TrimSpace(major) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "专业不能为空")
	}
	if strings.TrimSpace(college) == "" {
		return gerror.NewCode(gcode.CodeInvalidParameter, "学院不能为空")
	}
	return nil
}

func validatePage(page, size int) error {
	if page <= 0 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "页码不能小于1")
	}
	if size <= 0 || size > 100 {
		return gerror.NewCode(gcode.CodeInvalidParameter, "分页大小范围为1到100")
	}
	return nil
}
