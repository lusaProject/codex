package student

import (
	"context"
	"testing"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/errors/gcode"
	"github.com/gogf/gf/v2/errors/gerror"
)

func TestCreateStudentSuccess(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	id, err := New().Create(ctx, validStudent())
	if err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	if id == 0 {
		t.Fatalf("Create() id = 0")
	}
}

func TestCreateStudentDuplicateNo(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	student := New()
	if _, err := student.Create(ctx, validStudent()); err != nil {
		t.Fatalf("Create() first error = %v", err)
	}
	_, err := student.Create(ctx, validStudent())
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestCreateStudentInvalidName(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	in := validStudent()
	in.Name = ""
	_, err := New().Create(ctx, in)
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestGetStudentNotFound(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	_, err := New().Get(ctx, 999)
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestListUpdateAndStatus(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	student := New()
	id, err := student.Create(ctx, validStudent())
	if err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	list, err := student.List(ctx, model.StudentListInput{Page: 1, Size: 10, Name: "张"})
	if err != nil {
		t.Fatalf("List() error = %v", err)
	}
	if list.Total != 1 {
		t.Fatalf("List() total = %d", list.Total)
	}
	if err := student.Update(ctx, model.StudentUpdateInput{
		StudentID: id,
		Name:      "李四",
		Gender:    2,
		ClassName: "软件二班",
		Major:     "软件工程",
		College:   "计算机学院",
	}); err != nil {
		t.Fatalf("Update() error = %v", err)
	}
	if err := student.UpdateStatus(ctx, model.StudentStatusInput{StudentID: id, Status: model.StudentStatusDisabled}); err != nil {
		t.Fatalf("UpdateStatus() error = %v", err)
	}
	active, err := student.CheckActive(ctx, id)
	if err != nil {
		t.Fatalf("CheckActive() error = %v", err)
	}
	if active {
		t.Fatalf("CheckActive() active = true")
	}
}

func TestListInvalidPage(t *testing.T) {
	store.ResetForTest()
	_, err := New().List(context.Background(), model.StudentListInput{Page: 0, Size: 10})
	if gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid parameter, got %v", gerror.Code(err))
	}
}

func TestStudentInvalidBranches(t *testing.T) {
	store.ResetForTest()
	ctx := context.Background()
	svc := New()
	in := validStudent()
	in.Gender = 9
	if _, err := svc.Create(ctx, in); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid gender, got %v", gerror.Code(err))
	}
	if err := svc.Update(ctx, model.StudentUpdateInput{StudentID: 404, Name: "李四", ClassName: "一班", Major: "软件工程", College: "计算机学院"}); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected update not found, got %v", gerror.Code(err))
	}
	if err := svc.UpdateStatus(ctx, model.StudentStatusInput{StudentID: 1, Status: 9}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid status, got %v", gerror.Code(err))
	}
	if _, err := svc.CheckActive(ctx, 404); gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected check active not found, got %v", gerror.Code(err))
	}
	if err := svc.Update(ctx, model.StudentUpdateInput{}); gerror.Code(err) != gcode.CodeInvalidParameter {
		t.Fatalf("expected invalid update id, got %v", gerror.Code(err))
	}
	for name, mutate := range map[string]func(*model.StudentCreateInput){
		"empty class":   func(in *model.StudentCreateInput) { in.ClassName = "" },
		"empty major":   func(in *model.StudentCreateInput) { in.Major = "" },
		"empty college": func(in *model.StudentCreateInput) { in.College = "" },
	} {
		item := validStudent()
		mutate(&item)
		if _, err := svc.Create(ctx, item); gerror.Code(err) != gcode.CodeInvalidParameter {
			t.Fatalf("%s: expected invalid parameter, got %v", name, gerror.Code(err))
		}
	}
}

func validStudent() model.StudentCreateInput {
	return model.StudentCreateInput{
		StudentNo: "S20260001",
		Name:      "张三",
		Gender:    1,
		ClassName: "软件一班",
		Major:     "软件工程",
		College:   "计算机学院",
		Mobile:    "13800138000",
		Email:     "zhangsan@example.com",
	}
}
