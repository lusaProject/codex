package store

import (
	"context"
	"errors"
	"testing"
	"time"

	"student-management/internal/model"
)

func TestTieredStudentStorageCacheAside(t *testing.T) {
	ctx := context.Background()
	base := NewMemoryStudentStorage()
	id, duplicate, err := base.Create(ctx, testStudentCreateInput())
	if err != nil || duplicate {
		t.Fatalf("seed student error=%v duplicate=%v", err, duplicate)
	}
	cold := &countingStudentStorage{StudentStorage: base}
	l1 := NewMemoryStudentCache(time.Hour)
	l2 := NewMemoryStudentCache(time.Hour)
	storage := NewTieredStudentStorage(l1, l2, cold)

	if _, ok, err := storage.Get(ctx, id); err != nil || !ok {
		t.Fatalf("first Get() ok=%v err=%v", ok, err)
	}
	if cold.getCount != 1 {
		t.Fatalf("cold get count=%d, want 1", cold.getCount)
	}
	if _, ok, _ := l1.Get(ctx, id); !ok {
		t.Fatalf("student was not warmed into L1 cache")
	}
	if _, ok, _ := l2.Get(ctx, id); !ok {
		t.Fatalf("student was not warmed into L2 cache")
	}

	if _, ok, err := storage.Get(ctx, id); err != nil || !ok {
		t.Fatalf("second Get() ok=%v err=%v", ok, err)
	}
	if cold.getCount != 1 {
		t.Fatalf("second Get() should hit L1, cold get count=%d", cold.getCount)
	}

	if err := l1.Delete(ctx, id); err != nil {
		t.Fatalf("delete L1 error=%v", err)
	}
	if _, ok, err := storage.Get(ctx, id); err != nil || !ok {
		t.Fatalf("third Get() ok=%v err=%v", ok, err)
	}
	if cold.getCount != 1 {
		t.Fatalf("third Get() should hit L2, cold get count=%d", cold.getCount)
	}
}

func TestTieredStudentStorageWriteThroughCache(t *testing.T) {
	ctx := context.Background()
	l1 := NewMemoryStudentCache(time.Hour)
	l2 := NewMemoryStudentCache(time.Hour)
	storage := NewTieredStudentStorage(l1, l2, NewMemoryStudentStorage())

	id, duplicate, err := storage.Create(ctx, testStudentCreateInput())
	if err != nil || duplicate {
		t.Fatalf("Create() error=%v duplicate=%v", err, duplicate)
	}
	if student, ok, _ := l1.Get(ctx, id); !ok || student.StudentNo == "" {
		t.Fatalf("student was not written through to L1 cache")
	}
	if student, ok, _ := l2.Get(ctx, id); !ok || student.StudentNo == "" {
		t.Fatalf("student was not written through to L2 cache")
	}

	ok, err := storage.UpdateStatus(ctx, model.StudentStatusInput{
		StudentID: id,
		Status:    model.StudentStatusDisabled,
	})
	if err != nil || !ok {
		t.Fatalf("UpdateStatus() ok=%v err=%v", ok, err)
	}
	student, ok, err := storage.Get(ctx, id)
	if err != nil || !ok {
		t.Fatalf("Get() after UpdateStatus ok=%v err=%v", ok, err)
	}
	if student.Status != model.StudentStatusDisabled {
		t.Fatalf("student status=%d, want disabled", student.Status)
	}
}

func TestTieredStudentStorageInvalidatesStaleCacheWhenRedisSetFails(t *testing.T) {
	ctx := context.Background()
	l1 := NewMemoryStudentCache(time.Hour)
	l2 := NewMemoryStudentCache(time.Hour)
	storage := NewTieredStudentStorage(l1, &setFailingStudentCache{studentCache: l2}, NewMemoryStudentStorage())

	id, duplicate, err := storage.Create(ctx, testStudentCreateInput())
	if err != nil || duplicate {
		t.Fatalf("Create() error=%v duplicate=%v", err, duplicate)
	}
	stale := model.Student{StudentID: id, Status: model.StudentStatusActive}
	if err := l2.Set(ctx, stale); err != nil {
		t.Fatalf("seed stale L2 cache error=%v", err)
	}

	ok, err := storage.UpdateStatus(ctx, model.StudentStatusInput{
		StudentID: id,
		Status:    model.StudentStatusDisabled,
	})
	if err != nil || !ok {
		t.Fatalf("UpdateStatus() ok=%v err=%v", ok, err)
	}
	if err := l1.Delete(ctx, id); err != nil {
		t.Fatalf("delete L1 error=%v", err)
	}
	student, ok, err := storage.Get(ctx, id)
	if err != nil || !ok {
		t.Fatalf("Get() after stale L2 invalidation ok=%v err=%v", ok, err)
	}
	if student.Status != model.StudentStatusDisabled {
		t.Fatalf("student status=%d, want disabled; stale L2 cache was returned", student.Status)
	}
}

type countingStudentStorage struct {
	StudentStorage
	getCount int
}

func (s *countingStudentStorage) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	s.getCount++
	return s.StudentStorage.Get(ctx, id)
}

type setFailingStudentCache struct {
	studentCache
}

func (c *setFailingStudentCache) Set(ctx context.Context, student model.Student) error {
	return errors.New("set failed")
}

func testStudentCreateInput() model.StudentCreateInput {
	return model.StudentCreateInput{
		StudentNo: "S20260001",
		Name:      "Test Student",
		Gender:    1,
		ClassName: "Class One",
		Major:     "Software Engineering",
		College:   "Computer Science",
		Mobile:    "13800138000",
		Email:     "student@example.com",
	}
}
