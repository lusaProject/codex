package store

import (
	"context"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"student-management/internal/model"
)

// Store provides thread-safe business storage orchestration.
type Store struct {
	mu sync.RWMutex

	studentStorage StudentStorage

	nextCourseID    int64
	courses         map[int64]*model.Course
	courseCodeIndex map[string]int64

	nextEnrollmentID int64
	enrollments      map[int64]*model.Enrollment
	enrollmentIndex  map[string]int64

	nextGradeID int64
	grades      map[int64]*model.Grade
	gradeIndex  map[string]int64
}

var defaultStore = New()

// New creates a store. Tests and local units use memory student storage by default.
func New() *Store {
	return &Store{
		studentStorage:   NewMemoryStudentStorage(),
		nextCourseID:     1,
		courses:          make(map[int64]*model.Course),
		courseCodeIndex:  make(map[string]int64),
		nextEnrollmentID: 1,
		enrollments:      make(map[int64]*model.Enrollment),
		enrollmentIndex:  make(map[string]int64),
		nextGradeID:      1,
		grades:           make(map[int64]*model.Grade),
		gradeIndex:       make(map[string]int64),
	}
}

// Default returns the process-wide store.
func Default() *Store {
	return defaultStore
}

// ResetForTest resets default storage for unit tests.
func ResetForTest() {
	defaultStore = New()
}

// UseStudentStorage replaces the default student storage implementation.
func UseStudentStorage(storage StudentStorage) {
	defaultStore.SetStudentStorage(storage)
}

// EnableProductionStudentStorage enables L1 memory + L2 Redis + L3 MySQL.
func EnableProductionStudentStorage() {
	UseStudentStorage(NewProductionStudentStorage())
}

// SetStudentStorage sets the current store student storage.
func (s *Store) SetStudentStorage(storage StudentStorage) {
	if storage == nil {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.studentStorage = storage
}

func (s *Store) getStudentStorage() StudentStorage {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.studentStorage
}

// ReplaceAcademicSnapshot replaces in-memory academic data with a database snapshot.
func (s *Store) ReplaceAcademicSnapshot(courses []model.Course, enrollments []model.Enrollment, grades []model.Grade) {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.courses = make(map[int64]*model.Course, len(courses))
	s.courseCodeIndex = make(map[string]int64, len(courses))
	s.nextCourseID = 1
	for _, item := range courses {
		course := item
		s.courses[course.CourseID] = &course
		s.courseCodeIndex[course.CourseCode] = course.CourseID
		if course.CourseID >= s.nextCourseID {
			s.nextCourseID = course.CourseID + 1
		}
	}

	s.enrollments = make(map[int64]*model.Enrollment, len(enrollments))
	s.enrollmentIndex = make(map[string]int64, len(enrollments))
	s.nextEnrollmentID = 1
	for _, item := range enrollments {
		enrollment := item
		s.enrollments[enrollment.EnrollmentID] = &enrollment
		s.enrollmentIndex[enrollmentKey(enrollment.StudentID, enrollment.CourseID)] = enrollment.EnrollmentID
		if enrollment.EnrollmentID >= s.nextEnrollmentID {
			s.nextEnrollmentID = enrollment.EnrollmentID + 1
		}
	}

	s.grades = make(map[int64]*model.Grade, len(grades))
	s.gradeIndex = make(map[string]int64, len(grades))
	s.nextGradeID = 1
	for _, item := range grades {
		grade := item
		s.grades[grade.GradeID] = &grade
		s.gradeIndex[gradeKey(grade.StudentID, grade.CourseID)] = grade.GradeID
		if grade.GradeID >= s.nextGradeID {
			s.nextGradeID = grade.GradeID + 1
		}
	}
}

// CreateStudent creates a student through the configured student storage.
func (s *Store) CreateStudent(ctx context.Context, in model.StudentCreateInput) (int64, bool, error) {
	return s.getStudentStorage().Create(ctx, in)
}

// GetStudent gets a student through the configured student storage.
func (s *Store) GetStudent(ctx context.Context, id int64) (model.Student, bool, error) {
	return s.getStudentStorage().Get(ctx, id)
}

// ListStudents lists students through the configured student storage.
func (s *Store) ListStudents(ctx context.Context, in model.StudentListInput) (model.StudentListOutput, error) {
	return s.getStudentStorage().List(ctx, in)
}

// UpdateStudent updates a student through the configured student storage.
func (s *Store) UpdateStudent(ctx context.Context, in model.StudentUpdateInput) (bool, error) {
	return s.getStudentStorage().Update(ctx, in)
}

// UpdateStudentStatus updates student status through the configured student storage.
func (s *Store) UpdateStudentStatus(ctx context.Context, in model.StudentStatusInput) (bool, error) {
	return s.getStudentStorage().UpdateStatus(ctx, in)
}

// CreateCourse creates a course.
func (s *Store) CreateCourse(in model.CourseCreateInput) (int64, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.courseCodeIndex[in.CourseCode]; ok {
		return 0, true
	}
	now := unixNow()
	id := s.nextCourseID
	s.nextCourseID++
	s.courses[id] = &model.Course{
		CourseID:      id,
		CourseCode:    in.CourseCode,
		CourseName:    in.CourseName,
		TeacherID:     in.TeacherID,
		TeacherName:   in.TeacherName,
		Credit:        in.Credit,
		Capacity:      in.Capacity,
		SelectedCount: 0,
		Status:        model.CourseStatusActive,
		CreatedAt:     now,
		UpdatedAt:     now,
	}
	s.courseCodeIndex[in.CourseCode] = id
	return id, false
}

// GetCourse gets a course.
func (s *Store) GetCourse(id int64) (model.Course, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	course, ok := s.courses[id]
	if !ok {
		return model.Course{}, false
	}
	return *course, true
}

// ListCourses lists courses.
func (s *Store) ListCourses(in model.CourseListInput) model.CourseListOutput {
	s.mu.RLock()
	defer s.mu.RUnlock()
	list := make([]model.Course, 0, len(s.courses))
	for _, item := range s.courses {
		if in.CourseName != "" && !strings.Contains(item.CourseName, in.CourseName) {
			continue
		}
		if in.TeacherID != 0 && item.TeacherID != in.TeacherID {
			continue
		}
		if in.Status != 0 && item.Status != in.Status {
			continue
		}
		list = append(list, *item)
	}
	sort.Slice(list, func(i, j int) bool { return list[i].CourseID < list[j].CourseID })
	total := len(list)
	return model.CourseListOutput{List: pageSlice(list, in.Page, in.Size), Total: total}
}

// UpdateCourse updates a course.
func (s *Store) UpdateCourse(in model.CourseUpdateInput) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	course, ok := s.courses[in.CourseID]
	if !ok {
		return false
	}
	course.CourseName = in.CourseName
	course.TeacherID = in.TeacherID
	course.TeacherName = in.TeacherName
	course.Credit = in.Credit
	course.Capacity = in.Capacity
	course.UpdatedAt = unixNow()
	return true
}

// UpdateCourseStatus updates course status.
func (s *Store) UpdateCourseStatus(in model.CourseStatusInput) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	course, ok := s.courses[in.CourseID]
	if !ok {
		return false
	}
	course.Status = in.Status
	course.UpdatedAt = unixNow()
	return true
}

// EnrollCourse atomically enrolls a student and increments course selected count.
func (s *Store) EnrollCourse(in model.EnrollmentCreateInput) (int64, string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	course, ok := s.courses[in.CourseID]
	if !ok {
		return 0, "course_not_found"
	}
	if course.Status != model.CourseStatusActive {
		return 0, "course_disabled"
	}
	if course.SelectedCount >= course.Capacity {
		return 0, "course_full"
	}
	key := enrollmentKey(in.StudentID, in.CourseID)
	if id, ok := s.enrollmentIndex[key]; ok {
		existing := s.enrollments[id]
		if existing.Status == model.EnrollmentStatusSelected {
			return 0, "duplicate"
		}
		now := unixNow()
		existing.Status = model.EnrollmentStatusSelected
		existing.UpdatedAt = now
		course.SelectedCount++
		course.UpdatedAt = now
		return id, ""
	}
	now := unixNow()
	id := s.nextEnrollmentID
	s.nextEnrollmentID++
	s.enrollments[id] = &model.Enrollment{
		EnrollmentID: id,
		StudentID:    in.StudentID,
		CourseID:     in.CourseID,
		Status:       model.EnrollmentStatusSelected,
		CreatedAt:    now,
		UpdatedAt:    now,
	}
	s.enrollmentIndex[key] = id
	course.SelectedCount++
	course.UpdatedAt = now
	return id, ""
}

// DropEnrollment atomically drops an enrollment and decrements course selected count.
func (s *Store) DropEnrollment(id int64) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	enrollment, ok := s.enrollments[id]
	if !ok {
		return "enrollment_not_found"
	}
	if enrollment.Status == model.EnrollmentStatusDropped {
		return "already_dropped"
	}
	course, ok := s.courses[enrollment.CourseID]
	if !ok {
		return "course_not_found"
	}
	now := unixNow()
	enrollment.Status = model.EnrollmentStatusDropped
	enrollment.UpdatedAt = now
	if course.SelectedCount > 0 {
		course.SelectedCount--
	}
	course.UpdatedAt = now
	return ""
}

// HasActiveEnrollment checks whether a student has selected a course.
func (s *Store) HasActiveEnrollment(studentID, courseID int64) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	id, ok := s.enrollmentIndex[enrollmentKey(studentID, courseID)]
	return ok && s.enrollments[id].Status == model.EnrollmentStatusSelected
}

// ListStudentCourses lists selected courses for a student.
func (s *Store) ListStudentCourses(studentID int64) []model.StudentCourse {
	s.mu.RLock()
	defer s.mu.RUnlock()
	list := make([]model.StudentCourse, 0)
	for _, enrollment := range s.enrollments {
		if enrollment.StudentID != studentID || enrollment.Status != model.EnrollmentStatusSelected {
			continue
		}
		course, ok := s.courses[enrollment.CourseID]
		if !ok {
			continue
		}
		list = append(list, model.StudentCourse{
			EnrollmentID: enrollment.EnrollmentID,
			Course:       *course,
			EnrolledAt:   enrollment.CreatedAt,
		})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].EnrollmentID < list[j].EnrollmentID })
	return list
}

// ListCourseStudents lists active students for a course.
func (s *Store) ListCourseStudents(ctx context.Context, courseID int64) ([]model.CourseStudent, error) {
	s.mu.RLock()
	enrollments := make([]model.Enrollment, 0)
	for _, enrollment := range s.enrollments {
		if enrollment.CourseID != courseID || enrollment.Status != model.EnrollmentStatusSelected {
			continue
		}
		enrollments = append(enrollments, *enrollment)
	}
	s.mu.RUnlock()

	list := make([]model.CourseStudent, 0, len(enrollments))
	for _, enrollment := range enrollments {
		student, ok, err := s.GetStudent(ctx, enrollment.StudentID)
		if err != nil {
			return nil, err
		}
		if !ok {
			continue
		}
		list = append(list, model.CourseStudent{
			EnrollmentID: enrollment.EnrollmentID,
			StudentID:    student.StudentID,
			StudentNo:    student.StudentNo,
			Name:         student.Name,
			ClassName:    student.ClassName,
			EnrolledAt:   enrollment.CreatedAt,
		})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].EnrollmentID < list[j].EnrollmentID })
	return list, nil
}

// SubmitGrade inserts or updates a grade.
func (s *Store) SubmitGrade(in model.GradeSubmitInput, gradeLevel string) (int64, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	key := gradeKey(in.StudentID, in.CourseID)
	now := unixNow()
	if id, ok := s.gradeIndex[key]; ok {
		grade := s.grades[id]
		grade.Score = in.Score
		grade.GradeLevel = gradeLevel
		grade.Remark = in.Remark
		grade.UpdatedAt = now
		return id, true
	}
	id := s.nextGradeID
	s.nextGradeID++
	s.grades[id] = &model.Grade{
		GradeID:    id,
		StudentID:  in.StudentID,
		CourseID:   in.CourseID,
		Score:      in.Score,
		GradeLevel: gradeLevel,
		Remark:     in.Remark,
		CreatedAt:  now,
		UpdatedAt:  now,
	}
	s.gradeIndex[key] = id
	return id, false
}

// UpdateGrade updates a grade.
func (s *Store) UpdateGrade(in model.GradeUpdateInput, gradeLevel string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	grade, ok := s.grades[in.GradeID]
	if !ok {
		return false
	}
	grade.Score = in.Score
	grade.GradeLevel = gradeLevel
	grade.Remark = in.Remark
	grade.UpdatedAt = unixNow()
	return true
}

// ListStudentGrades lists grades for a student.
func (s *Store) ListStudentGrades(studentID int64) []model.StudentGrade {
	s.mu.RLock()
	defer s.mu.RUnlock()
	list := make([]model.StudentGrade, 0)
	for _, grade := range s.grades {
		if grade.StudentID != studentID {
			continue
		}
		course, ok := s.courses[grade.CourseID]
		if !ok {
			continue
		}
		list = append(list, model.StudentGrade{Grade: *grade, Course: *course})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].Grade.GradeID < list[j].Grade.GradeID })
	return list
}

func unixNow() int64 {
	return time.Now().Unix()
}

func enrollmentKey(studentID, courseID int64) string {
	return strconv.FormatInt(studentID, 10) + ":" + strconv.FormatInt(courseID, 10)
}

func gradeKey(studentID, courseID int64) string {
	return strconv.FormatInt(studentID, 10) + ":" + strconv.FormatInt(courseID, 10)
}

func pageSlice[T any](list []T, page, size int) []T {
	if page <= 0 {
		page = 1
	}
	if size <= 0 {
		size = 10
	}
	start := (page - 1) * size
	if start >= len(list) {
		return []T{}
	}
	end := start + size
	if end > len(list) {
		end = len(list)
	}
	return list[start:end]
}
