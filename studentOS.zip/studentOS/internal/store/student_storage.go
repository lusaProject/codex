package store

import (
	"context"
	"encoding/json"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"student-management/internal/model"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/database/gredis"
	"github.com/gogf/gf/v2/frame/g"
)

const (
	studentCacheKeyPrefix = "student-management:student:"
	studentCacheTTL       = 10 * time.Minute
	studentTable          = "students"
)

// StudentStorage defines the full student data storage contract.
type StudentStorage interface {
	Create(ctx context.Context, in model.StudentCreateInput) (id int64, duplicate bool, err error)
	Get(ctx context.Context, id int64) (model.Student, bool, error)
	List(ctx context.Context, in model.StudentListInput) (model.StudentListOutput, error)
	Update(ctx context.Context, in model.StudentUpdateInput) (bool, error)
	UpdateStatus(ctx context.Context, in model.StudentStatusInput) (bool, error)
}

type studentCache interface {
	Get(ctx context.Context, id int64) (model.Student, bool, error)
	Set(ctx context.Context, student model.Student) error
	Delete(ctx context.Context, id int64) error
}

// NewProductionStudentStorage creates L1 memory cache + L2 Redis cache + L3 MySQL cold storage.
func NewProductionStudentStorage() StudentStorage {
	return NewTieredStudentStorage(
		NewMemoryStudentCache(studentCacheTTL),
		NewRedisStudentCache(g.Redis(), studentCacheTTL),
		NewMySQLStudentStorage(g.DB()),
	)
}

// NewTieredStudentStorage builds a cache-aside student storage chain.
func NewTieredStudentStorage(memory studentCache, redis studentCache, cold StudentStorage) StudentStorage {
	if cold == nil {
		cold = NewMemoryStudentStorage()
	}
	return &tieredStudentStorage{
		memory: memory,
		redis:  redis,
		cold:   cold,
	}
}

type tieredStudentStorage struct {
	memory studentCache
	redis  studentCache
	cold   StudentStorage
}

func (s *tieredStudentStorage) Create(ctx context.Context, in model.StudentCreateInput) (int64, bool, error) {
	id, duplicate, err := s.cold.Create(ctx, in)
	if err != nil || duplicate {
		return id, duplicate, err
	}
	student, ok, err := s.cold.Get(ctx, id)
	if err != nil {
		return 0, false, err
	}
	if ok {
		s.warm(ctx, student)
	}
	return id, false, nil
}

func (s *tieredStudentStorage) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	if s.memory != nil {
		student, ok, err := s.memory.Get(ctx, id)
		if err != nil {
			g.Log().Warningf(ctx, "student memory cache get failed: %+v", err)
		} else if ok {
			return student, true, nil
		}
	}
	if s.redis != nil {
		student, ok, err := s.redis.Get(ctx, id)
		if err != nil {
			g.Log().Warningf(ctx, "student redis cache get failed: %+v", err)
		} else if ok {
			s.setMemory(ctx, student)
			return student, true, nil
		}
	}
	student, ok, err := s.cold.Get(ctx, id)
	if err != nil || !ok {
		return student, ok, err
	}
	s.warm(ctx, student)
	return student, true, nil
}

func (s *tieredStudentStorage) List(ctx context.Context, in model.StudentListInput) (model.StudentListOutput, error) {
	out, err := s.cold.List(ctx, in)
	if err != nil {
		return model.StudentListOutput{}, err
	}
	for _, student := range out.List {
		s.warm(ctx, student)
	}
	return out, nil
}

func (s *tieredStudentStorage) Update(ctx context.Context, in model.StudentUpdateInput) (bool, error) {
	ok, err := s.cold.Update(ctx, in)
	if err != nil || !ok {
		return ok, err
	}
	if err := s.refreshCachesFromCold(ctx, in.StudentID); err != nil {
		return false, err
	}
	return true, nil
}

func (s *tieredStudentStorage) UpdateStatus(ctx context.Context, in model.StudentStatusInput) (bool, error) {
	ok, err := s.cold.UpdateStatus(ctx, in)
	if err != nil || !ok {
		return ok, err
	}
	if err := s.refreshCachesFromCold(ctx, in.StudentID); err != nil {
		return false, err
	}
	return true, nil
}

func (s *tieredStudentStorage) refreshCachesFromCold(ctx context.Context, id int64) error {
	s.invalidate(ctx, id)
	student, found, err := s.cold.Get(ctx, id)
	if err != nil {
		return err
	}
	if found {
		s.warm(ctx, student)
	}
	return nil
}

func (s *tieredStudentStorage) invalidate(ctx context.Context, id int64) {
	if s.memory != nil {
		if err := s.memory.Delete(ctx, id); err != nil {
			g.Log().Warningf(ctx, "student memory cache delete failed: %+v", err)
		}
	}
	if s.redis != nil {
		if err := s.redis.Delete(ctx, id); err != nil {
			g.Log().Warningf(ctx, "student redis cache delete failed: %+v", err)
		}
	}
}

func (s *tieredStudentStorage) warm(ctx context.Context, student model.Student) {
	if s.redis != nil {
		if err := s.redis.Set(ctx, student); err != nil {
			g.Log().Warningf(ctx, "student redis cache set failed: %+v", err)
		}
	}
	s.setMemory(ctx, student)
}

func (s *tieredStudentStorage) setMemory(ctx context.Context, student model.Student) {
	if s.memory == nil {
		return
	}
	if err := s.memory.Set(ctx, student); err != nil {
		g.Log().Warningf(ctx, "student memory cache set failed: %+v", err)
	}
}

type memoryStudentStorage struct {
	mu               sync.RWMutex
	nextID           int64
	students         map[int64]*model.Student
	studentNoIndexes map[string]int64
}

// NewMemoryStudentStorage creates a local in-memory cold store for tests and offline development.
func NewMemoryStudentStorage() StudentStorage {
	return &memoryStudentStorage{
		nextID:           1,
		students:         make(map[int64]*model.Student),
		studentNoIndexes: make(map[string]int64),
	}
}

func (s *memoryStudentStorage) Create(ctx context.Context, in model.StudentCreateInput) (int64, bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.studentNoIndexes[in.StudentNo]; ok {
		return 0, true, nil
	}
	now := unixNow()
	id := s.nextID
	s.nextID++
	s.students[id] = &model.Student{
		StudentID: id,
		StudentNo: in.StudentNo,
		Name:      in.Name,
		Gender:    in.Gender,
		ClassName: in.ClassName,
		Major:     in.Major,
		College:   in.College,
		Mobile:    in.Mobile,
		Email:     in.Email,
		Status:    model.StudentStatusActive,
		CreatedAt: now,
		UpdatedAt: now,
	}
	s.studentNoIndexes[in.StudentNo] = id
	return id, false, nil
}

func (s *memoryStudentStorage) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	student, ok := s.students[id]
	if !ok {
		return model.Student{}, false, nil
	}
	return *student, true, nil
}

func (s *memoryStudentStorage) List(ctx context.Context, in model.StudentListInput) (model.StudentListOutput, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	list := make([]model.Student, 0, len(s.students))
	for _, item := range s.students {
		if in.Name != "" && !strings.Contains(item.Name, in.Name) {
			continue
		}
		if in.ClassName != "" && item.ClassName != in.ClassName {
			continue
		}
		if in.Status != 0 && item.Status != in.Status {
			continue
		}
		list = append(list, *item)
	}
	sortStudents(list)
	return model.StudentListOutput{List: pageSlice(list, in.Page, in.Size), Total: len(list)}, nil
}

func (s *memoryStudentStorage) Update(ctx context.Context, in model.StudentUpdateInput) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	student, ok := s.students[in.StudentID]
	if !ok {
		return false, nil
	}
	student.Name = in.Name
	student.Gender = in.Gender
	student.ClassName = in.ClassName
	student.Major = in.Major
	student.College = in.College
	student.Mobile = in.Mobile
	student.Email = in.Email
	student.UpdatedAt = unixNow()
	return true, nil
}

func (s *memoryStudentStorage) UpdateStatus(ctx context.Context, in model.StudentStatusInput) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	student, ok := s.students[in.StudentID]
	if !ok {
		return false, nil
	}
	student.Status = in.Status
	student.UpdatedAt = unixNow()
	return true, nil
}

type memoryStudentCache struct {
	mu    sync.RWMutex
	ttl   time.Duration
	items map[int64]memoryStudentCacheItem
}

type memoryStudentCacheItem struct {
	student   model.Student
	expiresAt time.Time
}

// NewMemoryStudentCache creates the L1 memory cache.
func NewMemoryStudentCache(ttl time.Duration) studentCache {
	return &memoryStudentCache{
		ttl:   ttl,
		items: make(map[int64]memoryStudentCacheItem),
	}
}

func (c *memoryStudentCache) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	c.mu.RLock()
	item, ok := c.items[id]
	c.mu.RUnlock()
	if !ok {
		return model.Student{}, false, nil
	}
	if !item.expiresAt.IsZero() && time.Now().After(item.expiresAt) {
		_ = c.Delete(ctx, id)
		return model.Student{}, false, nil
	}
	return item.student, true, nil
}

func (c *memoryStudentCache) Set(ctx context.Context, student model.Student) error {
	item := memoryStudentCacheItem{student: student}
	if c.ttl > 0 {
		item.expiresAt = time.Now().Add(c.ttl)
	}
	c.mu.Lock()
	c.items[student.StudentID] = item
	c.mu.Unlock()
	return nil
}

func (c *memoryStudentCache) Delete(ctx context.Context, id int64) error {
	c.mu.Lock()
	delete(c.items, id)
	c.mu.Unlock()
	return nil
}

type redisStudentCache struct {
	client *gredis.Redis
	ttl    time.Duration
	prefix string
}

// NewRedisStudentCache creates the L2 Redis cache.
func NewRedisStudentCache(client *gredis.Redis, ttl time.Duration) studentCache {
	return &redisStudentCache{
		client: client,
		ttl:    ttl,
		prefix: studentCacheKeyPrefix,
	}
}

func (c *redisStudentCache) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	if c == nil || c.client == nil {
		return model.Student{}, false, nil
	}
	value, err := c.client.Get(ctx, c.key(id))
	if err != nil || value == nil || value.IsNil() || value.String() == "" {
		return model.Student{}, false, err
	}
	var student model.Student
	if err = json.Unmarshal(value.Bytes(), &student); err != nil {
		_ = c.Delete(ctx, id)
		return model.Student{}, false, err
	}
	return student, true, nil
}

func (c *redisStudentCache) Set(ctx context.Context, student model.Student) error {
	if c == nil || c.client == nil {
		return nil
	}
	data, err := json.Marshal(student)
	if err != nil {
		return err
	}
	ttlSeconds := int64(c.ttl.Seconds())
	if ttlSeconds <= 0 {
		_, err = c.client.Set(ctx, c.key(student.StudentID), data)
		return err
	}
	return c.client.SetEX(ctx, c.key(student.StudentID), data, ttlSeconds)
}

func (c *redisStudentCache) Delete(ctx context.Context, id int64) error {
	if c == nil || c.client == nil {
		return nil
	}
	_, err := c.client.Del(ctx, c.key(id))
	return err
}

func (c *redisStudentCache) key(id int64) string {
	return c.prefix + strconv.FormatInt(id, 10)
}

type mysqlStudentStorage struct {
	db gdb.DB
}

// NewMySQLStudentStorage creates the L3 MySQL cold store.
func NewMySQLStudentStorage(db gdb.DB) StudentStorage {
	return &mysqlStudentStorage{db: db}
}

func (s *mysqlStudentStorage) Create(ctx context.Context, in model.StudentCreateInput) (int64, bool, error) {
	if _, ok, err := s.getByStudentNo(ctx, in.StudentNo); err != nil || ok {
		return 0, ok, err
	}
	now := time.Now()
	id, err := s.db.Model(studentTable).Ctx(ctx).Data(newStudentDBInsert(in, now)).InsertAndGetId()
	if err != nil {
		if isDuplicateStudentError(err) {
			return 0, true, nil
		}
		return 0, false, err
	}
	return id, false, nil
}

func (s *mysqlStudentStorage) Get(ctx context.Context, id int64) (model.Student, bool, error) {
	var row studentDBRow
	err := s.db.Model(studentTable).Ctx(ctx).
		Where("id = ?", id).
		Where("deleted_at IS NULL").
		Scan(&row)
	if err != nil || row.ID == 0 {
		return model.Student{}, false, err
	}
	return row.toModel(), true, nil
}

func (s *mysqlStudentStorage) List(ctx context.Context, in model.StudentListInput) (model.StudentListOutput, error) {
	query := s.db.Model(studentTable).Ctx(ctx).Where("deleted_at IS NULL")
	if in.Name != "" {
		query = query.Where("name LIKE ?", "%"+in.Name+"%")
	}
	if in.ClassName != "" {
		query = query.Where("class_name = ?", in.ClassName)
	}
	if in.Status != 0 {
		query = query.Where("status = ?", in.Status)
	}
	total, err := query.Clone().Count()
	if err != nil {
		return model.StudentListOutput{}, err
	}
	var rows []studentDBRow
	if err = query.OrderAsc("id").Limit((in.Page-1)*in.Size, in.Size).Scan(&rows); err != nil {
		return model.StudentListOutput{}, err
	}
	list := make([]model.Student, 0, len(rows))
	for _, row := range rows {
		list = append(list, row.toModel())
	}
	return model.StudentListOutput{List: list, Total: total}, nil
}

func (s *mysqlStudentStorage) Update(ctx context.Context, in model.StudentUpdateInput) (bool, error) {
	if _, ok, err := s.Get(ctx, in.StudentID); err != nil || !ok {
		return ok, err
	}
	_, err := s.db.Model(studentTable).Ctx(ctx).
		Data(newStudentDBUpdate(in, time.Now())).
		Where("id = ?", in.StudentID).
		Where("deleted_at IS NULL").
		Update()
	return err == nil, err
}

func (s *mysqlStudentStorage) UpdateStatus(ctx context.Context, in model.StudentStatusInput) (bool, error) {
	if _, ok, err := s.Get(ctx, in.StudentID); err != nil || !ok {
		return ok, err
	}
	status := in.Status
	updatedAt := time.Now()
	_, err := s.db.Model(studentTable).Ctx(ctx).
		Data(studentDBStatusUpdate{Status: &status, UpdatedAt: &updatedAt}).
		Where("id = ?", in.StudentID).
		Where("deleted_at IS NULL").
		Update()
	return err == nil, err
}

func (s *mysqlStudentStorage) getByStudentNo(ctx context.Context, studentNo string) (model.Student, bool, error) {
	var row studentDBRow
	err := s.db.Model(studentTable).Ctx(ctx).
		Where("student_no = ?", studentNo).
		Where("deleted_at IS NULL").
		Scan(&row)
	if err != nil || row.ID == 0 {
		return model.Student{}, false, err
	}
	return row.toModel(), true, nil
}

type studentDBInsert struct {
	StudentNo *string    `orm:"student_no"`
	Name      *string    `orm:"name"`
	Gender    *int32     `orm:"gender"`
	ClassName *string    `orm:"class_name"`
	Major     *string    `orm:"major"`
	College   *string    `orm:"college"`
	Mobile    *string    `orm:"mobile"`
	Email     *string    `orm:"email"`
	Status    *int32     `orm:"status"`
	CreatedAt *time.Time `orm:"created_at"`
	UpdatedAt *time.Time `orm:"updated_at"`
}

type studentDBUpdate struct {
	Name      *string    `orm:"name"`
	Gender    *int32     `orm:"gender"`
	ClassName *string    `orm:"class_name"`
	Major     *string    `orm:"major"`
	College   *string    `orm:"college"`
	Mobile    *string    `orm:"mobile"`
	Email     *string    `orm:"email"`
	UpdatedAt *time.Time `orm:"updated_at"`
}

type studentDBStatusUpdate struct {
	Status    *int32     `orm:"status"`
	UpdatedAt *time.Time `orm:"updated_at"`
}

type studentDBRow struct {
	ID        int64     `orm:"id"`
	StudentNo string    `orm:"student_no"`
	Name      string    `orm:"name"`
	Gender    int32     `orm:"gender"`
	ClassName string    `orm:"class_name"`
	Major     string    `orm:"major"`
	College   string    `orm:"college"`
	Mobile    string    `orm:"mobile"`
	Email     string    `orm:"email"`
	Status    int32     `orm:"status"`
	CreatedAt time.Time `orm:"created_at"`
	UpdatedAt time.Time `orm:"updated_at"`
}

func newStudentDBInsert(in model.StudentCreateInput, now time.Time) studentDBInsert {
	status := int32(model.StudentStatusActive)
	return studentDBInsert{
		StudentNo: &in.StudentNo,
		Name:      &in.Name,
		Gender:    &in.Gender,
		ClassName: &in.ClassName,
		Major:     &in.Major,
		College:   &in.College,
		Mobile:    &in.Mobile,
		Email:     &in.Email,
		Status:    &status,
		CreatedAt: &now,
		UpdatedAt: &now,
	}
}

func newStudentDBUpdate(in model.StudentUpdateInput, now time.Time) studentDBUpdate {
	return studentDBUpdate{
		Name:      &in.Name,
		Gender:    &in.Gender,
		ClassName: &in.ClassName,
		Major:     &in.Major,
		College:   &in.College,
		Mobile:    &in.Mobile,
		Email:     &in.Email,
		UpdatedAt: &now,
	}
}

func (r studentDBRow) toModel() model.Student {
	return model.Student{
		StudentID: r.ID,
		StudentNo: r.StudentNo,
		Name:      r.Name,
		Gender:    r.Gender,
		ClassName: r.ClassName,
		Major:     r.Major,
		College:   r.College,
		Mobile:    r.Mobile,
		Email:     r.Email,
		Status:    r.Status,
		CreatedAt: r.CreatedAt.Unix(),
		UpdatedAt: r.UpdatedAt.Unix(),
	}
}

func isDuplicateStudentError(err error) bool {
	if err == nil {
		return false
	}
	message := strings.ToLower(err.Error())
	return strings.Contains(message, "duplicate") || strings.Contains(message, "1062")
}

func sortStudents(list []model.Student) {
	sort.Slice(list, func(i, j int) bool { return list[i].StudentID < list[j].StudentID })
}
