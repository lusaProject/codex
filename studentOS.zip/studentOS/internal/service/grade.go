// ================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// You can delete these comments if you wish manually maintain this interface file.
// ================================================================================

package service

import (
	"context"
	"student-management/internal/model"
)

type (
	IGrade interface {
		// Submit 录入或修改成绩。
		Submit(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error)
		// Update 修改成绩。
		Update(ctx context.Context, in model.GradeUpdateInput) (*model.GradeUpdateOutput, error)
		// ListStudentGrades 查询学生成绩。
		ListStudentGrades(ctx context.Context, studentID int64) ([]model.StudentGrade, error)
	}
)

var (
	localGrade IGrade
)

func Grade() IGrade {
	if localGrade == nil {
		panic("implement not found for interface IGrade, forgot register?")
	}
	return localGrade
}

func RegisterGrade(i IGrade) {
	localGrade = i
}
