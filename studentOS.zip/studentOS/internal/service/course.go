// ================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// You can delete these comments if you wish manually maintain this interface file.
// ================================================================================

package service

import (
	"context"
	"student-management/internal/model"
)

type (
	ICourse interface {
		// Create 创建课程。
		Create(ctx context.Context, in model.CourseCreateInput) (int64, error)
		// Get 查询课程详情。
		Get(ctx context.Context, courseID int64) (*model.Course, error)
		// List 分页查询课程。
		List(ctx context.Context, in model.CourseListInput) (*model.CourseListOutput, error)
		// Update 修改课程信息。
		Update(ctx context.Context, in model.CourseUpdateInput) error
		// UpdateStatus 修改课程状态。
		UpdateStatus(ctx context.Context, in model.CourseStatusInput) error
	}
)

var (
	localCourse ICourse
)

func Course() ICourse {
	if localCourse == nil {
		panic("implement not found for interface ICourse, forgot register?")
	}
	return localCourse
}

func RegisterCourse(i ICourse) {
	localCourse = i
}
