// ================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// You can delete these comments if you wish manually maintain this interface file.
// ================================================================================

package service

import (
	"context"
	"student-management/internal/model"
)

type (
	IEnrollment interface {
		// Enroll 学生选课。
		Enroll(ctx context.Context, in model.EnrollmentCreateInput) (int64, error)
		// Drop 学生退课。
		Drop(ctx context.Context, in model.EnrollmentDropInput) error
		// ListStudentCourses 查询学生已选课程。
		ListStudentCourses(ctx context.Context, studentID int64) ([]model.StudentCourse, error)
		// ListCourseStudents 查询课程选课名单。
		ListCourseStudents(ctx context.Context, courseID int64) ([]model.CourseStudent, error)
	}
)

var (
	localEnrollment IEnrollment
)

func Enrollment() IEnrollment {
	if localEnrollment == nil {
		panic("implement not found for interface IEnrollment, forgot register?")
	}
	return localEnrollment
}

func RegisterEnrollment(i IEnrollment) {
	localEnrollment = i
}
