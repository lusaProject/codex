// ================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// You can delete these comments if you wish manually maintain this interface file.
// ================================================================================

package service

import (
	"context"
	"student-management/internal/model"
)

type (
	IStudent interface {
		// Create 创建学生。
		Create(ctx context.Context, in model.StudentCreateInput) (int64, error)
		// Get 查询学生详情。
		Get(ctx context.Context, studentID int64) (*model.Student, error)
		// List 分页查询学生。
		List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error)
		// Update 修改学生信息。
		Update(ctx context.Context, in model.StudentUpdateInput) error
		// UpdateStatus 修改学生状态。
		UpdateStatus(ctx context.Context, in model.StudentStatusInput) error
		// CheckActive 校验学生是否存在且启用。
		CheckActive(ctx context.Context, studentID int64) (bool, error)
	}
)

var (
	localStudent IStudent
)

func Student() IStudent {
	if localStudent == nil {
		panic("implement not found for interface IStudent, forgot register?")
	}
	return localStudent
}

func RegisterStudent(i IStudent) {
	localStudent = i
}
