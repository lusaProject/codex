package academic

import (
	"context"

	"student-management/internal/model"
	"student-management/internal/service"
	academickitex "student-management/kitex_gen/academic"
)

// Handler academic-service RPC 处理器。
type Handler struct{}

// CreateCourse 创建课程。
func (h *Handler) CreateCourse(ctx context.Context, req *academickitex.CreateCourseReq) (*academickitex.CreateCourseResp, error) {
	id, err := service.Course().Create(ctx, model.CourseCreateInput{
		CourseCode:  req.CourseCode,
		CourseName:  req.CourseName,
		TeacherID:   req.TeacherId,
		TeacherName: req.TeacherName,
		Credit:      req.Credit,
		Capacity:    req.Capacity,
	})
	if err != nil {
		return nil, err
	}
	return &academickitex.CreateCourseResp{CourseId: id}, nil
}

// GetCourse 查询课程详情。
func (h *Handler) GetCourse(ctx context.Context, req *academickitex.GetCourseReq) (*academickitex.GetCourseResp, error) {
	course, err := service.Course().Get(ctx, req.CourseId)
	if err != nil {
		return nil, err
	}
	return &academickitex.GetCourseResp{Course: toRPCCourse(*course)}, nil
}

// ListCourses 分页查询课程。
func (h *Handler) ListCourses(ctx context.Context, req *academickitex.ListCoursesReq) (*academickitex.ListCoursesResp, error) {
	out, err := service.Course().List(ctx, model.CourseListInput{
		Page:       int(req.Page),
		Size:       int(req.Size),
		CourseName: req.GetCourseName(),
		TeacherID:  req.GetTeacherId(),
		Status:     req.GetStatus(),
	})
	if err != nil {
		return nil, err
	}
	list := make([]*academickitex.CourseInfo, 0, len(out.List))
	for _, item := range out.List {
		list = append(list, toRPCCourse(item))
	}
	return &academickitex.ListCoursesResp{List: list, Total: int32(out.Total)}, nil
}

// UpdateCourse 修改课程信息。
func (h *Handler) UpdateCourse(ctx context.Context, req *academickitex.UpdateCourseReq) (*academickitex.UpdateCourseResp, error) {
	err := service.Course().Update(ctx, model.CourseUpdateInput{
		CourseID:    req.CourseId,
		CourseName:  req.CourseName,
		TeacherID:   req.TeacherId,
		TeacherName: req.TeacherName,
		Credit:      req.Credit,
		Capacity:    req.Capacity,
	})
	if err != nil {
		return nil, err
	}
	return &academickitex.UpdateCourseResp{}, nil
}

// UpdateCourseStatus 修改课程状态。
func (h *Handler) UpdateCourseStatus(ctx context.Context, req *academickitex.UpdateCourseStatusReq) (*academickitex.UpdateCourseStatusResp, error) {
	if err := service.Course().UpdateStatus(ctx, model.CourseStatusInput{CourseID: req.CourseId, Status: req.Status}); err != nil {
		return nil, err
	}
	return &academickitex.UpdateCourseStatusResp{}, nil
}

// EnrollCourse 学生选课。
func (h *Handler) EnrollCourse(ctx context.Context, req *academickitex.EnrollCourseReq) (*academickitex.EnrollCourseResp, error) {
	id, err := service.Enrollment().Enroll(ctx, model.EnrollmentCreateInput{StudentID: req.StudentId, CourseID: req.CourseId})
	if err != nil {
		return nil, err
	}
	return &academickitex.EnrollCourseResp{EnrollmentId: id}, nil
}

// DropCourse 学生退课。
func (h *Handler) DropCourse(ctx context.Context, req *academickitex.DropCourseReq) (*academickitex.DropCourseResp, error) {
	if err := service.Enrollment().Drop(ctx, model.EnrollmentDropInput{EnrollmentID: req.EnrollmentId}); err != nil {
		return nil, err
	}
	return &academickitex.DropCourseResp{}, nil
}

// ListStudentCourses 查询学生已选课程。
func (h *Handler) ListStudentCourses(ctx context.Context, req *academickitex.ListStudentCoursesReq) (*academickitex.ListStudentCoursesResp, error) {
	list, err := service.Enrollment().ListStudentCourses(ctx, req.StudentId)
	if err != nil {
		return nil, err
	}
	out := make([]*academickitex.EnrollmentCourseInfo, 0, len(list))
	for _, item := range list {
		out = append(out, &academickitex.EnrollmentCourseInfo{
			EnrollmentId: item.EnrollmentID,
			Course:       toRPCCourse(item.Course),
			EnrolledAt:   item.EnrolledAt,
		})
	}
	return &academickitex.ListStudentCoursesResp{List: out}, nil
}

// ListCourseStudents 查询课程选课名单。
func (h *Handler) ListCourseStudents(ctx context.Context, req *academickitex.ListCourseStudentsReq) (*academickitex.ListCourseStudentsResp, error) {
	list, err := service.Enrollment().ListCourseStudents(ctx, req.CourseId)
	if err != nil {
		return nil, err
	}
	out := make([]*academickitex.CourseStudentInfo, 0, len(list))
	for _, item := range list {
		out = append(out, &academickitex.CourseStudentInfo{
			EnrollmentId: item.EnrollmentID,
			StudentId:    item.StudentID,
			StudentNo:    item.StudentNo,
			Name:         item.Name,
			ClassName:    item.ClassName,
			EnrolledAt:   item.EnrolledAt,
		})
	}
	return &academickitex.ListCourseStudentsResp{List: out}, nil
}

// SubmitGrade 录入或修改成绩。
func (h *Handler) SubmitGrade(ctx context.Context, req *academickitex.SubmitGradeReq) (*academickitex.SubmitGradeResp, error) {
	out, err := service.Grade().Submit(ctx, model.GradeSubmitInput{
		StudentID: req.StudentId,
		CourseID:  req.CourseId,
		Score:     req.Score,
		Remark:    req.GetRemark(),
	})
	if err != nil {
		return nil, err
	}
	return &academickitex.SubmitGradeResp{GradeId: out.GradeID, GradeLevel: out.GradeLevel}, nil
}

// UpdateGrade 修改成绩。
func (h *Handler) UpdateGrade(ctx context.Context, req *academickitex.UpdateGradeReq) (*academickitex.UpdateGradeResp, error) {
	out, err := service.Grade().Update(ctx, model.GradeUpdateInput{
		GradeID: req.GradeId,
		Score:   req.Score,
		Remark:  req.GetRemark(),
	})
	if err != nil {
		return nil, err
	}
	return &academickitex.UpdateGradeResp{GradeLevel: out.GradeLevel}, nil
}

// ListStudentGrades 查询学生成绩。
func (h *Handler) ListStudentGrades(ctx context.Context, req *academickitex.ListStudentGradesReq) (*academickitex.ListStudentGradesResp, error) {
	list, err := service.Grade().ListStudentGrades(ctx, req.StudentId)
	if err != nil {
		return nil, err
	}
	out := make([]*academickitex.StudentGradeInfo, 0, len(list))
	for _, item := range list {
		out = append(out, &academickitex.StudentGradeInfo{
			Grade:  toRPCGrade(item.Grade),
			Course: toRPCCourse(item.Course),
		})
	}
	return &academickitex.ListStudentGradesResp{List: out}, nil
}

func toRPCCourse(in model.Course) *academickitex.CourseInfo {
	return &academickitex.CourseInfo{
		CourseId:      in.CourseID,
		CourseCode:    in.CourseCode,
		CourseName:    in.CourseName,
		TeacherId:     in.TeacherID,
		TeacherName:   in.TeacherName,
		Credit:        in.Credit,
		Capacity:      in.Capacity,
		SelectedCount: in.SelectedCount,
		Status:        in.Status,
		CreatedAt:     in.CreatedAt,
		UpdatedAt:     in.UpdatedAt,
	}
}

func toRPCGrade(in model.Grade) *academickitex.GradeInfo {
	return &academickitex.GradeInfo{
		GradeId:    in.GradeID,
		StudentId:  in.StudentID,
		CourseId:   in.CourseID,
		Score:      in.Score,
		GradeLevel: in.GradeLevel,
		Remark:     stringPtr(in.Remark),
		CreatedAt:  in.CreatedAt,
		UpdatedAt:  in.UpdatedAt,
	}
}

func stringPtr(v string) *string {
	if v == "" {
		return nil
	}
	return &v
}
