package academic

import (
	"context"
	"testing"

	"student-management/internal/codes"
	"student-management/internal/model"
	"student-management/internal/service"
	academickitex "student-management/kitex_gen/academic"

	"github.com/gogf/gf/v2/errors/gerror"
)

func TestAcademicHandlerCreateCourse(t *testing.T) {
	service.RegisterCourse(fakeCourseService{createID: 12})
	resp, err := (&Handler{}).CreateCourse(context.Background(), &academickitex.CreateCourseReq{
		CourseCode:  "CS101",
		CourseName:  "Go 后端开发",
		TeacherId:   1001,
		TeacherName: "李老师",
		Credit:      3,
		Capacity:    30,
	})
	if err != nil {
		t.Fatalf("CreateCourse() error = %v", err)
	}
	if resp.CourseId != 12 {
		t.Fatalf("CourseId = %d", resp.CourseId)
	}
}

func TestAcademicHandlerErrorMapping(t *testing.T) {
	expected := gerror.NewCode(codes.CodeBusinessValidationFailed, "不能重复选课")
	service.RegisterEnrollment(fakeEnrollmentService{err: expected})
	_, err := (&Handler{}).EnrollCourse(context.Background(), &academickitex.EnrollCourseReq{StudentId: 1, CourseId: 2})
	if gerror.Code(err) != codes.CodeBusinessValidationFailed {
		t.Fatalf("expected business error, got %v", gerror.Code(err))
	}
}

func TestAcademicHandlerOtherMethods(t *testing.T) {
	service.RegisterCourse(fakeCourseService{createID: 12})
	service.RegisterEnrollment(fakeEnrollmentService{enrollmentID: 13})
	service.RegisterGrade(fakeGradeService{gradeID: 14, level: "A"})
	ctx := context.Background()
	h := &Handler{}
	if _, err := h.GetCourse(ctx, &academickitex.GetCourseReq{CourseId: 12}); err != nil {
		t.Fatalf("GetCourse() error = %v", err)
	}
	if _, err := h.ListCourses(ctx, &academickitex.ListCoursesReq{Page: 1, Size: 10}); err != nil {
		t.Fatalf("ListCourses() error = %v", err)
	}
	if _, err := h.UpdateCourse(ctx, &academickitex.UpdateCourseReq{CourseId: 12, CourseName: "Go", TeacherId: 1, TeacherName: "李老师", Credit: 1, Capacity: 1}); err != nil {
		t.Fatalf("UpdateCourse() error = %v", err)
	}
	if _, err := h.UpdateCourseStatus(ctx, &academickitex.UpdateCourseStatusReq{CourseId: 12, Status: model.CourseStatusActive}); err != nil {
		t.Fatalf("UpdateCourseStatus() error = %v", err)
	}
	if _, err := h.DropCourse(ctx, &academickitex.DropCourseReq{EnrollmentId: 13}); err != nil {
		t.Fatalf("DropCourse() error = %v", err)
	}
	if _, err := h.ListStudentCourses(ctx, &academickitex.ListStudentCoursesReq{StudentId: 1}); err != nil {
		t.Fatalf("ListStudentCourses() error = %v", err)
	}
	if _, err := h.ListCourseStudents(ctx, &academickitex.ListCourseStudentsReq{CourseId: 12}); err != nil {
		t.Fatalf("ListCourseStudents() error = %v", err)
	}
	if _, err := h.SubmitGrade(ctx, &academickitex.SubmitGradeReq{StudentId: 1, CourseId: 12, Score: 95}); err != nil {
		t.Fatalf("SubmitGrade() error = %v", err)
	}
	if _, err := h.UpdateGrade(ctx, &academickitex.UpdateGradeReq{GradeId: 14, Score: 85}); err != nil {
		t.Fatalf("UpdateGrade() error = %v", err)
	}
	if _, err := h.ListStudentGrades(ctx, &academickitex.ListStudentGradesReq{StudentId: 1}); err != nil {
		t.Fatalf("ListStudentGrades() error = %v", err)
	}
}

type fakeCourseService struct {
	createID int64
	err      error
}

func (f fakeCourseService) Create(ctx context.Context, in model.CourseCreateInput) (int64, error) {
	if f.err != nil {
		return 0, f.err
	}
	return f.createID, nil
}

func (f fakeCourseService) Get(ctx context.Context, courseID int64) (*model.Course, error) {
	return &model.Course{CourseID: courseID, CourseCode: "CS101", CourseName: "Go", TeacherID: 1, TeacherName: "李老师"}, f.err
}

func (f fakeCourseService) List(ctx context.Context, in model.CourseListInput) (*model.CourseListOutput, error) {
	return &model.CourseListOutput{List: []model.Course{{CourseID: 1, CourseCode: "CS101", CourseName: "Go"}}, Total: 1}, f.err
}

func (f fakeCourseService) Update(ctx context.Context, in model.CourseUpdateInput) error {
	return f.err
}

func (f fakeCourseService) UpdateStatus(ctx context.Context, in model.CourseStatusInput) error {
	return f.err
}

type fakeEnrollmentService struct {
	enrollmentID int64
	err          error
}

func (f fakeEnrollmentService) Enroll(ctx context.Context, in model.EnrollmentCreateInput) (int64, error) {
	if f.err != nil {
		return 0, f.err
	}
	return f.enrollmentID, nil
}

func (f fakeEnrollmentService) Drop(ctx context.Context, in model.EnrollmentDropInput) error {
	return f.err
}

func (f fakeEnrollmentService) ListStudentCourses(ctx context.Context, studentID int64) ([]model.StudentCourse, error) {
	return []model.StudentCourse{{EnrollmentID: 1, Course: model.Course{CourseID: 1}}}, f.err
}

func (f fakeEnrollmentService) ListCourseStudents(ctx context.Context, courseID int64) ([]model.CourseStudent, error) {
	return []model.CourseStudent{{EnrollmentID: 1, StudentID: 1, StudentNo: "S1", Name: "张三"}}, f.err
}

type fakeGradeService struct {
	gradeID int64
	level   string
	err     error
}

func (f fakeGradeService) Submit(ctx context.Context, in model.GradeSubmitInput) (*model.GradeSubmitOutput, error) {
	if f.err != nil {
		return nil, f.err
	}
	return &model.GradeSubmitOutput{GradeID: f.gradeID, GradeLevel: f.level}, nil
}

func (f fakeGradeService) Update(ctx context.Context, in model.GradeUpdateInput) (*model.GradeUpdateOutput, error) {
	if f.err != nil {
		return nil, f.err
	}
	return &model.GradeUpdateOutput{GradeLevel: f.level}, nil
}

func (f fakeGradeService) ListStudentGrades(ctx context.Context, studentID int64) ([]model.StudentGrade, error) {
	return []model.StudentGrade{{Grade: model.Grade{GradeID: f.gradeID}, Course: model.Course{CourseID: 1}}}, f.err
}
