package student

import (
	"context"

	"student-management/internal/model"
	"student-management/internal/service"
	studentkitex "student-management/kitex_gen/student"
)

// Handler student-service RPC 处理器。
type Handler struct{}

// CreateStudent 创建学生。
func (h *Handler) CreateStudent(ctx context.Context, req *studentkitex.CreateStudentReq) (*studentkitex.CreateStudentResp, error) {
	id, err := service.Student().Create(ctx, model.StudentCreateInput{
		StudentNo: req.StudentNo,
		Name:      req.Name,
		Gender:    req.Gender,
		ClassName: req.ClassName,
		Major:     req.Major,
		College:   req.College,
		Mobile:    req.GetMobile(),
		Email:     req.GetEmail(),
	})
	if err != nil {
		return nil, err
	}
	return &studentkitex.CreateStudentResp{StudentId: id}, nil
}

// GetStudent 查询学生详情。
func (h *Handler) GetStudent(ctx context.Context, req *studentkitex.GetStudentReq) (*studentkitex.GetStudentResp, error) {
	student, err := service.Student().Get(ctx, req.StudentId)
	if err != nil {
		return nil, err
	}
	return &studentkitex.GetStudentResp{Student: toRPCStudent(*student)}, nil
}

// ListStudents 分页查询学生。
func (h *Handler) ListStudents(ctx context.Context, req *studentkitex.ListStudentsReq) (*studentkitex.ListStudentsResp, error) {
	out, err := service.Student().List(ctx, model.StudentListInput{
		Page:      int(req.Page),
		Size:      int(req.Size),
		Name:      req.GetName(),
		ClassName: req.GetClassName(),
		Status:    req.GetStatus(),
	})
	if err != nil {
		return nil, err
	}
	list := make([]*studentkitex.StudentInfo, 0, len(out.List))
	for _, item := range out.List {
		list = append(list, toRPCStudent(item))
	}
	return &studentkitex.ListStudentsResp{List: list, Total: int32(out.Total)}, nil
}

// UpdateStudent 修改学生信息。
func (h *Handler) UpdateStudent(ctx context.Context, req *studentkitex.UpdateStudentReq) (*studentkitex.UpdateStudentResp, error) {
	err := service.Student().Update(ctx, model.StudentUpdateInput{
		StudentID: req.StudentId,
		Name:      req.Name,
		Gender:    req.Gender,
		ClassName: req.ClassName,
		Major:     req.Major,
		College:   req.College,
		Mobile:    req.GetMobile(),
		Email:     req.GetEmail(),
	})
	if err != nil {
		return nil, err
	}
	return &studentkitex.UpdateStudentResp{}, nil
}

// UpdateStudentStatus 修改学生状态。
func (h *Handler) UpdateStudentStatus(ctx context.Context, req *studentkitex.UpdateStudentStatusReq) (*studentkitex.UpdateStudentStatusResp, error) {
	if err := service.Student().UpdateStatus(ctx, model.StudentStatusInput{StudentID: req.StudentId, Status: req.Status}); err != nil {
		return nil, err
	}
	return &studentkitex.UpdateStudentStatusResp{}, nil
}

// CheckStudentActive 校验学生是否存在且启用。
func (h *Handler) CheckStudentActive(ctx context.Context, req *studentkitex.CheckStudentActiveReq) (*studentkitex.CheckStudentActiveResp, error) {
	active, err := service.Student().CheckActive(ctx, req.StudentId)
	if err != nil {
		return nil, err
	}
	return &studentkitex.CheckStudentActiveResp{Active: active}, nil
}

func toRPCStudent(in model.Student) *studentkitex.StudentInfo {
	return &studentkitex.StudentInfo{
		StudentId: in.StudentID,
		StudentNo: in.StudentNo,
		Name:      in.Name,
		Gender:    in.Gender,
		ClassName: in.ClassName,
		Major:     in.Major,
		College:   in.College,
		Mobile:    stringPtr(in.Mobile),
		Email:     stringPtr(in.Email),
		Status:    in.Status,
		CreatedAt: in.CreatedAt,
		UpdatedAt: in.UpdatedAt,
	}
}

func stringPtr(v string) *string {
	if v == "" {
		return nil
	}
	return &v
}
