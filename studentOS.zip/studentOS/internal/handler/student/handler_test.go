package student

import (
	"context"
	"testing"

	"student-management/internal/model"
	"student-management/internal/service"
	studentkitex "student-management/kitex_gen/student"
)

func TestStudentHandlerCreateStudent(t *testing.T) {
	service.RegisterStudent(fakeStudentService{createID: 11})
	resp, err := (&Handler{}).CreateStudent(context.Background(), &studentkitex.CreateStudentReq{
		StudentNo: "S20260001",
		Name:      "张三",
		Gender:    1,
		ClassName: "软件一班",
		Major:     "软件工程",
		College:   "计算机学院",
	})
	if err != nil {
		t.Fatalf("CreateStudent() error = %v", err)
	}
	if resp.StudentId != 11 {
		t.Fatalf("StudentId = %d", resp.StudentId)
	}
}

func TestStudentHandlerOtherMethods(t *testing.T) {
	service.RegisterStudent(fakeStudentService{createID: 11})
	ctx := context.Background()
	h := &Handler{}
	if _, err := h.GetStudent(ctx, &studentkitex.GetStudentReq{StudentId: 11}); err != nil {
		t.Fatalf("GetStudent() error = %v", err)
	}
	if _, err := h.ListStudents(ctx, &studentkitex.ListStudentsReq{Page: 1, Size: 10}); err != nil {
		t.Fatalf("ListStudents() error = %v", err)
	}
	if _, err := h.UpdateStudent(ctx, &studentkitex.UpdateStudentReq{StudentId: 11, Name: "李四", ClassName: "二班", Major: "软件工程", College: "计算机学院"}); err != nil {
		t.Fatalf("UpdateStudent() error = %v", err)
	}
	if _, err := h.UpdateStudentStatus(ctx, &studentkitex.UpdateStudentStatusReq{StudentId: 11, Status: model.StudentStatusActive}); err != nil {
		t.Fatalf("UpdateStudentStatus() error = %v", err)
	}
	resp, err := h.CheckStudentActive(ctx, &studentkitex.CheckStudentActiveReq{StudentId: 11})
	if err != nil {
		t.Fatalf("CheckStudentActive() error = %v", err)
	}
	if !resp.Active {
		t.Fatalf("Active = false")
	}
}

type fakeStudentService struct {
	createID int64
	err      error
}

func (f fakeStudentService) Create(ctx context.Context, in model.StudentCreateInput) (int64, error) {
	if f.err != nil {
		return 0, f.err
	}
	return f.createID, nil
}

func (f fakeStudentService) Get(ctx context.Context, studentID int64) (*model.Student, error) {
	return &model.Student{StudentID: studentID, StudentNo: "S1", Name: "张三", Mobile: "13800138000"}, f.err
}

func (f fakeStudentService) List(ctx context.Context, in model.StudentListInput) (*model.StudentListOutput, error) {
	return &model.StudentListOutput{List: []model.Student{{StudentID: 1, StudentNo: "S1", Name: "张三"}}, Total: 1}, f.err
}

func (f fakeStudentService) Update(ctx context.Context, in model.StudentUpdateInput) error {
	return f.err
}

func (f fakeStudentService) UpdateStatus(ctx context.Context, in model.StudentStatusInput) error {
	return f.err
}

func (f fakeStudentService) CheckActive(ctx context.Context, studentID int64) (bool, error) {
	return true, f.err
}
