package bootstrap

import (
	"fmt"
	"log"
	"net"
	"sync"
	"time"

	academichandler "student-management/internal/handler/academic"
	studenthandler "student-management/internal/handler/student"
	"student-management/kitex_gen/academic/academicservice"
	"student-management/kitex_gen/student/studentservice"

	"github.com/cloudwego/kitex/server"
)

const (
	StudentRPCAddress  = ":9001"
	AcademicRPCAddress = ":9002"

	rpcStartupGracePeriod = 500 * time.Millisecond
)

// RPCServices keeps the background RPC servers visible to the HTTP entrypoint.
type RPCServices struct {
	servers []namedRPCServer
	errCh   chan error
	once    sync.Once
}

type namedRPCServer struct {
	name    string
	address string
	server  server.Server
}

// StartRPCServices starts all RPC services required by the application.
func StartRPCServices() (*RPCServices, error) {
	services, err := newRPCServices()
	if err != nil {
		return nil, err
	}
	for _, item := range services.servers {
		item := item
		log.Printf("[startup] starting %s RPC server on %s", item.name, item.address)
		go func() {
			if err := item.server.Run(); err != nil {
				services.errCh <- fmt.Errorf("%s RPC server failed: %w", item.name, err)
				return
			}
			services.errCh <- fmt.Errorf("%s RPC server stopped", item.name)
		}()
	}
	if err := services.waitForImmediateFailure(); err != nil {
		services.Stop()
		return nil, err
	}
	for _, item := range services.servers {
		log.Printf("[startup] %s RPC server started on %s", item.name, item.address)
	}
	return services, nil
}

// MonitorFatal exits the process if a background RPC server stops unexpectedly.
func (s *RPCServices) MonitorFatal() {
	if s == nil {
		return
	}
	go func() {
		if err := <-s.errCh; err != nil {
			log.Fatal(err)
		}
	}()
}

// Stop stops all background RPC servers.
func (s *RPCServices) Stop() {
	if s == nil {
		return
	}
	s.once.Do(func() {
		for _, item := range s.servers {
			_ = item.server.Stop()
		}
	})
}

func newRPCServices() (*RPCServices, error) {
	studentServer, err := newStudentRPCServer()
	if err != nil {
		return nil, err
	}
	academicServer, err := newAcademicRPCServer()
	if err != nil {
		return nil, err
	}
	return &RPCServices{
		servers: []namedRPCServer{studentServer, academicServer},
		errCh:   make(chan error, 2),
	}, nil
}

func newStudentRPCServer() (namedRPCServer, error) {
	addr, err := net.ResolveTCPAddr("tcp", StudentRPCAddress)
	if err != nil {
		return namedRPCServer{}, err
	}
	return namedRPCServer{
		name:    "student",
		address: StudentRPCAddress,
		server:  studentservice.NewServer(&studenthandler.Handler{}, server.WithServiceAddr(addr)),
	}, nil
}

func newAcademicRPCServer() (namedRPCServer, error) {
	addr, err := net.ResolveTCPAddr("tcp", AcademicRPCAddress)
	if err != nil {
		return namedRPCServer{}, err
	}
	return namedRPCServer{
		name:    "academic",
		address: AcademicRPCAddress,
		server:  academicservice.NewServer(&academichandler.Handler{}, server.WithServiceAddr(addr)),
	}, nil
}

func (s *RPCServices) waitForImmediateFailure() error {
	timer := time.NewTimer(rpcStartupGracePeriod)
	defer timer.Stop()

	select {
	case err := <-s.errCh:
		return err
	case <-timer.C:
		return nil
	}
}
