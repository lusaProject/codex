package bootstrap

import (
	"context"
	"fmt"
	"log"
	"time"

	"student-management/internal/model"
	"student-management/internal/store"

	"github.com/gogf/gf/v2/frame/g"
)

// LoadAcademicSnapshotFromMySQL makes MySQL-seeded academic data visible to H5 APIs.
func LoadAcademicSnapshotFromMySQL(ctx context.Context) error {
	courses, err := loadCoursesFromMySQL(ctx)
	if err != nil {
		return err
	}
	enrollments, err := loadEnrollmentsFromMySQL(ctx)
	if err != nil {
		return err
	}
	grades, err := loadGradesFromMySQL(ctx)
	if err != nil {
		return err
	}
	store.Default().ReplaceAcademicSnapshot(courses, enrollments, grades)
	log.Printf("[startup] academic snapshot loaded: courses=%d, course_enrollments=%d, grades=%d", len(courses), len(enrollments), len(grades))
	return nil
}

func loadCoursesFromMySQL(ctx context.Context) ([]model.Course, error) {
	var rows []courseSnapshotRow
	if err := g.DB().Model("courses").Ctx(ctx).Where("deleted_at IS NULL").OrderAsc("id").Scan(&rows); err != nil {
		return nil, fmt.Errorf("load courses snapshot: %w", err)
	}
	out := make([]model.Course, 0, len(rows))
	for _, row := range rows {
		out = append(out, row.toModel())
	}
	return out, nil
}

func loadEnrollmentsFromMySQL(ctx context.Context) ([]model.Enrollment, error) {
	var rows []enrollmentSnapshotRow
	if err := g.DB().Model("course_enrollments").Ctx(ctx).OrderAsc("id").Scan(&rows); err != nil {
		return nil, fmt.Errorf("load course_enrollments snapshot: %w", err)
	}
	out := make([]model.Enrollment, 0, len(rows))
	for _, row := range rows {
		out = append(out, row.toModel())
	}
	return out, nil
}

func loadGradesFromMySQL(ctx context.Context) ([]model.Grade, error) {
	var rows []gradeSnapshotRow
	if err := g.DB().Model("grades").Ctx(ctx).OrderAsc("id").Scan(&rows); err != nil {
		return nil, fmt.Errorf("load grades snapshot: %w", err)
	}
	out := make([]model.Grade, 0, len(rows))
	for _, row := range rows {
		out = append(out, row.toModel())
	}
	return out, nil
}

type courseSnapshotRow struct {
	ID            int64     `orm:"id"`
	CourseCode    string    `orm:"course_code"`
	CourseName    string    `orm:"course_name"`
	TeacherID     int64     `orm:"teacher_id"`
	TeacherName   string    `orm:"teacher_name"`
	Credit        float64   `orm:"credit"`
	Capacity      int32     `orm:"capacity"`
	SelectedCount int32     `orm:"selected_count"`
	Status        int32     `orm:"status"`
	CreatedAt     time.Time `orm:"created_at"`
	UpdatedAt     time.Time `orm:"updated_at"`
}

type enrollmentSnapshotRow struct {
	ID        int64     `orm:"id"`
	StudentID int64     `orm:"student_id"`
	CourseID  int64     `orm:"course_id"`
	Status    int32     `orm:"status"`
	CreatedAt time.Time `orm:"created_at"`
	UpdatedAt time.Time `orm:"updated_at"`
}

type gradeSnapshotRow struct {
	ID         int64     `orm:"id"`
	StudentID  int64     `orm:"student_id"`
	CourseID   int64     `orm:"course_id"`
	Score      float64   `orm:"score"`
	GradeLevel string    `orm:"grade_level"`
	Remark     string    `orm:"remark"`
	CreatedAt  time.Time `orm:"created_at"`
	UpdatedAt  time.Time `orm:"updated_at"`
}

func (r courseSnapshotRow) toModel() model.Course {
	return model.Course{
		CourseID:      r.ID,
		CourseCode:    r.CourseCode,
		CourseName:    r.CourseName,
		TeacherID:     r.TeacherID,
		TeacherName:   r.TeacherName,
		Credit:        r.Credit,
		Capacity:      r.Capacity,
		SelectedCount: r.SelectedCount,
		Status:        r.Status,
		CreatedAt:     r.CreatedAt.Unix(),
		UpdatedAt:     r.UpdatedAt.Unix(),
	}
}

func (r enrollmentSnapshotRow) toModel() model.Enrollment {
	return model.Enrollment{
		EnrollmentID: r.ID,
		StudentID:    r.StudentID,
		CourseID:     r.CourseID,
		Status:       r.Status,
		CreatedAt:    r.CreatedAt.Unix(),
		UpdatedAt:    r.UpdatedAt.Unix(),
	}
}

func (r gradeSnapshotRow) toModel() model.Grade {
	return model.Grade{
		GradeID:    r.ID,
		StudentID:  r.StudentID,
		CourseID:   r.CourseID,
		Score:      r.Score,
		GradeLevel: r.GradeLevel,
		Remark:     r.Remark,
		CreatedAt:  r.CreatedAt.Unix(),
		UpdatedAt:  r.UpdatedAt.Unix(),
	}
}
