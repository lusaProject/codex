package bootstrap

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"student-management/internal/store"

	_ "github.com/gogf/gf/contrib/drivers/mysql/v2"
	_ "github.com/gogf/gf/contrib/nosql/redis/v2"
	"github.com/gogf/gf/v2/frame/g"
)

const dependencyCheckTimeout = 3 * time.Second

// PrepareProductionRuntime validates required infrastructure and enables the production store.
func PrepareProductionRuntime(ctx context.Context) error {
	if err := CheckRequiredDependencies(ctx); err != nil {
		return err
	}
	if err := EnsureMySQLSchema(ctx); err != nil {
		return fmt.Errorf("ensure mysql schema failed: %w", err)
	}
	if err := SeedSampleData(ctx); err != nil {
		return fmt.Errorf("seed sample data failed: %w", err)
	}
	store.EnableProductionStudentStorage()
	if err := LoadAcademicSnapshotFromMySQL(ctx); err != nil {
		return fmt.Errorf("load academic snapshot failed: %w", err)
	}
	return nil
}

// CheckRequiredDependencies prints and verifies MySQL and Redis connectivity.
func CheckRequiredDependencies(ctx context.Context) error {
	checkCtx, cancel := context.WithTimeout(ctx, dependencyCheckTimeout)
	defer cancel()

	checks := []dependencyCheck{
		checkMySQL(checkCtx),
		checkRedis(checkCtx),
	}
	failed := make([]string, 0)
	for _, check := range checks {
		if check.err == nil {
			log.Printf("[startup] %s connected", check.name)
			continue
		}
		log.Printf("[startup] %s connection failed: %v", check.name, check.err)
		failed = append(failed, check.name)
	}
	if len(failed) > 0 {
		return fmt.Errorf("required dependencies unavailable: %s", strings.Join(failed, ", "))
	}
	return nil
}

type dependencyCheck struct {
	name string
	err  error
}

func checkMySQL(ctx context.Context) (check dependencyCheck) {
	check.name = "MySQL"
	defer func() {
		if recovered := recover(); recovered != nil {
			check.err = fmt.Errorf("%v", recovered)
		}
	}()
	_, check.err = g.DB().GetValue(ctx, "SELECT 1")
	return check
}

func checkRedis(ctx context.Context) (check dependencyCheck) {
	check.name = "Redis"
	defer func() {
		if recovered := recover(); recovered != nil {
			check.err = fmt.Errorf("%v", recovered)
		}
	}()
	value, err := g.Redis().Do(ctx, "PING")
	if err != nil {
		check.err = err
		return check
	}
	if strings.ToUpper(value.String()) != "PONG" {
		check.err = fmt.Errorf("unexpected PING response: %s", value.String())
	}
	return check
}
