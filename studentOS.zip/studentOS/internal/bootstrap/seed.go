package bootstrap

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"time"

	"student-management/internal/model"

	"github.com/gogf/gf/v2/database/gdb"
	"github.com/gogf/gf/v2/frame/g"
)

const (
	sampleDataCount = 20
	sampleIDBase    = 900000
)

type sampleSeedSummary struct {
	students    int64
	courses     int64
	enrollments int64
	grades      int64
}

// SeedSampleData ensures every business table has a stable set of sample rows.
func SeedSampleData(ctx context.Context) error {
	summary, err := seedSampleData(ctx)
	if err != nil {
		return err
	}
	log.Printf(
		"[startup] sample data ensured: students=%d, courses=%d, course_enrollments=%d, grades=%d; inserted students=%d, courses=%d, course_enrollments=%d, grades=%d",
		sampleDataCount,
		sampleDataCount,
		sampleDataCount,
		sampleDataCount,
		summary.students,
		summary.courses,
		summary.enrollments,
		summary.grades,
	)
	return nil
}

func seedSampleData(ctx context.Context) (sampleSeedSummary, error) {
	var summary sampleSeedSummary
	err := g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) error {
		now := time.Now()
		result, err := tx.InsertIgnore("students", buildSampleStudents(now), sampleDataCount)
		if err != nil {
			return fmt.Errorf("seed students: %w", err)
		}
		summary.students = rowsAffected(result)

		studentIDs, err := loadSampleStudentIDs(tx)
		if err != nil {
			return err
		}

		result, err = tx.InsertIgnore("courses", buildSampleCourses(now), sampleDataCount)
		if err != nil {
			return fmt.Errorf("seed courses: %w", err)
		}
		summary.courses = rowsAffected(result)

		result, err = tx.InsertIgnore("course_enrollments", buildSampleEnrollments(now, studentIDs), sampleDataCount)
		if err != nil {
			return fmt.Errorf("seed course_enrollments: %w", err)
		}
		summary.enrollments = rowsAffected(result)

		result, err = tx.InsertIgnore("grades", buildSampleGrades(now, studentIDs), sampleDataCount)
		if err != nil {
			return fmt.Errorf("seed grades: %w", err)
		}
		summary.grades = rowsAffected(result)
		return nil
	})
	if err != nil {
		return sampleSeedSummary{}, err
	}
	return summary, nil
}

func buildSampleStudents(now time.Time) []map[string]any {
	rows := make([]map[string]any, 0, sampleDataCount)
	for i := 1; i <= sampleDataCount; i++ {
		rows = append(rows, map[string]any{
			"student_no": sampleStudentNo(i),
			"name":       fmt.Sprintf("Demo Student %02d", i),
			"gender":     int32(i % 3),
			"class_name": fmt.Sprintf("Demo Class %02d", (i-1)%4+1),
			"major":      sampleMajor(i),
			"college":    "Demo College",
			"mobile":     fmt.Sprintf("1380000%04d", i),
			"email":      fmt.Sprintf("demo.student%02d@example.com", i),
			"status":     int32(model.StudentStatusActive),
			"created_at": now,
			"updated_at": now,
			"deleted_at": nil,
		})
	}
	return rows
}

func buildSampleCourses(now time.Time) []map[string]any {
	rows := make([]map[string]any, 0, sampleDataCount)
	for i := 1; i <= sampleDataCount; i++ {
		rows = append(rows, map[string]any{
			"id":             sampleID(i),
			"course_code":    fmt.Sprintf("DEMO-COURSE-%03d", i),
			"course_name":    fmt.Sprintf("Demo Course %02d", i),
			"teacher_id":     int64(8000 + i),
			"teacher_name":   fmt.Sprintf("Demo Teacher %02d", i),
			"credit":         2.0 + float64(i%4)*0.5,
			"capacity":       int32(60),
			"selected_count": int32(1),
			"status":         int32(model.CourseStatusActive),
			"created_at":     now,
			"updated_at":     now,
			"deleted_at":     nil,
		})
	}
	return rows
}

func buildSampleEnrollments(now time.Time, studentIDs map[int]int64) []map[string]any {
	rows := make([]map[string]any, 0, sampleDataCount)
	for i := 1; i <= sampleDataCount; i++ {
		rows = append(rows, map[string]any{
			"id":         sampleID(i),
			"student_id": studentIDs[i],
			"course_id":  sampleID(i),
			"status":     int32(model.EnrollmentStatusSelected),
			"created_at": now,
			"updated_at": now,
		})
	}
	return rows
}

func buildSampleGrades(now time.Time, studentIDs map[int]int64) []map[string]any {
	rows := make([]map[string]any, 0, sampleDataCount)
	for i := 1; i <= sampleDataCount; i++ {
		score := 60 + float64(i)
		rows = append(rows, map[string]any{
			"id":          sampleID(i),
			"student_id":  studentIDs[i],
			"course_id":   sampleID(i),
			"score":       score,
			"grade_level": gradeLevel(score),
			"remark":      "Sample grade generated at startup",
			"created_at":  now,
			"updated_at":  now,
		})
	}
	return rows
}

func loadSampleStudentIDs(tx gdb.TX) (map[int]int64, error) {
	ids := make(map[int]int64, sampleDataCount)
	for i := 1; i <= sampleDataCount; i++ {
		studentNo := sampleStudentNo(i)
		value, err := tx.GetValue("SELECT id FROM students WHERE student_no = ? LIMIT 1", studentNo)
		if err != nil {
			return nil, fmt.Errorf("load sample student %s: %w", studentNo, err)
		}
		if value == nil || value.IsNil() || value.Int64() == 0 {
			return nil, fmt.Errorf("sample student %s is missing after seed", studentNo)
		}
		ids[i] = value.Int64()
	}
	return ids, nil
}

func sampleStudentNo(i int) string {
	return fmt.Sprintf("DEMO-STU-%03d", i)
}

func sampleID(i int) int64 {
	return int64(sampleIDBase + i)
}

func sampleMajor(i int) string {
	majors := []string{
		"Software Engineering",
		"Computer Science",
		"Information Management",
		"Data Science",
	}
	return majors[(i-1)%len(majors)]
}

func gradeLevel(score float64) string {
	switch {
	case score >= 90:
		return "A"
	case score >= 80:
		return "B"
	case score >= 70:
		return "C"
	default:
		return "D"
	}
}

func rowsAffected(result sql.Result) int64 {
	if result == nil {
		return 0
	}
	count, err := result.RowsAffected()
	if err != nil {
		return 0
	}
	return count
}
