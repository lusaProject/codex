package bootstrap

import (
	"context"
	"fmt"
	"log"
	"strings"

	"github.com/gogf/gf/v2/frame/g"
)

// EnsureMySQLSchema creates required business tables and indexes before seeding data.
func EnsureMySQLSchema(ctx context.Context) error {
	for _, statement := range mysqlTableStatements {
		if _, err := g.DB().Exec(ctx, statement); err != nil {
			return fmt.Errorf("create table: %w", err)
		}
	}
	for _, statement := range mysqlIndexStatements {
		if _, err := g.DB().Exec(ctx, statement); err != nil {
			if isDuplicateIndexError(err) {
				continue
			}
			return fmt.Errorf("create index: %w", err)
		}
	}
	log.Println("[startup] MySQL schema ensured")
	return nil
}

func isDuplicateIndexError(err error) bool {
	if err == nil {
		return false
	}
	message := strings.ToLower(err.Error())
	return strings.Contains(message, "1061") ||
		strings.Contains(message, "duplicate key name") ||
		strings.Contains(message, "already exists")
}

var mysqlTableStatements = []string{
	`CREATE TABLE IF NOT EXISTS students (
		id BIGINT PRIMARY KEY AUTO_INCREMENT,
		student_no VARCHAR(32) NOT NULL UNIQUE,
		name VARCHAR(64) NOT NULL,
		gender TINYINT NOT NULL DEFAULT 0,
		class_name VARCHAR(64) NOT NULL,
		major VARCHAR(64) NOT NULL,
		college VARCHAR(64) NOT NULL,
		mobile VARCHAR(32) NULL,
		email VARCHAR(128) NULL,
		status TINYINT NOT NULL DEFAULT 1,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		deleted_at DATETIME NULL
	)`,
	`CREATE TABLE IF NOT EXISTS courses (
		id BIGINT PRIMARY KEY,
		course_code VARCHAR(32) NOT NULL UNIQUE,
		course_name VARCHAR(128) NOT NULL,
		teacher_id BIGINT NOT NULL,
		teacher_name VARCHAR(64) NOT NULL,
		credit DECIMAL(4,1) NOT NULL,
		capacity INT NOT NULL,
		selected_count INT NOT NULL DEFAULT 0,
		status TINYINT NOT NULL DEFAULT 1,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		deleted_at DATETIME NULL
	)`,
	`CREATE TABLE IF NOT EXISTS course_enrollments (
		id BIGINT PRIMARY KEY,
		student_id BIGINT NOT NULL,
		course_id BIGINT NOT NULL,
		status TINYINT NOT NULL DEFAULT 1,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		UNIQUE(student_id, course_id)
	)`,
	`CREATE TABLE IF NOT EXISTS grades (
		id BIGINT PRIMARY KEY,
		student_id BIGINT NOT NULL,
		course_id BIGINT NOT NULL,
		score DECIMAL(5,2) NOT NULL,
		grade_level VARCHAR(8) NOT NULL,
		remark VARCHAR(255) NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		UNIQUE(student_id, course_id)
	)`,
}

var mysqlIndexStatements = []string{
	"CREATE INDEX idx_student_name ON students(name)",
	"CREATE INDEX idx_student_class ON students(class_name)",
	"CREATE INDEX idx_student_status ON students(status)",
	"CREATE INDEX idx_course_teacher ON courses(teacher_id)",
	"CREATE INDEX idx_course_status ON courses(status)",
	"CREATE INDEX idx_course_enrollments_course_id ON course_enrollments(course_id)",
	"CREATE INDEX idx_course_enrollments_student_id ON course_enrollments(student_id)",
	"CREATE INDEX idx_grade_student ON grades(student_id)",
	"CREATE INDEX idx_grade_course ON grades(course_id)",
}
