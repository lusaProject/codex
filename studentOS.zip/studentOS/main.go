package main

import (
	_ "student-management/internal/logic"

	"context"
	"log"

	"student-management/internal/cmd"
)

func main() {
	if err := cmd.Main.RunWithError(context.Background()); err != nil {
		log.Fatal(err)
	}
}
