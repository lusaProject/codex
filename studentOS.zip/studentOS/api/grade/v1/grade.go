package v1

import (
	"student-management/internal/model"

	"github.com/gogf/gf/v2/frame/g"
)

// SubmitReq 录入成绩请求。
type SubmitReq struct {
	g.Meta    `path:"/api/v1/grades" method:"post" tags:"成绩" summary:"录入成绩"`
	StudentID int64   `json:"student_id" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
	CourseID  int64   `json:"course_id" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
	Score     float64 `json:"score" v:"required|between:0,100#请输入分数|分数范围必须为0到100" dc:"分数"`
	Remark    string  `json:"remark" v:"length:0,255#备注不能超过255位" dc:"备注"`
}

// SubmitRes 录入成绩响应。
type SubmitRes struct {
	GradeID    int64  `json:"grade_id" dc:"成绩ID"`
	GradeLevel string `json:"grade_level" dc:"成绩等级"`
}

// UpdateReq 修改成绩请求。
type UpdateReq struct {
	g.Meta `path:"/api/v1/grades/{id}" method:"put" tags:"成绩" summary:"修改成绩"`
	ID     int64   `json:"id" in:"path" v:"required|min:1#请输入成绩ID|成绩ID必须大于0" dc:"成绩ID"`
	Score  float64 `json:"score" v:"required|between:0,100#请输入分数|分数范围必须为0到100" dc:"分数"`
	Remark string  `json:"remark" v:"length:0,255#备注不能超过255位" dc:"备注"`
}

// UpdateRes 修改成绩响应。
type UpdateRes struct {
	GradeLevel string `json:"grade_level" dc:"成绩等级"`
}

// ListStudentGradesReq 查询学生成绩请求。
type ListStudentGradesReq struct {
	g.Meta `path:"/api/v1/students/{id}/grades" method:"get" tags:"成绩" summary:"查询学生成绩"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
}

// ListStudentGradesRes 查询学生成绩响应。
type ListStudentGradesRes struct {
	List []model.StudentGrade `json:"list" dc:"成绩列表"`
}
