// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package grade

import (
	"context"

	"student-management/api/grade/v1"
)

type IGradeV1 interface {
	Submit(ctx context.Context, req *v1.SubmitReq) (res *v1.SubmitRes, err error)
	Update(ctx context.Context, req *v1.UpdateReq) (res *v1.UpdateRes, err error)
	ListStudentGrades(ctx context.Context, req *v1.ListStudentGradesReq) (res *v1.ListStudentGradesRes, err error)
}
