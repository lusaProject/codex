package v1

import (
	"student-management/internal/model"

	"github.com/gogf/gf/v2/frame/g"
)

// CreateReq 新增学生请求。
type CreateReq struct {
	g.Meta    `path:"/api/v1/students" method:"post" tags:"学生" summary:"新增学生"`
	StudentNo string `json:"student_no" v:"required|length:1,32#请输入学号|学号长度不能超过32位" dc:"学号"`
	Name      string `json:"name" v:"required|length:1,64#请输入姓名|姓名长度不能超过64位" dc:"姓名"`
	Gender    int32  `json:"gender" v:"in:0,1,2#性别值不合法" dc:"性别：1男，2女，0未知"`
	ClassName string `json:"class_name" v:"required|length:1,64#请输入班级|班级长度不能超过64位" dc:"班级"`
	Major     string `json:"major" v:"required|length:1,64#请输入专业|专业长度不能超过64位" dc:"专业"`
	College   string `json:"college" v:"required|length:1,64#请输入学院|学院长度不能超过64位" dc:"学院"`
	Mobile    string `json:"mobile" v:"phone#手机号格式错误" dc:"手机号"`
	Email     string `json:"email" v:"email#邮箱格式错误" dc:"邮箱"`
}

// CreateRes 新增学生响应。
type CreateRes struct {
	StudentID int64 `json:"student_id" dc:"学生ID"`
}

// GetReq 查询学生详情请求。
type GetReq struct {
	g.Meta `path:"/api/v1/students/{id}" method:"get" tags:"学生" summary:"查询学生详情"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
}

// GetRes 查询学生详情响应。
type GetRes struct {
	Student model.Student `json:"student" dc:"学生信息"`
}

// ListReq 分页查询学生请求。
type ListReq struct {
	g.Meta    `path:"/api/v1/students" method:"get" tags:"学生" summary:"分页查询学生"`
	Page      int    `json:"page" v:"min:1#页码不能小于1" d:"1" dc:"页码"`
	Size      int    `json:"size" v:"between:1,100#分页大小范围为1到100" d:"10" dc:"分页大小"`
	Name      string `json:"name" dc:"姓名"`
	ClassName string `json:"class_name" dc:"班级"`
	Status    int32  `json:"status" v:"in:0,1,2#学生状态不合法" dc:"状态"`
}

// ListRes 分页查询学生响应。
type ListRes struct {
	List  []model.Student `json:"list" dc:"学生列表"`
	Total int             `json:"total" dc:"总数"`
}

// UpdateReq 修改学生请求。
type UpdateReq struct {
	g.Meta    `path:"/api/v1/students/{id}" method:"put" tags:"学生" summary:"修改学生信息"`
	ID        int64  `json:"id" in:"path" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
	Name      string `json:"name" v:"required|length:1,64#请输入姓名|姓名长度不能超过64位" dc:"姓名"`
	Gender    int32  `json:"gender" v:"in:0,1,2#性别值不合法" dc:"性别"`
	ClassName string `json:"class_name" v:"required|length:1,64#请输入班级|班级长度不能超过64位" dc:"班级"`
	Major     string `json:"major" v:"required|length:1,64#请输入专业|专业长度不能超过64位" dc:"专业"`
	College   string `json:"college" v:"required|length:1,64#请输入学院|学院长度不能超过64位" dc:"学院"`
	Mobile    string `json:"mobile" v:"phone#手机号格式错误" dc:"手机号"`
	Email     string `json:"email" v:"email#邮箱格式错误" dc:"邮箱"`
}

// UpdateRes 修改学生响应。
type UpdateRes struct{}

// UpdateStatusReq 修改学生状态请求。
type UpdateStatusReq struct {
	g.Meta `path:"/api/v1/students/{id}/status" method:"patch" tags:"学生" summary:"修改学生状态"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
	Status int32 `json:"status" v:"required|in:1,2#请输入学生状态|学生状态不合法" dc:"状态"`
}

// UpdateStatusRes 修改学生状态响应。
type UpdateStatusRes struct{}
