package v1

import (
	"student-management/internal/model"

	"github.com/gogf/gf/v2/frame/g"
)

// EnrollReq 学生选课请求。
type EnrollReq struct {
	g.Meta    `path:"/api/v1/enrollments" method:"post" tags:"选课" summary:"学生选课"`
	StudentID int64 `json:"student_id" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
	CourseID  int64 `json:"course_id" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
}

// EnrollRes 学生选课响应。
type EnrollRes struct {
	EnrollmentID int64 `json:"enrollment_id" dc:"选课ID"`
}

// DropReq 学生退课请求。
type DropReq struct {
	g.Meta `path:"/api/v1/enrollments/{id}" method:"delete" tags:"选课" summary:"学生退课"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入选课ID|选课ID必须大于0" dc:"选课ID"`
}

// DropRes 学生退课响应。
type DropRes struct{}

// ListStudentCoursesReq 查询学生已选课程请求。
type ListStudentCoursesReq struct {
	g.Meta `path:"/api/v1/students/{id}/courses" method:"get" tags:"选课" summary:"查询学生已选课程"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入学生ID|学生ID必须大于0" dc:"学生ID"`
}

// ListStudentCoursesRes 查询学生已选课程响应。
type ListStudentCoursesRes struct {
	List []model.StudentCourse `json:"list" dc:"课程列表"`
}

// ListCourseStudentsReq 查询课程选课名单请求。
type ListCourseStudentsReq struct {
	g.Meta `path:"/api/v1/courses/{id}/students" method:"get" tags:"选课" summary:"查询课程选课名单"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
}

// ListCourseStudentsRes 查询课程选课名单响应。
type ListCourseStudentsRes struct {
	List []model.CourseStudent `json:"list" dc:"学生列表"`
}
