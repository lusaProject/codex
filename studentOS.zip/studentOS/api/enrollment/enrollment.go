// =================================================================================
// Code generated and maintained by GoFrame CLI tool. DO NOT EDIT.
// =================================================================================

package enrollment

import (
	"context"

	"student-management/api/enrollment/v1"
)

type IEnrollmentV1 interface {
	Enroll(ctx context.Context, req *v1.EnrollReq) (res *v1.EnrollRes, err error)
	Drop(ctx context.Context, req *v1.DropReq) (res *v1.DropRes, err error)
	ListStudentCourses(ctx context.Context, req *v1.ListStudentCoursesReq) (res *v1.ListStudentCoursesRes, err error)
	ListCourseStudents(ctx context.Context, req *v1.ListCourseStudentsReq) (res *v1.ListCourseStudentsRes, err error)
}
