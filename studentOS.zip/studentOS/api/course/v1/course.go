package v1

import (
	"student-management/internal/model"

	"github.com/gogf/gf/v2/frame/g"
)

// CreateReq 新增课程请求。
type CreateReq struct {
	g.Meta      `path:"/api/v1/courses" method:"post" tags:"课程" summary:"新增课程"`
	CourseCode  string  `json:"course_code" v:"required|length:1,32#请输入课程编号|课程编号长度不能超过32位" dc:"课程编号"`
	CourseName  string  `json:"course_name" v:"required|length:1,128#请输入课程名称|课程名称长度不能超过128位" dc:"课程名称"`
	TeacherID   int64   `json:"teacher_id" v:"required|min:1#请输入教师ID|教师ID必须大于0" dc:"教师ID"`
	TeacherName string  `json:"teacher_name" v:"required|length:1,64#请输入教师姓名|教师姓名长度不能超过64位" dc:"教师姓名"`
	Credit      float64 `json:"credit" v:"required|min:0.5#请输入学分|学分必须大于0" dc:"学分"`
	Capacity    int32   `json:"capacity" v:"required|min:1#请输入课程容量|课程容量必须大于0" dc:"容量"`
}

// CreateRes 新增课程响应。
type CreateRes struct {
	CourseID int64 `json:"course_id" dc:"课程ID"`
}

// GetReq 查询课程详情请求。
type GetReq struct {
	g.Meta `path:"/api/v1/courses/{id}" method:"get" tags:"课程" summary:"查询课程详情"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
}

// GetRes 查询课程详情响应。
type GetRes struct {
	Course model.Course `json:"course" dc:"课程信息"`
}

// ListReq 分页查询课程请求。
type ListReq struct {
	g.Meta     `path:"/api/v1/courses" method:"get" tags:"课程" summary:"分页查询课程"`
	Page       int    `json:"page" v:"min:1#页码不能小于1" d:"1" dc:"页码"`
	Size       int    `json:"size" v:"between:1,100#分页大小范围为1到100" d:"10" dc:"分页大小"`
	CourseName string `json:"course_name" dc:"课程名称"`
	TeacherID  int64  `json:"teacher_id" dc:"教师ID"`
	Status     int32  `json:"status" v:"in:0,1,2#课程状态不合法" dc:"状态"`
}

// ListRes 分页查询课程响应。
type ListRes struct {
	List  []model.Course `json:"list" dc:"课程列表"`
	Total int            `json:"total" dc:"总数"`
}

// UpdateReq 修改课程请求。
type UpdateReq struct {
	g.Meta      `path:"/api/v1/courses/{id}" method:"put" tags:"课程" summary:"修改课程信息"`
	ID          int64   `json:"id" in:"path" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
	CourseName  string  `json:"course_name" v:"required|length:1,128#请输入课程名称|课程名称长度不能超过128位" dc:"课程名称"`
	TeacherID   int64   `json:"teacher_id" v:"required|min:1#请输入教师ID|教师ID必须大于0" dc:"教师ID"`
	TeacherName string  `json:"teacher_name" v:"required|length:1,64#请输入教师姓名|教师姓名长度不能超过64位" dc:"教师姓名"`
	Credit      float64 `json:"credit" v:"required|min:0.5#请输入学分|学分必须大于0" dc:"学分"`
	Capacity    int32   `json:"capacity" v:"required|min:1#请输入课程容量|课程容量必须大于0" dc:"容量"`
}

// UpdateRes 修改课程响应。
type UpdateRes struct{}

// UpdateStatusReq 修改课程状态请求。
type UpdateStatusReq struct {
	g.Meta `path:"/api/v1/courses/{id}/status" method:"patch" tags:"课程" summary:"修改课程状态"`
	ID     int64 `json:"id" in:"path" v:"required|min:1#请输入课程ID|课程ID必须大于0" dc:"课程ID"`
	Status int32 `json:"status" v:"required|in:1,2#请输入课程状态|课程状态不合法" dc:"状态"`
}

// UpdateStatusRes 修改课程状态响应。
type UpdateStatusRes struct{}
