# WebRTC 推流前音频效果接入说明

本 demo 的 H5 端已经把音频效果插在 `getUserMedia()` 和 `RTCPeerConnection.addTrack()` 之间：原始麦克风只作为输入，真正发布给 WebRTC 的是 Web Audio 处理后的 `MediaStreamTrack`。

## H5 客户端

入口在 `public/app.js`：

- `state.rawLocalStream` 保存摄像头和麦克风原始采集流。
- `state.localStream` 是 WebRTC 发布流，里面的视频轨道来自原始采集，音频轨道来自音效处理链。
- `applyAudioEffects()` 会在入会前创建发布音轨，也会在会议中切换音效时通过 `RTCRtpSender.replaceTrack()` 热替换音轨。
- `VOICE_EFFECT_PRESETS`、`REVERB_PRESETS`、`BEAUTY_PRESETS` 分别维护变声、混响、美声参数。

当前 H5 效果链：

- 变声：基于短窗调制延迟做近实时音高偏移，并叠加 EQ、失真、颤音或短回声。
- 混响：使用 `ConvolverNode` 和合成 impulse response 模拟演唱会、KTV、录音棚、浴室空间。
- 美声：使用高通、低频搁架、高频搁架、动态压缩器做低频和高频增益。

这套实现适合 demo 和轻量产品验证。若要达到商业直播变声质量，建议把音高移动替换为 AudioWorklet + WSOLA/phase vocoder，或接入成熟 DSP/音频 SDK。

## Android 客户端

当前 Android 端使用：

```kotlin
val audioDeviceModule = JavaAudioDeviceModule.builder(applicationContext).createAudioDeviceModule()
peerFactory = PeerConnectionFactory.builder()
    .setAudioDeviceModule(audioDeviceModule)
    .createPeerConnectionFactory()
```

这个接法由 libwebrtc 的 `JavaAudioDeviceModule` 内部负责 `AudioRecord -> WebRTC native audio transport`。它暴露的 `SamplesReadyCallback` 只能观察采集样本，不能把处理后的 PCM 返回给 WebRTC，因此不能用它实现真正的“推流前变声”。

Android 要实现与 H5 同级别的推流前处理，需要把音频管线改为：

```text
AudioRecord
  -> PCM frame 10ms/20ms
  -> VoiceEffectProcessor
       -> pitch/formant/reverb/EQ/AGC limiter
  -> custom AudioDeviceModule
  -> PeerConnectionFactory
  -> WebRTC publish
```

建议落地点：

- 新增 `VoiceEffectProfile`：复用 H5 的 `voice/reverb/beauty/lowGain/highGain` 五类参数，保证 H5 和 Android 控件语义一致。
- 新增 native 或独立 Kotlin/NDK DSP 层 `VoiceEffectProcessor`：输入 16-bit PCM，输出同采样率、同声道数 PCM。
- 替换默认 `JavaAudioDeviceModule`：实现自定义 `AudioDeviceModule`，或 fork 当前 WebRTC SDK 的 `WebRtcAudioRecord` 采集实现，在调用 native transport 之前写入处理后的 direct buffer。
- 优先使用 48 kHz、mono、10 ms frame，处理耗时控制在 3 ms 内，最终输出前加 limiter 防止怪兽声、卡通声等预设削波。

不建议只在 `AudioTrack`、扬声器播放端或远端接收端加效果，因为那不会改变推给 SFU/其他参会者的音频。
