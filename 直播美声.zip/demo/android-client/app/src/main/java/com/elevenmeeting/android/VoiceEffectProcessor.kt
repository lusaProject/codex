package com.elevenmeeting.android

import org.webrtc.ExternalAudioProcessingFactory
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

data class VoiceEffectOption(val key: String, val label: String) {
    override fun toString(): String = label
}

data class VoiceEffectSettings(
    val voice: String = "none",
    val reverb: String = "none",
    val beauty: String = "none",
    val lowGain: Int = 0,
    val highGain: Int = 0,
) {
    fun isEnabled(): Boolean {
        return voice != "none" || reverb != "none" || beauty != "none" || lowGain != 0 || highGain != 0
    }
}

object VoiceEffectCatalog {
    val voiceOptions = listOf(
        VoiceEffectOption("none", "原声"),
        VoiceEffectOption("female", "女声"),
        VoiceEffectOption("child", "童声"),
        VoiceEffectOption("elder", "老人声"),
        VoiceEffectOption("cartoon", "卡通声"),
        VoiceEffectOption("monster", "怪兽声"),
    )

    val reverbOptions = listOf(
        VoiceEffectOption("none", "无混响"),
        VoiceEffectOption("concert", "演唱会"),
        VoiceEffectOption("ktv", "KTV"),
        VoiceEffectOption("studio", "录音棚"),
        VoiceEffectOption("bathroom", "浴室"),
    )

    val beautyOptions = listOf(
        VoiceEffectOption("none", "自然"),
        VoiceEffectOption("warm", "浑厚"),
        VoiceEffectOption("clear", "通透"),
        VoiceEffectOption("thin", "变薄"),
    )

    fun summary(settings: VoiceEffectSettings): String {
        val voice = labelFor(voiceOptions, settings.voice)
        val reverb = labelFor(reverbOptions, settings.reverb)
        val beauty = labelFor(beautyOptions, settings.beauty)
        return "$voice / $reverb / $beauty / 低频 ${formatDb(settings.lowGain)} / 高频 ${formatDb(settings.highGain)}"
    }

    fun formatDb(value: Int): String = "${if (value > 0) "+" else ""}$value dB"

    private fun labelFor(options: List<VoiceEffectOption>, key: String): String {
        return options.firstOrNull { it.key == key }?.label ?: options.first().label
    }
}

class VoiceEffectProcessor : ExternalAudioProcessingFactory.AudioProcessing {
    @Volatile
    private var requestedSettings = VoiceEffectSettings()

    private var activeSettings = VoiceEffectSettings()
    private var sampleRate = DEFAULT_SAMPLE_RATE
    private var channelCount = DEFAULT_CHANNEL_COUNT
    private var filterStages = emptyList<BiquadFilter>()
    private var pitchShifter = PitchShifter(sampleRate, channelCount)
    private var echo = EchoDelay(sampleRate, channelCount)
    private var reverb = SimpleReverb(sampleRate, channelCount)
    private var compressor = Compressor(sampleRate, channelCount)

    fun updateSettings(settings: VoiceEffectSettings) {
        requestedSettings = settings
    }

    override fun initialize(sampleRateHz: Int, numChannels: Int) {
        sampleRate = sampleRateHz.takeIf { it > 0 } ?: DEFAULT_SAMPLE_RATE
        channelCount = numChannels.takeIf { it > 0 } ?: DEFAULT_CHANNEL_COUNT
        rebuildGraph()
    }

    override fun reset(newRate: Int) {
        sampleRate = newRate.takeIf { it > 0 } ?: sampleRate
        rebuildGraph()
    }

    override fun process(numBands: Int, numFrames: Int, buffer: ByteBuffer?) {
        val audioBuffer = buffer ?: return
        if (!requestedSettings.isEnabled()) {
            return
        }
        if (requestedSettings != activeSettings) {
            rebuildGraph()
        }

        val originalOrder = audioBuffer.order()
        audioBuffer.order(ByteOrder.nativeOrder())
        try {
            processFloatBuffer(numBands, numFrames, audioBuffer)
                ?: processShortBuffer(numBands, numFrames, audioBuffer)
        } finally {
            audioBuffer.order(originalOrder)
        }
    }

    private fun rebuildGraph() {
        activeSettings = requestedSettings
        pitchShifter = PitchShifter(sampleRate, channelCount).apply {
            configure(voicePreset(activeSettings.voice).pitchSemitones)
        }
        echo = EchoDelay(sampleRate, channelCount).apply {
            configure(voicePreset(activeSettings.voice).echo)
        }
        reverb = SimpleReverb(sampleRate, channelCount).apply {
            configure(reverbPreset(activeSettings.reverb))
        }
        compressor = Compressor(sampleRate, channelCount)
        filterStages = buildFilters(activeSettings)
    }

    private fun processFloatBuffer(numBands: Int, numFrames: Int, buffer: ByteBuffer): Unit? {
        val start = buffer.position()
        val byteCount = buffer.limit() - start
        val sampleCount = byteCount / FLOAT_BYTES
        if (byteCount % FLOAT_BYTES != 0 || sampleCount !in sampleCountCandidates(numBands, numFrames)) {
            return null
        }

        processSamples(sampleCount) { index, channel ->
            val offset = start + index * FLOAT_BYTES
            val processed = processSample(buffer.getFloat(offset), channel)
            buffer.putFloat(offset, processed)
        }
        return Unit
    }

    private fun processShortBuffer(numBands: Int, numFrames: Int, buffer: ByteBuffer) {
        val start = buffer.position()
        val byteCount = buffer.limit() - start
        val sampleCount = byteCount / SHORT_BYTES
        if (byteCount % SHORT_BYTES != 0 || sampleCount !in sampleCountCandidates(numBands, numFrames)) {
            return
        }

        processSamples(sampleCount) { index, channel ->
            val offset = start + index * SHORT_BYTES
            val sample = buffer.getShort(offset) / SHORT_SCALE
            val processed = processSample(sample, channel)
            buffer.putShort(offset, (processed.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort())
        }
    }

    private inline fun processSamples(sampleCount: Int, writeSample: (index: Int, channel: Int) -> Unit) {
        val channels = channelCount.coerceAtLeast(1)
        var index = 0
        while (index < sampleCount) {
            for (channel in 0 until channels) {
                if (index >= sampleCount) {
                    break
                }
                writeSample(index, channel)
                index += 1
            }
            pitchShifter.advance()
            echo.advance()
            reverb.advance()
        }
    }

    private fun processSample(input: Float, channel: Int): Float {
        var sample = input.coerceIn(-1f, 1f)
        sample = pitchShifter.process(sample, channel)
        filterStages.forEach { stage ->
            sample = stage.process(sample, channel)
        }
        sample = applyDistortion(sample, voicePreset(activeSettings.voice).distortion)
        sample = applyTremolo(sample, voicePreset(activeSettings.voice).tremolo)
        sample = echo.process(sample, channel)
        sample = reverb.process(sample, channel)
        sample = compressor.process(sample, channel)
        return softLimit(sample)
    }

    private fun sampleCountCandidates(numBands: Int, numFrames: Int): Set<Int> {
        val bands = numBands.takeIf { it > 0 } ?: 1
        val frames = numFrames.takeIf { it > 0 } ?: 1
        val channels = channelCount.coerceAtLeast(1)
        return setOf(frames, frames * channels, frames * bands, frames * bands * channels)
    }

    private fun buildFilters(settings: VoiceEffectSettings): List<BiquadFilter> {
        val voice = voicePreset(settings.voice)
        val beauty = beautyPreset(settings.beauty)
        val filters = mutableListOf<BiquadFilter>()

        voice.highpass?.let { filters += BiquadFilter.highPass(sampleRate, channelCount, it, 0.72) }
        voice.lowpass?.let { filters += BiquadFilter.lowPass(sampleRate, channelCount, it, 0.72) }
        voice.lowShelf?.let { filters += BiquadFilter.lowShelf(sampleRate, channelCount, 180.0, it, 0.7) }
        voice.highShelf?.let { filters += BiquadFilter.highShelf(sampleRate, channelCount, 3600.0, it, 0.7) }
        voice.peaking?.let { filters += BiquadFilter.peaking(sampleRate, channelCount, it.frequency, it.gain, it.q) }

        filters += BiquadFilter.highPass(sampleRate, channelCount, beauty.highpass, 0.72)
        filters += BiquadFilter.lowShelf(
            sampleRate = sampleRate,
            channels = channelCount,
            frequency = 170.0,
            gainDb = settings.lowGain.toDouble() + beauty.lowGain,
            slope = 0.7,
        )
        filters += BiquadFilter.peaking(sampleRate, channelCount, 850.0, beauty.midGain, 0.8)
        filters += BiquadFilter.highShelf(
            sampleRate = sampleRate,
            channels = channelCount,
            frequency = 4200.0,
            gainDb = settings.highGain.toDouble() + beauty.highGain,
            slope = 0.7,
        )
        return filters
    }

    private fun applyDistortion(sample: Float, amount: Double?): Float {
        amount ?: return sample
        val drive = 1.0 + amount / 18.0
        return (tanh(sample * drive) / tanh(drive)).toFloat()
    }

    private fun applyTremolo(sample: Float, tremolo: TremoloPreset?): Float {
        tremolo ?: return sample
        val phase = tremoloPhase
        tremoloPhase = (tremoloPhase + TWO_PI * tremolo.frequency / sampleRate).wrapPhase()
        val gain = 1.0 - tremolo.depth + tremolo.depth * (0.5 + 0.5 * sin(phase))
        return (sample * gain).toFloat()
    }

    private var tremoloPhase = 0.0

    private fun voicePreset(key: String): VoicePreset {
        return VOICE_PRESETS[key] ?: VOICE_PRESETS.getValue("none")
    }

    private fun reverbPreset(key: String): ReverbPreset {
        return REVERB_PRESETS[key] ?: REVERB_PRESETS.getValue("none")
    }

    private fun beautyPreset(key: String): BeautyPreset {
        return BEAUTY_PRESETS[key] ?: BEAUTY_PRESETS.getValue("none")
    }

    private data class VoicePreset(
        val pitchSemitones: Double = 0.0,
        val highpass: Double? = null,
        val lowpass: Double? = null,
        val lowShelf: Double? = null,
        val highShelf: Double? = null,
        val peaking: PeakingPreset? = null,
        val distortion: Double? = null,
        val tremolo: TremoloPreset? = null,
        val echo: EchoPreset? = null,
    )

    private data class PeakingPreset(val frequency: Double, val gain: Double, val q: Double)
    private data class TremoloPreset(val frequency: Double, val depth: Double)
    private data class EchoPreset(val delaySeconds: Double, val feedback: Double, val wet: Double)
    private data class ReverbPreset(val seconds: Double, val decay: Double, val wet: Double)
    private data class BeautyPreset(
        val lowGain: Double = 0.0,
        val highGain: Double = 0.0,
        val highpass: Double = 75.0,
        val midGain: Double = 0.0,
    )

    private class PitchShifter(private val sampleRate: Int, private val channels: Int) {
        private val ringSize = max(sampleRate / 2, 1)
        private val history = Array(channels.coerceAtLeast(1)) { FloatArray(ringSize) }
        private var writeIndex = 0
        private var framePosition = 0L
        private var ratio = 1.0
        private var sweepSamples = 0.0
        private var grainSamples = max((sampleRate * 0.1).toInt(), 1)

        fun configure(semitones: Double) {
            ratio = 2.0.pow(semitones / 12.0)
            val sweepSeconds = min(0.075, max(0.008, abs(ratio - 1.0) * 0.1))
            sweepSamples = sweepSeconds * sampleRate
            grainSamples = max((sampleRate * 0.1).toInt(), 1)
        }

        fun process(input: Float, channel: Int): Float {
            if (abs(ratio - 1.0) < 0.015) {
                history[channel][writeIndex] = input
                return input
            }

            history[channel][writeIndex] = input
            val phase = (framePosition % grainSamples).toDouble() / grainSamples
            val first = pitchTap(channel, phase)
            val second = pitchTap(channel, (phase + 0.5) % 1.0)
            val gainSum = first.second + second.second
            return if (gainSum > 0.0001) {
                ((first.first + second.first) / gainSum).toFloat()
            } else {
                input
            }
        }

        fun advance() {
            writeIndex = (writeIndex + 1) % ringSize
            framePosition += 1
        }

        private fun pitchTap(channel: Int, phase: Double): Pair<Double, Double> {
            val pitchUp = ratio > 1.0
            val delay = if (pitchUp) sweepSamples * (1.0 - phase) else sweepSamples * phase
            val gain = max(0.0, 1.0 - abs(phase - 0.5) * 2.0)
            return readDelay(channel, delay) * gain to gain
        }

        private fun readDelay(channel: Int, delaySamples: Double): Double {
            val read = writeIndex - delaySamples
            val base = floorIndex(read, ringSize)
            val next = (base + 1) % ringSize
            val fraction = read - kotlin.math.floor(read)
            return history[channel][base].toDouble() * (1.0 - fraction) +
                history[channel][next].toDouble() * fraction
        }
    }

    private class EchoDelay(private val sampleRate: Int, private val channels: Int) {
        private val ringSize = max((sampleRate * 0.5).toInt(), 1)
        private val history = Array(channels.coerceAtLeast(1)) { FloatArray(ringSize) }
        private var writeIndex = 0
        private var delaySamples = 0
        private var feedback = 0.0
        private var wet = 0.0

        fun configure(preset: EchoPreset?) {
            if (preset == null) {
                delaySamples = 0
                feedback = 0.0
                wet = 0.0
                return
            }
            delaySamples = (preset.delaySeconds * sampleRate).toInt().coerceIn(1, ringSize - 1)
            feedback = preset.feedback.coerceIn(0.0, 0.85)
            wet = preset.wet.coerceIn(0.0, 0.75)
        }

        fun process(input: Float, channel: Int): Float {
            if (wet <= 0.0 || delaySamples <= 0) {
                return input
            }
            val readIndex = floorIndex((writeIndex - delaySamples).toDouble(), ringSize)
            val delayed = history[channel][readIndex]
            history[channel][writeIndex] = (input.toDouble() + delayed.toDouble() * feedback)
                .toFloat()
                .coerceIn(-1f, 1f)
            return (input.toDouble() + delayed.toDouble() * wet).toFloat()
        }

        fun advance() {
            writeIndex = (writeIndex + 1) % ringSize
        }
    }

    private class SimpleReverb(private val sampleRate: Int, private val channels: Int) {
        private val combs = listOf(0.0297, 0.0371, 0.0411, 0.0437).map { delaySeconds ->
            CombDelay(sampleRate, channels, delaySeconds)
        }
        private var wet = 0.0
        private var feedback = 0.0

        fun configure(preset: ReverbPreset) {
            wet = preset.wet.coerceIn(0.0, 0.65)
            feedback = if (wet <= 0.0) {
                0.0
            } else {
                (0.32 + preset.seconds * 0.12 + preset.decay * 0.08).coerceIn(0.35, 0.82)
            }
            combs.forEachIndexed { index, comb ->
                val spread = 1.0 + index * 0.11 + preset.seconds * 0.05
                comb.configure(feedback, spread)
            }
        }

        fun process(input: Float, channel: Int): Float {
            if (wet <= 0.0) {
                return input
            }
            var sum = 0.0
            combs.forEach { comb -> sum += comb.process(input, channel) }
            return input + (sum / combs.size * wet).toFloat()
        }

        fun advance() {
            combs.forEach { it.advance() }
        }
    }

    private class CombDelay(sampleRate: Int, private val channels: Int, baseDelaySeconds: Double) {
        private val maxSize = max((sampleRate * 0.16).toInt(), 1)
        private val baseDelay = max((sampleRate * baseDelaySeconds).toInt(), 1)
        private val history = Array(channels.coerceAtLeast(1)) { FloatArray(maxSize) }
        private var writeIndex = 0
        private var delaySamples = baseDelay.coerceAtMost(maxSize - 1)
        private var feedback = 0.0

        fun configure(feedback: Double, spread: Double) {
            this.feedback = feedback
            delaySamples = (baseDelay * spread).toInt().coerceIn(1, maxSize - 1)
        }

        fun process(input: Float, channel: Int): Float {
            val readIndex = floorIndex((writeIndex - delaySamples).toDouble(), maxSize)
            val delayed = history[channel][readIndex]
            history[channel][writeIndex] = (input.toDouble() + delayed.toDouble() * feedback)
                .toFloat()
                .coerceIn(-1f, 1f)
            return delayed
        }

        fun advance() {
            writeIndex = (writeIndex + 1) % maxSize
        }
    }

    private class Compressor(sampleRate: Int, channels: Int) {
        private val envelope = FloatArray(channels.coerceAtLeast(1))
        private val threshold = 10.0.pow(-20.0 / 20.0).toFloat()
        private val ratio = 2.4f
        private val attackCoeff = exp(-1.0 / (sampleRate * 0.006)).toFloat()
        private val releaseCoeff = exp(-1.0 / (sampleRate * 0.18)).toFloat()

        fun process(input: Float, channel: Int): Float {
            val level = abs(input)
            val coeff = if (level > envelope[channel]) attackCoeff else releaseCoeff
            envelope[channel] = coeff * envelope[channel] + (1f - coeff) * level
            if (envelope[channel] <= threshold) {
                return input
            }
            val over = envelope[channel] / threshold
            val gain = over.toDouble().pow(1.0 / ratio - 1.0).toFloat()
            return input * gain
        }
    }

    private class BiquadFilter(
        private val channels: Int,
        private val b0: Double,
        private val b1: Double,
        private val b2: Double,
        private val a1: Double,
        private val a2: Double,
    ) {
        private val x1 = DoubleArray(channels.coerceAtLeast(1))
        private val x2 = DoubleArray(channels.coerceAtLeast(1))
        private val y1 = DoubleArray(channels.coerceAtLeast(1))
        private val y2 = DoubleArray(channels.coerceAtLeast(1))

        fun process(input: Float, channel: Int): Float {
            val x = input.toDouble()
            val y = b0 * x + b1 * x1[channel] + b2 * x2[channel] - a1 * y1[channel] - a2 * y2[channel]
            x2[channel] = x1[channel]
            x1[channel] = x
            y2[channel] = y1[channel]
            y1[channel] = y
            return y.toFloat()
        }

        companion object {
            fun lowPass(sampleRate: Int, channels: Int, frequency: Double, q: Double): BiquadFilter {
                val params = commonParams(sampleRate, frequency, q)
                val b0 = (1.0 - params.cosW0) / 2.0
                val b1 = 1.0 - params.cosW0
                val b2 = (1.0 - params.cosW0) / 2.0
                val a0 = 1.0 + params.alpha
                val a1 = -2.0 * params.cosW0
                val a2 = 1.0 - params.alpha
                return normalized(channels, b0, b1, b2, a0, a1, a2)
            }

            fun highPass(sampleRate: Int, channels: Int, frequency: Double, q: Double): BiquadFilter {
                val params = commonParams(sampleRate, frequency, q)
                val b0 = (1.0 + params.cosW0) / 2.0
                val b1 = -(1.0 + params.cosW0)
                val b2 = (1.0 + params.cosW0) / 2.0
                val a0 = 1.0 + params.alpha
                val a1 = -2.0 * params.cosW0
                val a2 = 1.0 - params.alpha
                return normalized(channels, b0, b1, b2, a0, a1, a2)
            }

            fun peaking(sampleRate: Int, channels: Int, frequency: Double, gainDb: Double, q: Double): BiquadFilter {
                if (abs(gainDb) < 0.01) {
                    return bypass(channels)
                }
                val params = commonParams(sampleRate, frequency, q)
                val amp = 10.0.pow(gainDb / 40.0)
                val b0 = 1.0 + params.alpha * amp
                val b1 = -2.0 * params.cosW0
                val b2 = 1.0 - params.alpha * amp
                val a0 = 1.0 + params.alpha / amp
                val a1 = -2.0 * params.cosW0
                val a2 = 1.0 - params.alpha / amp
                return normalized(channels, b0, b1, b2, a0, a1, a2)
            }

            fun lowShelf(
                sampleRate: Int,
                channels: Int,
                frequency: Double,
                gainDb: Double,
                slope: Double,
            ): BiquadFilter {
                return shelf(sampleRate, channels, frequency, gainDb, slope, low = true)
            }

            fun highShelf(
                sampleRate: Int,
                channels: Int,
                frequency: Double,
                gainDb: Double,
                slope: Double,
            ): BiquadFilter {
                return shelf(sampleRate, channels, frequency, gainDb, slope, low = false)
            }

            private fun shelf(
                sampleRate: Int,
                channels: Int,
                frequency: Double,
                gainDb: Double,
                slope: Double,
                low: Boolean,
            ): BiquadFilter {
                if (abs(gainDb) < 0.01) {
                    return bypass(channels)
                }
                val clampedFrequency = frequency.coerceIn(20.0, sampleRate * 0.45)
                val amp = 10.0.pow(gainDb / 40.0)
                val w0 = TWO_PI * clampedFrequency / sampleRate
                val cosW0 = cos(w0)
                val sinW0 = sin(w0)
                val shelfSlope = slope.coerceIn(0.1, 1.0)
                val alpha = sinW0 / 2.0 * sqrt((amp + 1.0 / amp) * (1.0 / shelfSlope - 1.0) + 2.0)
                val sqrtAmp = sqrt(amp)

                val b0: Double
                val b1: Double
                val b2: Double
                val a0: Double
                val a1: Double
                val a2: Double
                if (low) {
                    b0 = amp * ((amp + 1) - (amp - 1) * cosW0 + 2 * sqrtAmp * alpha)
                    b1 = 2 * amp * ((amp - 1) - (amp + 1) * cosW0)
                    b2 = amp * ((amp + 1) - (amp - 1) * cosW0 - 2 * sqrtAmp * alpha)
                    a0 = (amp + 1) + (amp - 1) * cosW0 + 2 * sqrtAmp * alpha
                    a1 = -2 * ((amp - 1) + (amp + 1) * cosW0)
                    a2 = (amp + 1) + (amp - 1) * cosW0 - 2 * sqrtAmp * alpha
                } else {
                    b0 = amp * ((amp + 1) + (amp - 1) * cosW0 + 2 * sqrtAmp * alpha)
                    b1 = -2 * amp * ((amp - 1) + (amp + 1) * cosW0)
                    b2 = amp * ((amp + 1) + (amp - 1) * cosW0 - 2 * sqrtAmp * alpha)
                    a0 = (amp + 1) - (amp - 1) * cosW0 + 2 * sqrtAmp * alpha
                    a1 = 2 * ((amp - 1) - (amp + 1) * cosW0)
                    a2 = (amp + 1) - (amp - 1) * cosW0 - 2 * sqrtAmp * alpha
                }
                return normalized(channels, b0, b1, b2, a0, a1, a2)
            }

            private fun commonParams(sampleRate: Int, frequency: Double, q: Double): CommonParams {
                val clampedFrequency = frequency.coerceIn(20.0, sampleRate * 0.45)
                val w0 = TWO_PI * clampedFrequency / sampleRate
                val alpha = sin(w0) / (2.0 * q.coerceAtLeast(0.1))
                return CommonParams(cos(w0), alpha)
            }

            private fun normalized(
                channels: Int,
                b0: Double,
                b1: Double,
                b2: Double,
                a0: Double,
                a1: Double,
                a2: Double,
            ): BiquadFilter {
                return BiquadFilter(channels, b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }

            private fun bypass(channels: Int): BiquadFilter {
                return BiquadFilter(channels, 1.0, 0.0, 0.0, 0.0, 0.0)
            }

            private data class CommonParams(val cosW0: Double, val alpha: Double)
        }
    }

    companion object {
        private const val DEFAULT_SAMPLE_RATE = 48000
        private const val DEFAULT_CHANNEL_COUNT = 1
        private const val FLOAT_BYTES = 4
        private const val SHORT_BYTES = 2
        private const val SHORT_SCALE = 32768f
        private const val TWO_PI = PI * 2.0

        private val VOICE_PRESETS = mapOf(
            "none" to VoicePreset(),
            "female" to VoicePreset(
                pitchSemitones = 5.0,
                highpass = 95.0,
                highShelf = 4.0,
                peaking = PeakingPreset(2600.0, 2.2, 0.9),
            ),
            "child" to VoicePreset(
                pitchSemitones = 9.0,
                highpass = 150.0,
                highShelf = 5.0,
                peaking = PeakingPreset(3200.0, 3.4, 1.1),
            ),
            "elder" to VoicePreset(
                pitchSemitones = -3.0,
                lowpass = 4300.0,
                lowShelf = 4.0,
                tremolo = TremoloPreset(5.5, 0.16),
            ),
            "cartoon" to VoicePreset(
                pitchSemitones = 7.0,
                highpass = 130.0,
                highShelf = 4.0,
                tremolo = TremoloPreset(13.0, 0.28),
                echo = EchoPreset(0.045, 0.18, 0.16),
            ),
            "monster" to VoicePreset(
                pitchSemitones = -7.0,
                lowpass = 2600.0,
                lowShelf = 6.0,
                distortion = 85.0,
                tremolo = TremoloPreset(38.0, 0.22),
            ),
        )

        private val REVERB_PRESETS = mapOf(
            "none" to ReverbPreset(0.0, 0.0, 0.0),
            "concert" to ReverbPreset(2.8, 2.6, 0.24),
            "ktv" to ReverbPreset(1.35, 1.8, 0.2),
            "studio" to ReverbPreset(0.48, 1.25, 0.09),
            "bathroom" to ReverbPreset(0.85, 0.72, 0.28),
        )

        private val BEAUTY_PRESETS = mapOf(
            "none" to BeautyPreset(lowGain = 0.0, highGain = 0.0, highpass = 75.0),
            "warm" to BeautyPreset(lowGain = 4.5, highGain = 1.0, highpass = 65.0),
            "clear" to BeautyPreset(lowGain = -1.0, highGain = 5.0, highpass = 95.0),
            "thin" to BeautyPreset(lowGain = -4.0, highGain = 2.5, highpass = 145.0),
        )

        private fun floorIndex(value: Double, size: Int): Int {
            val floored = kotlin.math.floor(value).toInt()
            val remainder = floored % size
            return if (remainder < 0) remainder + size else remainder
        }

        private fun Double.wrapPhase(): Double {
            return if (this >= TWO_PI) this - TWO_PI else this
        }

        private fun softLimit(sample: Float): Float {
            return (tanh(sample * 1.35f) / tanh(1.35f)).coerceIn(-0.98f, 0.98f)
        }
    }
}
