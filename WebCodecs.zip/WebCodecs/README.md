# WebCodecs Codec Matrix

本项目是一个本地 WebCodecs 编解码能力示例。页面结构、样式和逻辑都在 `index.html` 中：

- 使用 `VideoDecoder.isConfigSupported()` 检测注册的音频解码项：AV1、AVC/H.264、HEVC/H.265、VP8、VP9。
- 使用 `AudioDecoder.isConfigSupported()` 检测注册的音频解码项：AAC、MP3、Opus、Vorbis、FLAC、u-law、A-law、Linear PCM。
- 使用 `VideoEncoder.isConfigSupported()` 检测注册的视频编码项：AV1、AVC/H.264、HEVC/H.265、VP8、VP9。
- 使用 `AudioEncoder.isConfigSupported()` 检测注册的音频编码项：AAC、MP3、Opus、Vorbis、FLAC、u-law、A-law、Linear PCM。
- 保留原有 Annex B `.h265/.hevc/.265` 裸流播放器，使用 WebCodecs `VideoDecoder` 解码并绘制到 canvas。
- 支持输入自定义完整 codec 字符串，分别检测视频解码、音频解码、视频编码、音频编码。

## 运行

```bash
py -m http.server 5173 --bind 127.0.0.1
```

打开 `http://127.0.0.1:5173/`。页面会自动检测当前浏览器的音频/视频编解码配置，并尝试加载项目根目录下的 `output.h265` 播放；也可以手动选择本地 `.h265/.hevc/.265` 文件。

WebCodecs 需要 `localhost` 或 HTTPS 这类安全上下文。

## 说明

- 矩阵展示的是当前浏览器对具体 `AudioDecoderConfig`、`VideoDecoderConfig`、`AudioEncoderConfig`、`VideoEncoderConfig` 的支持结果，不代表所有 profile、level、bit depth、码率、分辨率的排列组合都支持。
- AV1、VP9、AVC/H.264、HEVC/H.265 这类带 profile/level 的 codec 可在自定义输入中继续测试更精确的字符串。
- AAC 编码测试使用注册项中的 `aac.format = "aac"`；H.264/H.265 编码测试使用注册项默认的 `avc` / `hevc` 输出格式。
- Vorbis 解码实际配置需要来自容器的 Xiph extradata，因此解码矩阵中标记为“需样本”；Vorbis 编码仍会直接查询 `AudioEncoder.isConfigSupported()`。
- H.265 播放器使用 `hardwareAcceleration: "prefer-hardware"`。WebCodecs 只能表达“硬解/硬编优先”，最终是否真的走硬件由浏览器、系统和显卡/驱动决定。
- 裸 `.h265` 文件没有容器时间戳，本示例按 25 fps 生成播放时间轴。
