# H5 HTTP-FLV Live Player

这个页面用于在浏览器里播放下面这路 HTTP-FLV 直播流：

```bash
ffplay http://172.20.173.132/live/test.live.flv
```

浏览器原生 `<video>` 通常不能直接解码 FLV，所以页面使用 `mpegts.js` 通过 Media Source Extensions 播放。

## 本地运行

```bash
python -m http.server 8080
```

然后打开：

```text
http://localhost:8080/
```

浏览器通常不允许页面一打开就自动有声播放。如果页面自动切成静音预览，点击播放器右侧的“开启声音”即可恢复音频。

## 服务端要求

如果 `ffplay` 能播但浏览器播不了，通常需要检查直播服务是否允许跨域访问。HTTP-FLV 服务建议返回类似响应头：

```nginx
add_header Access-Control-Allow-Origin *;
add_header Access-Control-Allow-Methods "GET, OPTIONS";
add_header Access-Control-Allow-Headers "*";
```

你当前的响应头显示服务端是 ZLMediaKit。ZLMediaKit 的配置文件里可以检查 `[http]` 段：

```ini
[http]
allow_cross_domains=1
```

页面不要部署在 HTTPS 域名下去拉 `http://` 流，否则浏览器可能会拦截混合内容。
